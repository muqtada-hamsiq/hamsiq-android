# Server-side media re-sign — deploy README (audit finding H-04 follow-up)

## What this is

DM / story / post media lives in the PRIVATE `private-media` bucket
behind 1-hour signed URLs. Stories live 24h and reels/posts live
indefinitely, so a stored URL opened after expiry 403s — unless the
render path re-signs it on demand.

Client-side re-signing (`createSignedUrl` as the signed-in user) only
fixes the UPLOADER's view: the bucket's SELECT policy is owner-only,
so a RECIPIENT cannot re-sign the sender's media. Media sent to
someone else stopped loading for them 1 hour after upload — and the
same applied to every migrated old-media row.

The Edge Function `resign-media`
(`supabase/functions/resign-media/index.ts`) closes that gap
server-side: it verifies, with the requester's own JWT, that the
requester can actually READ a row that references this media (Row
Level Security is the access check — the function never re-implements
the posts/stories/DM visibility rules), and only then mints a fresh
1-hour signed URL with the service_role key.

## Contract

```
POST /functions/v1/resign-media
Headers: Authorization: Bearer <user JWT>, apikey: <anon key>
Body:    { "bucket": "private-media", "path": "<owner-id>/<file>" }
```

| Status | Body | Meaning |
| ------ | ---- | ------- |
| 200 | `{"signedUrl": "<full https URL, valid 1h>"}` | Access check passed, fresh URL minted |
| 401 | `{"error": "Unauthorized"}` | No/invalid JWT |
| 400 | `{"error": "Invalid request"}` | Bad bucket/path (only `private-media`, no traversal, `<owner>/<file>` shape) |
| 403 | `{"error": "Access denied"}` | No row readable by the requester references this media (also covers "file does not exist" — the two are deliberately indistinguishable) |
| 500 | `{"error": "Server error"}` | Never leaks details |

Reference tables checked (as the requester, under RLS):
`messages.media_url`, `stories.media_url`, `posts.media_url`,
`post_drafts.media_url`, `cloud_files.file_url`. A missing
table/column on an older schema is logged and skipped, never fatal.

Security notes (also in `index.ts`):

- Only the `private-media` bucket is ever signed here. Public
  buckets (`avatars`, `chat-media`) never need re-signing.
- The path is validated and matched against stored URLs in their
  URL-encoded form, so odd filenames cannot smuggle a different
  object.
- No rate limit is enforced in the function: each call requires a
  valid session AND a readable row, and signing is a single cheap
  Storage call. The abuse surface is one signed URL per media the
  caller can already view.

## What deployment needs

1. **Supabase CLI** installed and logged in: `supabase login` (needs a
   Supabase **access token** — Dashboard → Account → Access Tokens).
2. **Project refs:**
   - Staging: `bkieprlxjjysnxbalvun` (project `hamsiq-staging`).
   - Production: `yjmqmkvefabiuxtbmetm` (project `muqtada-chat`).
3. **No secrets to set, no migration to apply.** The function reads
   `SUPABASE_URL`, `SUPABASE_ANON_KEY` and
   `SUPABASE_SERVICE_ROLE_KEY` from its environment; Supabase injects
   all three into Edge Functions automatically. Never put any key in
   the code or the repo. There is no new table — the access check
   reads the existing `messages` / `stories` / `posts` /
   `post_drafts` / `cloud_files` tables under RLS.
4. **Deploy to staging FIRST and verify there** (curl checks below),
   including the recipient case. Production deploy needs its own
   approval — this README does not authorise it.

## Deploy

```bash
# Staging (first):
supabase functions deploy resign-media --project-ref bkieprlxjjysnxbalvun

# Production (only with separate approval):
supabase functions deploy resign-media --project-ref yjmqmkvefabiuxtbmetm
```

## Verify with curl (staging first, then production)

`<USER_JWT>` is a real signed-in user's JWT (e.g. from a logged-in
session), `<ANON_KEY>` the project's public anon key. `<PATH>` is a
`private-media` object path, e.g. `<owner-id>/story-1731599999999.mp4`.

```bash
BASE=https://bkieprlxjjysnxbalvun.supabase.co/functions/v1/resign-media
# (production: https://yjmqmkvefabiuxtbmetm.supabase.co/functions/v1/resign-media)

# 1) Owner re-signs their own media — must be 200 with a signedUrl
#    that actually loads (curl it: must be 200, not 403).
curl -s -X POST "$BASE" \
  -H "Authorization: Bearer <USER_JWT>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"bucket":"private-media","path":"<PATH>"}'

# 2) RECIPIENT re-signs media sent to them (the case client-side
#    signing could not serve) — must ALSO be 200 with a working
#    signedUrl. Use the recipient's JWT and a DM/story/post media
#    path the recipient can see. This is the whole point of the
#    function: if this returns 403, the gap is not closed.
curl -s -X POST "$BASE" \
  -H "Authorization: Bearer <RECIPIENT_JWT>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"bucket":"private-media","path":"<PATH>"}'

# 3) Stranger re-signs media they cannot see — must be 403
#    {"error":"Access denied"} (use a third user's JWT).
curl -s -X POST "$BASE" \
  -H "Authorization: Bearer <STRANGER_JWT>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"bucket":"private-media","path":"<PATH>"}'

# 4) No JWT — must be 401 {"error":"Unauthorized"}.
curl -s -X POST "$BASE" \
  -H "apikey: <ANON_KEY>" -H "Content-Type: application/json" \
  -d '{"bucket":"private-media","path":"<PATH>"}'

# 5) Wrong bucket / bad path — must be 400 {"error":"Invalid request"}.
curl -s -X POST "$BASE" \
  -H "Authorization: Bearer <USER_JWT>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"bucket":"chat-media","path":"<PATH>"}'
curl -s -X POST "$BASE" \
  -H "Authorization: Bearer <USER_JWT>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"bucket":"private-media","path":"../etc/passwd"}'

# 6) Non-existent path — must be 403, IDENTICAL to (3): the caller
#    must not learn whether the file exists.
curl -s -X POST "$BASE" \
  -H "Authorization: Bearer <USER_JWT>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"bucket":"private-media","path":"no-such-user/no-such-file.jpg"}'
```

## Flutter side

`lib/services/media_api.dart` — `MediaApi.ensureFreshUrl` is the
single re-sign entry point for every render site:

1. **Primary:** `functions.invoke('resign-media', body:
   {'bucket', 'path'})` (the Supabase client attaches the user's
   JWT automatically). 200 with a `signedUrl` wins.
2. **Fallback:** direct Storage `createSignedUrl` (works for the
   uploader's own media; fails for recipients — which is why the
   function is tried first).
3. **Last resort:** the original URL unchanged — best-effort,
   rendering is never broken by a re-sign failure.

Only signed URLs that are expired or within the 5-minute
`resignMargin` are re-signed; fresh and public URLs make no call.
Test seams mirror `secure_login.dart`: `MediaResignInvoker` /
`MediaDirectSigner` (see `test/signed_media_test.dart` — 200,
403-fallback, malformed-body fallback, total-failure, fresh-URL
no-call, public-URL no-call, non-private-bucket cases).

Render sites wired (all through `ensureFreshUrl`, directly or via
the `SignedMediaImage` widget in `lib/widgets/common.dart`):

- **DMs (pre-existing):** image thumbnail, full-screen image/video
  viewers, voice bubble (re-sign before `play()`), view-once tile,
  shared-post card, story-reply thumbnail.
- **Stories:** viewer image + video (re-sign before creating the
  `VideoPlayerController`), highlight covers.
- **Reels:** current page + preloaded neighbours (re-sign before
  creating each controller), reel voiceover (re-sign before `play()`).
- **Blend:** shared-reels feed video (re-sign before creating the
  controller).
- **Posts/feed:** feed card, post detail, Discover grid.
- **Profile:** posts grid, reposts tab, grid-reorder list.
- **Collections:** collection tiles + detail grid.
- **Other stored-media renders:** drafts list + editor preview,
  insights top-post thumbnails, channel posts, collab-invite cards.

Deliberately NOT wired (no signed URL involved):

- **Avatars** (`AvatarWidget`) — public `chat-media` bucket, no
  signing, by design.
- **Comment GIFs** — public Giphy URLs (`curatedGifUrls`), not
  stored media.
- **Video tiles in feed / post detail / shared-post card** — static
  play-icon tiles, no URL is loaded (playback lives in the Reels tab).
- **Reels editor voiceover preview / camera previews** — local
  device files, not stored URLs.
- **`cloud_files.file_url`** — the function checks this table, but
  no native render site loads a `cloud_files` URL today; if one is
  added later it must go through `ensureFreshUrl` like the rest.

Async-safety note for the video sites: `_setupCurrent` (stories),
`_initController` / `_createPreloadController` (reels) and
`_initController` (Blend) are now `async` and re-sign before
creating the controller. Each carries a generation/page guard so a
re-sign that completes after the user swiped on is dropped instead
of overwriting the new page's controller. The H-07b preloaded
fast path is untouched: adopting an already-initialised neighbour
controller still happens synchronously, with no re-sign await in
the way (the neighbour was already re-signed when preloaded).
