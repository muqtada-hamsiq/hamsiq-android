# Secure login — deploy README (audit fix H-01)

## What this is

The old login called the `SECURITY DEFINER` RPC `get_email_by_username()`
(granted to `anon`) and received the account's email in the app — anyone
who knew a username could harvest the email without logging in.

The new flow is the Edge Function `secure-login`
(`supabase/functions/secure-login/index.ts`): it resolves
username → id via `public.profiles` with the service-role client, fetches
the email server-side with `auth.admin.getUserById()`, signs in server-side,
and returns **only** `{access_token, refresh_token, user: {id, username}}`.
The email never leaves the server. Every failure returns the **same**
generic body (`{"error": "Invalid username or password"}`); rate limiting
is signalled only by HTTP status `429`. Failed attempts (including for
usernames that do not exist) are logged in `public.login_attempts`
(`sql-v36.sql`) so a `429` does not leak account existence either.

Rate limits (also in `index.ts` and `lib/services/secure_login.dart`):
**5 failed attempts per username per 15 minutes, 10 per IP per 15 minutes.**

## What deployment needs

1. **Supabase CLI** installed (`npm i -g supabase` or the standalone
   binary) and logged in: `supabase login` (needs a Supabase **access
   token** — Dashboard → Account → Access Tokens).
2. **Project ref:** `yjmqmkvefabiuxtbmetm` (project `muqtada-chat`).
3. **No secrets to set.** The function reads `SUPABASE_URL`,
   `SUPABASE_ANON_KEY` and `SUPABASE_SERVICE_ROLE_KEY` from its
   environment; Supabase injects all three into Edge Functions
   automatically. Never put any key in the code or the repo.
4. **Apply `sql-v36.sql` FIRST** — paste it into the Supabase Dashboard →
   SQL Editor and run it (same as sql-v29..v31). It creates
   `public.login_attempts` (RLS enabled, **no policies** — only the
   service-role client can read/write it). The function cannot rate-limit
   without this table.
5. **Do NOT drop or alter `get_email_by_username()` yet.** It stays in the
   database untouched until the new flow is proven in staging; revoking it
   is a separate step with its own approval.

## Deploy

```bash
# from ~/workspace/hamsiq-native
bash supabase/deploy-secure-login.sh
# (or just: supabase functions deploy secure-login --project-ref yjmqmkvefabiuxtbmetm)
```

## Verify with curl (staging first, then production)

Replace `<ANON_KEY>` with the project's public anon key (the same one in
`lib/services/supabase_service.dart`).

```bash
BASE=https://yjmqmkvefabiuxtbmetm.supabase.co/functions/v1/secure-login

# 1) Unknown username — must be 401 with the generic body, no email.
curl -s -i -X POST "$BASE" \
  -H "Authorization: Bearer <ANON_KEY>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"username":"no-such-user-xyz","password":"wrongpass123"}'

# 2) Real username, wrong password — must return the IDENTICAL 401 body
#    as (1) (same status, same JSON, no hint the account exists).
curl -s -X POST "$BASE" \
  -H "Authorization: Bearer <ANON_KEY>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"username":"<real-username>","password":"wrongpass123"}'

# 3) Correct credentials — must be 200 with access_token + refresh_token
#    + user{id, username} and NO "email" key anywhere in the body.
curl -s -X POST "$BASE" \
  -H "Authorization: Bearer <ANON_KEY>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"username":"<real-username>","password":"<correct-password>"}'

# 4) Rate limit — 6 rapid failures for one username: the 6th must be 429
#    (body still the generic message). Wait 15 minutes, it works again.
for i in 1 2 3 4 5 6; do
  curl -s -o /dev/null -w "%{http_code}\n" -X POST "$BASE" \
    -H "Authorization: Bearer <ANON_KEY>" -H "apikey: <ANON_KEY>" \
    -H "Content-Type: application/json" \
    -d '{"username":"<rate-test-user>","password":"wrongpass123"}'
done

# 5) Old RPC untouched:
#    In the SQL Editor: select proname from pg_proc where proname =
#    'get_email_by_username';  → must still return 1 row.
```

## check-username — closing the remaining H-01 exposure (signup)

The signup flow used to check whether a username was taken by calling
`get_email_by_username()` directly — the same RPC that leaks the taken
account's email to an anonymous caller. That call is now gone from
`lib/screens/auth_screen.dart`: signup calls the second Edge Function
`check-username` (`supabase/functions/check-username/index.ts`) instead.

Contract: `POST {username}` → **200 `{"available": true/false}` and
nothing else**. No email, no account data, ever. `false` covers both
"taken" and "invalid input" (empty, too short/long, illegal characters),
so the response never reveals why a name is unavailable. The lookup is
case-insensitive via `public.profiles` with the service-role client
(`select("id")` only — no email is even read). Rate limiting is
signalled only by HTTP status **429** (`{"error": "Too many requests"}`);
server errors are **500** (`{"error": "Service unavailable"}`) — the
client shows its generic error for any non-200 status and never lets
signup proceed on a malformed or email-bearing body (see
`parseUsernameAvailability` in `auth_screen.dart`).

Rate limit: **30 checks per client IP per 15 minutes** (also in
`auth_screen.dart` as `checkUsernameMaxPerIp`). It reuses
`public.login_attempts` (sql-v36.sql, no new table) with a sentinel row
(`username = "__check_username__"`, `success = true`) per check, so it
can never pollute the secure-login limits: secure-login counts only
`success = false` rows, and login successes (real username) never match
the sentinel. No per-username limit: username existence is already
revealed by the signup UX itself ("اسم المستخدم محجوز"), and the shared
table cannot tell a check of name X apart from a successful login of X.

Deploy (appended to `supabase/deploy-secure-login.sh`, same project ref,
no new secrets — only `SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY`,
both auto-injected):

```bash
supabase functions deploy check-username --project-ref yjmqmkvefabiuxtbmetm
```

Verify with curl (staging first, then production):

```bash
BASE=https://yjmqmkvefabiuxtbmetm.supabase.co/functions/v1/check-username

# 1) Free username — must be 200 {"available":true}, nothing else.
curl -s -X POST "$BASE" \
  -H "Authorization: Bearer <ANON_KEY>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"username":"definitely-free-name-xyz"}'

# 2) Taken username — must be 200 {"available":false}, IDENTICAL shape
#    to (1) apart from the boolean, and NO "email" key anywhere.
curl -s -X POST "$BASE" \
  -H "Authorization: Bearer <ANON_KEY>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"username":"<real-username>"}'

# 3) Invalid input — must be the same 200 {"available":false} as (2).
curl -s -X POST "$BASE" \
  -H "Authorization: Bearer <ANON_KEY>" -H "apikey: <ANON_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"username":""}'

# 4) Rate limit — 31 rapid checks from one IP: the 31st must be 429.
for i in $(seq 1 31); do
  curl -s -o /dev/null -w "%{http_code}\n" -X POST "$BASE" \
    -H "Authorization: Bearer <ANON_KEY>" -H "apikey: <ANON_KEY>" \
    -H "Content-Type: application/json" \
    -d '{"username":"rate-test-user"}'
done

# 5) Signup end-to-end still works: free name → OTP step; taken name →
#    "اسم المستخدم محجوز"; 429 → "محاولات كثيرة، انتظر 15 دقيقة".
```

## Flutter side

`lib/services/secure_login.dart` calls `functions.invoke('secure-login', …)`
and applies the session with `client.auth.setSession(...)`;
`lib/screens/auth_screen.dart` login now uses it. The login path contains
no email anywhere. The **signup** availability check no longer calls
`get_email_by_username` either — it calls the `check-username` function
(see the section above); the only remaining caller of that RPC in the
app is the now-unused `Api.loginWithUsername` in `supabase_service.dart`,
which must only be deleted once staging proves the new flows. The RPC
itself stays in the database untouched until then (see step 5 above).
