#!/usr/bin/env bash
# Hamsiq audit fix H-01 — deploy the secure-login Edge Function.
# DO NOT RUN until sql-v36.sql has been applied (see the README next to
# this script). This script only deploys; it changes nothing locally.
set -euo pipefail

# Deploy from the project root (this script lives in supabase/).
cd "$(dirname "$0")/.."

# 1) Apply the migration FIRST, in the Supabase Dashboard -> SQL Editor:
#      sql-v36.sql   (creates public.login_attempts; RLS on, no policies)
#    The function cannot rate-limit without that table.
#    There is no `supabase db push` step here: this project applies SQL
#    by pasting the file into the SQL Editor, like sql-v29..v31.

# 2) Deploy the function (needs: Supabase CLI installed + `supabase login`
#    with an access token that can deploy to this project).
supabase functions deploy secure-login --project-ref yjmqmkvefabiuxtbmetm

# 2b) Deploy the check-username function (H-01 part 2 — closes the
#     remaining signup availability exposure; see the "check-username"
#     section in supabase/secure-login-README.md). Same project, same
#     prerequisites; sql-v36.sql (public.login_attempts) must already be
#     applied — no new table is needed.
supabase functions deploy check-username --project-ref yjmqmkvefabiuxtbmetm

# 3) Verify with curl (see supabase/secure-login-README.md for the exact
#    commands): wrong username vs wrong password must return the IDENTICAL
#    401 body, a correct login must return tokens with NO email, and 6
#    rapid failures for one username must return 429.
