// Hamsiq — username availability check (audit finding H-01 fix, part 2).
//
// Closes the REMAINING H-01 exposure: the signup flow used to check
// whether a username was taken by calling the SECURITY DEFINER RPC
// get_email_by_username(), which returns the taken account's email to an
// anonymous caller. The signup flow now calls this function instead, and
// no longer calls that RPC anywhere.
//
// This function NEVER returns an email or any account data. It returns
// ONLY {"available": true/false} (HTTP 200) for every username input:
//   * available: true  — no profile has this username (case-insensitive).
//   * available: false — the username is taken, OR the input is invalid
//     (empty, too short/long, illegal characters). Taken and invalid are
//     deliberately indistinguishable, so the response never reveals why
//     a name is unavailable — and, unlike the old RPC, never reveals
//     anything about the account that holds the name.
//
// Rate limiting is signalled ONLY by the HTTP status (429); the body
// stays a generic {"error": "Too many requests"}. Every check is
// recorded in public.login_attempts (sql-v36.sql) so the limit can be
// counted — reusing the same table/approach as secure-login, but in a
// way that can NEVER pollute the login limits:
//   * rows are written with username = "__check_username__" (sentinel)
//     and success = true. secure-login counts only success = false
//     rows, so these rows are invisible to its per-username and per-IP
//     failure counts; and login successes (success = true, real
//     username) never match the sentinel, so they are invisible to this
//     function's own count.
//   * this function's limit counts ONLY sentinel rows for the caller IP
//     inside the window.
// Per-username limiting is deliberately NOT done here: username
// existence is already revealed by the signup UX itself (the app shows
// "اسم المستخدم محجوز"), and the shared table cannot distinguish a
// check of name X from a successful login of X. The IP limit's job is
// to slow mass enumeration from one client.
//
// Rate limit (must match lib/screens/auth_screen.dart):
//   - 30 availability checks per client IP per 15 minutes
//
// Environment (auto-provided by Supabase to Edge Functions — never hardcode
// any key here): SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const MAX_CHECKS_PER_IP = 30;
const WINDOW_MINUTES = 15;

// Sentinel username written into public.login_attempts for every
// availability check. See the header comment: it keeps these rows
// invisible to secure-login's failure counts.
const CHECK_USERNAME_SENTINEL = "__check_username__";

const CORS_HEADERS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function jsonResponse(body: unknown, status: number): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

/// The ONLY success body this function ever returns. `false` covers
/// both "taken" and "invalid input" — the caller cannot tell which.
function availabilityResponse(available: boolean): Response {
  return jsonResponse({ available }, 200);
}

function rateLimited(): Response {
  return jsonResponse({ error: "Too many requests" }, 429);
}

/// Client IP from the gateway headers (first entry of x-forwarded-for).
function clientIp(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) {
    const first = forwarded.split(",")[0]?.trim();
    if (first) return first;
  }
  return req.headers.get("x-real-ip")?.trim() || "unknown";
}

/// Escape LIKE wildcards so a username containing % or _ cannot match
/// other users when we do the case-insensitive lookup.
function escapeLike(value: string): string {
  return value.replace(/\\/g, "\\\\").replace(/%/g, "\\%").replace(/_/g, "\\_");
}

/// Same shape as the app's isValidUsername (lib/screens/auth_screen.dart):
/// letters, digits, _ . - and Arabic letters, min 3 chars. The app
/// validates before calling; this is defense in depth for direct API
/// callers — an invalid name is simply "not available", never an error
/// that distinguishes it from a taken name.
function isValidUsernameShape(username: string): boolean {
  return (
    username.length >= 3 &&
    username.length <= 64 &&
    /^[a-z0-9_.\u0600-\u06FF-]+$/.test(username)
  );
}

Deno.serve(async (req: Request): Promise<Response> => {
  // CORS preflight.
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  if (req.method !== "POST") {
    // Same body shape as every other answer; the status carries the
    // "wrong method" signal, nothing about any account.
    return availabilityResponse(false);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceRoleKey) {
    // Server misconfiguration: never leak details, and never claim a
    // name is available when we could not check — the client shows its
    // generic error for any non-200 status.
    console.error("check-username: missing Supabase env vars");
    return jsonResponse({ error: "Service unavailable" }, 500);
  }

  // Service-role client: bypasses RLS, used ONLY for the profiles
  // existence lookup and the login_attempts bookkeeping. It never talks
  // to the caller, and no account data it reads ever leaves the server.
  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    // Unparseable body: same shape as any other unavailable name.
    return availabilityResponse(false);
  }
  const usernameRaw =
    typeof body === "object" && body !== null
      ? (body as Record<string, unknown>)["username"]
      : undefined;
  const username =
    typeof usernameRaw === "string"
      ? usernameRaw.trim().toLowerCase()
      : "";
  // Invalid shape (empty, wrong type, too short/long, illegal chars):
  // indistinguishable from "taken" — same 200, same body.
  const shapeValid =
    typeof usernameRaw === "string" && isValidUsernameShape(username);

  const ip = clientIp(req);
  const windowStart = new Date(
    Date.now() - WINDOW_MINUTES * 60 * 1000,
  ).toISOString();

  // Rate limit FIRST, before any profile lookup (and before recording,
  // so a blocked client cannot extend its own window by retrying).
  // Counts only this function's own sentinel rows for this IP.
  const { count, error: countError } = await admin
    .from("login_attempts")
    .select("id", { count: "exact", head: true })
    .eq("username", CHECK_USERNAME_SENTINEL)
    .eq("ip", ip)
    .eq("success", true)
    .gte("attempted_at", windowStart);
  if (countError) {
    console.error("check-username: rate-limit lookup failed", countError);
    // Fail closed: if we cannot check the limit, do not let the check
    // through unchecked — the caller only sees the generic 429 body.
    return rateLimited();
  }
  if ((count ?? 0) >= MAX_CHECKS_PER_IP) {
    return rateLimited();
  }

  // Record the check (sentinel row, success = true — see header: this
  // keeps the row invisible to secure-login's failure counts). Recorded
  // even for invalid input, so probing with garbage also consumes quota.
  const { error: recordError } = await admin.from("login_attempts").insert({
    username: CHECK_USERNAME_SENTINEL,
    ip,
    success: true,
    attempted_at: new Date().toISOString(),
  });
  if (recordError) {
    console.error("check-username: recordAttempt failed", recordError);
  }

  if (!shapeValid) {
    return availabilityResponse(false);
  }

  // Existence check via public.profiles (service role bypasses RLS).
  // Case-insensitive, like the old RPC; wildcards escaped. Only the
  // profile id is selected — no email, no account data of any kind is
  // read, let alone returned.
  const { data: profile, error: profileError } = await admin
    .from("profiles")
    .select("id")
    .ilike("username", escapeLike(username))
    .maybeSingle();
  if (profileError) {
    console.error("check-username: profiles lookup failed", profileError);
    // Do not claim "available" when we could not check — the client
    // shows its generic error for any non-200 status.
    return jsonResponse({ error: "Service unavailable" }, 500);
  }

  return availabilityResponse(!profile);
});
