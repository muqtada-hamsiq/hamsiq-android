// Hamsiq — secure username login (audit finding H-01 fix).
//
// Replaces the old client-side login flow that called the SECURITY DEFINER
// RPC get_email_by_username() and received the account's email in the
// browser/app. That RPC is granted EXECUTE to anon, so anyone who knew a
// username could harvest the account's email without logging in. The old
// RPC is left untouched in the database until this flow is proven in
// staging (see supabase/secure-login-README.md); the Flutter app no longer
// calls it for login.
//
// This function NEVER returns an email to the caller. It:
//   1. resolves username -> user id via public.profiles with the
//      service-role client (bypasses RLS, email never leaves the server),
//   2. fetches the email server-side with auth.admin.getUserById(),
//   3. signs in with that email + password server-side (anon-key client),
//   4. returns ONLY the session tokens + minimal user info.
//
// Every failure returns the SAME generic error body, so the response never
// reveals whether the account exists, whether the username was found, or
// whether the password was wrong. Rate limiting is signalled ONLY by the
// HTTP status (429); the body stays the generic message. Failed attempts
// (including attempts for usernames that do not exist) are recorded in
// public.login_attempts (sql-v36.sql) so a 429 does not leak existence
// either.
//
// Rate limits (must match lib/services/secure_login.dart):
//   - 5 failed attempts per username per 15 minutes
//   - 10 failed attempts per client IP per 15 minutes
//
// Environment (auto-provided by Supabase to Edge Functions — never hardcode
// any key here): SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const GENERIC_ERROR = "Invalid username or password";

const MAX_FAILURES_PER_USER = 5;
const MAX_FAILURES_PER_IP = 10;
const WINDOW_MINUTES = 15;

const CORS_HEADERS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function jsonResponse(body: unknown, status: number): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

function genericFailure(status = 401): Response {
  return jsonResponse({ error: GENERIC_ERROR }, status);
}

/// Client IP from the gateway headers (first entry of x-forwarded-for).
function clientIp(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) {
    const first = forwarded.split(",")[0]?.trim();
    if (first) return first;
  }
  return req.headers.get("x-real-ip")?.trim() || "unknown";
}

/// Escape LIKE wildcards so a username containing % or _ cannot match
/// other users when we do the case-insensitive lookup.
function escapeLike(value: string): string {
  return value.replace(/\\/g, "\\\\").replace(/%/g, "\\%").replace(/_/g, "\\_");
}

Deno.serve(async (req: Request): Promise<Response> => {
  // CORS preflight.
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  if (req.method !== "POST") {
    return genericFailure(405);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  if (!supabaseUrl || !serviceRoleKey || !anonKey) {
    // Server misconfiguration: never leak details, same generic body.
    console.error("secure-login: missing Supabase env vars");
    return genericFailure(500);
  }

  // Service-role client: bypasses RLS, used ONLY for the profiles lookup,
  // the admin email fetch and the login_attempts bookkeeping. It never
  // talks to the caller.
  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  // Anon-key client: the password sign-in happens with a normal user
  // session, exactly as if the client had signed in itself.
  const anon = createClient(supabaseUrl, anonKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return genericFailure();
  }
  const usernameRaw =
    typeof body === "object" && body !== null
      ? (body as Record<string, unknown>)["username"]
      : undefined;
  const passwordRaw =
    typeof body === "object" && body !== null
      ? (body as Record<string, unknown>)["password"]
      : undefined;
  if (typeof usernameRaw !== "string" || typeof passwordRaw !== "string") {
    return genericFailure();
  }
  const username = usernameRaw.trim().toLowerCase();
  const password = passwordRaw;
  // Same validation shape as the app (usernames are stored lowercase,
  // min 3 chars); an invalid shape is indistinguishable from a wrong
  // password to the caller.
  if (username.length < 3 || username.length > 64 || password.length === 0) {
    return genericFailure();
  }

  const ip = clientIp(req);
  const windowStart = new Date(
    Date.now() - WINDOW_MINUTES * 60 * 1000,
  ).toISOString();

  async function recordAttempt(success: boolean): Promise<void> {
    const { error } = await admin.from("login_attempts").insert({
      username,
      ip,
      success,
      attempted_at: new Date().toISOString(),
    });
    if (error) console.error("secure-login: recordAttempt failed", error);
  }

  async function failureCount(column: "username" | "ip", value: string) {
    const { count, error } = await admin
      .from("login_attempts")
      .select("id", { count: "exact", head: true })
      .eq(column, value)
      .eq("success", false)
      .gte("attempted_at", windowStart);
    if (error) {
      console.error("secure-login: rate-limit lookup failed", error);
      // Fail closed: if we cannot check the limit, do not let the login
      // through unchecked — the caller only sees the generic error.
      return Number.MAX_SAFE_INTEGER;
    }
    return count ?? 0;
  }

  // Rate limits first, before any user lookup (and before recording, so a
  // blocked client cannot extend its own window by retrying).
  if ((await failureCount("ip", ip)) >= MAX_FAILURES_PER_IP) {
    return genericFailure(429);
  }
  if ((await failureCount("username", username)) >= MAX_FAILURES_PER_USER) {
    return genericFailure(429);
  }

  // 1) username -> user id via public.profiles (service role bypasses RLS).
  // Case-insensitive, like the old RPC; wildcards escaped.
  const { data: profile, error: profileError } = await admin
    .from("profiles")
    .select("id, username")
    .ilike("username", escapeLike(username))
    .maybeSingle();
  if (profileError || !profile) {
    await recordAttempt(false);
    return genericFailure();
  }

  // 2) Email, server-side only. It is never put in any response.
  const { data: userData, error: userError } =
    await admin.auth.admin.getUserById(profile.id as string);
  const email = userData?.user?.email;
  if (userError || !email) {
    await recordAttempt(false);
    return genericFailure();
  }

  // 3) Password check, server-side.
  const { data: signInData, error: signInError } =
    await anon.auth.signInWithPassword({ email, password });
  const session = signInData?.session;
  if (signInError || !session) {
    await recordAttempt(false);
    return genericFailure();
  }

  await recordAttempt(true);

  // 4) ONLY the session tokens + minimal user info leave the server.
  // No email, ever.
  return jsonResponse(
    {
      access_token: session.access_token,
      refresh_token: session.refresh_token,
      user: { id: session.user.id, username: profile.username },
    },
    200,
  );
});
