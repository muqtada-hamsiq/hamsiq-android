// Hamsiq — server-side push notifications via FCM HTTP v1.
//
// Problem: a user whose app is closed never learns about a new DM /
// group message or an incoming call. In-app `notifications` rows
// (sql-v9) only render while the app is open. This function is the
// single server-side sender: it is invoked either by the Postgres
// trigger on messages INSERT (sql-v39, pg_net, header
// x-push-trigger-secret) or directly by a caller starting a call
// (caller JWT, type 'call_invite').
//
// Contract:
//   POST /functions/v1/send-push
//   Auth EITHER:
//     (a) header x-push-trigger-secret == PUSH_TRIGGER_SECRET env
//         (the DB trigger path), OR
//     (b) Authorization: Bearer <user JWT> (the caller-invoked call
//         path). A user JWT may NEVER use type 'message' — only the
//         trigger may, so no user can spoof a push for someone
//         else's message.
//   Body:
//     { "type": "message", "message_id": <bigint> }
//       — trigger only. The function loads the message row AS
//       service_role, resolves recipients (DM receiver, or all group
//       members except the sender), and checks each recipient's
//       profiles.notif_messages toggle + muted_chats + device_tokens.
//     { "type": "call_invite", "recipient_id": "<uuid>",
//       "call_id": "<string>", "sender_id": "<uuid>",
//       "group_id": <bigint, optional> }
//       — caller JWT only, and sender_id MUST equal the caller's id.
//       Anti-spam guard: the caller and recipient must share a DM
//       thread (a message in either direction) or a group membership
//       (or both be members of the given group_id); otherwise 403.
//   200: { "sent": <n>, "skipped": <bool> }
//        sent = FCM messages accepted; skipped = true when there was
//        nothing to send (no tokens, recipient muted/toggled off,
//        message gone). A trigger call for a user with no tokens
//        returns 200 { "sent": 0, "skipped": true }.
//   401: { "error": "Unauthorized" }  — no/invalid auth
//   400: { "error": "Invalid request" } — bad body / unknown type
//   403: { "error": "Access denied" } — user JWT on type 'message',
//        sender_id != caller, or no DM/group link for a call invite
//   500: { "error": "Server error" }  — never leaks details
//
// Payload: DATA-ONLY, always exactly these string fields (FCM data
// values must be strings; absent optionals are ""):
//   type, sender_id, sender_name, chat_type ('dm' | 'group'),
//   thread_peer_id, group_id, message_id, preview ("" when none),
//   message_kind, call_id. No `notification` block EVER — the client
//   renders the notification itself from the data payload.
// Android: priority high; collapse_key per thread
//   (dm:<peer> / group:<id> / call:<id>); TTL 86400s for messages,
//   60s for call invites (a ringing phone must not buzz a minute
//   after the caller hung up).
//
// FCM via HTTP v1: an OAuth2 access token is minted from the
// service-account JSON in FIREBASE_SERVICE_ACCOUNT_JSON (client_email
// + private_key), JWT signed RS256, POST to
// https://oauth2.googleapis.com/token with scope
// https://www.googleapis.com/auth/firebase.messaging, then POST to
// https://fcm.googleapis.com/v1/projects/hamsiq-ab146/messages:send.
// The token is cached in memory until shortly before expiry.
// Stale tokens: on FCM UNREGISTERED / INVALID_ARGUMENT the token row
// is deleted with service_role.
//
// Security notes:
//   * The service-account JSON is NOT in this file — it is an Edge
//     Function secret (FIREBASE_SERVICE_ACCOUNT_JSON), set by the
//     deploy step. Until it is set, sends to real tokens return 500
//     but the no-tokens path still returns 200 {skipped:true}, so
//     the function deploys and verifies without FCM.
//   * No token value and no message body is ever logged — logs carry
//     ids and counts only.
//   * There is NO notif_calls toggle in profiles (sql-v9/v29 only
//     define notif_messages/likes/followers/mentions/comments), so
//     call invites are NOT gated on a toggle. If a calls toggle is
//     added later, gate here before sending.
//
// Environment (auto-provided by Supabase to Edge Functions — never
// hardcode any key here): SUPABASE_URL, SUPABASE_ANON_KEY,
// SUPABASE_SERVICE_ROLE_KEY. Plus PUSH_TRIGGER_SECRET and
// FIREBASE_SERVICE_ACCOUNT_JSON, set as function secrets.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const FCM_PROJECT_ID = "hamsiq-ab146";
const FCM_SCOPE = "https://www.googleapis.com/auth/firebase.messaging";
const MESSAGE_TTL_SECONDS = 86400;
const CALL_TTL_SECONDS = 60;
const PREVIEW_MAX_CHARS = 200;

const CORS_HEADERS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-push-trigger-secret",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function jsonResponse(body: unknown, status: number): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

/// Constant-time string comparison (no early exit on first mismatch).
function timingSafeEqual(a: string, b: string): boolean {
  if (!a || !b) return false;
  const enc = new TextEncoder();
  const ab = enc.encode(a);
  const bb = enc.encode(b);
  let diff = ab.length ^ bb.length;
  const len = Math.max(ab.length, bb.length);
  for (let i = 0; i < len; i++) {
    diff |= ab[i % ab.length] ^ bb[i % bb.length];
  }
  return diff === 0;
}

function isUuid(v: unknown): v is string {
  return (
    typeof v === "string" &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v)
  );
}

// ---------------- FCM access token (service account) ----------------

let cachedAccessToken: { token: string; expiresAt: number } | null = null;

function base64Url(bytes: Uint8Array): string {
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function pemToDer(pem: string): ArrayBuffer {
  const b64 = pem
    .replace(/-----BEGIN [^-]+-----/g, "")
    .replace(/-----END [^-]+-----/g, "")
    .replace(/\s+/g, "");
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out.buffer;
}

/// Mint (or reuse the cached) OAuth2 access token for FCM.
/// Returns null when the service-account secret is missing/invalid —
/// the caller turns that into a generic 500.
async function getFcmAccessToken(): Promise<string | null> {
  const now = Math.floor(Date.now() / 1000);
  if (cachedAccessToken && cachedAccessToken.expiresAt > now + 60) {
    return cachedAccessToken.token;
  }
  const raw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON");
  if (!raw) return null;
  let sa: Record<string, unknown>;
  try {
    sa = JSON.parse(raw) as Record<string, unknown>;
  } catch {
    console.error("send-push: FIREBASE_SERVICE_ACCOUNT_JSON is not JSON");
    return null;
  }
  const clientEmail = sa["client_email"];
  const privateKey = sa["private_key"];
  if (typeof clientEmail !== "string" || typeof privateKey !== "string") {
    console.error("send-push: service account JSON lacks client_email/private_key");
    return null;
  }
  const header = base64Url(
    new TextEncoder().encode(JSON.stringify({ alg: "RS256", typ: "JWT" })),
  );
  const payload = base64Url(
    new TextEncoder().encode(
      JSON.stringify({
        iss: clientEmail,
        scope: FCM_SCOPE,
        aud: "https://oauth2.googleapis.com/token",
        iat: now,
        exp: now + 3600,
      }),
    ),
  );
  let key: CryptoKey;
  try {
    key = await crypto.subtle.importKey(
      "pkcs8",
      pemToDer(privateKey),
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
      false,
      ["sign"],
    );
  } catch {
    console.error("send-push: service account private_key unusable");
    return null;
  }
  const sig = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    key,
    new TextEncoder().encode(`${header}.${payload}`),
  );
  const assertion = `${header}.${payload}.${base64Url(new Uint8Array(sig))}`;
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion,
    }),
  });
  if (!res.ok) {
    console.error("send-push: oauth token exchange failed", res.status);
    return null;
  }
  const data = (await res.json()) as Record<string, unknown>;
  const token = data["access_token"];
  const expiresIn = data["expires_in"];
  if (typeof token !== "string" || !token) return null;
  cachedAccessToken = {
    token,
    expiresAt: now + (typeof expiresIn === "number" ? expiresIn : 3600),
  };
  return token;
}

// ---------------- FCM send ----------------

type FcmData = Record<string, string>;

/// Send one data-only FCM message. Returns "sent", "stale" (token
/// dead — delete the row) or "failed" (transient/other — keep row).
async function sendFcm(
  accessToken: string,
  token: string,
  data: FcmData,
  collapseKey: string,
  ttlSeconds: number,
): Promise<"sent" | "stale" | "failed"> {
  const res = await fetch(
    `https://fcm.googleapis.com/v1/projects/${FCM_PROJECT_ID}/messages:send`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message: {
          token,
          data,
          android: {
            priority: "high",
            collapse_key: collapseKey,
            ttl: `${ttlSeconds}s`,
          },
        },
      }),
    },
  );
  if (res.ok) return "sent";
  let status = "";
  try {
    const err = (await res.json()) as {
      error?: { status?: string; message?: string };
    };
    status = err?.error?.status ?? "";
  } catch {
    // Non-JSON error body — treat as a generic failure.
  }
  if (status === "UNREGISTERED" || status === "INVALID_ARGUMENT") {
    return "stale";
  }
  console.error("send-push: FCM send failed", res.status, status || "unknown");
  return "failed";
}

Deno.serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  if (req.method !== "POST") {
    return jsonResponse({ error: "Invalid request" }, 400);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  if (!supabaseUrl || !serviceRoleKey || !anonKey) {
    console.error("send-push: missing Supabase env vars");
    return jsonResponse({ error: "Server error" }, 500);
  }
  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  // 1) Auth: trigger secret OR user JWT. Neither => 401.
  const triggerSecret = Deno.env.get("PUSH_TRIGGER_SECRET") ?? "";
  const presentedSecret = req.headers.get("x-push-trigger-secret") ?? "";
  const isTrigger =
    triggerSecret !== "" && timingSafeEqual(presentedSecret, triggerSecret);

  let authedUserId: string | null = null;
  if (!isTrigger) {
    const authHeader = req.headers.get("authorization") ?? "";
    const jwt = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!jwt) return jsonResponse({ error: "Unauthorized" }, 401);
    const anon = createClient(supabaseUrl, anonKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
    const { data: userData, error: userError } = await anon.auth.getUser(jwt);
    if (userError || !userData?.user) {
      return jsonResponse({ error: "Unauthorized" }, 401);
    }
    authedUserId = userData.user.id;
  }

  // 2) Validate the body.
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: "Invalid request" }, 400);
  }
  const b = body as Record<string, unknown>;
  const type = b?.["type"];
  if (type !== "message" && type !== "call_invite") {
    return jsonResponse({ error: "Invalid request" }, 400);
  }

  // type 'message' is trigger-only: a user JWT must never be able to
  // push for someone else's message.
  if (type === "message" && !isTrigger) {
    return jsonResponse({ error: "Access denied" }, 403);
  }
  // type 'call_invite' is caller-only: the trigger has no caller.
  if (type === "call_invite" && isTrigger) {
    return jsonResponse({ error: "Invalid request" }, 400);
  }

  // 3) Resolve the send list: { recipientId, data, collapseKey, ttl }.
  type SendTarget = {
    recipientId: string;
    data: FcmData;
    collapseKey: string;
    ttl: number;
  };
  const targets: SendTarget[] = [];

  if (type === "message") {
    const messageId = b?.["message_id"];
    if (typeof messageId !== "number" || !Number.isInteger(messageId)) {
      return jsonResponse({ error: "Invalid request" }, 400);
    }
    const { data: msg, error: msgErr } = await admin
      .from("messages")
      .select(
        "id,sender_id,receiver_id,group_id,body,message_type,view_once,vanish",
      )
      .eq("id", messageId)
      .limit(1)
      .maybeSingle();
    if (msgErr || !msg) {
      // Message gone (unsent/deleted between trigger and here) —
      // nothing to send. 200 skipped, never a 404 leak.
      return jsonResponse({ sent: 0, skipped: true }, 200);
    }
    const senderId = msg["sender_id"] as string;
    const receiverId = msg["receiver_id"] as string | null;
    const groupId = msg["group_id"] as number | null;
    const messageType = (msg["message_type"] as string | null) ?? "text";
    const isGroup = groupId !== null && groupId !== undefined;

    // Recipients: the DM receiver, or every group member but sender.
    let recipientIds: string[] = [];
    if (isGroup) {
      const { data: members, error: memErr } = await admin
        .from("group_members")
        .select("user_id")
        .eq("group_id", groupId);
      if (memErr) {
        console.error("send-push: group members lookup failed");
        return jsonResponse({ error: "Server error" }, 500);
      }
      recipientIds = ((members as Array<{ user_id: string }>) ?? [])
        .map((m) => m.user_id)
        .filter((id) => id !== senderId);
    } else if (receiverId) {
      if (receiverId === senderId) {
        return jsonResponse({ sent: 0, skipped: true }, 200);
      }
      recipientIds = [receiverId];
    } else {
      return jsonResponse({ sent: 0, skipped: true }, 200);
    }
    if (recipientIds.length === 0) {
      return jsonResponse({ sent: 0, skipped: true }, 200);
    }

    // Sender display name (never an email — profiles has no email).
    const { data: senderProfile } = await admin
      .from("profiles")
      .select("display_name,username")
      .eq("id", senderId)
      .limit(1)
      .maybeSingle();
    const senderName =
      (senderProfile?.["display_name"] as string | undefined)?.trim() ||
      (senderProfile?.["username"] as string | undefined)?.trim() ||
      "Hamsiq";

    // Preview: text body only, truncated; never for view-once /
    // vanish messages, and never for media/poll/shared types.
    const isSecret = msg["view_once"] === true || msg["vanish"] === true;
    const preview =
      !isSecret && messageType === "text"
        ? ((msg["body"] as string | null) ?? "").slice(0, PREVIEW_MAX_CHARS)
        : "";

    for (const rid of recipientIds) {
      targets.push({
        recipientId: rid,
        data: {
          type: "message",
          sender_id: senderId,
          sender_name: senderName,
          chat_type: isGroup ? "group" : "dm",
          thread_peer_id: isGroup ? "" : senderId,
          group_id: isGroup ? String(groupId) : "",
          message_id: String(messageId),
          preview,
          message_kind: messageType,
          call_id: "",
        },
        collapseKey: isGroup
          ? `group:${groupId}`
          : `dm:${senderId}`,
        ttl: MESSAGE_TTL_SECONDS,
      });
    }
  } else {
    // ---- type 'call_invite' (caller JWT) ----
    const recipientId = b?.["recipient_id"];
    const callId = b?.["call_id"];
    const senderId = b?.["sender_id"];
    const groupIdRaw = b?.["group_id"];
    if (
      !isUuid(recipientId) ||
      !isUuid(senderId) ||
      typeof callId !== "string" ||
      callId.length === 0 ||
      callId.length > 128
    ) {
      return jsonResponse({ error: "Invalid request" }, 400);
    }
    if (senderId !== authedUserId) {
      return jsonResponse({ error: "Access denied" }, 403);
    }
    if (recipientId === senderId) {
      return jsonResponse({ sent: 0, skipped: true }, 200);
    }
    const groupId =
      typeof groupIdRaw === "number" && Number.isInteger(groupIdRaw)
        ? groupIdRaw
        : null;

    // Anti-spam guard: caller and recipient must share a DM thread
    // (a message in either direction) or a group membership. For a
    // group call, both must be members of the given group.
    let linked = false;
    if (groupId !== null) {
      const { data: both } = await admin
        .from("group_members")
        .select("user_id")
        .eq("group_id", groupId)
        .in("user_id", [senderId, recipientId as string]);
      linked =
        ((both as Array<{ user_id: string }>) ?? []).length === 2;
    } else {
      const { data: dm } = await admin
        .from("messages")
        .select("id")
        .or(
          `and(sender_id.eq.${senderId},receiver_id.eq.${recipientId}),` +
            `and(sender_id.eq.${recipientId},receiver_id.eq.${senderId})`,
        )
        .limit(1);
      const { data: shared } = await admin
        .from("group_members")
        .select("group_id")
        .eq("user_id", senderId);
      let sharedGroup = false;
      if (shared && (shared as Array<{ group_id: number }>).length > 0) {
        const gids = (shared as Array<{ group_id: number }>).map(
          (r) => r.group_id,
        );
        const { data: other } = await admin
          .from("group_members")
          .select("group_id")
          .eq("user_id", recipientId as string)
          .in("group_id", gids)
          .limit(1);
        sharedGroup = !!other && (other as unknown[]).length > 0;
      }
      linked = !!dm && (dm as unknown[]).length > 0 ? true : sharedGroup;
    }
    if (!linked) {
      return jsonResponse({ error: "Access denied" }, 403);
    }

    const { data: senderProfile } = await admin
      .from("profiles")
      .select("display_name,username")
      .eq("id", senderId)
      .limit(1)
      .maybeSingle();
    const senderName =
      (senderProfile?.["display_name"] as string | undefined)?.trim() ||
      (senderProfile?.["username"] as string | undefined)?.trim() ||
      "Hamsiq";

    targets.push({
      recipientId: recipientId as string,
      data: {
        type: "call_invite",
        sender_id: senderId as string,
        sender_name: senderName,
        chat_type: groupId !== null ? "group" : "dm",
        thread_peer_id: groupId !== null ? "" : (senderId as string),
        group_id: groupId !== null ? String(groupId) : "",
        message_id: "",
        preview: "",
        message_kind: "",
        call_id: callId as string,
      },
      collapseKey: `call:${callId}`,
      ttl: CALL_TTL_SECONDS,
    });
  }

  // 4) Per recipient: notif_messages toggle (messages only) + mute +
  // device tokens. No tokens anywhere => 200 skipped without ever
  // touching FCM (so the function verifies before the service-account
  // secret exists).
  type ReadySend = { tokenRowId: number; token: string; target: SendTarget };
  const ready: ReadySend[] = [];
  for (const t of targets) {
    if (type === "message") {
      const { data: prof } = await admin
        .from("profiles")
        .select("notif_messages")
        .eq("id", t.recipientId)
        .limit(1)
        .maybeSingle();
      if (prof && prof["notif_messages"] === false) continue;
      const chatKind = t.data["chat_type"] === "group" ? "group" : "dm";
      const chatId =
        chatKind === "group" ? t.data["group_id"] : t.data["thread_peer_id"];
      const { data: muted } = await admin
        .from("muted_chats")
        .select("chat_id")
        .eq("user_id", t.recipientId)
        .eq("chat_kind", chatKind)
        .eq("chat_id", chatId)
        .limit(1);
      if (muted && (muted as unknown[]).length > 0) continue;
    }
    const { data: tokens, error: tokErr } = await admin
      .from("device_tokens")
      .select("id,token")
      .eq("user_id", t.recipientId);
    if (tokErr) {
      console.error("send-push: device_tokens lookup failed");
      return jsonResponse({ error: "Server error" }, 500);
    }
    for (const row of (tokens as Array<{ id: number; token: string }>) ?? []) {
      ready.push({ tokenRowId: row.id, token: row.token, target: t });
    }
  }
  if (ready.length === 0) {
    return jsonResponse({ sent: 0, skipped: true }, 200);
  }

  // 5) Send via FCM. Service-account secret missing => 500 (live
  // send is untested until the secret is set — see the file header).
  const accessToken = await getFcmAccessToken();
  if (!accessToken) {
    console.error("send-push: no FCM access token (service account not configured)");
    return jsonResponse({ error: "Server error" }, 500);
  }
  let sent = 0;
  for (const r of ready) {
    const outcome = await sendFcm(
      accessToken,
      r.token,
      r.target.data,
      r.target.collapseKey,
      r.target.ttl,
    );
    if (outcome === "sent") {
      sent++;
    } else if (outcome === "stale") {
      // Token dead on FCM's side — remove it so it is never tried again.
      const { error: delErr } = await admin
        .from("device_tokens")
        .delete()
        .eq("id", r.tokenRowId);
      if (delErr) console.error("send-push: stale token delete failed");
    }
  }
  return jsonResponse({ sent, skipped: sent === 0 }, 200);
});
