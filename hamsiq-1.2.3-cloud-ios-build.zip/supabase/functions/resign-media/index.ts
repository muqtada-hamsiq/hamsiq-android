// Hamsiq — server-side media re-sign (audit finding H-04 follow-up).
//
// Problem: DM / story / post media lives in the PRIVATE `private-media`
// bucket with 1-hour signed URLs. The bucket's SELECT policy is
// owner-only, so a RECIPIENT cannot re-sign the media client-side
// (createSignedUrl as the recipient fails) — media sent to someone else
// stops loading for them 1 hour after upload, and the same applies to
// every migrated old-media row. The client-side helper
// (lib/services/media_api.dart ensureFreshUrl) only fixes the uploader's
// own view.
//
// This function closes the gap server-side: it verifies, with the
// requester's own JWT, that the requester can actually READ a row that
// references this media (Row Level Security is the access check — the
// function never re-implements the posts/stories/DM visibility rules),
// and only then mints a fresh 1-hour signed URL with the service_role
// key. No readable row => 403. No row at all => 403 (fail closed).
// The requester never learns whether the file exists: a missing file
// and a forbidden file both return 403.
//
// Contract:
//   POST /functions/v1/resign-media
//   Headers: Authorization: Bearer <user JWT>, apikey: <anon key>
//   Body: { "bucket": "private-media", "path": "<owner-id>/<file>" }
//   200: { "signedUrl": "<full https URL, valid 1h>" }
//   401: { "error": "Unauthorized" }            — no/invalid JWT
//   400: { "error": "Invalid request" }         — bad bucket/path
//   403: { "error": "Access denied" }           — no readable row
//   500: { "error": "Server error" }            — never leaks details
//
// Security notes:
//   * Only the `private-media` bucket is ever signed here. Public
//     buckets (avatars, chat-media) never need re-signing.
//   * The path is validated (no traversal, no leading slash, sane
//     length) and matched against stored URLs in their URL-encoded
//     form, so odd filenames cannot smuggle a different object.
//   * The signed URL is minted with the service_role key and is only
//     returned after the access check passes. An authenticated user
//     can only re-sign media they could already see in the app.
//   * No rate limit is enforced here: each call requires a valid
//     session AND a readable row, and signing is a single cheap
//     Storage call; the abuse surface is one signed URL per media the
//     caller can already view.
//
// Environment (auto-provided by Supabase to Edge Functions — never
// hardcode any key here): SUPABASE_URL, SUPABASE_ANON_KEY,
// SUPABASE_SERVICE_ROLE_KEY.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SIGNED_TTL_SECONDS = 3600;
const ALLOWED_BUCKET = "private-media";

// Tables whose URL columns can reference private-media objects, with
// the column holding the URL. The access check queries each of these
// AS THE REQUESTER (RLS enforced) for a row referencing the path.
const REFERENCE_TABLES: Array<{ table: string; urlCol: string }> = [
  { table: "messages", urlCol: "media_url" },
  { table: "stories", urlCol: "media_url" },
  { table: "posts", urlCol: "media_url" },
  { table: "post_drafts", urlCol: "media_url" },
  { table: "cloud_files", urlCol: "file_url" },
];

const CORS_HEADERS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function jsonResponse(body: unknown, status: number): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

/// Escape LIKE wildcards so a path containing % or _ cannot match
/// other objects when we do the ilike lookup.
function escapeLike(value: string): string {
  return value.replace(/\\/g, "\\\\").replace(/%/g, "\\%").replace(/_/g, "\\_");
}

/// Validate the requested path. Returns an error string, or null if OK.
function validatePath(path: unknown): string | null {
  if (typeof path !== "string") return "path must be a string";
  if (path.length === 0 || path.length > 512) return "bad path length";
  if (path.startsWith("/") || path.includes("\\")) return "bad path";
  const segments = path.split("/");
  if (segments.length < 2) return "path needs owner/file segments";
  if (segments.some((s) => s === "" || s === "." || s === "..")) {
    return "bad path segment";
  }
  return null;
}

Deno.serve(async (req: Request): Promise<Response> => {
  // CORS preflight.
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  if (req.method !== "POST") {
    return jsonResponse({ error: "Invalid request" }, 400);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  if (!supabaseUrl || !serviceRoleKey || !anonKey) {
    console.error("resign-media: missing Supabase env vars");
    return jsonResponse({ error: "Server error" }, 500);
  }

  // 1) Authenticate the caller from their JWT. No token => 401.
  const authHeader = req.headers.get("authorization") ?? "";
  const jwt = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (!jwt) return jsonResponse({ error: "Unauthorized" }, 401);
  const anon = createClient(supabaseUrl, anonKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
  const { data: userData, error: userError } = await anon.auth.getUser(jwt);
  const user = userData?.user;
  if (userError || !user) {
    return jsonResponse({ error: "Unauthorized" }, 401);
  }

  // 2) Validate the body.
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: "Invalid request" }, 400);
  }
  const bucket = (body as Record<string, unknown>)?.["bucket"];
  const path = (body as Record<string, unknown>)?.["path"];
  if (bucket !== ALLOWED_BUCKET) {
    return jsonResponse({ error: "Invalid request" }, 400);
  }
  const pathError = validatePath(path);
  if (pathError) return jsonResponse({ error: "Invalid request" }, 400);
  const cleanPath = path as string;

  // 3) Access check, AS THE REQUESTER (RLS is the authority): is there
  // at least one row the caller can read that references this object?
  // Stored URLs hold the path URL-encoded, so match the encoded form.
  const encodedPath = cleanPath
    .split("/")
    .map((seg) => encodeURIComponent(seg))
    .join("/");
  const pattern = `%${escapeLike(encodedPath)}%`;
  const userClient = createClient(supabaseUrl, anonKey, {
    auth: { autoRefreshToken: false, persistSession: false },
    global: { headers: { Authorization: `Bearer ${jwt}` } },
  });
  let readable = false;
  for (const { table, urlCol } of REFERENCE_TABLES) {
    const { data, error } = await userClient
      .from(table)
      .select("id")
      .ilike(urlCol, pattern)
      .limit(1);
    if (!error && data && data.length > 0) {
      readable = true;
      break;
    }
    if (error) {
      // A missing table/column (e.g. post_drafts on an older schema)
      // must not fail the whole check — log and continue.
      console.error(`resign-media: lookup ${table} failed`, error.message);
    }
  }
  if (!readable) {
    // Deliberately the same response whether the file exists or not.
    return jsonResponse({ error: "Access denied" }, 403);
  }

  // 4) Mint a fresh 1-hour signed URL with the service_role key.
  // The sign endpoint returns a path WITHOUT the /storage/v1 prefix
  // ("/object/sign/<bucket>/<path>?token=...") — the full fetchable
  // URL needs the prefix (proven by the H-04 staging test).
  const enc = cleanPath
    .split("/")
    .map((seg) => encodeURIComponent(seg))
    .join("/");
  const signRes = await fetch(
    `${supabaseUrl}/storage/v1/object/sign/${ALLOWED_BUCKET}/${enc}`,
    {
      method: "POST",
      headers: {
        apikey: serviceRoleKey,
        Authorization: `Bearer ${serviceRoleKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ expiresIn: SIGNED_TTL_SECONDS }),
    },
  );
  if (!signRes.ok) {
    console.error("resign-media: sign failed", signRes.status);
    return jsonResponse({ error: "Server error" }, 500);
  }
  const signData = (await signRes.json()) as Record<string, unknown>;
  const signed = signData["signedURL"];
  if (typeof signed !== "string" || !signed) {
    console.error("resign-media: sign returned no signedURL");
    return jsonResponse({ error: "Server error" }, 500);
  }
  const signedUrl = signed.startsWith("http")
    ? signed
    : `${supabaseUrl}/storage/v1${signed}`;
  return jsonResponse({ signedUrl }, 200);
});
