# TURN server verification for Hamsiq Phase 2 calls — 2026-11-15

**Verdict: CALLS ARE BLOCKED — no free TURN server verified.**
No `relay` ICE candidate was gathered from any candidate server, and — critically —
this VM *cannot* verify TURN at all: its sandbox network blocks UDP and fabricates
STUN responses on TCP (proof below). A negative result here proves nothing about the
real servers, and a positive result here would have been untrustworthy too.
**Do not wire any TURN config into the app until verification is re-run from a real
network (a real phone or an unsandboxed machine).**

Test scripts (reusable on a real network):
`~/workspace/hamsiq-native/turn-verification/turn_test.py` (aiortc ICE gathering)
and `turn_allocate.py` (raw TURN Allocate over TCP, with a wrong-password control).

## 1. Test results (all run live 2026-11-15, aiortc 1.16.0, Python 3.12)

Decisive test: a gathered ICE candidate of type `relay`. `srflx` alone does not count.

| # | Server | Transport | Username | relay? | Candidates | Notes |
|---|--------|-----------|----------|--------|------------|-------|
| 0 | `stun:stun.l.google.com:19302` (STUN baseline) | UDP | — | NO | 0 | 0 candidates even for STUN → test rig broken, not the server |
| 1 | `turn:openrelay.metered.ca:80` | UDP | `openrelayproject` | NO | 0 | legacy creds |
| 2 | `turn:openrelay.metered.ca:443` | UDP | `openrelayproject` | NO | 0 | legacy creds |
| 3 | `turn:openrelay.metered.ca:80?transport=tcp` | TCP | `openrelayproject` | NO | 0 | legacy creds |
| 4 | `turns:openrelay.metered.ca:443` | TLS | `openrelayproject` | NO | 0 | gathering failed in 0.1 s (TLS intercepted, see §2) |
| 5 | `turn:staticauth.openrelay.metered.ca:80` | UDP | `<expiry>:hamsiq-test` (HMAC, secret `openrelayprojectsecret`) | NO | 0 | |
| 6 | `turn:staticauth.openrelay.metered.ca:443` | UDP | HMAC as above | NO | 0 | |
| 7 | `turn:staticauth.openrelay.metered.ca:80?transport=tcp` | TCP | HMAC as above | NO | 0 | |
| 8 | `turns:staticauth.openrelay.metered.ca:443` | TLS | HMAC as above | NO | 0 | gathering failed in 0.3 s |
| 9 | `turn:numb.viagenie.ca:3478` (published demo creds `webrtc@live.com` / `muazkh`) | UDP | see creds | NOT TESTED via aiortc | — | DNS-dead (see §3); creds are someone else's decade-old public demo pair — unsuitable for production regardless |
| — | Raw TURN Allocate over TCP (openrelay + staticauth, correct AND wrong passwords) | TCP 80 | as above | — | — | All 4 attempts: TCP connected, then `ConnectionResetError` before any STUN/TURN reply. Control inconclusive. |

**No `relay` candidate line exists to quote — none was ever gathered.**
Round-trip time: not measurable (no allocation ever completed).

## 2. Why this VM cannot verify TURN (first-hand evidence)

1. **UDP egress is blocked by the sandbox.** `socket.sendto()` → `PermissionError:
   [Errno 1] Operation not permitted` for every host. UDP is how TURN normally
   works, so the primary path is untestable here.
2. **Sandbox DNS is proxied.** The local resolver returns `198.18.58.43–45`
   (benchmark range) for every host. Independent DNS-over-HTTPS (Google + Cloudflare)
   returns the real IPs.
3. **TCP is intercepted.** Connects "succeed" in 0.00 s to the proxy; plain HTTP
   works (200), so general TCP forwarding exists.
4. **STUN responses on TCP are fabricated by the proxy — proven.** A STUN Binding
   Request over TCP to `74.125.250.129:19302` (Google STUN, a UDP-only service that
   does not serve TCP STUN) returned an identical 191-byte STUN success response in
   0.00 s, as did requests to the real IPs of Metered's servers. A real Google
   server cannot answer that. Any "success" on this path would be the proxy's, not
   Metered's.
5. **Proxy behaviour is non-deterministic.** The same request returned a canned
   191-byte response in one run and `ConnectionResetError` in the next three runs.
6. **TLS is intercepted.** `openssl s_client` to `openrelay.metered.ca:443` /
   `staticauth.openrelay.metered.ca:443` fails with `wrong version number` — the
   peer answers the TLS ClientHello with non-TLS bytes. `turns:` is untestable here.
7. **STUN baseline failed too** (0 candidates), confirming the rig, not the servers,
   is the problem. A negative TURN result under these conditions is meaningless.

## 3. Documentation + DNS findings (web, 2026-11-15)

- **Legacy static creds `openrelayproject` / `openrelayproject` are stale.**
  Metered's own Open Relay page (metered.ca/tools/openrelay/) no longer documents
  them; it now says: sign up for a free account to obtain an API key, then fetch
  `iceServers` from the TURN REST API. Multiple independent 2026 sources confirm
  the static pair stopped working. **Do not use these creds.**
- **`openrelay.metered.ca` is DNS-sinkholed.** Google DoH *and* Cloudflare DoH both
  resolve it to `192.0.2.1` (TEST-NET-1, non-routable documentation address).
  The legacy endpoint appears dead at the DNS level.
- **`staticauth.openrelay.metered.ca` still resolves to a real IP**
  (`216.39.253.123`) and Metered still documents it for static-auth (Nextcloud
  Talk-style) use with shared secret `openrelayprojectsecret` and client-computed
  time-limited HMAC credentials (`username = <expiry>:<label>`,
  `credential = base64(HMAC-SHA1(secret, username))`). This is the **only**
  no-signup TURN path still documented anywhere — but it is **UNVERIFIED**
  (no allocation was ever observed; one Aug-2026 report also found it unresponsive
  from a sandbox). It is the first thing to re-test from a real network.
- **`numb.viagenie.ca` is dead**: no A record via DoH; requires registration anyway.
- **PeerJS free TURN is dead**: `turn.peerjs.com` is NXDOMAIN (decommissioned 2026).
- **Metered's own pages disagree on the free quota**: the Open Relay marketing page
  says "20 GB/month free"; the official pricing page (metered.ca/pricing) says the
  free plan is a **500 MB/month trial**, Growth $99/mo for 150 GB, overage $0.40/GB.
  Community reports: 0.5 GB free without a card, 20 GB after adding a card. Treat
  the real free quota as **unverified until seen in the dashboard**.
- No other genuinely free, no-signup TURN server was found. Every other "free TURN"
  list resolves to signup-gated quotas (below) or dead endpoints.

## 4. Verified iceServers config

**NONE. There is no verified config to give the calls agent.**
Do not ship `openrelayproject`/`openrelayproject`, and do not ship the staticauth
HMAC config, until one of them produces a `relay` candidate from a real network.

## 5. Alternatives (all require an account signup — none verifiable from here)

| Option | Free tier (as documented) | Cost after free tier | Steps |
|--------|---------------------------|----------------------|-------|
| **Cloudflare Realtime TURN** (best free tier) | **1,000 GB/month egress free**, shared SFU+TURN — official docs, developers.cloudflare.com/realtime/sfu/platform/pricing/, updated 2026-09-22 | $0.05/GB egress | 1. Create Cloudflare account. 2. Enable Realtime. 3. Issue TURN credentials via API (max 48 h validity — needs a small backend/token endpoint or short-lived creds refreshed in-app; do not hardcode). 4. Verify with the scripts in this folder from a real network. Card requirement unpublished — check at signup. |
| **Metered.ca (account)** | 500 MB/month free trial per official pricing page (marketing page claims 20 GB — conflict, unverified) | Growth $99/mo / 150 GB; overage $0.40/GB | 1. Sign up at dashboard.metered.ca (no card for trial). 2. Generate TURN credentials / API key. 3. `GET https://metered.live/api/v1/turn/credentials?apiKey=…` returns `iceServers`. 4. Verify a `relay` candidate from a real network. |
| **Twilio Network Traversal Service** | No dedicated free quota; trial credit only | $0.40/GB US/EU, $0.60/GB Singapore/Mumbai, $0.80/GB Sydney/São Paulo (twilio.com/en-us/stun-turn/pricing, via secondary sources Oct 2026) | Twilio account → NTS REST credentials (short-lived, via server). Most expensive per GB. |
| **Xirsys** | 500 MB/month free after a 30-day full-feature trial (secondary source — not checked against xirsys.com this session) | From $39/mo with 50 GB (secondary source, unverified) | Xirsys account → dashboard ICE servers. |
| **Self-hosted coturn** | Software free (BSD). No quota except the VPS's bandwidth. | Cheapest VPS ≈ $4–6/mo (e.g. Hetzner CX23 €5.49/mo post-June-2026 prices; DigitalOcean $4/mo droplet class). No Middle-East Hetzner region — nearest is EU (higher latency to Baghdad). Oracle Always Free tier (2 VMs, 10 TB egress/mo) is a $0 option if eligible — **unverified this session**. | 1. Rent VPS with a public IP. 2. `apt install coturn`, configure long-term credentials + TLS cert (Let's Encrypt), open UDP 3478 + TCP 3478/5349. 3. Point `iceServers` at it. 4. Verify `relay` candidate from a real phone on mobile data. Full control, no third-party quota — the only option with no account-dependency risk. |

## 6. How to verify for real (for the parent agent / calls agent)

Run from a **real phone on mobile data** or any unsandboxed machine — never from this VM:

1. Easiest: open https://www.metered.ca/turn-server-testing in a real browser,
   enter the staticauth HMAC creds (compute with `turn_test.py`'s `hmac_creds()`),
   and check for a `relay` candidate. Or use the WebRTC trickle-ICE sample page
   (webrtc.github.io/samples/src/content/peerconnection/trickle-ice/) with the
   same `iceServers`.
2. Or run `turn_test.py` on a real machine: `python3 -m venv v && v/bin/pip install
   aiortc && v/bin/python turn_test.py "staticauth"` — it prints every candidate and
   flags `RELAY=YES/NO`. A `relay` line must appear; `srflx` alone is not proof.
3. Preferably also verify end-to-end: two real phones on mobile data, force relay
   (`iceTransportPolicy: "relay"` in flutter_webrtc), confirm audio/video flows.
4. Only after (2) or (3) passes should the calls agent hardcode the verified
   `iceServers` — and the HMAC creds must be generated at runtime (short expiry),
   never pasted as a fixed username/password.

## 7. Bottom line for the parent agent

- **Calls workstream is BLOCKED on TURN until a real-network verification passes.**
  STUN-only calls will work phone-to-phone only when NATs cooperate; on Iraqi mobile
  data (CGNAT/symmetric NAT) a significant share of calls will fail without a relay.
- **Recommended path:** create a free Cloudflare account and use Realtime TURN
  (1 TB/mo free — by far the most headroom, $0.05/GB after). Fallback: Metered free
  account (500 MB trial). Long-term robust path: self-hosted coturn on a cheap VPS.
- **Do not** ship the legacy `openrelayproject` creds: undocumented, DNS-sinkholed,
  and reported dead by multiple 2026 sources.
