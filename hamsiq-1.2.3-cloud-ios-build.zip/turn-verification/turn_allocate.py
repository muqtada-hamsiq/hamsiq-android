"""Raw TURN Allocate test over TCP (RFC 5766 + RFC 4571 framing).
Control: a WRONG password must yield 401. If wrong password 'succeeds',
the network path is fabricating responses and nothing here is trustworthy.
"""
import socket, struct, random, hashlib, hmac, base64, time, sys

MAGIC = 0x2112A442

def build_msg(msg_type, txn, attrs):
    body = b"".join(attrs)
    return struct.pack("!HHI12s", msg_type, len(body), MAGIC, txn) + body

def attr(atype, val):
    pad = (4 - len(val) % 4) % 4
    return struct.pack("!HH", atype, len(val)) + val + b"\x00" * pad

def parse_attrs(data):
    out = {}
    off = 20
    while off + 4 <= len(data):
        atype, alen = struct.unpack("!HH", data[off:off+4])
        val = data[off+4:off+4+alen]
        out.setdefault(atype, []).append(val)
        off += 4 + alen + (4 - alen % 4) % 4
    return out

def recv_frame(s, timeout=10):
    s.settimeout(timeout)
    hdr = b""
    while len(hdr) < 2:
        c = s.recv(2 - len(hdr))
        if not c:
            raise ConnectionError("EOF reading frame header")
        hdr += c
    ln = struct.unpack("!H", hdr)[0]
    data = b""
    while len(data) < ln:
        c = s.recv(ln - len(data))
        if not c:
            raise ConnectionError("EOF reading frame body")
        data += c
    return data

def send_frame(s, msg):
    s.sendall(struct.pack("!H", len(msg)) + msg)

def allocate(host, port, username, password, timeout=10, label=""):
    print(f"\n--- {label} {host}:{port} user={username} ---")
    try:
        ip = socket.gethostbyname(host)
        print(f"  DNS -> {ip}")
    except Exception as e:
        print(f"  DNS FAIL {e}")
        return None
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        t0 = time.time()
        s.connect((ip, port))
        print(f"  TCP connect OK in {time.time()-t0:.2f}s")
        # Allocate, no auth: REQUESTED-TRANSPORT UDP (0x19, value 17<<24)
        txn = random.randbytes(12)
        req = build_msg(0x0003, txn, [attr(0x0019, struct.pack("!I", 17 << 24))])
        send_frame(s, req)
        resp = recv_frame(s, timeout)
        mtype = struct.unpack("!H", resp[:2])[0]
        attrs = parse_attrs(resp)
        if mtype == 0x0113:  # Allocate error
            err = attrs.get(0x0009, [b""])[0]
            code = err[2] * 100 + err[3] if len(err) >= 4 else -1
            print(f"  Allocate error {code}: {err[4:].decode(errors='replace')}")
            realm = attrs.get(0x0014, [b""])[0].decode(errors="replace")
            nonce = attrs.get(0x0015, [b""])[0].decode(errors="replace")
            print(f"  REALM={realm!r} NONCE={nonce!r}")
            if code != 401 or not realm or not nonce:
                print("  !! expected 401 with REALM+NONCE; got something else")
                return False
            # Authenticated retry: long-term creds, key = MD5(user:realm:pass)
            key = hashlib.md5(f"{username}:{realm}:{password}".encode()).digest()
            txn2 = random.randbytes(12)
            # Build message with placeholder integrity, then compute HMAC
            a_user = attr(0x0006, username.encode())
            a_realm = attr(0x0014, realm.encode())
            a_nonce = attr(0x0015, nonce.encode())
            a_rt = attr(0x0019, struct.pack("!I", 17 << 24))
            a_mi = attr(0x0008, b"\x00" * 20)
            body = a_user + a_realm + a_nonce + a_rt + a_mi
            hdr = struct.pack("!HHI12s", 0x0003, len(body), MAGIC, txn2)
            mac = hmac.new(key, hdr + body, hashlib.sha1).digest()
            a_mi = attr(0x0008, mac)
            body = a_user + a_realm + a_nonce + a_rt + a_mi
            req2 = struct.pack("!HHI12s", 0x0003, len(body), MAGIC, txn2) + body
            send_frame(s, req2)
            resp2 = recv_frame(s, timeout)
            mtype2 = struct.unpack("!H", resp2[:2])[0]
            attrs2 = parse_attrs(resp2)
            if mtype2 == 0x0103:  # Allocate success
                xra = attrs2.get(0x0016, [b""])[0]
                xma = attrs2.get(0x0020, [b""])[0]
                lt = attrs2.get(0x000d, [b""])[0]
                relay = "?"
                if len(xra) >= 8:
                    xp = struct.unpack("!H", xra[2:4])[0] ^ 0x2112
                    xip = bytes(b ^ m for b, m in zip(xra[4:8], struct.pack("!I", MAGIC)))
                    relay = f"{socket.inet_ntoa(xip)}:{xp}"
                lifetime = struct.unpack("!I", lt)[0] if len(lt) == 4 else "?"
                print(f"  *** ALLOCATE SUCCESS *** relayed-address={relay} lifetime={lifetime}s")
                return True
            else:
                err = attrs2.get(0x0009, [b""])[0]
                code = err[2] * 100 + err[3] if len(err) >= 4 else -1
                print(f"  Authenticated Allocate error {code}: {err[4:].decode(errors='replace')}")
                return False
        elif mtype == 0x0103:
            print("  !! Allocate succeeded WITHOUT auth (unexpected)")
            return True
        else:
            print(f"  !! unexpected message type 0x{mtype:04x}")
            return False
    except Exception as e:
        print(f"  ERROR {type(e).__name__}: {e}")
        return None
    finally:
        s.close()

if __name__ == "__main__":
    # staticauth HMAC creds
    expiry = int(time.time()) + 3600
    su = f"{expiry}:hamsiq-test"
    sc = base64.b64encode(hmac.new(b"openrelayprojectsecret", su.encode(), hashlib.sha1).digest()).decode()
    print(f"staticauth HMAC: user={su} pass={sc}")
    allocate("openrelay.metered.ca", 80, "openrelayproject", "openrelayproject",
             label="openrelay legacy CORRECT")
    allocate("openrelay.metered.ca", 80, "openrelayproject", "WRONGPASSWORD123",
             label="openrelay legacy WRONG (control)")
    allocate("staticauth.openrelay.metered.ca", 80, su, sc,
             label="staticauth HMAC CORRECT")
    allocate("staticauth.openrelay.metered.ca", 80, su, "WRONGPASSWORD123",
             label="staticauth HMAC WRONG (control)")
