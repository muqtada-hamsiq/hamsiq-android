"""Live TURN/STUN verification via aiortc ICE gathering.
Decisive test: a gathered candidate of type 'relay' (srflx alone is NOT enough).
"""
import asyncio
import base64
import hashlib
import hmac
import sys
import time

from aiortc import RTCConfiguration, RTCIceServer, RTCPeerConnection


def hmac_creds(secret: str, label: str = "hamsiq-test", ttl: int = 3600):
    expiry = int(time.time()) + ttl
    username = f"{expiry}:{label}"
    digest = hmac.new(secret.encode(), username.encode(), hashlib.sha1).digest()
    credential = base64.b64encode(digest).decode()
    return username, credential


async def test_server(name, ice_servers, timeout=25):
    print(f"\n=== {name} ===", flush=True)
    t0 = time.time()
    pc = RTCPeerConnection(RTCConfiguration(iceServers=ice_servers))
    candidates = []
    relay_time = None
    done = asyncio.Event()

    @pc.on("icecandidate")
    def on_candidate(candidate):
        nonlocal relay_time
        if candidate is None:
            return
        line = candidate.candidate
        candidates.append(line)
        print(f"  [{time.time()-t0:5.1f}s] {line}", flush=True)
        if " typ relay " in line and relay_time is None:
            relay_time = time.time() - t0

    @pc.on("icegatheringstatechange")
    def on_state():
        if pc.iceGatheringState == "complete":
            done.set()

    pc.createDataChannel("test")
    await pc.setLocalDescription(await pc.createOffer())
    try:
        await asyncio.wait_for(done.wait(), timeout=timeout)
    except asyncio.TimeoutError:
        print(f"  !! gathering NOT complete after {timeout}s (state={pc.iceGatheringState})", flush=True)
    await pc.close()

    types = {}
    for c in candidates:
        for t in ("host", "srflx", "relay", "prflx"):
            if f" typ {t} " in c:
                types[t] = types.get(t, 0) + 1
    has_relay = "relay" in types
    print(f"RESULT {name}: candidates={len(candidates)} types={types} "
          f"RELAY={'YES' if has_relay else 'NO'} "
          f"first_relay_at={relay_time if relay_time is None else round(relay_time,1)}s "
          f"total_time={round(time.time()-t0,1)}s", flush=True)
    return {"name": name, "candidates": candidates, "types": types,
            "relay": has_relay, "relay_time": relay_time}


async def main():
    only = sys.argv[1] if len(sys.argv) > 1 else None
    su, sc = hmac_creds("openrelayprojectsecret")
    print(f"staticauth HMAC creds computed: username={su} credential={sc}", flush=True)

    tests = [
        ("STUN baseline stun:stun.l.google.com:19302",
         [RTCIceServer(urls="stun:stun.l.google.com:19302")]),
        ("TURN openrelay.metered.ca:80 UDP legacy creds",
         [RTCIceServer(urls="turn:openrelay.metered.ca:80",
                       username="openrelayproject", credential="openrelayproject")]),
        ("TURN openrelay.metered.ca:443 UDP legacy creds",
         [RTCIceServer(urls="turn:openrelay.metered.ca:443",
                       username="openrelayproject", credential="openrelayproject")]),
        ("TURN openrelay.metered.ca:80 TCP legacy creds",
         [RTCIceServer(urls="turn:openrelay.metered.ca:80?transport=tcp",
                       username="openrelayproject", credential="openrelayproject")]),
        ("TURNS openrelay.metered.ca:443 TLS legacy creds",
         [RTCIceServer(urls="turns:openrelay.metered.ca:443",
                       username="openrelayproject", credential="openrelayproject")]),
        ("TURN staticauth.openrelay.metered.ca:80 UDP HMAC creds",
         [RTCIceServer(urls="turn:staticauth.openrelay.metered.ca:80",
                       username=su, credential=sc)]),
        ("TURN staticauth.openrelay.metered.ca:443 UDP HMAC creds",
         [RTCIceServer(urls="turn:staticauth.openrelay.metered.ca:443",
                       username=su, credential=sc)]),
        ("TURN staticauth.openrelay.metered.ca:80 TCP HMAC creds",
         [RTCIceServer(urls="turn:staticauth.openrelay.metered.ca:80?transport=tcp",
                       username=su, credential=sc)]),
        ("TURNS staticauth.openrelay.metered.ca:443 TLS HMAC creds",
         [RTCIceServer(urls="turns:staticauth.openrelay.metered.ca:443",
                       username=su, credential=sc)]),
        ("TURN numb.viagenie.ca:3478 published demo creds",
         [RTCIceServer(urls="turn:numb.viagenie.ca:3478",
                       username="webrtc@live.com", credential="muazkh")]),
    ]
    results = []
    for name, servers in tests:
        if only and only not in name:
            continue
        try:
            results.append(await test_server(name, servers))
        except Exception as e:
            print(f"RESULT {name}: ERROR {type(e).__name__}: {e}", flush=True)
    print("\n===== SUMMARY =====")
    for r in results:
        print(f"{'RELAY-YES' if r['relay'] else 'relay-NO '} | {r['name']} | types={r['types']}")


if __name__ == "__main__":
    asyncio.run(main())
