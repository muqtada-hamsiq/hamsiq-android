#!/usr/bin/env python3
import plistlib, re
from pathlib import Path
project = Path('ios/Runner.xcodeproj/project.pbxproj')
if not project.exists():
    raise SystemExit('Missing generated iOS Xcode project')
text = project.read_text()
text, count = re.subn(r'PRODUCT_BUNDLE_IDENTIFIER\s*=\s*[^;]+;', 'PRODUCT_BUNDLE_IDENTIFIER = com.hamsiq.app;', text)
if count < 1:
    raise SystemExit('Could not set PRODUCT_BUNDLE_IDENTIFIER')
project.write_text(text)
info = Path('ios/Runner/Info.plist')
with info.open('rb') as f: data = plistlib.load(f)
data['CFBundleDisplayName'] = 'Himsiq'
data['NSCameraUsageDescription'] = 'يحتاج همسيق إلى الكاميرا لالتقاط الصور والفيديو ونشرها.'
data['NSMicrophoneUsageDescription'] = 'يحتاج همسيق إلى المايكروفون لتسجيل الرسائل الصوتية والفيديو.'
data['NSPhotoLibraryUsageDescription'] = 'يحتاج همسيق إلى الوصول إلى الصور والفيديو لاختيار الوسائط ومشاركتها.'
data['NSPhotoLibraryAddUsageDescription'] = 'يحتاج همسيق إلى حفظ الوسائط التي تختار حفظها على جهازك.'
data['CFBundleURLTypes'] = [{'CFBundleTypeRole':'Editor','CFBundleURLSchemes':['com.hamsiq.app']}]
data['LSApplicationQueriesSchemes'] = ['https', 'http']
with info.open('wb') as f: plistlib.dump(data, f)
podfile = Path('ios/Podfile')
if podfile.exists():
    pod = podfile.read_text()
    if re.search(r'^\s*platform\s+:ios,', pod, re.M):
        pod = re.sub(r'^\s*platform\s+:ios,\s*[\'\"][^\'\"]+[\'\"]', "platform :ios, '13.0'", pod, count=1, flags=re.M)
    else: pod = "platform :ios, '13.0'\n" + pod
    podfile.write_text(pod)
print('Applied Himsiq iOS settings.')
