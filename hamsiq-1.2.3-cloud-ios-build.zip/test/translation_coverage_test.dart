// H-06 Part 1 — translation coverage.
// (a) Every key added by the Part 1 migration exists in BOTH the Arabic
//     and English maps with a non-empty value (checked through the public
//     AppStrings.t() lookup, once per language).
// (b) Two migrated screens pump under RTL/Arabic and LTR/English and show
//     the expected language strings (QrScreen is pure; CloseFriendsScreen
//     shows its AppBar title even while its list load fails offline).
// (c) Arabic is still the default language.
// Plus a source guard: no covered screen still contains a hardcoded
// Arabic string literal (the only allowed exception is the '؟' avatar
// initial placeholder in groups_screen.dart).
//
// H-06 Part 2 — the same coverage for the remaining screens (auth,
// profile, reels, chats), the five widgets, timeAgo() and the Reel
// template names. The two auth_screen.dart literals Part 2 had to freeze
// (check_username_test.dart pinned them) were migrated by the coordinator
// once those assertions were updated; the guard now allows none.

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/models.dart';
import 'package:hamsiq/screens/auth_screen.dart';
import 'package:hamsiq/screens/chats_screen.dart';
import 'package:hamsiq/screens/close_friends_screen.dart';
import 'package:hamsiq/screens/qr_screen.dart';
import 'package:hamsiq/services/app_strings.dart';
import 'package:hamsiq/services/wave3_api.dart';
import 'package:hamsiq/theme.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// The 212 keys added by the H-06 Part 1 migration.
const _newKeys = <String>[
    'retry', 'videoPlayFailed', 'videoUploadFailed', 'fileUploadFailed', 'voiceoverUploadFailed', 'writeSomething', 'searchUser', 'searchPeopleToAdd',
    'noPostsYet', 'postSingular', 'postPlural', 'memberSingular', 'memberPlural', 'secondsUnit', 'secAbbr', 'allFilter',
    'youLabel', 'pollLabel', 'pollAction', 'cameraNoCamera', 'cameraOpenFailed', 'photoCaptureFailed', 'recordStartFailed', 'recordStopFailed',
    'cameraOpening', 'cameraDisabled', 'cameraDisabledHint', 'pickFromGallery', 'cameraNotReady', 'useGalleryInstead', 'modePhoto', 'modeVideo',
    'tapToStop60', 'tapToStartRecording', 'tapToTakePhoto', 'blendInviteSent', 'blendEndConfirm', 'myChannel', 'deleteChannelPostTitle', 'deleteChannelPostBody',
    'noMembersYet', 'closeFriendsInfo', 'inTheList', 'followSomeoneFirst', 'collabInvitedYou', 'noCollabResults', 'inviteAction', 'addedToCollection',
    'collectionCreatedAndAdded', 'saveToCollection', 'newCollectionNameHint', 'createCollection', 'noCollectionsYet', 'collectionCreated', 'newCollectionTitle', 'collectionNameHint',
    'createAction', 'savedAndCollectionsTitle', 'myCollections', 'allSaved', 'noSavedPosts', 'deleteCollectionTitle', 'deleteCollectionBody', 'deleteCollectionTooltip',
    'collectionEmpty', 'deleteDraftTitle', 'deleteDraftBody', 'scheduledCancelled', 'textDraftTooltip', 'imageDraftTooltip', 'draftsScheduleNote', 'draftsSection',
    'noDrafts', 'draftNoText', 'lastEdited', 'noScheduled', 'scheduledNoText', 'publishesAt', 'draftSaved', 'postPublished',
    'pickPublishDate', 'pickPublishTime', 'scheduledDone', 'editDraftTitle', 'publishNow', 'schedulePublish', 'scheduleNoteLong', 'blendPickFriend',
    'blendIntroLong', 'noChatsYet', 'favouritesFilter', 'noFavouritePosts', 'groupsTitle', 'createGroup', 'channelsRowHint', 'collabInvitesHint',
    'noGroupsYet', 'roleAdmin', 'roleMember', 'noMessagesYet', 'groupNameHint', 'selectedPrefix', 'noPeopleToAdd', 'searching',
    'writeMessageHint', 'published', 'newPostTitle', 'videoReadyReels', 'publishAction', 'noDataYet', 'insightsEstimateNote', 'last7Days',
    'followingStat', 'postsStat', 'totalLikesStat', 'average', 'perPost', 'storyViewsStat', 'newFollowers30', 'notAvailable',
    'bestPost', 'postNoText', 'unmuted', 'noMuted', 'snoozedUntil', 'snoozeEnded', 'mutedForever', 'unmuteAction',
    'markedAllRead', 'markAllRead', 'notifInAppOnly', 'noNotifications', 'reposted', 'repostUndone', 'unsaved', 'postPinned',
    'postUnpinned', 'addedToFavourites', 'removedFromFavourites', 'altTextHint', 'altTextSaved', 'snoozed30Done', 'mutedDone', 'postOptions',
    'removeFromFavourites', 'addToFavourites', 'muteThisAccount', 'muteAccountHint', 'collabUpTo5', 'altTextNotWritten', 'pickGif', 'gifNote',
    'commentPinned', 'commentUnpinned', 'deleteCommentTitle', 'deleteCommentBody', 'commentDeleted', 'postTitle', 'imageDescription', 'commentsClosed',
    'shareTooltip', 'repostTooltip', 'saveTooltip', 'pinTooltip', 'commentsClosedPost', 'noCommentsYet', 'replyTo', 'writeComment',
    'writeReply', 'scanQrHint', 'profileLinkCopied', 'copyLink', 'templateApplied', 'templateEditBeforePublish', 'writeTextFirst', 'micPermission',
    'reelPublished', 'createReelFromVideo', 'reelEditorIntro', 'fromGallery', 'recordVideo', 'changeVideo', 'reelDescHint', 'overlaysTitle',
    'colourLabel', 'sizeLabel', 'saveEdit', 'recordingNow', 'recordedVoiceover', 'rerecord', 'captureCamera', 'photoFromGallery',
    'videoFromGallery', 'closeFriendsStory', 'closeFriendsStoryHint', 'closeFriendsStoryPublished', 'storyPublished', 'myStory', 'deleteStoryTitle', 'deleteStoryBody',
    'addedToHighlights', 'viewsLabel', 'noViewsYet', 'replySent', 'noStories', 'addToHighlights', 'replyToStory', 'highlightEmpty',
    'storiesTitle', 'highlightsTitle', 'noHighlights', 'membersTitle',
];

/// The 122 keys added by the H-06 Part 2 migration (auth, profile,
/// reels and chats screens, the five widgets, timeAgo() units).
const _newKeysPart2 = <String>[
    'authTooManyAttempts', 'authEmailInvalid', 'authWrongCredentials', 'authNoConnection', 'genericError', 'authInvalidUsernameChars', 'authUsernameMin3', 'authWeakPassword',
    'authOtp8Digits', 'authEnterEmail', 'authResetLinkSent', 'authTagline', 'loginTab', 'signupTab', 'loginButton', 'signupButton',
    'authPasswordLabel', 'authPasswordHint', 'authForgot', 'authOtpTitle', 'authOtpSentTo', 'authOtpHint', 'authForgotTitle', 'authForgotBody',
    'authSendLink', 'addAccount', 'postsCount', 'followersStat', 'followingButton', 'followButton', 'messageButton', 'reelsTab',
    'profileLoadFailed', 'accountNotFound', 'noReelsYet', 'noCollabPostsYet', 'createReel', 'chatsTitle', 'startChat', 'viewOncePhoto',
    'viewOncePhotoHint', 'replyToMessage', 'copyText', 'textCopied', 'translateViaMyMemory', 'autoTranslateMyMemory', 'unsendForAll', 'unsendTitle',
    'unsendBody', 'deleteForEveryone', 'unsentDone', 'vanishDialogBody', 'enableAction', 'vanishBanner', 'vanishOff', 'viewProfile',
    'archiveChat', 'unarchiveChat', 'muteChat', 'unmuteChat', 'messageLabel', 'imagePlaceholder', 'imageLoadFailed', 'videoPlaceholder',
    'videoLabel', 'voiceMessagePlaceholder', 'fileLabel', 'locationLabel', 'locationWithCoords', 'contactLabel', 'viewOnceExpired', 'viewOnceVideo',
    'tapToViewOnce', 'onceBadge', 'voicePlayFailed', 'imageLoadFailedPlain', 'stopRecordingAndSend', 'recordVoiceMessage', 'recordingReleaseHint', 'replyToSelf',
    'byteUnit', 'kbUnit', 'mbUnit', 'accountCapMessage', 'commentsTitle', 'commentsLoadFailed', 'pinnedBadge', 'replyAction',
    'pinComment', 'unpinComment', 'pollLoadFailed', 'percentSuffix', 'pollNoVotesYet', 'pollVoteSingular', 'pollVotePlural', 'pollTapToChangeVote',
    'pollNeedQuestionAndOptions', 'newPollTitle', 'pollQuestionHint', 'pollOptionLabel', 'pollAddOption', 'pollCreate', 'noRepostsYet', 'collectionsEntryTitle',
    'collectionSingular', 'collectionPlural', 'gridOrderSaved', 'noPostsToReorder', 'pinnedStaysTop', 'sharedPostLoadFailed', 'tapToOpenPost', 'storyReplyLabel',
    'sharedWith', 'sharePostTitle', 'searchPersonHint', 'noFollowingToShare', 'noResultsFor', 'sendAction', 'timeNow', 'timeMin',
    'timeHour', 'timeDay',
];

const _coveredScreens = [
  'auth_screen.dart',
  'blend_screen.dart',
  'camera_screen.dart',
  'channels_screen.dart',
  'chats_screen.dart',
  'close_friends_screen.dart',
  'collab_invites_screen.dart',
  'collections_screen.dart',
  'drafts_screen.dart',
  'feed_screen.dart',
  'groups_screen.dart',
  'home_shell.dart',
  'insights_screen.dart',
  'muted_accounts_screen.dart',
  'notifications_screen.dart',
  'post_detail_screen.dart',
  'profile_screen.dart',
  'qr_screen.dart',
  'reels_editor_screen.dart',
  'reels_screen.dart',
  'settings_screen.dart',
  'stories_screen.dart',
];

/// The five widgets migrated in H-06 Part 2 (scanned in lib/widgets/).
const _coveredWidgets = [
  'account_switcher_sheet.dart',
  'comments_sheet.dart',
  'poll_card.dart',
  'profile_extra_tabs.dart',
  'shared_post_card.dart',
];

/// Literals the source guard still allows, per file. None anymore: the
/// two auth_screen.dart literals frozen by H-06 Part 2 were migrated by
/// the coordinator once check_username_test.dart stopped pinning them.
const _allowedLiterals = <String, Set<String>>{};

final _testProfile = HamsiqProfile(
  id: 'test-user',
  username: 'testuser',
  displayName: 'Test User',
  avatar: '😀',
  bio: '',
  verified: false,
  isAdmin: false,
  approved: true,
  isPrivate: false,
);

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
  });

  setUp(() => AppStrings.lang.value = 'ar');
  tearDown(() => AppStrings.lang.value = 'ar');

  group('H-06 Part 1: every new key exists in both languages', () {
    test('all 212 new keys resolve to non-empty strings in ar and en', () {
      expect(_newKeys.length, 212);
      for (final key in _newKeys) {
        AppStrings.lang.value = 'ar';
        final ar = AppStrings.t(key);
        expect(ar, isNotEmpty, reason: 'ar[$key]');
        expect(ar, isNot(key), reason: 'ar[$key] fell back to the key');

        AppStrings.lang.value = 'en';
        final en = AppStrings.t(key);
        expect(en, isNotEmpty, reason: 'en[$key]');
        expect(en, isNot(key), reason: 'en[$key] fell back to the key');
      }
    });

    test('the two languages actually differ for the new keys', () {
      var same = <String>[];
      for (final key in _newKeys) {
        AppStrings.lang.value = 'ar';
        final ar = AppStrings.t(key);
        AppStrings.lang.value = 'en';
        if (AppStrings.t(key) == ar) same.add(key);
      }
      expect(same, isEmpty, reason: 'keys identical in ar and en: $same');
    });
  });

  group('H-06 Part 1: Arabic is still the default', () {
    test('defaultLang is ar and a fresh lookup is Arabic', () {
      expect(AppStrings.defaultLang, 'ar');
      expect(AppStrings.supported, contains('ar'));
      expect(AppStrings.supported, contains('en'));
      AppStrings.lang.value = 'ar';
      expect(AppStrings.isArabic, isTrue);
      expect(AppStrings.t('titleSettings'), 'الإعدادات');
      expect(AppStrings.t('retry'), 'إعادة المحاولة');
    });
  });

  group('H-06 Part 1: migrated screens render in both languages', () {
    Future<void> pumpQr(WidgetTester tester) async {
      // QrScreen's content is ~513px tall plus the AppBar, so it
      // overflows the default 800x600 test surface by 17px. That is a
      // pre-existing test-surface limit, not a translation issue: give
      // the test a phone-tall surface instead of changing the screen.
      tester.view.physicalSize = const Size(800, 1200);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(
        MaterialApp(
          home: Directionality(
            textDirection: AppStrings.isArabic
                ? TextDirection.rtl
                : TextDirection.ltr,
            child: QrScreen(profile: _testProfile),
          ),
        ),
      );
      await tester.pump();
    }

    Future<void> pumpCloseFriends(WidgetTester tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Directionality(
            textDirection: AppStrings.isArabic
                ? TextDirection.rtl
                : TextDirection.ltr,
            child: const CloseFriendsScreen(),
          ),
        ),
      );
      // The list load hits the network and fails offline; the AppBar
      // title is visible regardless. Do NOT pumpAndSettle (the failed
      // request can leave pending timers).
      await tester.pump(const Duration(milliseconds: 100));
    }

    testWidgets('QrScreen in Arabic (RTL)', (tester) async {
      AppStrings.lang.value = 'ar';
      await pumpQr(tester);
      expect(find.text('رمز QR للملف الشخصي'), findsOneWidget);
      expect(find.text('امسح الرمز لفتح الملف الشخصي'), findsOneWidget);
      expect(find.text('نسخ الرابط'), findsOneWidget);
    });

    testWidgets('QrScreen in English (LTR)', (tester) async {
      AppStrings.lang.value = 'en';
      await pumpQr(tester);
      expect(find.text('Profile QR code'), findsOneWidget);
      expect(find.text('Scan the code to open the profile'), findsOneWidget);
      expect(find.text('Copy link'), findsOneWidget);
    });

    testWidgets('CloseFriendsScreen title in Arabic (RTL)', (tester) async {
      AppStrings.lang.value = 'ar';
      await pumpCloseFriends(tester);
      expect(find.text('الأصدقاء المقرّبون'), findsOneWidget);
    });

    testWidgets('CloseFriendsScreen title in English (LTR)', (tester) async {
      AppStrings.lang.value = 'en';
      await pumpCloseFriends(tester);
      expect(find.text('Close Friends'), findsOneWidget);
    });
  });

  group('H-06 Part 1: no hardcoded Arabic literals left in covered screens',
      () {
    test('covered screens + widgets have no Arabic string literal except the allowed ones',
        () {
      // Single- or double-quoted literals containing an Arabic character.
      final arabicLiteral = RegExp(
          r'''('[^'\n]*[\u0600-\u06FF][^'\n]*'|"[^"\n]*[\u0600-\u06FF][^"\n]*")''');
      for (final file in _coveredScreens) {
        final path = 'lib/screens/$file';
        final src = File(path).readAsStringSync();
        final hits = arabicLiteral
            .allMatches(src)
            .map((m) => m.group(0)!)
            .toList();
        final allowed = _allowedLiterals[path] ?? {"'؟'"};
        final unexpected =
            hits.where((h) => !allowed.contains(h)).toList();
        expect(unexpected, isEmpty,
            reason: '$path still has hardcoded Arabic literals: $unexpected');
      }
      for (final file in _coveredWidgets) {
        final path = 'lib/widgets/$file';
        final src = File(path).readAsStringSync();
        final hits = arabicLiteral
            .allMatches(src)
            .map((m) => m.group(0)!)
            .toList();
        final unexpected =
            hits.where((h) => h != "'؟'").toList();
        expect(unexpected, isEmpty,
            reason: '$path still has hardcoded Arabic literals: $unexpected');
      }
    });
  });

  group('H-06 Part 2: every new key exists in both languages', () {
  test('all 122 new keys resolve to non-empty strings in ar and en', () {
    expect(_newKeysPart2.length, 122);
    for (final key in _newKeysPart2) {
      AppStrings.lang.value = 'ar';
      final ar = AppStrings.t(key);
      expect(ar, isNotEmpty, reason: 'ar[$key]');
      expect(ar, isNot(key), reason: 'ar[$key] fell back to the key');

      AppStrings.lang.value = 'en';
      final en = AppStrings.t(key);
      expect(en, isNotEmpty, reason: 'en[$key]');
      expect(en, isNot(key), reason: 'en[$key] fell back to the key');
    }
  });

  test('the two languages actually differ for the new keys', () {
    var same = <String>[];
    for (final key in _newKeysPart2) {
      AppStrings.lang.value = 'ar';
      final ar = AppStrings.t(key);
      AppStrings.lang.value = 'en';
      if (AppStrings.t(key) == ar) same.add(key);
    }
    expect(same, isEmpty, reason: 'keys identical in ar and en: $same');
  });

  test('placeholder keys keep their placeholders in both languages', () {
    AppStrings.lang.value = 'ar';
    expect(AppStrings.t('authOtpSentTo'), contains('{email}'));
    expect(AppStrings.t('locationWithCoords'), contains('{lat}'));
    expect(AppStrings.t('locationWithCoords'), contains('{lng}'));
    expect(AppStrings.t('sharedWith'), contains('{name}'));
    expect(AppStrings.t('noResultsFor'), contains('{query}'));
    expect(AppStrings.t('timeMin'), contains('{n}'));
    AppStrings.lang.value = 'en';
    expect(AppStrings.t('authOtpSentTo'), contains('{email}'));
    expect(AppStrings.t('locationWithCoords'), contains('{lat}'));
    expect(AppStrings.t('sharedWith'), contains('{name}'));
    expect(AppStrings.t('noResultsFor'), contains('{query}'));
    expect(AppStrings.t('timeMin'), contains('{n}'));
    // And the placeholders actually fill in.
    AppStrings.lang.value = 'ar';
    expect(
        AppStrings.t('authOtpSentTo').replaceAll('{email}', 'a@b.c'),
        'أُرسل رمز من 8 أرقام إلى a@b.c');
    expect(
        AppStrings.t('locationWithCoords')
            .replaceAll('{lat}', '33.31')
            .replaceAll('{lng}', '44.36'),
        '📍 الموقع: 33.31، 44.36');
  });
});

group('H-06 Part 2: timeAgo renders in the current language', () {
  test('relative times are Arabic in ar, English in en', () {
    final now = DateTime.now();
    AppStrings.lang.value = 'ar';
    expect(timeAgo(now.subtract(const Duration(seconds: 30))), 'الآن');
    expect(timeAgo(now.subtract(const Duration(minutes: 5))), '5 د');
    expect(timeAgo(now.subtract(const Duration(hours: 2))), '2 س');
    expect(timeAgo(now.subtract(const Duration(days: 3))), '3 ي');
    final old = DateTime(2026, 1, 2);
    expect(timeAgo(old), '2/1/2026');

    AppStrings.lang.value = 'en';
    expect(timeAgo(now.subtract(const Duration(seconds: 30))), 'Now');
    expect(timeAgo(now.subtract(const Duration(minutes: 5))), '5 min');
    expect(timeAgo(now.subtract(const Duration(hours: 2))), '2 h');
    expect(timeAgo(now.subtract(const Duration(days: 3))), '3 d');
    expect(timeAgo(old), '2/1/2026');
  });
});

group('H-06 Part 2: Reel template names follow the language', () {
  test('template name is Arabic in ar, English in en; nameAr never changes',
      () {
    final title = templateById('title')!;
    AppStrings.lang.value = 'ar';
    expect(title.nameAr, 'عنوان وخاتمة');
    expect(title.name, 'عنوان وخاتمة');
    AppStrings.lang.value = 'en';
    expect(title.nameAr, 'عنوان وخاتمة');
    expect(title.name, 'Title & outro');
    expect(templateById('quote')!.name, 'Quote');
    expect(templateById('before_after')!.name, 'Before / After');
    AppStrings.lang.value = 'ar';
    expect(templateById('quote')!.name, 'اقتباس');
    expect(templateById('before_after')!.name, 'قبل / بعد');
  });
});

group('H-06 Part 2: migrated screens render in both languages', () {
  Future<void> pumpAuth(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Directionality(
          textDirection: AppStrings.isArabic
              ? TextDirection.rtl
              : TextDirection.ltr,
          child: AuthScreen(onAuthed: () {}),
        ),
      ),
    );
    await tester.pump();
  }

  Future<void> pumpChats(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Directionality(
          textDirection: AppStrings.isArabic
              ? TextDirection.rtl
              : TextDirection.ltr,
          child: const ChatsScreen(),
        ),
      ),
    );
    // The chat list load fails offline (no Supabase in tests); the
    // list then renders its empty state. Do NOT pumpAndSettle.
    await tester.pump(const Duration(milliseconds: 100));
    await tester.pump(const Duration(milliseconds: 100));
  }

  testWidgets('AuthScreen in Arabic (RTL)', (tester) async {
    AppStrings.lang.value = 'ar';
    await pumpAuth(tester);
    expect(find.text('مرحباً بعودتك'), findsOneWidget);
    expect(find.text('سجّل دخولك للمتابعة إلى همسيق'), findsOneWidget);
    // Mockup-match: 'تسجيل الدخول' is both the toggle's active half
    // and the login button.
    expect(find.text('تسجيل الدخول'), findsNWidgets(2));
    expect(find.text('أنشئ حساب جديد'), findsOneWidget);
    expect(find.text('نسيت كلمة المرور؟'), findsOneWidget);
  });

  testWidgets('AuthScreen in English (LTR)', (tester) async {
    AppStrings.lang.value = 'en';
    await pumpAuth(tester);
    expect(find.text('Welcome back'), findsOneWidget);
    expect(find.text('Sign in to continue to Hamsiq'), findsOneWidget);
    expect(find.text('Sign in'), findsNWidgets(2));
    expect(find.text('Create a new account'), findsOneWidget);
    expect(find.text('Forgot your password?'), findsOneWidget);
  });

  testWidgets('AuthScreen rebuilds live when the language changes',
      (tester) async {
    AppStrings.lang.value = 'ar';
    await pumpAuth(tester);
    expect(find.text('تسجيل الدخول'), findsNWidgets(2));
    AppStrings.lang.value = 'en';
    await tester.pump();
    expect(find.text('Sign in'), findsNWidgets(2));
    expect(find.text('تسجيل الدخول'), findsNothing);
    AppStrings.lang.value = 'ar';
    await tester.pump();
    expect(find.text('تسجيل الدخول'), findsNWidgets(2));
  });

  testWidgets('ChatsScreen in Arabic (RTL)', (tester) async {
    AppStrings.lang.value = 'ar';
    await pumpChats(tester);
    expect(find.text('الرسائل المباشرة'), findsOneWidget);
    expect(find.text('لا توجد محادثات بعد'), findsOneWidget);
  });

  testWidgets('ChatsScreen in English (LTR)', (tester) async {
    AppStrings.lang.value = 'en';
    await pumpChats(tester);
    expect(find.text('Direct Messages'), findsOneWidget);
    expect(find.text('No chats yet'), findsOneWidget);
  });

  testWidgets('ChatsScreen rebuilds live when the language changes',
      (tester) async {
    AppStrings.lang.value = 'ar';
    await pumpChats(tester);
    expect(find.text('الرسائل المباشرة'), findsOneWidget);
    AppStrings.lang.value = 'en';
    await tester.pump();
    expect(find.text('Direct Messages'), findsOneWidget);
    expect(find.text('الرسائل المباشرة'), findsNothing);
  });
});
}
