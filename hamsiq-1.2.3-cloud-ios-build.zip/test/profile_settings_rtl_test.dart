// v1.2.1: profile cleanup (7 rows moved to Settings), compact
// Instagram-style profile action buttons, and login-screen RTL.
// The profile-screen and settings-screen checks are source
// assertions: pumping ProfileScreen would hit the network, so the
// test reads the source files and asserts each row lives in exactly
// one place. The buttons and the RTL direction are widget tests.
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/main.dart';
import 'package:hamsiq/screens/profile_screen.dart';
import 'package:hamsiq/services/supabase_service.dart';
import 'package:hamsiq/theme.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: Api.supabaseUrl,
      publishableKey: Api.supabaseAnonKey,
    );
  });

  group('profile cleanup (source assertions)', () {
    late String profileSrc;
    late String settingsSrc;

    setUpAll(() {
      profileSrc =
          File('lib/screens/profile_screen.dart').readAsStringSync();
      settingsSrc =
          File('lib/screens/settings_screen.dart').readAsStringSync();
    });

    // The 7 rows removed from the profile screen (Arabic labels as
    // they appeared there).
    const removedRows = [
      'المجموعات والمحفوظات',
      'إعادة ترتيب الشبكة',
      'المسودات والمنشورات المجدولة',
      'الأصدقاء المقرّبون',
      'الحسابات المكتومة',
      'رمز QR للملف الشخصي',
      'الإحصائيات',
    ];

    test('profile screen no longer contains any of the 7 rows', () {
      for (final row in removedRows) {
        expect(profileSrc, isNot(contains(row)), reason: row);
      }
      expect(profileSrc, isNot(contains('_ownExtras')));
      expect(profileSrc, isNot(contains('CollectionsEntry')));
      // The profile body keeps only header/stats/actions/tabs/grid.
      expect(profileSrc, contains('OwnProfileActions'));
    });

    test('settings screen contains all 7 relocated rows', () {
      // Each row is reachable in Settings via its AppStrings key.
      const settingsKeys = [
        'titleCollections',
        'gridReorder',
        'titleDrafts',
        'titleCloseFriends',
        'titleMutedAccounts',
        'titleQr',
        'titleInsights',
      ];
      for (final key in settingsKeys) {
        expect(settingsSrc, contains(key), reason: key);
      }
      expect(settingsSrc, contains('secContent'));
    });
  });

  testWidgets('own-profile actions are two compact buttons side by side: '
      'blue filled edit, outlined share', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: Scaffold(
          body: OwnProfileActions(onEdit: () {}, onShare: () {}),
        ),
      ),
    );
    await tester.pump();

    expect(OwnProfileActions.buttonHeight, 34);
    final edit = tester.widget<ElevatedButton>(
      find.widgetWithText(ElevatedButton, 'تعديل الملف الشخصي'),
    );
    final share = tester.widget<OutlinedButton>(
      find.widgetWithText(OutlinedButton, 'مشاركة الملف الشخصي'),
    );
    // Mockup round: edit is the blue filled button, share is outlined
    // in accent blue — not the old dark Instagram-style pair.
    expect(edit.style?.backgroundColor?.resolve({}), HamsiqTheme.accent);
    expect(
      share.style?.side?.resolve({}),
      const BorderSide(color: HamsiqTheme.accent, width: 1.5),
    );
    // Side by side on the same row.
    final editY = tester
        .getTopLeft(
          find.widgetWithText(ElevatedButton, 'تعديل الملف الشخصي'),
        )
        .dy;
    final shareY =
        tester.getTopLeft(find.widgetWithText(OutlinedButton, 'مشاركة الملف الشخصي')).dy;
    expect(editY, shareY);
    // Compact height.
    expect(
      tester
          .getSize(find.widgetWithText(ElevatedButton, 'تعديل الملف الشخصي'))
          .height,
      34,
    );
  });

  testWidgets('login screen is RTL when the language is Arabic',
      (tester) async {
    await tester.pumpWidget(const HamsiqApp());
    await tester.pump(const Duration(seconds: 1));
    await tester.pump(const Duration(seconds: 1));

    expect(find.text('نسيت كلمة المرور؟'), findsOneWidget);
    // A Directionality wrapping the login screen is RTL.
    final directions = find
        .ancestor(
          of: find.text('نسيت كلمة المرور؟'),
          matching: find.byType(Directionality),
        )
        .evaluate()
        .map((e) => (e.widget as Directionality).textDirection);
    expect(directions, contains(TextDirection.rtl));
    // Mockup login design (user order 2026-11-16): the "forgot
    // password" link uses a directional START alignment, so it sits
    // on the RIGHT in Arabic (the mockup's start-side link), mirrored
    // to the left in English.
    final alignments = find
        .ancestor(
          of: find.text('نسيت كلمة المرور؟'),
          matching: find.byType(Align),
        )
        .evaluate()
        .map((e) => (e.widget as Align).alignment);
    expect(alignments, contains(AlignmentDirectional.centerStart));
    // ...and it actually renders on the right half of the screen.
    final center = tester.getCenter(find.text('نسيت كلمة المرور؟'));
    expect(center.dx, greaterThan(400));
  });
}
