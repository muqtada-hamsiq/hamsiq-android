// Hamsiq native — push notifications tests.
//
// Everything runs against fakes: no real FCM, no real local
// notifications, no Supabase. Covers the data-payload contract,
// permission paths (granted / denied / never-ask-again), token
// upsert + refresh + sign-out delete, foreground suppression, the
// background handler composition, tap routing, init failure
// (app still boots), and the ar+en strings.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/services/app_strings.dart';
import 'package:hamsiq/services/push_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _Shown {
  final int id;
  final String title;
  final String body;
  final String? payload;

  const _Shown({
    required this.id,
    required this.title,
    required this.body,
    this.payload,
  });
}

class FakeMessaging implements PushMessagingBackend {
  PushPermissionStatus permissionResult = PushPermissionStatus.granted;
  int requestPermissionCalls = 0;
  String? token;
  Map<String, dynamic>? initialMessage;

  final _tokenRefresh = StreamController<String>();
  final _onMessage = StreamController<Map<String, dynamic>>();
  final _onMessageOpenedApp = StreamController<Map<String, dynamic>>();

  @override
  Future<PushPermissionStatus> requestPermission() async {
    requestPermissionCalls++;
    return permissionResult;
  }

  @override
  Future<String?> getToken() async => token;

  @override
  Stream<String> get onTokenRefresh => _tokenRefresh.stream;

  @override
  Stream<Map<String, dynamic>> get onMessage => _onMessage.stream;

  @override
  Stream<Map<String, dynamic>> get onMessageOpenedApp =>
      _onMessageOpenedApp.stream;

  @override
  Future<Map<String, dynamic>?> getInitialMessage() async => initialMessage;

  void emitMessage(Map<String, dynamic> data) => _onMessage.add(data);
  void emitOpenedApp(Map<String, dynamic> data) =>
      _onMessageOpenedApp.add(data);
  void emitTokenRefresh(String value) => _tokenRefresh.add(value);

  Future<void> close() async {
    // Do NOT await the closes: a single-subscription controller that
    // was never listened to never completes its close future (the done
    // event waits for a listener that never attaches) — awaiting would
    // hang the init-failure tests, whose init() returns before
    // subscribing to these streams.
    unawaited(_tokenRefresh.close());
    unawaited(_onMessage.close());
    unawaited(_onMessageOpenedApp.close());
  }
}

class FakeLocal implements PushLocalNotifications {
  bool enabled = false;
  bool initialized = false;
  final List<_Shown> shown = [];

  @override
  Future<void> initialize({
    required void Function(String? payload) onTap,
  }) async {
    initialized = true;
  }

  @override
  Future<void> show({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    shown.add(_Shown(id: id, title: title, body: body, payload: payload));
  }

  @override
  Future<bool?> areNotificationsEnabled() async => enabled;
}

class FakeTokens implements DeviceTokenStore {
  final List<Map<String, String>> upserts = [];
  final List<String> deletedTokens = [];
  final List<String> deletedUsers = [];

  @override
  Future<void> upsert({required String userId, required String token}) async {
    upserts.add({'user_id': userId, 'token': token});
  }

  @override
  Future<void> deleteToken(String token) async {
    deletedTokens.add(token);
  }

  @override
  Future<void> deleteForUser(String userId) async {
    deletedUsers.add(userId);
  }
}

class FakeNavigator implements PushNavigator {
  final List<PushRoute> opened = [];

  @override
  Future<void> openRoute(PushRoute route) async {
    opened.add(route);
  }
}

class FakeSettingsOpener implements PushSettingsOpener {
  int opens = 0;

  @override
  Future<void> openNotificationSettings() async {
    opens++;
  }
}

class FakeAskedStore implements PushAskedStore {
  bool asked = false;

  @override
  Future<bool> wasAsked() async => asked;

  @override
  Future<void> markAsked() async {
    asked = true;
  }
}

const _dmData = <String, dynamic>{
  'type': 'message',
  'sender_id': 'sender-1',
  'sender_name': 'Sara',
  'chat_type': 'dm',
  'thread_peer_id': 'peer-1',
  'message_id': 'msg-1',
  'preview': 'hello there',
  'message_kind': 'text',
};

const _groupData = <String, dynamic>{
  'type': 'message',
  'sender_id': 'sender-2',
  'sender_name': 'Omar',
  'chat_type': 'group',
  'group_id': '42',
  'message_id': 'msg-2',
  'preview': 'see you there',
  'message_kind': 'text',
};

const _callData = <String, dynamic>{
  'type': 'call_invite',
  'sender_id': 'sender-1',
  'sender_name': 'Sara',
  'chat_type': 'dm',
  'thread_peer_id': 'peer-1',
  'call_id': 'call-9',
};

PushService _service({
  FakeMessaging? messaging,
  FakeLocal? local,
  FakeTokens? tokens,
  FakeNavigator? navigator,
  FakeSettingsOpener? settingsOpener,
  FakeAskedStore? askedStore,
  String? currentUserId,
}) {
  return PushService.forTest(
    messaging: messaging,
    local: local,
    tokens: tokens,
    navigator: navigator,
    settingsOpener: settingsOpener,
    askedStore: askedStore,
    currentUserId: currentUserId,
  );
}

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    await AppStrings.load();
  });

  setUp(() {
    AppStrings.lang.value = 'ar';
  });

  group('payload contract', () {
    test('parses every contract field, group id as string', () {
      final p = PushPayload.fromData(_groupData);
      expect(p.type, 'message');
      expect(p.senderId, 'sender-2');
      expect(p.senderName, 'Omar');
      expect(p.chatType, 'group');
      expect(p.groupId, 42);
      expect(p.messageId, 'msg-2');
      expect(p.preview, 'see you there');
      expect(p.messageKind, 'text');
      expect(p.callId, isNull);
    });

    test('missing optional fields fall back to defaults', () {
      final p = PushPayload.fromData({'sender_name': 'Sara'});
      expect(p.type, 'message');
      expect(p.chatType, 'dm');
      expect(p.messageKind, 'text');
      expect(p.threadPeerId, isNull);
      expect(p.groupId, isNull);
      expect(p.preview, isNull);
    });

    test('non-numeric group id parses to null instead of throwing', () {
      final p = PushPayload.fromData({'chat_type': 'group', 'group_id': 'x'});
      expect(p.groupId, isNull);
    });
  });

  group('route mapping', () {
    test('dm payload routes to the peer', () {
      expect(
        PushRoute.fromPayload(PushPayload.fromData(_dmData)),
        const PushRoute.dm('peer-1'),
      );
    });

    test('group payload routes to the group', () {
      expect(
        PushRoute.fromPayload(PushPayload.fromData(_groupData)),
        const PushRoute.group(42),
      );
    });

    test('call invite routes to the call with its sender', () {
      final route = PushRoute.fromPayload(PushPayload.fromData(_callData));
      expect(route, isNotNull);
      expect(route!.kind, 'call');
      expect(route.callId, 'call-9');
      expect(route.senderId, 'sender-1');
    });

    test('payloads without a target route to null', () {
      expect(
        PushRoute.fromPayload(PushPayload.fromData({'type': 'message'})),
        isNull,
      );
      expect(
        PushRoute.fromPayload(
          PushPayload.fromData({'type': 'call_invite'}),
        ),
        isNull,
      );
      expect(
        PushRoute.fromPayload(
          PushPayload.fromData({'type': 'message', 'chat_type': 'group'}),
        ),
        isNull,
      );
    });

    test('routes compare by kind + target', () {
      expect(
        const PushRoute.dm('a'),
        isNot(const PushRoute.dm('b')),
      );
      expect(const PushRoute.dm('a'), const PushRoute.dm('a'));
      expect(
        const PushRoute.group(1),
        isNot(const PushRoute.dm('1')),
      );
    });
  });

  group('notification composition', () {
    test('text message uses the sender name and preview', () {
      final c = composeNotificationContent(PushPayload.fromData(_dmData));
      expect(c.title, 'Sara');
      expect(c.body, 'hello there');
    });

    test('text message without preview falls back to the new-message label',
        () {
      final c = composeNotificationContent(
        PushPayload.fromData({'sender_name': 'Sara', 'message_kind': 'text'}),
      );
      expect(c.body, AppStrings.t('pushNewMessage'));
    });

    test('media kinds use localized labels, never the raw preview', () {
      for (final entry in {
        'image': 'imagePlaceholder',
        'voice': 'voiceMessagePlaceholder',
        'video': 'videoPlaceholder',
        'file': 'fileLabel',
      }.entries) {
        final c = composeNotificationContent(
          PushPayload.fromData({
            'sender_name': 'Sara',
            'message_kind': entry.key,
            'preview': 'should not show',
          }),
        );
        expect(c.body, AppStrings.t(entry.value));
      }
    });

    test('call invite body is the localized incoming-call label', () {
      final c = composeNotificationContent(PushPayload.fromData(_callData));
      expect(c.title, 'Sara');
      expect(c.body, AppStrings.t('pushIncomingCall'));
    });

    test('missing sender name falls back to the app name', () {
      final c = composeNotificationContent(
        PushPayload.fromData({'message_kind': 'text', 'preview': 'hi'}),
      );
      expect(c.title, AppStrings.t('appName'));
    });

    test('notification id is stable per message and non-zero', () {
      final p = PushPayload.fromData(_dmData);
      expect(pushNotificationId(p), pushNotificationId(p));
      expect(pushNotificationId(p), isNot(0));
      expect(
        pushNotificationId(PushPayload.fromData(_dmData)),
        isNot(pushNotificationId(PushPayload.fromData(_groupData))),
      );
    });
  });

  group('permission', () {
    test('granted maps through and updates the status notifier', () async {
      final messaging = FakeMessaging();
      final svc = _service(messaging: messaging);
      await svc.init();
      expect(await svc.requestPermission(), PushPermissionStatus.granted);
      expect(svc.permissionStatus.value, PushPermissionStatus.granted);
      await messaging.close();
    });

    test('first denial stays denied (dialog may still be shown again)',
        () async {
      final messaging = FakeMessaging()
        ..permissionResult = PushPermissionStatus.denied;
      final asked = FakeAskedStore()..asked = false;
      final svc = _service(messaging: messaging, askedStore: asked);
      await svc.init();
      expect(await svc.requestPermission(), PushPermissionStatus.denied);
      expect(svc.permissionStatus.value, PushPermissionStatus.denied);
      expect(asked.asked, isTrue);
      await messaging.close();
    });

    test('denial after a previous ask is permanently denied', () async {
      final messaging = FakeMessaging()
        ..permissionResult = PushPermissionStatus.denied;
      final asked = FakeAskedStore()..asked = true;
      final svc = _service(messaging: messaging, askedStore: asked);
      await svc.init();
      expect(
        await svc.requestPermission(),
        PushPermissionStatus.permanentlyDenied,
      );
      await messaging.close();
    });

    test('backend permanently-denied maps straight through', () async {
      final messaging = FakeMessaging()
        ..permissionResult = PushPermissionStatus.permanentlyDenied;
      final svc = _service(messaging: messaging);
      await svc.init();
      expect(
        await svc.requestPermission(),
        PushPermissionStatus.permanentlyDenied,
      );
      await messaging.close();
    });

    test('not-determined passes through', () async {
      final messaging = FakeMessaging()
        ..permissionResult = PushPermissionStatus.notDetermined;
      final svc = _service(messaging: messaging);
      await svc.init();
      expect(
        await svc.requestPermission(),
        PushPermissionStatus.notDetermined,
      );
      await messaging.close();
    });

    test('already-enabled notifications short-circuit to granted', () async {
      final messaging = FakeMessaging()
        ..permissionResult = PushPermissionStatus.denied;
      final local = FakeLocal()..enabled = true;
      final svc = _service(messaging: messaging, local: local);
      await svc.init();
      expect(await svc.requestPermission(), PushPermissionStatus.granted);
      expect(messaging.requestPermissionCalls, 0);
      await messaging.close();
    });
  });

  group('settings entry', () {
    test('permanently denied opens system settings without re-asking',
        () async {
      final messaging = FakeMessaging()
        ..permissionResult = PushPermissionStatus.denied;
      final opener = FakeSettingsOpener();
      final asked = FakeAskedStore()..asked = true;
      final svc = _service(
        messaging: messaging,
        settingsOpener: opener,
        askedStore: asked,
      );
      await svc.init();
      svc.permissionStatus.value = PushPermissionStatus.permanentlyDenied;
      await svc.requestPermissionFromSettings();
      expect(opener.opens, 1);
      expect(messaging.requestPermissionCalls, 0);
      await messaging.close();
    });

    test('denied (not permanent) re-asks; permanent result opens settings',
        () async {
      final messaging = FakeMessaging()
        ..permissionResult = PushPermissionStatus.denied;
      final opener = FakeSettingsOpener();
      final asked = FakeAskedStore()..asked = true;
      final svc = _service(
        messaging: messaging,
        settingsOpener: opener,
        askedStore: asked,
      );
      await svc.init();
      await svc.requestPermissionFromSettings();
      expect(messaging.requestPermissionCalls, 1);
      expect(opener.opens, 1);
      await messaging.close();
    });

    test('granted from settings does not open system settings', () async {
      final messaging = FakeMessaging();
      final opener = FakeSettingsOpener();
      final svc = _service(messaging: messaging, settingsOpener: opener);
      await svc.init();
      await svc.requestPermissionFromSettings();
      expect(opener.opens, 0);
      await messaging.close();
    });

    test('subtitle key follows availability and status', () async {
      final messaging = FakeMessaging();
      final svc = _service(messaging: messaging);
      await svc.init();
      svc.permissionStatus.value = PushPermissionStatus.granted;
      expect(svc.statusSubtitleKey(), 'pushEnabled');
      svc.permissionStatus.value = PushPermissionStatus.permanentlyDenied;
      expect(svc.statusSubtitleKey(), 'pushDeniedSettings');
      svc.permissionStatus.value = PushPermissionStatus.denied;
      expect(svc.statusSubtitleKey(), 'pushDisabled');
      svc.permissionStatus.value = null;
      expect(svc.statusSubtitleKey(), 'pushDisabled');
      await messaging.close();
    });
  });

  group('token registration', () {
    test('upserts token for the signed-in user, once per token', () async {
      final messaging = FakeMessaging()..token = 'tok-1';
      final tokens = FakeTokens();
      final svc = _service(
        messaging: messaging,
        tokens: tokens,
        currentUserId: 'user-1',
      );
      await svc.init();
      await svc.registerToken();
      await svc.registerToken();
      expect(tokens.upserts, [
        {'user_id': 'user-1', 'token': 'tok-1'},
      ]);
      await messaging.close();
    });

    test('no user or no token means no upsert', () async {
      final messaging = FakeMessaging()..token = 'tok-1';
      final tokens = FakeTokens();
      final noUser = _service(messaging: messaging, tokens: tokens);
      await noUser.init();
      await noUser.registerToken();
      expect(tokens.upserts, isEmpty);

      final noToken = _service(
        messaging: FakeMessaging(),
        tokens: tokens,
        currentUserId: 'user-1',
      );
      await noToken.init();
      await noToken.registerToken();
      expect(tokens.upserts, isEmpty);
      await messaging.close();
    });

    test('token refresh deletes the old row and upserts the new one',
        () async {
      final messaging = FakeMessaging()..token = 'tok-1';
      final tokens = FakeTokens();
      final svc = _service(
        messaging: messaging,
        tokens: tokens,
        currentUserId: 'user-1',
      );
      await svc.init();
      await svc.registerToken();
      messaging.emitTokenRefresh('tok-2');
      await Future<void>.delayed(const Duration(milliseconds: 50));
      expect(tokens.deletedTokens, ['tok-1']);
      expect(tokens.upserts.last, {'user_id': 'user-1', 'token': 'tok-2'});
      await messaging.close();
    });

    test('sign-out deletes the token row', () async {
      final messaging = FakeMessaging()..token = 'tok-1';
      final tokens = FakeTokens();
      final svc = _service(
        messaging: messaging,
        tokens: tokens,
        currentUserId: 'user-1',
      );
      await svc.init();
      await svc.registerToken();
      await svc.unregisterToken();
      expect(tokens.deletedTokens, ['tok-1']);
      // Second sign-out is a no-op (nothing cached anymore).
      await svc.unregisterToken();
      expect(tokens.deletedTokens, ['tok-1']);
      await messaging.close();
    });

    test('sign-out with nothing cached is a no-op', () async {
      final messaging = FakeMessaging();
      final tokens = FakeTokens();
      final svc = _service(
        messaging: messaging,
        tokens: tokens,
        currentUserId: 'user-1',
      );
      await svc.init();
      // No token was ever registered in-memory, so there is nothing to
      // delete and no user-level delete either (the token row is the
      // unit of deletion; deleteForUser is only a fallback).
      await svc.unregisterToken();
      expect(tokens.deletedTokens, isEmpty);
      expect(tokens.deletedUsers, isEmpty);
      await messaging.close();
    });
  });

  group('foreground + background', () {
    test('shows a local notification for a thread the user is not viewing',
        () async {
      final messaging = FakeMessaging();
      final local = FakeLocal();
      final svc = _service(messaging: messaging, local: local);
      await svc.init();
      await svc.handleForegroundMessage(_dmData);
      expect(local.shown, hasLength(1));
      expect(local.shown.first.title, 'Sara');
      expect(local.shown.first.body, 'hello there');
      expect(local.shown.first.payload, contains('peer-1'));
      await messaging.close();
    });

    test('suppresses the banner for the thread already on screen', () async {
      final messaging = FakeMessaging();
      final local = FakeLocal();
      final svc = _service(messaging: messaging, local: local);
      await svc.init();
      svc.setActiveThread(const PushRoute.dm('peer-1'));
      await svc.handleForegroundMessage(_dmData);
      expect(local.shown, isEmpty);
      // A different thread still shows.
      await svc.handleForegroundMessage(_groupData);
      expect(local.shown, hasLength(1));
      // Leaving the thread re-enables its banner.
      svc.clearActiveThread(const PushRoute.dm('peer-1'));
      await svc.handleForegroundMessage(_dmData);
      expect(local.shown, hasLength(2));
      await messaging.close();
    });

    test('clearing a different route does not clear the active thread',
        () async {
      final messaging = FakeMessaging();
      final local = FakeLocal();
      final svc = _service(messaging: messaging, local: local);
      await svc.init();
      svc.setActiveThread(const PushRoute.dm('peer-1'));
      svc.clearActiveThread(const PushRoute.group(42));
      expect(svc.activeRoute.value, const PushRoute.dm('peer-1'));
      await messaging.close();
    });

    test('call invites are never suppressed, even inside a thread',
        () async {
      final messaging = FakeMessaging();
      final local = FakeLocal();
      final svc = _service(messaging: messaging, local: local);
      await svc.init();
      svc.setActiveThread(const PushRoute.dm('peer-1'));
      await svc.handleForegroundMessage(_callData);
      expect(local.shown, hasLength(1));
      expect(local.shown.first.body, AppStrings.t('pushIncomingCall'));
      await messaging.close();
    });

    test('background handler builds the right notification per kind',
        () async {
      final messaging = FakeMessaging();
      final local = FakeLocal();
      final svc = _service(messaging: messaging, local: local);
      await svc.init();
      await svc.handleBackgroundMessage(_dmData);
      await svc.handleBackgroundMessage({
        ..._dmData,
        'message_kind': 'image',
        'message_id': 'msg-3',
      });
      await svc.handleBackgroundMessage(_callData);
      expect(local.shown, hasLength(3));
      expect(local.shown[0].body, 'hello there');
      expect(local.shown[1].body, AppStrings.t('imagePlaceholder'));
      expect(local.shown[2].body, AppStrings.t('pushIncomingCall'));
      await messaging.close();
    });

    test('onMessage stream drives the foreground path', () async {
      final messaging = FakeMessaging();
      final local = FakeLocal();
      final svc = _service(messaging: messaging, local: local);
      await svc.init();
      messaging.emitMessage(_dmData);
      await Future<void>.delayed(const Duration(milliseconds: 50));
      expect(local.shown, hasLength(1));
      await messaging.close();
    });
  });

  group('tap routing', () {
    test('dm / group / call taps open the right routes', () async {
      final messaging = FakeMessaging();
      final navigator = FakeNavigator();
      final svc = _service(messaging: messaging, navigator: navigator);
      await svc.init();
      await svc.handleTap(_dmData);
      await svc.handleTap(_groupData);
      await svc.handleTap(_callData);
      expect(navigator.opened, [
        const PushRoute.dm('peer-1'),
        const PushRoute.group(42),
        const PushRoute.call('call-9', senderId: 'sender-1'),
      ]);
      await messaging.close();
    });

    test('tap without a target opens nothing and never throws', () async {
      final messaging = FakeMessaging();
      final navigator = FakeNavigator();
      final svc = _service(messaging: messaging, navigator: navigator);
      await svc.init();
      await svc.handleTap({'type': 'message'});
      await svc.handleTap({});
      expect(navigator.opened, isEmpty);
      await messaging.close();
    });

    test('local-notification tap payload round-trips the FCM data', () async {
      final messaging = FakeMessaging();
      final navigator = FakeNavigator();
      final svc = _service(messaging: messaging, navigator: navigator);
      await svc.init();
      await svc.handleLocalNotificationTap(
        '{"type":"message","sender_id":"sender-2","sender_name":"Omar",'
        '"chat_type":"group","group_id":"42","message_id":"msg-2",'
        '"preview":"see you there","message_kind":"text"}',
      );
      expect(navigator.opened, [const PushRoute.group(42)]);
      // Malformed payloads are dropped silently.
      await svc.handleLocalNotificationTap('not json');
      await svc.handleLocalNotificationTap(null);
      await svc.handleLocalNotificationTap('');
      expect(navigator.opened, hasLength(1));
      await messaging.close();
    });

    test('onMessageOpenedApp + initial message drive tap routing', () async {
      final messaging = FakeMessaging()
        ..initialMessage = _groupData;
      final navigator = FakeNavigator();
      final svc = _service(messaging: messaging, navigator: navigator);
      await svc.init();
      expect(navigator.opened, [const PushRoute.group(42)]);
      messaging.emitOpenedApp(_dmData);
      await Future<void>.delayed(const Duration(milliseconds: 50));
      expect(navigator.opened, [
        const PushRoute.group(42),
        const PushRoute.dm('peer-1'),
      ]);
      await messaging.close();
    });
  });

  group('init failure', () {
    test('a throwing Firebase init never throws: app still boots degraded',
        () async {
      final messaging = FakeMessaging()..token = 'tok-1';
      final local = FakeLocal();
      final tokens = FakeTokens();
      final svc = _service(
        messaging: messaging,
        local: local,
        tokens: tokens,
        currentUserId: 'user-1',
      );
      await svc.init(
        firebaseInitializer: () async {
          throw Exception('Default FirebaseApp is not initialized');
        },
      );
      expect(svc.available, isFalse);
      expect(svc.statusSubtitleKey(), 'pushUnavailable');
      // Everything downstream is a silent no-op.
      await svc.registerToken();
      await svc.unregisterToken();
      await svc.handleForegroundMessage(_dmData);
      await svc.handleBackgroundMessage(_dmData);
      await svc.requestPermission();
      await svc.requestPermissionFromSettings();
      expect(tokens.upserts, isEmpty);
      expect(local.shown, isEmpty);
      await messaging.close();
    });

    testWidgets('maybeRequestPermission is a no-op when degraded',
        (tester) async {
      final messaging = FakeMessaging();
      final local = FakeLocal();
      final svc = _service(messaging: messaging, local: local);
      await svc.init(
        firebaseInitializer: () async {
          throw Exception('Default FirebaseApp is not initialized');
        },
      );
      expect(svc.available, isFalse);
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                unawaited(svc.maybeRequestPermission(context));
              });
              return const SizedBox.shrink();
            },
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text(AppStrings.t('pushRationaleTitle')), findsNothing);
      expect(messaging.requestPermissionCalls, 0);
      await messaging.close();
    });

    test('init is idempotent: a second call does not re-wire listeners',
        () async {
      final messaging = FakeMessaging();
      final local = FakeLocal();
      final svc = _service(messaging: messaging, local: local);
      await svc.init();
      await svc.init();
      messaging.emitMessage(_dmData);
      await Future<void>.delayed(const Duration(milliseconds: 50));
      expect(local.shown, hasLength(1));
      await messaging.close();
    });
  });

  group('rationale dialog', () {
    testWidgets('enable returns true, later returns false', (tester) async {
      var result = await _pumpRationale(tester, tapEnable: true);
      expect(result, isTrue);
      result = await _pumpRationale(tester, tapEnable: false);
      expect(result, isFalse);
    });

    testWidgets('maybeRequestPermission asks once, then requests',
        (tester) async {
      final messaging = FakeMessaging();
      final local = FakeLocal()..enabled = false;
      final asked = FakeAskedStore();
      final svc = _service(
        messaging: messaging,
        local: local,
        askedStore: asked,
      );
      await svc.init();
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                unawaited(svc.maybeRequestPermission(context));
              });
              return const SizedBox.shrink();
            },
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text(AppStrings.t('pushRationaleTitle')), findsOneWidget);
      await tester.tap(find.text(AppStrings.t('pushEnable')));
      await tester.pumpAndSettle();
      expect(messaging.requestPermissionCalls, 1);
      expect(svc.permissionStatus.value, PushPermissionStatus.granted);
      expect(asked.asked, isTrue);
      await messaging.close();
    });

    testWidgets('maybeRequestPermission never asks twice', (tester) async {
      final messaging = FakeMessaging();
      final local = FakeLocal();
      final asked = FakeAskedStore()..asked = true;
      final svc = _service(
        messaging: messaging,
        local: local,
        askedStore: asked,
      );
      await svc.init();
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) {
              WidgetsBinding.instance.addPostFrameCallback((_) {
                unawaited(svc.maybeRequestPermission(context));
              });
              return const SizedBox.shrink();
            },
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text(AppStrings.t('pushRationaleTitle')), findsNothing);
      expect(messaging.requestPermissionCalls, 0);
      await messaging.close();
    });
  });

  group('i18n keys', () {
    const keys = [
      'pushNotifications',
      'pushEnabled',
      'pushDisabled',
      'pushDeniedSettings',
      'pushUnavailable',
      'pushRationaleTitle',
      'pushRationaleBody',
      'pushEnable',
      'pushLater',
      'pushIncomingCall',
      'pushNewMessage',
    ];
    test('every push key exists in ar and en and differs', () {
      for (final key in keys) {
        AppStrings.lang.value = 'ar';
        final ar = AppStrings.t(key);
        expect(ar, isNotEmpty, reason: 'ar $key');
        expect(ar, isNot(key), reason: 'ar $key missing');
        AppStrings.lang.value = 'en';
        final en = AppStrings.t(key);
        expect(en, isNotEmpty, reason: 'en $key');
        expect(en, isNot(key), reason: 'en $key missing');
        expect(en, isNot(ar), reason: '$key identical in ar/en');
      }
    });
  });
}

/// Pumps a host that shows the rationale dialog and taps one button.
/// Returns the dialog result.
Future<bool?> _pumpRationale(WidgetTester tester, {required bool tapEnable}) {
  final completer = Completer<bool?>();
  final svc = _service();
  return tester
      .pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) {
              WidgetsBinding.instance.addPostFrameCallback((_) async {
                completer.complete(
                  await svc.showPushRationaleDialog(context),
                );
              });
              return const SizedBox.shrink();
            },
          ),
        ),
      )
      .then((_) => tester.pumpAndSettle())
      .then((_) async {
        await tester.tap(
          find.text(
            AppStrings.t(tapEnable ? 'pushEnable' : 'pushLater'),
          ),
        );
        await tester.pumpAndSettle();
        return completer.future;
      });
}
