// Profile header mockup round (2026-11-16, user design): waves header
// with the top row ("..." / @username + verified / gear), 120pt glowing
// avatar with a "+" badge on the own profile, stats row with dividers
// (following/followers/posts), display name 20 right-aligned with the
// verified tick kept, bio 15, blue filled edit + outlined share buttons
// (12pt radius), real highlights row ("new" (+) first), icon tabs with
// a 3pt blue underline, 3-column grid. Pumping ProfileScreen would hit
// the network, so the header itself is asserted against the source
// (same pattern as profile_interactions_test.dart); OwnProfileActions,
// ProfileTopBar and ProfileHighlightsRow are widget tests.
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/screens/profile_screen.dart';
import 'package:hamsiq/services/app_strings.dart';
import 'package:hamsiq/services/stories_api.dart';
import 'package:hamsiq/theme.dart';

void main() {
  late String profileSrc;
  late String stringsSrc;

  setUpAll(() {
    profileSrc =
        File('lib/screens/profile_screen.dart').readAsStringSync();
    stringsSrc =
        File('lib/services/app_strings.dart').readAsStringSync();
  });

  // The _header method body, for assertions scoped to the header.
  String headerBlock() {
    final start = profileSrc.indexOf('Widget _header(');
    final end = profileSrc.indexOf('Widget _postTile(');
    return profileSrc.substring(start, end);
  }

  // The _statColumn method body.
  String statBlock() {
    final start = profileSrc.indexOf('Widget _statColumn(');
    final end = profileSrc.indexOf('Widget _header(');
    return profileSrc.substring(start, end);
  }

  // The OwnProfileActions class body.
  String actionsBlock() {
    final start = profileSrc.indexOf('class OwnProfileActions');
    final end = profileSrc.indexOf('class ProfileUsernameTitle');
    return profileSrc.substring(start, end);
  }

  group('header layout (source assertions)', () {
    test('header padding is 16 / status-bar / 16 / 18', () {
      expect(headerBlock(), contains('EdgeInsets.fromLTRB('));
      expect(
        headerBlock(),
        contains('MediaQuery.of(context).padding.top + 4'),
      );
    });

    test('stats row is LTR, on the left, in the mockup order '
        'following/followers/posts, with dividers between', () {
      final header = headerBlock();
      // The whole stats+avatar row is forced LTR so the stats stay on
      // the left and the avatar on the right in both locales.
      expect(header, contains('Directionality('));
      expect(header, contains('TextDirection.ltr'));
      final row = header.substring(header.indexOf('Directionality('));
      final following = row.indexOf("AppStrings.t('followingStat')");
      final followers = row.indexOf("AppStrings.t('followersStat')");
      final posts = row.indexOf("AppStrings.t('postsCount')");
      expect(following, greaterThanOrEqualTo(0));
      expect(followers, greaterThan(following));
      expect(posts, greaterThan(followers));
      // Thin vertical dividers between the three columns.
      expect('_statDivider()'.allMatches(row).length, 2);
      // Stats come before the avatar in the row (stats left, avatar
      // right in LTR).
      expect(row.indexOf('_glowingAvatar'), greaterThan(posts));
      expect(row, contains('const SizedBox(width: 14)'));
    });

    test('avatar is a 120pt glowing avatar with a gradient ring', () {
      final header = headerBlock();
      expect(header, contains('_glowingAvatar(profile)'));
      final glow = profileSrc.substring(
        profileSrc.indexOf('Widget _glowingAvatar('),
        profileSrc.indexOf('Widget _header('),
      );
      expect(glow, contains('width: 126'));
      expect(glow, contains('height: 126'));
      expect(glow, contains('AvatarWidget('));
      expect(glow, contains('size: 120'));
      expect(glow, contains('showRing: false'));
      expect(glow, contains('LinearGradient('));
      expect(glow, contains('blurRadius: 26'));
      expect(
        header,
        contains('onTap: widget.isMe ? _openEditDialog : null'),
      );
    });

    test('"+" badge (32x32, accent circle, 2px black border, white 20 '
        'plus icon) shows on the own profile only', () {
      final header = headerBlock();
      final badge = header.substring(header.indexOf('Positioned('));
      expect(badge, contains('width: 32'));
      expect(badge, contains('height: 32'));
      expect(badge, contains('color: HamsiqTheme.accent'));
      expect(badge, contains('shape: BoxShape.circle'));
      expect(badge, contains('Border.all('));
      expect(badge, contains('color: Colors.black'));
      expect(badge, contains('width: 2'));
      expect(badge, contains('Icons.add'));
      expect(badge, contains('color: Colors.white'));
      expect(badge, contains('size: 20'));
      expect(badge, contains('bottom: 0'));
      expect(badge, contains('left: 0'));
      // Gated on isMe, inside the avatar Stack.
      final stack = header.substring(header.indexOf('Stack('));
      expect(stack, contains('if (widget.isMe)'));
      expect(stack, contains('clipBehavior: Clip.none'));
    });

    test('display name is 20/w800, physically right-aligned, with the '
        'verified tick kept', () {
      final header = headerBlock();
      final name = header.substring(header.indexOf('profile.displayName'));
      expect(name, contains('fontSize: 20'));
      expect(name, contains('FontWeight.w800'));
      // Deliberate deviation from the pasted design: physical
      // centerRight, NOT directional centerEnd (centerEnd resolves to
      // the LEFT in the app's RTL locale, under the avatar on the
      // right).
      expect(header, contains('alignment: Alignment.centerRight'));
      expect(
        header,
        isNot(contains('alignment: AlignmentDirectional.centerEnd')),
      );
      // The verified tick is kept next to the name (the pasted design
      // drops it; dropping a verification badge would be a regression).
      expect(header, contains('if (profile.verified)'));
      expect(header, contains('const VerifiedTick()'));
    });

    test('bio is start-aligned, 15px, line height 1.45, 7px gap above',
        () {
      final header = headerBlock();
      final bio = header.substring(header.indexOf('profile.bio'));
      expect(bio, contains('textAlign: TextAlign.start'));
      expect(bio, contains('fontSize: 15'));
      expect(bio, contains('height: 1.45'));
      expect(header, contains('const SizedBox(height: 7)'));
    });

    test('stat text sizes are 20 for the count and 13 for the label', () {
      final stat = statBlock();
      expect(stat, contains('fontSize: 20'));
      expect(stat, contains('fontSize: 13'));
      expect(stat, contains('mainAxisSize: MainAxisSize.min'));
      expect(stat, contains('const SizedBox(height: 3)'));
      expect(stat, contains('textAlign: TextAlign.center'));
      expect(stat, contains('color: HamsiqTheme.muted'));
    });
  });

  group('mockup top row + waves (source assertions)', () {
    test('top row: gear right (own) / back (other), centred @username '
        'with swap + verified, "..." left opening the options sheet',
        () {
      expect(profileSrc, contains('class ProfileTopBar'));
      expect(profileSrc, contains('Icons.settings_outlined'));
      expect(profileSrc, contains('Icons.more_horiz'));
      expect(profileSrc, contains('Icons.swap_horiz'));
      expect(profileSrc, contains('VerifiedTick(size: 18)'));
      expect(profileSrc, contains('onMore: _openOptionsSheet'));
      expect(profileSrc, contains('onSettings: _openSettings'));
      expect(profileSrc, contains('_openOptionsSheet'));
      // The v1.2.2 hamburger is gone, and there is no AppBar — the
      // top row lives inside the waves header.
      expect(profileSrc, isNot(contains('Icons.menu')));
      expect(profileSrc, isNot(contains('appBar: AppBar(')));
    });

    test('waves header is gradients + a CustomPainter, never an image',
        () {
      expect(profileSrc, contains('class ProfileWavesBackground'));
      expect(profileSrc, contains('class ProfileWavesPainter'));
      expect(profileSrc, contains('CustomPaint('));
      expect(profileSrc, contains('cubicTo'));
      expect(profileSrc, contains('RadialGradient('));
      expect(profileSrc, contains('LinearGradient('));
      expect(profileSrc, isNot(contains('Image.asset')));
      expect(profileSrc, isNot(contains('AssetImage')));
    });

    test('highlights come from real data; no fake stats, bio, link or '
        'highlight collections', () {
      expect(profileSrc, contains('StoriesApi.fetchHighlights'));
      expect(profileSrc, contains('ProfileHighlightsRow'));
      expect(profileSrc, contains("AppStrings.t('newHighlight')"));
      expect(profileSrc, contains('_openHighlight'));
      expect(profileSrc, isNot(contains('hamsiq.app')));
      expect(profileSrc, isNot(contains('348')));
      expect(profileSrc, isNot(contains('12.5K')));
    });

    test('tabs are icons (grid / reels) with a 3pt blue underline', () {
      expect(profileSrc, contains('indicatorWeight: 3'));
      expect(profileSrc, contains('indicatorColor: HamsiqTheme.accent'));
      expect(profileSrc, contains('Icons.grid_on'));
      expect(profileSrc, contains('Icons.smart_display_outlined'));
      expect(profileSrc, contains('Tab(icon: Icon('));
    });

    test('photo grid is 3 columns, square, 2pt gaps', () {
      expect(profileSrc, contains('crossAxisCount: 3'));
      expect(profileSrc, contains('crossAxisSpacing: 2'));
      expect(profileSrc, contains('mainAxisSpacing: 2'));
      expect(profileSrc, contains('childAspectRatio: 1'));
    });
  });

  group('kept, not regressed (source assertions)', () {
    test('_postTile still uses SignedMediaImage (H-04 re-sign), '
        'never plain Image.network', () {
      final tile = profileSrc.substring(
        profileSrc.indexOf('Widget _postTile('),
        profileSrc.indexOf('Widget _gridSliver('),
      );
      expect(tile, contains('SignedMediaImage('));
      expect(profileSrc, isNot(contains('Image.network')));
    });

    test('zero hardcoded Arabic literals in the screen (H-06)', () {
      final arabic = RegExp(r'[\u0600-\u06FF]');
      for (final line in profileSrc.split('\n')) {
        expect(line, isNot(matches(arabic)), reason: line);
      }
      // The three literals the uploaded file hardcodes must not be here.
      expect(profileSrc, isNot(contains('تبديل الحساب')));
      expect(profileSrc, isNot(contains('مشاركة الملف الشخصي')));
      expect(profileSrc, isNot(contains('الإعدادات')));
    });
  });

  group('own-profile action buttons', () {
    test('edit is blue filled, share is accent-outlined, 12pt radius',
        () {
      final actions = actionsBlock();
      expect(actions, contains('Icons.edit_outlined'));
      expect(actions, contains('Icons.ios_share_outlined'));
      expect(actions, contains("AppStrings.t('shareProfile')"));
      expect(actions, isNot(contains("AppStrings.t('shareTooltip')")));
      // 34pt height, 12px radii, noScaling 14pt label, ellipsis kept.
      expect(actions, contains('buttonHeight = 34'));
      expect(actions, contains('BorderRadius.circular(12)'));
      expect(actions, contains('TextScaler.noScaling'));
      expect(actions, contains('overflow: TextOverflow.ellipsis'));
      expect(actions, contains('backgroundColor:'));
      expect(actions, contains('HamsiqTheme.accent'));
      expect(actions, contains('OutlinedButton('));
      expect(actions, contains('BorderSide('));
    });

    test('shareProfile key exists in both languages with the full phrase',
        () {
      expect(stringsSrc, contains("'shareProfile': 'مشاركة الملف الشخصي'"));
      expect(stringsSrc, contains("'shareProfile': 'Share profile'"));
      // The short 'shareTooltip' key is untouched (still used by the
      // other-profile share button).
      expect(stringsSrc, contains("'shareTooltip': 'مشاركة'"));
      expect(stringsSrc, contains("'shareTooltip': 'Share'"));
    });

    test('new i18n keys exist in both languages', () {
      expect(stringsSrc, contains("'profileOptions': 'خيارات الملف الشخصي'"));
      expect(stringsSrc, contains("'profileOptions': 'Profile options'"));
      expect(stringsSrc, contains("'newHighlight': 'جديد'"));
      expect(stringsSrc, contains("'newHighlight': 'New'"));
    });

    testWidgets('edit and share buttons render with icons, full labels, '
        'at 34pt height', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          theme: HamsiqTheme.dark,
          home: Scaffold(
            body: OwnProfileActions(onEdit: () {}, onShare: () {}),
          ),
        ),
      );
      await tester.pump();

      expect(find.byIcon(Icons.edit_outlined), findsOneWidget);
      expect(find.byIcon(Icons.ios_share_outlined), findsOneWidget);
      expect(find.text('تعديل الملف الشخصي'), findsOneWidget);
      expect(find.text('مشاركة الملف الشخصي'), findsOneWidget);
      // Edit is the blue filled button, share the outlined one.
      expect(
        find.widgetWithText(ElevatedButton, 'تعديل الملف الشخصي'),
        findsOneWidget,
      );
      expect(
        find.widgetWithText(OutlinedButton, 'مشاركة الملف الشخصي'),
        findsOneWidget,
      );
      // The old short label must not appear on these buttons.
      expect(find.text('مشاركة'), findsNothing);
      expect(
        tester
            .getSize(
              find.widgetWithText(
                ElevatedButton,
                'تعديل الملف الشخصي',
              ),
            )
            .height,
        34,
      );
      // Labels render from AppStrings, not a hardcoded literal.
      expect(AppStrings.t('shareProfile'), 'مشاركة الملف الشخصي');
    });
  });

  group('mockup top bar + highlights row (widget tests)', () {
    testWidgets('own top bar: gear right, centred @username + verified, '
        '"..." left; gear opens settings, "..." opens options',
        (tester) async {
      var settings = false;
      var more = false;
      var switched = false;
      await tester.pumpWidget(
        MaterialApp(
          theme: HamsiqTheme.dark,
          home: Scaffold(
            body: Directionality(
              textDirection: TextDirection.rtl,
              child: ProfileTopBar(
                username: 'm',
                verified: true,
                isMe: true,
                onMore: () => more = true,
                onSettings: () => settings = true,
                onSwitchAccount: () => switched = true,
                onBack: () {},
              ),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('@m'), findsOneWidget);
      expect(find.byIcon(Icons.verified), findsOneWidget);
      expect(find.byIcon(Icons.settings_outlined), findsOneWidget);
      expect(find.byIcon(Icons.more_horiz), findsOneWidget);
      expect(find.byIcon(Icons.swap_horiz), findsOneWidget);
      expect(find.byIcon(Icons.menu), findsNothing);
      // Physical layout, as in the mockup: gear on the right, "..."
      // on the left.
      final gearX = tester.getCenter(find.byIcon(Icons.settings_outlined)).dx;
      final moreX = tester.getCenter(find.byIcon(Icons.more_horiz)).dx;
      final nameX = tester.getCenter(find.text('@m')).dx;
      expect(gearX, greaterThan(nameX));
      expect(moreX, lessThan(nameX));

      await tester.tap(find.byIcon(Icons.settings_outlined));
      expect(settings, isTrue);
      await tester.tap(find.byIcon(Icons.more_horiz));
      expect(more, isTrue);
      await tester.tap(find.text('@m'));
      expect(switched, isTrue);
    });

    testWidgets('other top bar: back arrow instead of gear, no swap icon',
        (tester) async {
      var backed = false;
      await tester.pumpWidget(
        MaterialApp(
          theme: HamsiqTheme.dark,
          home: Scaffold(
            body: Directionality(
              textDirection: TextDirection.rtl,
              child: ProfileTopBar(
                username: 'h',
                verified: false,
                isMe: false,
                onMore: () {},
                onSettings: () {},
                onSwitchAccount: () {},
                onBack: () => backed = true,
              ),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('@h'), findsOneWidget);
      expect(find.byIcon(Icons.arrow_back), findsOneWidget);
      expect(find.byIcon(Icons.settings_outlined), findsNothing);
      expect(find.byIcon(Icons.swap_horiz), findsNothing);
      expect(find.byIcon(Icons.verified), findsNothing);
      await tester.tap(find.byIcon(Icons.arrow_back));
      expect(backed, isTrue);
    });

    testWidgets('highlights row with no highlights shows ONLY the new '
        '(+) circle', (tester) async {
      var newTapped = false;
      await tester.pumpWidget(
        MaterialApp(
          theme: HamsiqTheme.dark,
          home: Scaffold(
            body: ProfileHighlightsRow(
              highlights: const [],
              isMe: true,
              onOpen: (_) {},
              onNew: () => newTapped = true,
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('جديد'), findsOneWidget);
      expect(find.byIcon(Icons.add), findsOneWidget);
      // The row is 96pt tall (64pt circle + label).
      expect(tester.getSize(find.byType(ProfileHighlightsRow)).height, 96);
      await tester.tap(find.byIcon(Icons.add));
      expect(newTapped, isTrue);
    });

    testWidgets('highlights row shows real collections after the new '
        'circle, and opens them', (tester) async {
      HighlightItem? opened;
      final items = [
        HighlightItem(
          id: 1,
          userId: 'u1',
          title: 'رحلات',
          createdAt: DateTime(2026, 11, 1),
        ),
        HighlightItem(
          id: 2,
          userId: 'u1',
          title: 'القهوة',
          createdAt: DateTime(2026, 11, 2),
        ),
      ];
      await tester.pumpWidget(
        MaterialApp(
          theme: HamsiqTheme.dark,
          home: Scaffold(
            body: ProfileHighlightsRow(
              highlights: items,
              isMe: true,
              onOpen: (h) => opened = h,
              onNew: () {},
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('جديد'), findsOneWidget);
      expect(find.text('رحلات'), findsOneWidget);
      expect(find.text('القهوة'), findsOneWidget);
      // No fake mockup collection names.
      expect(find.text('المميز'), findsNothing);
      expect(find.text('ألعاب'), findsNothing);
      await tester.tap(find.text('القهوة'));
      expect(opened?.id, 2);
    });

    testWidgets('waves background paints behind its child', (tester) async {
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: ProfileWavesBackground(
              child: Text('header'),
            ),
          ),
        ),
      );
      await tester.pump();

      expect(find.text('header'), findsOneWidget);
      expect(
        find.byWidgetPredicate(
          (w) => w is CustomPaint && w.painter is ProfileWavesPainter,
        ),
        findsOneWidget,
      );
      expect(find.byType(ProfileWavesBackground), findsOneWidget);
    });
  });
}
