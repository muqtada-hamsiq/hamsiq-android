// Unit tests for the comments API (Phase 2, workstream A).
// Pure / offline only: CommentItem parsing and the comment-count
// mapping. No Supabase session or network is needed here.

import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/services/comments_api.dart';

void main() {
  test('CommentItem.fromMap parses the real comments columns', () {
    final c = CommentItem.fromMap({
      'id': 7,
      'post_id': 42,
      'author_id': '00000000-0000-0000-0000-000000000001',
      'body': 'منشور جميل',
      'created_at': '2026-11-15T10:00:00+00:00',
    });
    expect(c.id, 7);
    expect(c.postId, 42);
    expect(c.authorId, '00000000-0000-0000-0000-000000000001');
    expect(c.body, 'منشور جميل');
    expect(c.createdAt, DateTime.parse('2026-11-15T10:00:00+00:00'));
    expect(c.author, isNull);
  });

  test('countByPost counts rows per post and zero-fills the rest', () {
    final counts = CommentsApi.countByPost([
      {'post_id': 1},
      {'post_id': 1},
      {'post_id': 2},
      {'post_id': 99}, // not requested: ignored
    ], [1, 2, 3]);
    expect(counts, {1: 2, 2: 1, 3: 0});
  });

  test('countByPost returns an empty map for an empty request', () {
    expect(CommentsApi.countByPost([{'post_id': 1}], []), isEmpty);
  });

  test('comment body limit matches the web app maxlength', () {
    expect(CommentsApi.maxBodyLength, 300);
  });
}
