// v1.2.2 tests: compact profile button labels at true Instagram size,
// username + chevron on the own profile, account switcher (list, add
// row, 5-account cap), multi-account switching, and the add-account
// login back button. Pumping ProfileScreen itself would hit the network,
// so the header pieces are tested as isolated widgets + source
// assertions, following test/profile_settings_rtl_test.dart.
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/screens/auth_screen.dart';
import 'package:hamsiq/screens/profile_screen.dart';
import 'package:hamsiq/services/account_store.dart';
import 'package:hamsiq/services/supabase_service.dart';
import 'package:hamsiq/theme.dart';
import 'package:hamsiq/widgets/account_switcher_sheet.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: Api.supabaseUrl,
      publishableKey: Api.supabaseAnonKey,
    );
  });

  setUp(() {
    // Fresh (empty) prefs for every test — the store reads them per call.
    SharedPreferences.setMockInitialValues({});
  });

  SavedAccount acct(String id, String username, [String name = '']) =>
      SavedAccount(
        id: id,
        username: username,
        displayName: name.isEmpty ? username : name,
      );

  AccountStore testStore({Future<void> Function(String)? refresh}) =>
      AccountStore.forTest(
        tokenStorage: MemoryTokenStorage(),
        refreshSession: refresh,
      );

  Future<void> seed(
    AccountStore store,
    List<SavedAccount> accounts, {
    String currentId = '',
  }) async {
    for (final a in accounts) {
      await store.addSavedAccount(
        a,
        accessToken: 'access-${a.id}',
        refreshToken: 'refresh-${a.id}',
      );
    }
    if (currentId.isNotEmpty) {
      // Mark the current account by re-adding through the store's
      // current pointer: addSavedAccount does not set it, so write the
      // prefs key the same way the store does.
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('hamsiq_current_account', currentId);
    }
  }

  // ---------- item 1: compact button labels ----------

  testWidgets('profile button labels render at true 14pt even with a '
      '1.5x phone text scaler', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: const Scaffold(
          body: MediaQuery(
            data: MediaQueryData(
              textScaler: TextScaler.linear(1.5),
            ),
            child: Directionality(
              textDirection: TextDirection.rtl,
              child: OwnProfileActions(onEdit: _noop, onShare: _noop),
            ),
          ),
        ),
      ),
    );
    await tester.pump();

    for (final label in ['تعديل الملف الشخصي', 'مشاركة الملف الشخصي']) {
      final text = tester.widget<Text>(find.text(label));
      // Explicit style on the label itself, scaler-proof.
      expect(text.style?.fontSize, 14, reason: label);
      expect(text.style?.fontWeight, FontWeight.w600, reason: label);
      expect(text.textScaler, TextScaler.noScaling, reason: label);
      // The rendered glyph height stays 14 — a 1.5x phone scaler must
      // not inflate it to 21 (the v1.2.1 screenshot bug).
      expect(
        tester.getSize(find.text(label)).height,
        14,
        reason: label,
      );
    }
  });

  testWidgets('profile button labels render at 14pt with no scaler',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: const Scaffold(
          body: Directionality(
            textDirection: TextDirection.rtl,
            child: OwnProfileActions(onEdit: _noop, onShare: _noop),
          ),
        ),
      ),
    );
    await tester.pump();
    final text = tester.widget<Text>(find.text('تعديل الملف الشخصي'));
    expect(text.style?.fontSize, 14);
    expect(tester.getSize(find.text('تعديل الملف الشخصي')).height, 14);
  });

  // ---------- item 2: username + chevron ----------

  testWidgets('own profile title shows username + chevron and taps',
      (tester) async {
    var tapped = false;
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: Scaffold(
          body: ProfileUsernameTitle(
            username: 'm',
            showChevron: true,
            onTap: () => tapped = true,
          ),
        ),
      ),
    );
    await tester.pump();
    expect(find.text('m'), findsOneWidget);
    expect(find.byIcon(Icons.keyboard_arrow_down), findsOneWidget);
    final icon = tester.widget<Icon>(find.byIcon(Icons.keyboard_arrow_down));
    expect(icon.size, 16);
    await tester.tap(find.byType(ProfileUsernameTitle));
    expect(tapped, isTrue);
  });

  testWidgets('other profile title shows plain username, no chevron',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: const Scaffold(
          body: ProfileUsernameTitle(username: 'h', showChevron: false),
        ),
      ),
    );
    await tester.pump();
    expect(find.text('h'), findsOneWidget);
    expect(find.byIcon(Icons.keyboard_arrow_down), findsNothing);
  });

  test('profile screen wires the mockup top bar (gear + "..." + '
      '@username, account switcher on the centre row)', () {
    final src = File('lib/screens/profile_screen.dart').readAsStringSync();
    expect(src, contains('ProfileTopBar'));
    expect(src, contains('onSettings: _openSettings'));
    expect(src, contains('onMore: _openOptionsSheet'));
    expect(src, contains('onSwitchAccount: _openAccountSwitcher'));
    // Mockup round: the gear replaces the v1.2.2 hamburger, and the
    // "..." opens the options sheet — no hamburger, no AppBar.
    expect(src, contains('Icons.settings_outlined'));
    expect(src, contains('Icons.more_horiz'));
    expect(src, isNot(contains('Icons.menu')));
    expect(src, isNot(contains('appBar: AppBar(')));
  });

  // ---------- item 3: switcher sheet ----------

  Future<void> pumpSheet(
    WidgetTester tester, {
    required List<SavedAccount> accounts,
    String? currentId,
    AccountStore? store,
  }) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: Scaffold(
          body: Builder(
            builder: (ctx) => ElevatedButton(
              onPressed: () {
                showModalBottomSheet<void>(
                  context: ctx,
                  backgroundColor: HamsiqTheme.panel,
                  builder: (_) => AccountSwitcherSheet(
                    accounts: accounts,
                    currentId: currentId,
                    parentContext: ctx,
                    store: store,
                  ),
                );
              },
              child: const Text('open'),
            ),
          ),
        ),
      ),
    );
    await tester.pump();
    await tester.tap(find.text('open'));
    await tester.pumpAndSettle();
  }

  testWidgets('switcher lists saved accounts with a check on current '
      'and an add row', (tester) async {
    final accounts = [acct('u1', 'm', 'M'), acct('u2', 'h', 'H')];
    await pumpSheet(tester, accounts: accounts, currentId: 'u1');
    expect(find.text('m'), findsOneWidget);
    expect(find.text('h'), findsOneWidget);
    expect(find.text('إضافة حساب'), findsOneWidget);
    expect(find.byIcon(Icons.check), findsOneWidget);
  });

  testWidgets('switcher add row shows the 5-account cap message',
      (tester) async {
    final accounts = List.generate(5, (i) => acct('u$i', 'user$i'));
    await pumpSheet(tester, accounts: accounts, currentId: 'u0');
    // With 5 accounts the add row sits below the fold — scroll the
    // sheet list into view first (a real user scrolls the same way).
    await tester.drag(find.byType(ListView), const Offset(0, -400));
    await tester.pumpAndSettle();
    await tester.tap(find.text('إضافة حساب'));
    await tester.pump();
    expect(find.textContaining('الحد الأقصى 5 حسابات'), findsOneWidget);
    // The sheet stays open — no login screen was pushed.
    expect(find.text('إضافة حساب'), findsOneWidget);
  });

  testWidgets('switcher add row opens the add-account login with a '
      'back button', (tester) async {
    final accounts = [acct('u1', 'm', 'M')];
    await pumpSheet(tester, accounts: accounts, currentId: 'u1');
    await tester.tap(find.text('إضافة حساب'));
    await tester.pumpAndSettle();
    // The login screen in add-account mode shows a back arrow.
    expect(find.byIcon(Icons.arrow_back), findsOneWidget);
    // The new login design renders "تسجيل الدخول" twice (toggle tab +
    // login button), so scope the finder to the login button itself.
    expect(
      find.widgetWithText(ElevatedButton, 'تسجيل الدخول'),
      findsOneWidget,
    );
  });

  testWidgets('switching accounts uses the target account tokens and '
      'makes it current', (tester) async {
    final accounts = [acct('u1', 'm', 'M'), acct('u2', 'h', 'H')];
    String? usedToken;
    final switching = AccountStore.forTest(
      tokenStorage: MemoryTokenStorage(),
      refreshSession: (token) async {
        usedToken = token;
      },
    );
    // Seed the same accounts into the switching store.
    for (final a in accounts) {
      await switching.addSavedAccount(
        a,
        accessToken: 'access-${a.id}',
        refreshToken: 'refresh-${a.id}',
      );
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('hamsiq_current_account', 'u1');

    await pumpSheet(
      tester,
      accounts: accounts,
      currentId: 'u1',
      store: switching,
    );
    await tester.tap(find.text('h'));
    await tester.pumpAndSettle();
    expect(usedToken, 'refresh-u2');
    expect(await switching.currentAccountId(), 'u2');
    // The app reloads as the switched account (login screen in tests,
    // where no live session exists). "تسجيل الدخول" renders twice on
    // the new login design (toggle tab + login button), so scope the
    // finder to the login button itself.
    expect(
      find.widgetWithText(ElevatedButton, 'تسجيل الدخول'),
      findsOneWidget,
    );
  });

  // ---------- item 4: session switching logic ----------

  test('switchTo exchanges the stored refresh token of the target '
      'account', () async {
    String? usedToken;
    final store = AccountStore.forTest(
      tokenStorage: MemoryTokenStorage(),
      refreshSession: (token) async {
        usedToken = token;
      },
    );
    await seed(
      store,
      [acct('u1', 'm', 'M'), acct('u2', 'h', 'H')],
      currentId: 'u1',
    );
    await store.switchTo('u2');
    expect(usedToken, 'refresh-u2');
    expect(await store.currentAccountId(), 'u2');
  });

  test('switchTo with an expired stored session drops the account and '
      'asks to log in again', () async {
    final store = AccountStore.forTest(
      tokenStorage: MemoryTokenStorage(),
      refreshSession: (_) async {
        throw Exception('invalid_grant');
      },
    );
    await seed(
      store,
      [acct('u1', 'm', 'M'), acct('u2', 'h', 'H')],
      currentId: 'u1',
    );
    await expectLater(
      store.switchTo('u2'),
      throwsA(
        predicate(
          (e) =>
              e.toString().contains('انتهت جلسة هذا الحساب'),
        ),
      ),
    );
    final remaining = await store.loadAccounts();
    expect(remaining.map((a) => a.id), ['u1']);
  });

  test('saved accounts never exceed 5', () async {
    final store = testStore();
    for (var i = 0; i < 7; i++) {
      await store.addSavedAccount(
        acct('u$i', 'user$i'),
        accessToken: 'a$i',
        refreshToken: 'r$i',
      );
    }
    final accounts = await store.loadAccounts();
    expect(accounts.length, AccountStore.maxAccounts);
  });

  // ---------- item 5: add-account login back button ----------

  testWidgets('add-account login shows a back button that calls onBack',
      (tester) async {
    var backed = false;
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: Scaffold(
          body: AuthScreen(
            isAddAccount: true,
            onBack: () => backed = true,
            onAuthed: () {},
          ),
        ),
      ),
    );
    await tester.pump();
    expect(find.byIcon(Icons.arrow_back), findsOneWidget);
    await tester.tap(find.byIcon(Icons.arrow_back));
    expect(backed, isTrue);
  });

  testWidgets('normal login shows no back button', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: Scaffold(body: AuthScreen(onAuthed: () {})),
      ),
    );
    await tester.pump();
    expect(find.byIcon(Icons.arrow_back), findsNothing);
  });
}

void _noop() {}
