// Mockup-match round (2026-11-16, Direct screenshot): the Direct screen
// reproduces the user's mockup — waves behind the top bar, centred
// "الرسائل المباشرة" title, blue paper-plane + Hamsiq brand on the
// right, blue-outline compose button on the left, pill search field,
// All / Requests pill tabs, and rounded chat cards with a blue glow
// border. Pumped offline: the list load fails, so the header + tabs +
// empty state are asserted, plus the Requests placeholder on tab tap.
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/screens/chats_screen.dart';
import 'package:hamsiq/services/app_strings.dart';
import 'package:hamsiq/services/supabase_service.dart';
import 'package:hamsiq/theme.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: Api.supabaseUrl,
      publishableKey: Api.supabaseAnonKey,
    );
    AppStrings.lang.value = 'ar';
  });

  Future<void> pumpDirect(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: const Directionality(
          textDirection: TextDirection.rtl,
          child: ChatsScreen(),
        ),
      ),
    );
    await tester.pumpAndSettle(
      const Duration(milliseconds: 100),
      EnginePhase.sendSemanticsUpdate,
      const Duration(seconds: 15),
    );
  }

  testWidgets('mockup header: title, brand, compose, no AppBar',
      (tester) async {
    await pumpDirect(tester);
    expect(find.text('الرسائل المباشرة'), findsOneWidget);
    expect(find.text('Hamsiq'), findsOneWidget);
    expect(find.byIcon(Icons.edit_square), findsOneWidget);
    expect(find.byIcon(Icons.send_outlined), findsOneWidget);
    // The old AppBar (title + groups icon) is gone.
    expect(find.byType(AppBar), findsNothing);
    // Offline the list load fails, so the empty state shows.
    expect(find.text('لا توجد محادثات بعد'), findsOneWidget);
  });

  testWidgets('search pill + All/Requests tabs, requests placeholder',
      (tester) async {
    await pumpDirect(tester);
    expect(find.text('ابحث في الرسائل...'), findsOneWidget);
    expect(find.byIcon(Icons.search), findsOneWidget);
    expect(find.text('جميع الرسائل'), findsOneWidget);
    expect(find.text('طلبات الرسائل'), findsOneWidget);
    expect(find.byIcon(Icons.person_add_outlined), findsOneWidget);
    await tester.tap(find.text('طلبات الرسائل'));
    await tester.pump();
    expect(find.text('لا توجد طلبات رسائل بعد'), findsOneWidget);
    await tester.tap(find.text('جميع الرسائل'));
    await tester.pump();
    expect(find.text('لا توجد محادثات بعد'), findsOneWidget);
  });
}
