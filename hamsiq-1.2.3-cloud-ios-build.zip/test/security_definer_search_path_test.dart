// Tests for sql-v34.sql (audit finding H-05): every SECURITY DEFINER
// function defined in the combined schema
// (~/workspace/your_files/hamsiq-supabase-schema-v4-v31.sql, migrations
// v4..v31) must have exactly one
//   ALTER FUNCTION <name>(<args>) SET search_path = pg_catalog, public;
// line in the migration, and the migration must reference no function
// that does not exist there. Pure / offline only: reads SQL files from
// disk, no Supabase session or network is needed.
//
// The expected list below is the output of /tmp/gen_search_path_migration.py
// (one entry per distinct SECURITY DEFINER signature, using the LAST
// definition's signature where a function was redefined across migrations).
// When the combined schema file is present next to the workspace (the
// ../your_files/ path below), the test additionally re-parses the schema
// itself and asserts the embedded list matches it exactly, so a stale
// embedded list cannot hide a drift.

import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

// (qualified name, argument list exactly as written in the source
// definition, isTriggerFunction)
const List<(String, String, bool)> kExpectedDefinerFunctions = [
  ('public.get_email_by_username', 'p_username text', false),
  ('public.group_caller_is_admin', 'p_group_id bigint', false),
  ('public.resolve_group_invite', 'p_code text', false),
  ('public.join_group_by_invite', 'p_code text', false),
  ('public.get_or_create_group_invite', 'p_group_id bigint', false),
  ('public.add_group_member', 'p_group_id bigint, p_user_id uuid', false),
  ('public.set_group_member_role',
      'p_group_id bigint, p_user_id uuid, p_role text', false),
  ('public.remove_group_member', 'p_group_id bigint, p_user_id uuid', false),
  ('public.update_group_profile',
      'p_group_id bigint, p_name text, p_avatar_url text', false),
  ('public.get_peer_presence', 'p_user_id uuid', false),
  ('public.award_achievement', 'p_user_id uuid, p_achievement_id text', false),
  ('public.log_admin_action',
      'p_action text, p_target_type text, p_target_id text, p_details text',
      false),
  ('public.admin_stats', '', false),
  ('public.check_rate_limit',
      'p_action text, p_limit int, p_window_seconds int', false),
  ('public.flag_user_for_spam',
      'p_user_id uuid, p_content_type text, p_content_id text, '
      'p_reason text, p_preview text',
      false),
  ('public.resolve_moderation_item', 'p_id bigint, p_approve boolean', false),
  ('public.mark_message_read', 'p_message_id bigint', false),
  ('public.mark_thread_read', 'p_peer_id uuid', false),
  ('public.approve_follow_request', 'p_follower uuid', false),
  ('public.set_comment_pinned', 'p_comment_id bigint, p_pinned boolean', false),
  ('public.unsend_message', 'p_message_id bigint', false),
  ('public.mark_view_once_seen', 'p_message_id bigint', false),
  ('public.purge_vanish_messages', 'p_peer_id uuid', false),
  ('public.invite_collaborator', 'p_post_id bigint, p_user_id uuid', false),
  ('public.respond_collab_invite', 'p_post_id bigint, p_accept boolean', false),
  ('public.respond_blend_invite', 'p_blend_id bigint, p_accept boolean', false),
  ('public.end_blend', 'p_blend_id bigint', false),
  ('public.add_group_creator', '', true),
  ('public.log_username_change', '', true),
  ('public.enforce_username_rules', '', true),
  ('public.update_streak', '', true),
];

String _norm(String s) => s.replaceAll(RegExp(r'\s+'), ' ').trim();

/// ALTER FUNCTION <name>(<args>) SET search_path = pg_catalog, public;
final _alterRegExp = RegExp(
  r'ALTER\s+FUNCTION\s+((?:public|auth|private)\.[A-Za-z_][A-Za-z0-9_$]*)'
  r'\s*\(([^)]*)\)\s*SET\s+search_path\s*=\s*pg_catalog,\s*public\s*;',
  caseSensitive: false,
);

/// Parses the combined schema and returns the distinct SECURITY DEFINER
/// signatures (last definition wins), mirroring
/// /tmp/gen_search_path_migration.py. Returns (name, args, isTrigger).
List<(String, String, bool)> _parseDefinerFunctions(String schema) {
  final startRegExp = RegExp(
    r'^[ \t]*create\s+(?:or\s+replace\s+)?function\s+'
    r'((?:public|auth|private)\.)?([A-Za-z_][A-Za-z0-9_$]*)\s*\(',
    caseSensitive: false,
    multiLine: true,
  );
  final dollarQuote = RegExp(r'\$[A-Za-z_][A-Za-z0-9_]*\$|\$\$');
  final kept = <String, (String, String, bool)>{};
  final order = <String>[];

  String argType(String arg) {
    final a = _norm(arg).replaceFirst(
      RegExp(r'^(in|out|inout|variadic)\s+', caseSensitive: false),
      '',
    );
    final tokens = a.split(' ');
    return tokens.length == 1
        ? tokens.single.toLowerCase()
        : tokens.sublist(1).join(' ').toLowerCase();
  }

  for (final m in startRegExp.allMatches(schema)) {
    final lineStart = schema.lastIndexOf('\n', m.start) + 1;
    if (schema.substring(lineStart, m.start).trim().startsWith('--')) {
      continue; // definition mentioned in a comment, not a real one
    }
    final schemaName = (m.group(1) ?? 'public.').replaceAll('.', '');
    final name = '$schemaName.${m.group(2)}';
    // Argument list: the '(' is the last char of the match; scan forward
    // with paren depth (args may span lines).
    final openIdx = m.end - 1;
    var depth = 0;
    var closeIdx = -1;
    for (var k = openIdx; k < schema.length; k++) {
      final ch = schema[k];
      if (ch == '(') depth++;
      if (ch == ')') {
        depth--;
        if (depth == 0) {
          closeIdx = k;
          break;
        }
      }
    }
    expect(closeIdx, isNot(-1), reason: 'Unbalanced parens in $name');
    final rawArgs = schema.substring(openIdx + 1, closeIdx);
    final dq = dollarQuote.firstMatch(schema.substring(closeIdx + 1));
    expect(dq, isNotNull, reason: 'No dollar-quoted body for $name');
    final tail = schema.substring(
      closeIdx + 1,
      closeIdx + 1 + dq!.start,
    );
    final isDefiner =
        RegExp(r'security\s+definer', caseSensitive: false).hasMatch(tail);
    final isTrigger =
        RegExp(r'returns\s+trigger\b', caseSensitive: false).hasMatch(tail);
    final args = _norm(rawArgs);
    final argTypes = args.isEmpty
        ? <String>[]
        : args.split(',').map((a) => argType(a.trim())).toList();
    final key = '$name(${argTypes.join(',')})';
    if (!kept.containsKey(key) && !order.contains(key)) order.add(key);
    // Last definition wins: a redefinition without SECURITY DEFINER
    // resets the live function to invoker, so drop it from the list.
    if (isDefiner) {
      kept[key] = (name, args, isTrigger);
    } else {
      kept.remove(key);
    }
  }
  // Filter out signatures whose last definition was not a definer.
  return order
      .where((k) => kept.containsKey(k))
      .map((k) => kept[k]!)
      .toList();
}

void main() {
  group('sql-v34 (H-05 search_path) —', () {
    late String migration;

    setUpAll(() {
      // flutter test runs with the package root as the working directory.
      migration = File('sql-v34.sql').readAsStringSync();
    });

    test('migration covers every SECURITY DEFINER function exactly once',
        () {
      final alters = <String, int>{};
      for (final m in _alterRegExp.allMatches(migration)) {
        final key = '${m.group(1)}(${_norm(m.group(2)!)})';
        alters[key] = (alters[key] ?? 0) + 1;
      }
      expect(alters.length, kExpectedDefinerFunctions.length,
          reason: 'distinct ALTERs must equal expected functions');
      for (final (name, args, _) in kExpectedDefinerFunctions) {
        final key = '$name($args)';
        expect(alters[key], 1,
            reason: 'expected exactly one ALTER for $key');
      }
      for (final key in alters.keys) {
        expect(
          kExpectedDefinerFunctions
              .any((e) => '${e.$1}(${e.$2})' == key),
          isTrue,
          reason: 'ALTER references unknown function $key',
        );
      }
    });

    test('migration contains only ALTER ... SET search_path statements',
        () {
      final withoutComments = migration.replaceAll(
        RegExp(r'--[^\n]*'),
        '',
      );
      final withoutAlters =
          withoutComments.replaceAll(_alterRegExp, '').trim();
      expect(withoutAlters, isEmpty,
          reason: 'migration must not contain other statements; found: '
              '$withoutAlters');
      // Belt-and-braces on the comment-free text (the header comments
      // legitimately mention words like GRANT): no other statement
      // keywords may appear outside the ALTER lines.
      expect(
        RegExp(r'\b(create|grant|revoke|drop|insert|update|delete)\b',
                caseSensitive: false)
            .hasMatch(withoutComments.replaceAll(_alterRegExp, '')),
        isFalse,
        reason: 'no function body or grant may be rewritten here',
      );
    });

    test('trigger functions are listed in the separate trigger section', () {
      final triggerSection =
          migration.split('2) Trigger functions').elementAtOrNull(1);
      expect(triggerSection, isNotNull);
      final rpcSection = migration.split('2) Trigger functions').first;
      for (final (name, args, isTrigger) in kExpectedDefinerFunctions) {
        final alter =
            'ALTER FUNCTION $name($args) SET search_path = pg_catalog, public;';
        if (isTrigger) {
          expect(triggerSection, contains(alter),
              reason: '$name must be in the trigger section');
          expect(rpcSection, isNot(contains(alter)),
              reason: '$name must not be in the RPC section');
        } else {
          expect(rpcSection, contains(alter),
              reason: '$name must be in the RPC section');
          expect(triggerSection, isNot(contains(alter)),
              reason: '$name must not be in the trigger section');
        }
      }
    });

    test(
        'embedded list matches the combined schema when it is present',
        () {
      final schemaFile = File(
        '../your_files/hamsiq-supabase-schema-v4-v31.sql',
      );
      if (!schemaFile.existsSync()) {
        // The schema lives outside the package; the embedded list above
        // is the source of truth when it is absent.
        return;
      }
      final parsed =
          _parseDefinerFunctions(schemaFile.readAsStringSync());
      // The migration groups RPCs first, then trigger functions, while
      // the parser returns file order — compare as sets, not ordered.
      expect(parsed.length, kExpectedDefinerFunctions.length,
          reason: 'schema-derived definer count must match the embedded list');
      expect(
        parsed.toSet(),
        kExpectedDefinerFunctions.toSet(),
        reason: 'schema-derived definer set must match the embedded list',
      );
    });
  });
}
