// Boot tests: the app must start and show the login screen with no session.
// This is the closest available boot check on this VM (no KVM, no emulator
// binary in the SDK). A real-phone boot test by the user is still owed.
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/main.dart';
import 'package:hamsiq/screens/auth_screen.dart';
import 'package:hamsiq/services/supabase_service.dart';
import 'package:hamsiq/theme.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    // Supabase.initialize uses shared_preferences (a platform plugin);
    // the test host has no plugin registrant, so mock its storage.
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: Api.supabaseUrl,
      publishableKey: Api.supabaseAnonKey,
    );
  });

  testWidgets('app boots to the login screen', (tester) async {
    await tester.pumpWidget(const HamsiqApp());
    await tester.pump(const Duration(seconds: 1));
    await tester.pump(const Duration(seconds: 1));
    // New login design (user order 2026-11-16): welcome title, no
    // standalone 'Hamsiq' text (the logo is the image asset).
    expect(find.text('مرحباً بعودتك'), findsOneWidget);
    expect(find.text('مكانك يجمع العالم'), findsOneWidget);
    // Mockup-match: 'تسجيل الدخول' is both the toggle's active half
    // and the login button. The toggle's signup half says 'إنشاء حساب'
    // (signupTab); the bottom switch row says 'أنشئ حساب جديد'.
    expect(find.text('تسجيل الدخول'), findsNWidgets(2));
    expect(find.text('إنشاء حساب'), findsOneWidget);
    expect(find.text('أنشئ حساب جديد'), findsOneWidget);
    expect(find.widgetWithText(TextField, 'اسم المستخدم'),
        findsOneWidget);
    expect(find.widgetWithText(TextField, 'كلمة المرور'),
        findsOneWidget);
    expect(find.widgetWithText(ElevatedButton, 'تسجيل الدخول'),
        findsOneWidget);
  });

  testWidgets('auth screen renders login form directly', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: AuthScreen(onAuthed: () {}),
      ),
    );
    await tester.pump();
    expect(find.text('مرحباً بعودتك'), findsOneWidget);
    expect(find.widgetWithText(TextField, 'اسم المستخدم'),
        findsOneWidget);
    expect(find.widgetWithText(TextField, 'كلمة المرور'),
        findsOneWidget);
    expect(find.text('نسيت كلمة المرور؟'), findsOneWidget);
  });

  testWidgets('signup tab renders and rejects a weak password offline',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: AuthScreen(onAuthed: () {}),
      ),
    );
    await tester.pump();
    // The create-account link sits at the bottom of the tall login
    // view — scroll it into view first (a real user scrolls the same
    // way).
    await tester.ensureVisible(find.text('أنشئ حساب جديد'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('أنشئ حساب جديد'));
    await tester.pump();
    expect(find.widgetWithText(TextField, 'البريد الإلكتروني'),
        findsOneWidget);
    // Empty submit -> "املأ كل الحقول" without any network call.
    // The logo makes the form taller than the 800x600 test viewport, so
    // scroll the button into view first (a real user scrolls the same way).
    await tester.ensureVisible(
        find.widgetWithText(ElevatedButton, 'إنشاء الحساب'));
    await tester.pumpAndSettle();
    await tester.tap(find.widgetWithText(ElevatedButton, 'إنشاء الحساب'));
    await tester.pump();
    expect(find.text('املأ كل الحقول'), findsOneWidget);
  });

  testWidgets('login form shows the required-field message on empty submit',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: AuthScreen(onAuthed: () {}),
      ),
    );
    await tester.pump();
    final loginButton =
        find.widgetWithText(ElevatedButton, 'تسجيل الدخول');
    await tester.ensureVisible(loginButton);
    await tester.pumpAndSettle();
    await tester.tap(loginButton);
    await tester.pump();
    // Both fields are required: the Form validators fire inline, with
    // no network call and no stub snackbar.
    expect(find.text('هذا الحقل مطلوب'), findsNWidgets(2));
  });

  testWidgets('password visibility toggle reveals the password',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: AuthScreen(onAuthed: () {}),
      ),
    );
    await tester.pump();
    final passwordField =
        find.widgetWithText(TextField, 'كلمة المرور');
    await tester.enterText(passwordField, 'secret123');
    await tester.pump();
    expect(
      tester.widget<TextField>(passwordField).obscureText,
      isTrue,
    );
    // The eye icon sits below the fold on the 800x600 test surface
    // (the mockup header is taller now) — scroll it into view first.
    await tester.ensureVisible(find.byIcon(Icons.visibility_off_outlined));
    await tester.pumpAndSettle();
    await tester.tap(find.byIcon(Icons.visibility_off_outlined));
    await tester.pump();
    expect(
      tester.widget<TextField>(passwordField).obscureText,
      isFalse,
    );
    expect(find.byIcon(Icons.visibility_outlined), findsOneWidget);
  });

  testWidgets('forgot-password screen renders', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: AuthScreen(onAuthed: () {}),
      ),
    );
    await tester.pump();
    // The forgot link sits below the fold on the 800x600 test surface
    // (the mockup header is taller now) — scroll it into view first.
    await tester.ensureVisible(find.text('نسيت كلمة المرور؟'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('نسيت كلمة المرور؟'));
    await tester.pump();
    expect(find.text('استعادة كلمة المرور'), findsOneWidget);
    expect(find.widgetWithText(TextField, 'البريد الإلكتروني'),
        findsOneWidget);
    expect(find.widgetWithText(ElevatedButton, 'إرسال الرابط'),
        findsOneWidget);
  });
}
