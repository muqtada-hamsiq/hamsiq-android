// Pure model tests for StoriesApi — no camera, no network, no widgets.
// Verifies the mapping against the real DB columns (sql-v5.sql /
// sql-v16.sql): stories(id, user_id, media_url, media_type, created_at,
// expires_at), highlights(id, user_id, title, cover_url, created_at).

import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/models.dart';
import 'package:hamsiq/services/stories_api.dart';

HamsiqProfile _profile(String id) => HamsiqProfile(
      id: id,
      username: 'u-$id',
      displayName: 'User $id',
      avatar: '😀',
      bio: '',
      verified: false,
      isAdmin: false,
      approved: true,
      isPrivate: false,
    );

Map<String, dynamic> _storyRow({
  required int id,
  required String userId,
  String mediaType = 'image',
  required DateTime createdAt,
  DateTime? expiresAt,
}) =>
    {
      'id': id,
      'user_id': userId,
      'media_url': 'https://example.com/$id.jpg',
      'media_type': mediaType,
      'created_at': createdAt.toIso8601String(),
      'expires_at': expiresAt?.toIso8601String(),
    };

void main() {
  test('StoryItem maps the real stories columns', () {
    final created = DateTime.now().subtract(const Duration(hours: 1));
    final s = StoryItem.fromMap(_storyRow(
      id: 7,
      userId: 'user-1',
      mediaType: 'video',
      createdAt: created,
      expiresAt: created.add(const Duration(hours: 24)),
    ));
    expect(s.id, 7);
    expect(s.userId, 'user-1');
    expect(s.mediaType, 'video');
    expect(s.mediaUrl, 'https://example.com/7.jpg');
    expect(s.isActive, isTrue);
  });

  test('StoryItem without expires_at falls back to created_at + 24h', () {
    final fresh = StoryItem.fromMap(_storyRow(
      id: 1,
      userId: 'user-1',
      createdAt: DateTime.now().subtract(const Duration(hours: 2)),
    ));
    expect(fresh.isActive, isTrue);
    final old = StoryItem.fromMap(_storyRow(
      id: 2,
      userId: 'user-1',
      createdAt: DateTime.now().subtract(const Duration(hours: 25)),
    ));
    expect(old.isActive, isFalse);
  });

  test('StoryItem with a past expires_at is not active', () {
    final created = DateTime.now().subtract(const Duration(hours: 25));
    final s = StoryItem.fromMap(_storyRow(
      id: 3,
      userId: 'user-1',
      createdAt: created,
      expiresAt: created.add(const Duration(hours: 24)),
    ));
    expect(s.isActive, isFalse);
  });

  test('HighlightItem maps the real highlights columns', () {
    final h = HighlightItem.fromMap({
      'id': 5,
      'user_id': 'user-1',
      'title': 'السفر',
      'cover_url': 'https://example.com/cover.jpg',
      'created_at': DateTime.now().toIso8601String(),
    });
    expect(h.id, 5);
    expect(h.title, 'السفر');
    expect(h.coverUrl, 'https://example.com/cover.jpg');
  });

  test('groupByUser orders stories oldest-first, newest group first', () {
    final now = DateTime.now();
    final rows = [
      _storyRow(id: 1, userId: 'a', createdAt: now.subtract(const Duration(hours: 3))),
      _storyRow(id: 2, userId: 'a', createdAt: now.subtract(const Duration(hours: 1))),
      _storyRow(id: 3, userId: 'b', createdAt: now.subtract(const Duration(hours: 2))),
    ].map(StoryItem.fromMap).toList();
    final groups = StoriesApi.groupByUser(rows, {
      'a': _profile('a'),
      'b': _profile('b'),
    });
    expect(groups.length, 2);
    // Group 'a' is newest (latest story 1h ago vs 2h ago).
    expect(groups.first.author.id, 'a');
    expect(groups.first.stories.map((s) => s.id).toList(), [1, 2]);
    expect(groups.last.stories.map((s) => s.id).toList(), [3]);
  });
}
