// v1.2.1: the comments bottom sheet opens OVER the feed/reel and
// posts a comment without navigating anywhere. Runs offline with
// fake fetch/send overrides — no Supabase session needed (the
// sheet only touches Api.isLoggedIn, which is false with no session).
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/models.dart';
import 'package:hamsiq/services/comments_api.dart';
import 'package:hamsiq/services/supabase_service.dart';
import 'package:hamsiq/theme.dart';
import 'package:hamsiq/widgets/comments_sheet.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

PostItem _fakePost({bool commentsDisabled = false}) => PostItem(
      id: 1,
      userId: 'user-1',
      caption: 'test post',
      mediaType: 'image',
      isReel: false,
      createdAt: DateTime(2026, 11, 15),
      commentsDisabled: commentsDisabled,
    );

HamsiqProfile _fakeAuthor() => HamsiqProfile(
      id: 'user-2',
      username: 'tester',
      displayName: 'Tester',
      avatar: '🧪',
      avatarUrl: null,
      bio: '',
      verified: false,
      isAdmin: false,
      approved: true,
      isPrivate: false,
    );

CommentItem _fakeComment({int id = 7, String body = 'تعليق موجود'}) =>
    CommentItem(
      id: id,
      postId: 1,
      authorId: 'user-2',
      body: body,
      createdAt: DateTime(2026, 11, 15, 10, 0),
      author: _fakeAuthor(),
    );

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: Api.supabaseUrl,
      publishableKey: Api.supabaseAnonKey,
    );
  });

  Future<void> pumpSheet(
    WidgetTester tester, {
    bool commentsDisabled = false,
    Future<List<CommentItem>> Function(int)? fetch,
    Future<CommentItem> Function(int, String, int?)? send,
  }) async {
    final controller = ScrollController();
    addTearDown(controller.dispose);
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: Scaffold(
          body: CommentsSheet(
            post: _fakePost(commentsDisabled: commentsDisabled),
            scrollController: controller,
            fetchCommentsOverride:
                fetch ?? (_) async => [_fakeComment()],
            sendCommentOverride: send,
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
  }

  testWidgets('sheet lists comments and posts a new one in place',
      (tester) async {
    final sent = <String>[];
    await pumpSheet(
      tester,
      send: (postId, text, parentId) async {
        sent.add(text);
        return _fakeComment(id: 99, body: text.trim());
      },
    );

    // Existing comment from the fake fetch is listed.
    expect(find.text('تعليق موجود'), findsOneWidget);
    expect(find.text('التعليقات (1)'), findsOneWidget);
    // Composer is present in the sheet itself.
    expect(find.widgetWithText(TextField, 'اكتب تعليقاً...'), findsOneWidget);

    await tester.enterText(
      find.widgetWithText(TextField, 'اكتب تعليقاً...'),
      'تعليق تجريبي',
    );
    await tester.tap(find.widgetWithIcon(IconButton, Icons.send));
    await tester.pumpAndSettle();

    // The new comment appears in the same sheet; no navigation happened
    // (the sheet is still the only thing on screen).
    expect(sent, ['تعليق تجريبي']);
    expect(find.text('تعليق تجريبي'), findsOneWidget);
    expect(find.text('تعليق موجود'), findsOneWidget);
    expect(find.text('التعليقات (2)'), findsOneWidget);
  });

  testWidgets('comments-off post hides the composer', (tester) async {
    await pumpSheet(tester, commentsDisabled: true);
    expect(find.text('التعليقات مغلقة لهذا المنشور'), findsOneWidget);
    expect(find.byType(TextField), findsNothing);
  });

  testWidgets('reply target is shown and cleared after sending',
      (tester) async {
    await pumpSheet(
      tester,
      send: (postId, text, parentId) async {
        expect(parentId, 7);
        return _fakeComment(id: 100, body: text.trim());
      },
    );

    await tester.tap(find.text('رد'));
    await tester.pump();
    expect(find.textContaining('رد على'), findsOneWidget);
    expect(find.widgetWithText(TextField, 'اكتب رداً...'), findsOneWidget);

    await tester.enterText(
      find.widgetWithText(TextField, 'اكتب رداً...'),
      'رد تجريبي',
    );
    await tester.tap(find.widgetWithIcon(IconButton, Icons.send));
    await tester.pumpAndSettle();
    expect(find.text('رد تجريبي'), findsOneWidget);
    expect(find.textContaining('رد على'), findsNothing);
  });
}
