// Audit fix H-08b (2026-11-16): a release build must FAIL LOUDLY when
// android/keystore.properties is missing, instead of silently signing
// with the debug key. Reads android/app/build.gradle.kts and asserts
// the loud-failure throw exists and no debug fallback remains for the
// release build type. (Whether the Gradle script actually aborts a
// real release build without the file still needs a release-build
// attempt on a machine with the Android toolchain — no build is run
// by this test.)
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  late String gradle;

  setUpAll(() {
    gradle = File('android/app/build.gradle.kts').readAsStringSync();
  });

  test('release build throws loudly when keystore.properties is missing',
      () {
    expect(gradle, contains('throw GradleException('));
    expect(
      gradle,
      contains('Release signing requires android/keystore.properties'),
    );
    expect(
      gradle,
      contains('refusing to sign a release build with the debug key'),
    );
  });

  test('the loud failure is gated on release tasks, not on every build',
      () {
    // Debug builds must keep working without the properties file.
    expect(gradle, contains('taskGraph.whenReady'));
    expect(gradle, contains('contains("Release"'));
  });

  test('no debug signing fallback remains for the release build type', () {
    expect(gradle, isNot(contains('else "debug"')));
    expect(gradle, isNot(contains('getByName("debug")')));
    expect(
      gradle,
      contains('signingConfig = signingConfigs.getByName("release")'),
    );
  });

  test('the release path still works when keystore.properties exists', () {
    expect(
      gradle,
      contains('keystoreProperties.load(keystorePropertiesFile.inputStream())'),
    );
    expect(gradle, contains('keyAlias = keystoreProperties["keyAlias"]'));
    expect(gradle, contains('storeFile = file(keystoreProperties["storeFile"]'));
  });
}
