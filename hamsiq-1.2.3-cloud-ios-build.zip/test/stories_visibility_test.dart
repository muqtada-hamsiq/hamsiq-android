// H-03 (critical) — Close Friends stories must be enforced SERVER-side.
//
// The real enforcement is the stories SELECT policy in sql-v33.sql, so
// these tests assert on the migration text itself: the policy must
// contain every required condition, use the exact table/column names
// from the combined schema (v4..v31), never query its own table
// (42P17 recursion), and must not be the old bare is_approved()-only
// rule. The client-side rule is tested for real through the pure
// helper StoriesApi.filterCloseFriendsStories — the same helper
// fetchActiveStories / fetchUserStories now apply — proving a
// non-member's Close Friends stories are excluded from the lists the
// app shows. Live role-based behaviour (anonymous, non-member /
// member, owner, blocked, admin) can only be proven against a staging
// Supabase project — see the verification block at the end of
// sql-v33.sql.
//
// Pure file + model tests — no network, no Supabase session. Run from
// the package root (flutter test), where sql-v33.sql lives.

import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/services/stories_api.dart';

/// The CREATE POLICY statement for the stories SELECT policy.
/// Anchored to a line-start match: the file header quotes the old
/// policy text inside `--` comments, so a bare indexOf would find
/// the quote instead of the real statement.
String _storiesSelectPolicy(String sql) {
  const marker = '\ncreate policy "stories visible to approved"';
  final start = sql.indexOf(marker);
  expect(start, isNot(-1), reason: 'sql-v33.sql must recreate the stories SELECT policy');
  final end = sql.indexOf(');', start);
  expect(end, isNot(-1), reason: 'stories SELECT policy statement must terminate');
  return sql.substring(start, end);
}

StoryItem _story({
  required int id,
  required String userId,
  bool closeFriends = false,
}) {
  final now = DateTime.now();
  return StoryItem.fromMap({
    'id': id,
    'user_id': userId,
    'media_url': 'https://example.com/$id.jpg',
    'media_type': 'image',
    'created_at': now.subtract(const Duration(hours: 1)).toIso8601String(),
    'expires_at': now.add(const Duration(hours: 23)).toIso8601String(),
    'is_close_friends': closeFriends,
  });
}

void main() {
  late String sql;
  late String policy;

  setUpAll(() {
    final file = File('sql-v33.sql');
    expect(file.existsSync(), isTrue,
        reason: 'sql-v33.sql must exist at the package root');
    sql = file.readAsStringSync();
    policy = _storiesSelectPolicy(sql);
  });

  group('sql-v33.sql — H-03 stories SELECT policy', () {
    test('policy is dropped before recreation (idempotent re-run)', () {
      const drop = '\ndrop policy if exists "stories visible to approved"';
      const create = '\ncreate policy "stories visible to approved"';
      expect(sql.contains(drop), isTrue);
      expect(sql.indexOf(drop), lessThan(sql.indexOf(create)));
    });

    test('policy still requires an approved account', () {
      expect(policy.contains('public.is_approved()'), isTrue);
    });

    test('owner can always see their own stories', () {
      expect(policy.contains('auth.uid() = user_id'), isTrue);
    });

    test('admin can see every story', () {
      expect(policy.contains('public.is_admin()'), isTrue);
    });

    test('public stories stay public; Close Friends need list membership', () {
      expect(policy.contains('is_close_friends'), isTrue);
      expect(policy.contains('is_on_close_friends_list'), isTrue);
      expect(policy.contains('not is_close_friends'), isTrue);
      expect(
        policy.contains(
            'public.is_on_close_friends_list(user_id, auth.uid())'),
        isTrue,
      );
    });

    test('blocked users see nothing (either direction)', () {
      expect(policy.contains('is_blocked_between'), isTrue);
      expect(
        policy.contains(
            'not public.is_blocked_between(auth.uid(), user_id)'),
        isTrue,
      );
    });

    test('policy is NOT the old bare is_approved()-only rule', () {
      expect(
        sql.contains(
            'for select using (\n  public.is_approved()\n);'),
        isFalse,
        reason: 'the old H-03 policy text must be gone',
      );
      expect(policy.contains('is_on_close_friends_list'), isTrue);
      expect(policy.contains('is_close_friends'), isTrue);
    });

    test('policy never queries its own table (no 42P17 recursion)', () {
      expect(policy.contains('from public.stories'), isFalse);
      expect(policy.contains('from stories'), isFalse);
    });
  });

  group('sql-v33.sql — SECURITY DEFINER helpers', () {
    test('helpers exist, are SECURITY DEFINER, and pin search_path', () {
      for (final name in [
        'is_on_close_friends_list',
        'is_blocked_between',
      ]) {
        expect(sql.contains('function public.$name('), isTrue,
            reason: 'helper $name must be defined');
        final start = sql.indexOf('function public.$name(');
        final body = sql.substring(start, sql.indexOf(r'$$;', start));
        expect(body.contains('security definer'), isTrue,
            reason: '$name must be SECURITY DEFINER');
        expect(body.contains('set search_path = pg_catalog, public'),
            isTrue,
            reason: '$name must pin search_path (H-05 convention)');
      }
    });

    test('helpers use the exact schema table/column names', () {
      // close_friends(user_id, friend_id) (sql-v30) and
      // blocks(blocker_id, blocked_id) (sql-v5) — copied from the
      // combined schema v4..v31, never guessed.
      expect(sql.contains('public.close_friends'), isTrue);
      expect(sql.contains('cf.user_id = p_owner_id'), isTrue);
      expect(sql.contains('cf.friend_id = p_friend_id'), isTrue);
      expect(sql.contains('public.blocks'), isTrue);
      expect(sql.contains('blocker_id'), isTrue);
      expect(sql.contains('blocked_id'), isTrue);
    });
  });

  group('StoriesApi — client filter matches the server rule', () {
    const me = 'me';
    // Owners whose Close Friends list includes me.
    final cfOwners = {'alice'};

    test('non-member never sees a Close Friends story', () {
      final stories = [
        _story(id: 1, userId: 'bob', closeFriends: true),
        _story(id: 2, userId: 'bob'),
      ];
      final visible = StoriesApi.filterCloseFriendsStories(
        stories,
        cfOwners,
        me,
      );
      expect(visible.map((s) => s.id).toList(), [2]);
    });

    test('list member sees the Close Friends story', () {
      final stories = [
        _story(id: 1, userId: 'alice', closeFriends: true),
        _story(id: 2, userId: 'alice'),
      ];
      final visible = StoriesApi.filterCloseFriendsStories(
        stories,
        cfOwners,
        me,
      );
      expect(visible.map((s) => s.id).toList(), [1, 2]);
    });

    test('owner always sees their own Close Friends stories', () {
      final stories = [
        _story(id: 1, userId: me, closeFriends: true),
      ];
      final visible = StoriesApi.filterCloseFriendsStories(
        stories,
        <String>{},
        me,
      );
      expect(visible.map((s) => s.id).toList(), [1]);
    });

    test('public stories are shown to everyone, mixed list', () {
      final stories = [
        _story(id: 1, userId: 'alice', closeFriends: true),
        _story(id: 2, userId: 'bob', closeFriends: true),
        _story(id: 3, userId: 'bob'),
        _story(id: 4, userId: 'carol'),
      ];
      final visible = StoriesApi.filterCloseFriendsStories(
        stories,
        cfOwners,
        me,
      );
      expect(visible.map((s) => s.id).toList(), [1, 3, 4]);
    });

    test('StoryItem maps is_close_friends from the real column', () {
      expect(_story(id: 9, userId: 'bob', closeFriends: true).isCloseFriends,
          isTrue);
      expect(_story(id: 10, userId: 'bob').isCloseFriends, isFalse);
    });
  });

  group('StoriesApi — fetch methods apply the filter', () {
    late String dart;

    setUpAll(() {
      dart = File('lib/services/stories_api.dart').readAsStringSync();
    });

    test('fetchActiveStories applies filterCloseFriendsStories', () {
      final start = dart.indexOf('fetchActiveStories');
      final end = dart.indexOf('fetchUserStories', start);
      final fn = dart.substring(start, end);
      expect(fn.contains('filterCloseFriendsStories'), isTrue);
      expect(fn.contains('fetchCloseFriendOwnerIds'), isTrue);
    });

    test('fetchUserStories applies filterCloseFriendsStories', () {
      final start = dart.indexOf('fetchUserStories');
      final end = dart.indexOf('publishStory', start);
      final fn = dart.substring(start, end);
      expect(fn.contains('filterCloseFriendsStories'), isTrue);
      expect(fn.contains('fetchCloseFriendOwnerIds'), isTrue);
    });

    test('the stale "separate server change" admission is gone', () {
      expect(dart.contains('tightening the stories RLS policy'), isFalse);
      expect(dart.contains('is a separate server change'), isFalse);
      expect(dart.contains('A direct API read could still fetch'), isFalse);
      expect(dart.contains('sql-v33'), isTrue);
      expect(dart.contains('H-03'), isTrue);
    });
  });
}
