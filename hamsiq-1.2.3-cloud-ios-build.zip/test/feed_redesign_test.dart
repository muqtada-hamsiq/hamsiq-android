// Feed redesign tests (user order 2026-11-16, files 1 + 2 + StoryBar height).
// - AppBar shows the real logo asset next to the 'Hamsiq' name.
// - No "what's on your mind" composer box anywhere in the feed.
// - All/Favourites filter chips toggle the favourites filter.
// - StoryBar tiles are circular, including "my story" with its + badge,
//   inside a 112-high bar (new _StoryCircle is 70px circle + label).
// - The bottom-nav + button still opens the create-post sheet.
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/models.dart';
import 'package:hamsiq/screens/feed_screen.dart';
import 'package:hamsiq/screens/home_shell.dart';
import 'package:hamsiq/screens/stories_screen.dart';
import 'package:hamsiq/services/app_strings.dart';
import 'package:hamsiq/services/supabase_service.dart';
import 'package:hamsiq/theme.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

HamsiqProfile _me() => HamsiqProfile(
      id: 'test-user',
      username: 'testuser',
      displayName: 'Test User',
      avatar: '😀',
      bio: '',
      verified: false,
      isAdmin: false,
      approved: true,
      isPrivate: false,
    );

Widget _wrap(Widget child) => MaterialApp(
      theme: HamsiqTheme.dark,
      home: Scaffold(body: child),
    );

Finder _logoImage() => find.byWidgetPredicate(
      (w) =>
          w is Image &&
          w.image is AssetImage &&
          (w.image as AssetImage).assetName == 'assets/logo.png',
    );

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: Api.supabaseUrl,
      publishableKey: Api.supabaseAnonKey,
    );
    AppStrings.lang.value = 'ar';
  });

  testWidgets('feed AppBar shows logo asset + Hamsiq name + verified badge',
      (tester) async {
    await tester.pumpWidget(_wrap(FeedScreen(
      me: _me(),
      refreshTick: ValueNotifier<int>(0),
      onOpenChats: () {},
    )));
    await tester.pump();
    expect(_logoImage(), findsOneWidget);
    expect(find.text('Hamsiq'), findsOneWidget);
    // Mockup-match: blue verified badge next to the brand name.
    expect(find.byIcon(Icons.verified), findsOneWidget);
    // Kept actions: notifications bell + messages only. The Blend
    // button was removed from the AppBar (2026-11-16 mockup round);
    // _openBlendPicker + BlendScreen stay intact, unreachable until a
    // new Blend placement is decided.
    expect(find.byIcon(Icons.notifications_outlined), findsOneWidget);
    expect(find.byIcon(Icons.people_alt_outlined), findsNothing);
    expect(find.byIcon(Icons.send_outlined), findsOneWidget);
  });

  testWidgets('feed has no composer box', (tester) async {
    await tester.pumpWidget(_wrap(FeedScreen(
      me: _me(),
      refreshTick: ValueNotifier<int>(0),
      onOpenChats: () {},
    )));
    await tester.pump();
    expect(find.text('ماذا يدور في ذهنك؟'), findsNothing);
    expect(find.byType(TextField), findsNothing);
  });

  testWidgets('filter chips toggle favourites', (tester) async {
    await tester.pumpWidget(_wrap(FeedScreen(
      me: _me(),
      refreshTick: ValueNotifier<int>(0),
      onOpenChats: () {},
    )));
    await tester.pump();
    final allChip =
        find.widgetWithText(ChoiceChip, AppStrings.t('allFilter'));
    final favChip =
        find.widgetWithText(ChoiceChip, AppStrings.t('favouritesFilter'));
    expect(allChip, findsOneWidget);
    expect(favChip, findsOneWidget);
    expect(tester.widget<ChoiceChip>(allChip).selected, isTrue);
    expect(tester.widget<ChoiceChip>(favChip).selected, isFalse);
    await tester.tap(favChip);
    await tester.pump();
    expect(tester.widget<ChoiceChip>(allChip).selected, isFalse);
    expect(tester.widget<ChoiceChip>(favChip).selected, isTrue);
    await tester.tap(allChip);
    await tester.pump();
    expect(tester.widget<ChoiceChip>(allChip).selected, isTrue);
    expect(tester.widget<ChoiceChip>(favChip).selected, isFalse);
  });

  testWidgets('StoryBar: circular tiles, my-story + badge, height 112',
      (tester) async {
    await tester.pumpWidget(_wrap(StoryBar(me: _me())));
    // StoryBar loads from the API; let the load finish or fail, then
    // the row (with my circle) renders. Bounded pumps only — no
    // pumpAndSettle, so a slow network cannot hang the test.
    for (var i = 0; i < 6; i++) {
      await tester.pump(const Duration(seconds: 1));
      if (find.text(AppStrings.t('myStory')).evaluate().isNotEmpty) break;
    }
    expect(find.text(AppStrings.t('myStory')), findsOneWidget);
    // The + badge on my story.
    expect(find.byIcon(Icons.add), findsOneWidget);
    // Circular ring containers exist (ring + + badge are circles).
    final circles = find.byWidgetPredicate((w) =>
        w is Container &&
        w.decoration is BoxDecoration &&
        (w.decoration as BoxDecoration).shape == BoxShape.circle);
    expect(circles, findsWidgets);
    // Follow-up: the bar is 112 high to fit the taller circles + label.
    expect(
      find.byWidgetPredicate((w) => w is SizedBox && w.height == 112),
      findsOneWidget,
    );
  });

  testWidgets('bottom-nav + button still opens the create-post sheet',
      (tester) async {
    await tester.pumpWidget(MaterialApp(
      theme: HamsiqTheme.dark,
      home: HomeShell(me: _me()),
    ));
    await tester.pump();
    // The + icon also exists as the my-story badge inside the feed tab,
    // so scope the tap to the bottom navigation bar.
    final navPlus = find.descendant(
      of: find.byType(BottomNavigationBar),
      matching: find.byIcon(Icons.add),
    );
    expect(navPlus, findsOneWidget);
    await tester.tap(navPlus);
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.byType(CreateSheet), findsOneWidget);
  });
}
