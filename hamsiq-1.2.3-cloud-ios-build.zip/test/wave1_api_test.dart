// Unit tests for Wave 1 (Instagram features).
// Pure / offline only: comment ordering + threading, notification
// toggle filtering, grid ordering, story-reply parsing, model parsing.
// No Supabase session or network is needed here.

import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/models.dart';
import 'package:hamsiq/services/comments_api.dart';
import 'package:hamsiq/services/messages_api.dart';
import 'package:hamsiq/services/notifications_api.dart';
import 'package:hamsiq/services/share_api.dart';
import 'package:hamsiq/services/stories_api.dart';

CommentItem _comment({
  required int id,
  int? parentId,
  bool isPinned = false,
  String createdAt = '2026-11-15T10:00:00+00:00',
}) =>
    CommentItem(
      id: id,
      postId: 42,
      authorId: '00000000-0000-0000-0000-000000000001',
      body: 'c$id',
      createdAt: DateTime.parse(createdAt),
      parentId: parentId,
      isPinned: isPinned,
    );

PostItem _post({
  required int id,
  bool isPinned = false,
  int gridOrder = 0,
  String createdAt = '2026-11-15T10:00:00+00:00',
}) =>
    PostItem(
      id: id,
      userId: '00000000-0000-0000-0000-000000000001',
      caption: 'p$id',
      mediaType: 'image',
      isReel: false,
      createdAt: DateTime.parse(createdAt),
      isPinned: isPinned,
      gridOrder: gridOrder,
    );

void main() {
  group('comments: new columns', () {
    test('CommentItem.fromMap parses parent_id, gif_url, is_pinned', () {
      final c = CommentItem.fromMap({
        'id': 9,
        'post_id': 42,
        'author_id': '00000000-0000-0000-0000-000000000001',
        'body': '',
        'created_at': '2026-11-15T10:00:00+00:00',
        'parent_id': 3,
        'gif_url': 'https://media.giphy.com/media/abc/giphy.gif',
        'is_pinned': true,
      });
      expect(c.parentId, 3);
      expect(c.gifUrl, 'https://media.giphy.com/media/abc/giphy.gif');
      expect(c.isPinned, isTrue);
      expect(c.isGifOnly, isTrue);
    });

    test('orderComments puts pinned first, oldest first within groups', () {
      final ordered = CommentsApi.orderComments([
        _comment(id: 1, createdAt: '2026-11-15T10:00:00+00:00'),
        _comment(id: 2, isPinned: true, createdAt: '2026-11-15T11:00:00+00:00'),
        _comment(id: 3, isPinned: true, createdAt: '2026-11-15T09:00:00+00:00'),
        _comment(id: 4, createdAt: '2026-11-15T08:00:00+00:00'),
      ]);
      expect(ordered.map((c) => c.id).toList(), [3, 2, 4, 1]);
    });

    test('threadComments nests replies directly under their parent', () {
      final threaded = CommentsApi.threadComments([
        _comment(id: 1),
        _comment(id: 2, parentId: 1),
        _comment(id: 3),
        _comment(id: 4, parentId: 1),
        _comment(id: 5, parentId: 3),
      ]);
      expect(threaded.map((c) => c.id).toList(), [1, 2, 4, 3, 5]);
    });

    test('curated GIF list is non-empty and all Giphy direct URLs', () {
      expect(CommentsApi.curatedGifUrls, isNotEmpty);
      for (final url in CommentsApi.curatedGifUrls) {
        expect(url, startsWith('https://media.giphy.com/media/'));
        expect(url, endsWith('/giphy.gif'));
      }
    });
  });

  group('notifications: toggle gating', () {
    NotificationItem notif(String type, {bool isRead = false}) =>
        NotificationItem(
          id: type.hashCode,
          userId: 'u1',
          actorId: 'u2',
          type: type,
          createdAt: DateTime.parse('2026-11-15T10:00:00+00:00'),
          isRead: isRead,
        );

    test('filterByToggles hides types whose toggle is off', () {
      final items = [
        notif('like'),
        notif('comment'),
        notif('follow'),
        notif('message'),
      ];
      final kept = NotificationsApi.filterByToggles(items, {
        'notif_likes': false,
        'notif_comments': true,
        'notif_followers': true,
        'notif_messages': false,
      });
      expect(kept.map((n) => n.type).toList(), ['comment', 'follow']);
    });

    test('filterByToggles defaults a missing toggle to on', () {
      final kept = NotificationsApi.filterByToggles([notif('mention')], {});
      expect(kept, hasLength(1));
    });

    test('typeLabel covers every type the API writes', () {
      for (final type in NotificationsApi.types) {
        expect(NotificationsApi.typeLabel(type), isNotEmpty);
        expect(NotificationsApi.toggleColumnForType[type], isNotNull);
      }
    });
  });

  group('share: grid ordering', () {
    test('orderPostsForGrid puts pinned first, then grid_order, then newest', () {
      final ordered = ShareApi.orderPostsForGrid([
        _post(id: 1, gridOrder: 2, createdAt: '2026-11-15T10:00:00+00:00'),
        _post(id: 2, gridOrder: 0, createdAt: '2026-11-15T09:00:00+00:00'),
        _post(id: 3, isPinned: true, createdAt: '2026-11-15T08:00:00+00:00'),
        _post(id: 4, isPinned: true, createdAt: '2026-11-15T12:00:00+00:00'),
        _post(id: 5, gridOrder: 1, createdAt: '2026-11-15T11:00:00+00:00'),
      ]);
      expect(ordered.map((p) => p.id).toList(), [4, 3, 2, 5, 1]);
    });

    test('maxPinnedPosts is 3 (verified Instagram limit)', () {
      expect(ShareApi.maxPinnedPosts, 3);
      expect(CommentsApi.maxPinnedComments, 3);
    });
  });

  group('messages: shared post + story reply', () {
    test('parseStoryReplyBody decodes the JSON body', () {
      final parsed = MessagesApi.parseStoryReplyBody(
        '{"story_id": 77, "text": "حلوة!"}',
      );
      expect(parsed.storyId, 77);
      expect(parsed.text, 'حلوة!');
    });

    test('parseStoryReplyBody falls back to raw text on bad JSON', () {
      final parsed = MessagesApi.parseStoryReplyBody('not json');
      expect(parsed.storyId, isNull);
      expect(parsed.text, 'not json');
    });

    test('lastMessageLabel names the new message types', () {
      expect(MessagesApi.lastMessageLabel('shared_post', '42'),
          contains('منشور'));
      expect(MessagesApi.lastMessageLabel('story_reply', '{}'),
          contains('قصة'));
    });
  });

  group('stories: views', () {
    test('StoryView.fromMap parses the real story_views columns', () {
      final v = StoryView.fromMap({
        'id': 5,
        'story_id': 77,
        'viewer_id': '00000000-0000-0000-0000-000000000001',
        'created_at': '2026-11-15T10:00:00+00:00',
      });
      expect(v.id, 5);
      expect(v.storyId, 77);
      expect(v.viewer, isNull);
    });
  });

  group('models: PostItem new fields', () {
    test('PostItem.fromMap defaults is_pinned/grid_order when absent', () {
      final p = PostItem.fromMap({
        'id': 1,
        'user_id': 'u1',
        'caption': 'x',
        'media_type': 'image',
        'is_reel': false,
        'created_at': '2026-11-15T10:00:00+00:00',
      });
      expect(p.isPinned, isFalse);
      expect(p.gridOrder, 0);
    });
  });
}
