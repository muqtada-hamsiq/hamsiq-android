// Hamsiq audit fix H-01 (part 2) — check-username tests.
//
// These tests run with NO Supabase initialization and NO network: they
// pin the client-side contract of the check-username Edge Function
// (supabase/functions/check-username/index.ts) and the signup wiring in
// lib/screens/auth_screen.dart:
//   * the response shape is exactly {"available": true/false} — taken
//     and invalid input look identical, and an email can never appear
//     in a client-visible response (any email-bearing body is rejected
//     wholesale, so signup can never proceed on one),
//   * invalid/empty input is handled generically (never sent by the
//     app; the server answers the same {"available": false} as "taken"),
//   * rate-limit threshold logic (30 checks / IP / 15 min) and the
//     429 -> rate-limit-message mapping,
//   * the signup path calls check-username and no longer references the
//     email-leaking RPC anywhere.
// The live checks (deploy, curl as anonymous for a taken vs free
// username, signup end-to-end, 429 after 31 checks) still need a staging
// Supabase project — see supabase/secure-login-README.md.

import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/screens/auth_screen.dart';

void main() {
  group('response shape: exactly {"available": bool}, nothing else', () {
    test('free username parses to true', () {
      final body = <String, dynamic>{'available': true};
      expect(body.keys.toSet(), {'available'});
      expect(parseUsernameAvailability(body), isTrue);
    });

    test('taken username parses to false, same shape as free', () {
      final body = <String, dynamic>{'available': false};
      expect(body.keys.toSet(), {'available'});
      expect(parseUsernameAvailability(body), isFalse);
      // The ONLY difference between free and taken is the boolean.
      expect(
        body.keys.toSet(),
        (<String, dynamic>{'available': true}).keys.toSet(),
      );
    });

    test('a body containing an email key is rejected wholesale', () {
      expect(
        parseUsernameAvailability(<String, dynamic>{
          'available': false,
          'email': 'victim@example.com',
        }),
        isNull,
      );
      expect(
        parseUsernameAvailability(<String, dynamic>{
          'available': true,
          'email': 'victim@example.com',
        }),
        isNull,
      );
    });

    test('any extra key besides available is rejected', () {
      for (final body in [
        <String, dynamic>{'available': true, 'username': 'muqtada'},
        <String, dynamic>{'available': false, 'id': 'user-id-123'},
        <String, dynamic>{'available': true, 'reason': 'taken'},
      ]) {
        expect(
          parseUsernameAvailability(body),
          isNull,
          reason: 'should reject $body',
        );
      }
    });

    test('malformed bodies are rejected (never treated as available)', () {
      for (final bad in [
        null,
        'true',
        1,
        <String, dynamic>{},
        <String, dynamic>{'available': 'yes'},
        <String, dynamic>{'available': 1},
        <String, dynamic>{'available': null},
        <dynamic>['available', true],
      ]) {
        expect(
          parseUsernameAvailability(bad),
          isNull,
          reason: 'should reject $bad',
        );
      }
    });
  });

  group('invalid/empty input handled generically', () {
    test('server answers the same {"available": false} for invalid input',
        () {
      final src = File(
        'supabase/functions/check-username/index.ts',
      ).readAsStringSync();
      // Invalid shape (empty, wrong type, too short/long, illegal
      // chars) returns the taken-shaped body — never an error that
      // distinguishes it from a taken name.
      expect(src.contains('if (!shapeValid)'), isTrue);
      expect(
        src.contains('return availabilityResponse(false);'),
        isTrue,
      );
      // And the taken path returns the identical call.
      expect(
        'availabilityResponse(false)'.allMatches(src).length,
        greaterThanOrEqualTo(2),
      );
      // The function never builds an error body that names a reason
      // for unavailability (only the 429 / 500 statuses do, and those
      // say nothing about the username).
      expect(src.contains('username taken'), isFalse);
      expect(src.contains('invalid username'), isFalse);
    });

    test('the app never sends an empty/invalid username to the function',
        () {
      final src = File(
        'lib/screens/auth_screen.dart',
      ).readAsStringSync();
      final signupBlock = src.substring(
        src.indexOf('Future<void> _doSignup()'),
        src.indexOf('Future<void> _doVerifyOtp()'),
      );
      final invokeAt = signupBlock.indexOf("functions.invoke(");
      expect(invokeAt, greaterThan(0));
      final beforeInvoke = signupBlock.substring(0, invokeAt);
      // All client-side validation happens before the invoke.
      expect(beforeInvoke.contains('u.isEmpty'), isTrue);
      expect(beforeInvoke.contains('isValidUsername(u)'), isTrue);
      expect(beforeInvoke.contains('u.length < 3'), isTrue);
    });
  });

  group('rate-limit behaviour', () {
    test('threshold constants match the server (index.ts)', () {
      expect(checkUsernameMaxPerIp, 30);
      expect(checkUsernameRateLimitWindow, const Duration(minutes: 15));
    });

    test('decision function: block exactly at the limit', () {
      expect(
        isUsernameCheckRateLimited(checksInWindow: 29, maxChecks: 30),
        isFalse,
      );
      expect(
        isUsernameCheckRateLimited(checksInWindow: 30, maxChecks: 30),
        isTrue,
      );
      expect(
        isUsernameCheckRateLimited(checksInWindow: 31, maxChecks: 30),
        isTrue,
      );
      expect(
        isUsernameCheckRateLimited(checksInWindow: 0, maxChecks: 30),
        isFalse,
      );
    });

    test('server counts sentinel rows per IP, never login failures', () {
      final src = File(
        'supabase/functions/check-username/index.ts',
      ).readAsStringSync();
      expect(src.contains('const MAX_CHECKS_PER_IP = 30;'), isTrue);
      expect(src.contains('const WINDOW_MINUTES = 15;'), isTrue);
      expect(
        src.contains(
          'const CHECK_USERNAME_SENTINEL = "__check_username__";',
        ),
        isTrue,
      );
      // The limit counts only this function's own sentinel rows for
      // the caller IP (success = true, so secure-login's failure
      // counts can never see them).
      expect(
        src.contains('.eq("username", CHECK_USERNAME_SENTINEL)'),
        isTrue,
      );
      expect(src.contains('.eq("success", true)'), isTrue);
      expect(src.contains('.eq("ip", ip)'), isTrue);
      // Over the limit -> 429, signalled by status only.
      expect(src.contains('return rateLimited();'), isTrue);
      expect(src.contains('jsonResponse({ error: "Too many requests" }, 429)'), isTrue);
    });

    test('HTTP 429 maps to the rate-limit message in the signup flow',
        () {
      final src = File(
        'lib/screens/auth_screen.dart',
      ).readAsStringSync();
      final signupBlock = src.substring(
        src.indexOf('Future<void> _doSignup()'),
        src.indexOf('Future<void> _doVerifyOtp()'),
      );
      expect(
        signupBlock.contains('on FunctionsHttpException catch (e)'),
        isTrue,
      );
      expect(signupBlock.contains('e.status == 429'), isTrue);
      expect(
        signupBlock.contains('checkUsernameRateLimitError'),
        isTrue,
      );
      expect(
        checkUsernameRateLimitError,
        'محاولات كثيرة، انتظر 15 دقيقة وحاول مرة ثانية',
      );
    });
  });

  group('auth_screen signup wiring (source assertions)', () {
    test('signup calls check-username, never the email-leaking RPC', () {
      final src = File(
        'lib/screens/auth_screen.dart',
      ).readAsStringSync();
      final signupBlock = src.substring(
        src.indexOf('Future<void> _doSignup()'),
        src.indexOf('Future<void> _doVerifyOtp()'),
      );
      expect(signupBlock.contains("functions.invoke("), isTrue);
      expect(signupBlock.contains("'check-username'"), isTrue);
      expect(signupBlock.contains('parseUsernameAvailability'), isTrue);
      // No RPC invocation and no mention of the old RPC in the signup
      // path at all — not even in a comment.
      expect(signupBlock.contains('get_email_by_username'), isFalse);
      expect(signupBlock.contains('client.rpc'), isFalse);
      // File-wide: the quoted RPC name must not appear anywhere in
      // this screen any more (the login flow never named it with
      // quotes; only the old signup call did).
      expect("'get_email_by_username'".allMatches(src).length, 0);
    });

    test('signup still proceeds to signUp + OTP exactly as before', () {
      final src = File(
        'lib/screens/auth_screen.dart',
      ).readAsStringSync();
      final signupBlock = src.substring(
        src.indexOf('Future<void> _doSignup()'),
        src.indexOf('Future<void> _doVerifyOtp()'),
      );
      // Taken name still shows the same message.
      expect(signupBlock.contains("AppStrings.t('usernameTaken')"), isTrue);
      // Free name still goes through Api.signUp, then OTP when no
      // session is created immediately.
      expect(signupBlock.contains('await Api.signUp('), isTrue);
      expect(signupBlock.contains("_step = 'otp'"), isTrue);
      // A rejected (malformed / email-bearing) response blocks signup
      // with the generic error instead of proceeding.
      expect(
        signupBlock.contains("AppStrings.t('genericError')"),
        isTrue,
      );
    });

    test('login flow untouched by this change', () {
      final src = File(
        'lib/screens/auth_screen.dart',
      ).readAsStringSync();
      final loginBlock = src.substring(
        src.indexOf('Future<void> _doLogin()'),
        src.indexOf('Future<void> _doSignup()'),
      );
      // This change must not have touched login at all: no
      // check-username reference and no availability parsing there.
      expect(loginBlock.contains('check-username'), isFalse);
      expect(loginBlock.contains('parseUsernameAvailability'), isFalse);
      expect(loginBlock.contains('checkUsernameRateLimitError'), isFalse);
    });
  });

  group('check-username Edge Function source (no email anywhere)', () {
    test('the function never reads or returns an email', () {
      final src = File(
        'supabase/functions/check-username/index.ts',
      ).readAsStringSync();
      // No email key in any response, no admin email fetch, no
      // sign-in — the function only checks profile existence.
      expect(src.contains("'email'"), isFalse);
      expect(src.contains('"email"'), isFalse);
      expect(src.contains('getUserById'), isFalse);
      expect(src.contains('signInWithPassword'), isFalse);
      expect(src.contains('auth.admin'), isFalse);
      // The only profile columns read are the id (existence check).
      expect(src.contains('.from("profiles")'), isTrue);
      expect(src.contains('.select("id")'), isTrue);
      expect(src.contains('.ilike("username"'), isTrue);
      // The only 200 body the function builds is {"available": bool}.
      expect(src.contains('jsonResponse({ available }, 200)'), isTrue);
    });
  });
}
