// Audit fixes H-07 (2026-11-16): the three incomplete interactions.
// Pumping ProfileScreen / ReelsScreen / ThreadScreen would hit the
// network, so — like profile_settings_rtl_test.dart — these are source
// assertions on the wiring, plus a structural check that the detail
// screen actually receives the tapped post.
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  late String profileSrc;
  late String postDetailSrc;
  late String reelsSrc;
  late String chatsSrc;

  setUpAll(() {
    profileSrc = File('lib/screens/profile_screen.dart').readAsStringSync();
    postDetailSrc =
        File('lib/screens/post_detail_screen.dart').readAsStringSync();
    reelsSrc = File('lib/screens/reels_screen.dart').readAsStringSync();
    chatsSrc = File('lib/screens/chats_screen.dart').readAsStringSync();
  });

  group('H-07a: tapping a post tile opens the post detail screen', () {
    test('the stale "does nothing" note is gone', () {
      expect(
        profileSrc,
        isNot(contains('does nothing in Phase 1')),
        reason: 'header comment still claims the tile does nothing',
      );
      expect(profileSrc, contains('opens PostDetailScreen'));
    });

    test('the tile tap navigates to PostDetailScreen with the tapped post',
        () {
      // _postTile is the only grid-tile builder; its onTap must push
      // the detail screen carrying exactly the tapped post.
      final tile = profileSrc.substring(profileSrc.indexOf('_postTile'));
      expect(tile, contains('Navigator.of(context).push'));
      expect(tile, contains('PostDetailScreen(post: post)'));
    });

    test('PostDetailScreen requires the post it is given', () {
      expect(postDetailSrc, contains('required this.post'));
      expect(postDetailSrc, contains('final PostItem post;'));
    });
  });

  group('H-07b: neighbouring reels are preloaded', () {
    test('the stale "no controller yet" placeholder note is gone', () {
      expect(
        reelsSrc,
        isNot(contains('no controller yet')),
        reason: 'adjacent pages still documented as controller-less',
      );
    });

    test('a preload cache exists for the immediate neighbours only', () {
      expect(reelsSrc, contains('_preloadControllers'));
      expect(reelsSrc, contains('_preloadAdjacent'));
      // Neighbours are _current ± 1 — never further away.
      expect(reelsSrc, contains('_current - 1'));
      expect(reelsSrc, contains('_current + 1'));
      expect(reelsSrc, isNot(contains('_current - 2')));
      expect(reelsSrc, isNot(contains('_current + 2')));
    });

    test('_initController adopts a preloaded controller and plays it', () {
      // _initController is async since the H-04 re-sign (it awaits
      // ensureFreshUrl before creating a fresh controller), so locate
      // it by signature without the return type.
      final init = reelsSrc.substring(
        reelsSrc.indexOf('_initController(int index)'),
        reelsSrc.indexOf('_createPreloadController'),
      );
      expect(init, contains('_preloadControllers.remove(index)'));
      expect(init, contains('preloaded.play()'));
      // A preloaded neighbour that FAILED to initialise is not adopted
      // (it would sit on a spinner forever) — it is disposed and a
      // fresh controller is created instead.
      expect(init, contains('_preloadFailed.contains(index)'));
      expect(init, contains('preloaded.dispose()'));
    });

    test('a preloaded neighbour renders its video, not a dark tile', () {
      final page = reelsSrc.substring(reelsSrc.indexOf('_buildPage'));
      expect(page, contains('VideoPlayer(preloaded)'));
      expect(page, contains('_preloadInitialized.contains(index)'));
    });

    test('preloaded controllers are disposed (prune + feed reload + dispose)',
        () {
      expect(reelsSrc, contains('_disposePreload('));
      expect(reelsSrc, contains('_clearPreloads()'));
      // _clearPreloads runs both when the feed reloads and in dispose().
      expect('_clearPreloads();'.allMatches(reelsSrc).length,
          greaterThanOrEqualTo(2));
      // The outgoing controller is parked, not disposed, on a
      // one-page move — so swiping back is instant too.
      expect(reelsSrc, contains('_preloadControllers[previous] = outgoing'));
    });
  });

  group('H-07c: the mic button records on tap', () {
    test('tap toggles the same recording the long-press drives', () {
      final toggle = chatsSrc.substring(
        chatsSrc.indexOf('_toggleRecording()'),
        chatsSrc.indexOf('Future<void> _startRecording'),
      );
      expect(toggle, contains('_stopRecording(send: true)'));
      expect(toggle, contains('_startRecording()'));
    });

    test('the mic button is wired to the toggle and never dead', () {
      // The mic control is the block between the long-press gesture
      // and the send button.
      final micBlock = chatsSrc.substring(
        chatsSrc.indexOf('onLongPressStart'),
        chatsSrc.indexOf('Icons.send,'),
      );
      expect(micBlock, contains('onPressed: _sending ? null : _toggleRecording'));
      expect(micBlock, isNot(contains('onPressed: null,')));
      // The long-press gesture still works alongside the tap.
      expect(micBlock, contains('onLongPressStart'));
      expect(micBlock, contains('onLongPressEnd'));
    });

    test('recording has a visible state change on the button', () {
      final micBlock = chatsSrc.substring(
        chatsSrc.indexOf('onLongPressStart'),
        chatsSrc.indexOf('Icons.send,'),
      );
      // Red stop icon while recording, mic icon otherwise.
      expect(micBlock, contains('Icons.stop'));
      expect(micBlock, contains('Icons.mic'));
      expect(micBlock, contains('Colors.red'));
    });

    test('a fast double-tap cannot start the recorder twice', () {
      expect(chatsSrc, contains('_recStarting'));
    });
  });
}
