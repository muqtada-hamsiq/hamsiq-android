// Mockup-match round (2026-11-16, login screenshot): the login screen
// reproduces the user's mockup literally — bare 120pt logo, Hamsiq
// title + tagline, 56pt pill login/signup toggle, 60pt pill inputs
// (28 radius), 60pt pill blue login button with arrow, and the white
// Google button kept below the login button with the "or" divider.
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/screens/auth_screen.dart';
import 'package:hamsiq/services/app_strings.dart';
import 'package:hamsiq/services/supabase_service.dart';
import 'package:hamsiq/theme.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

Finder _logoImage() => find.byWidgetPredicate(
      (w) =>
          w is Image &&
          w.image is AssetImage &&
          (w.image as AssetImage).assetName == 'assets/logo.png',
    );

/// Pill input containers: 28 radius + a 60pt min height (the toggle
/// also has radius 28, but no min-height constraint).
Finder _pillInputs() => find.byWidgetPredicate((w) =>
    w is Container &&
    w.decoration is BoxDecoration &&
    (w.decoration as BoxDecoration).borderRadius ==
        BorderRadius.circular(28) &&
    w.constraints != null &&
    w.constraints!.minHeight == 60);

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: Api.supabaseUrl,
      publishableKey: Api.supabaseAnonKey,
    );
    AppStrings.lang.value = 'ar';
  });

  Future<void> pumpLogin(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: HamsiqTheme.dark,
        home: AuthScreen(onAuthed: () {}),
      ),
    );
    await tester.pump();
  }

  testWidgets('bare 120pt logo, Hamsiq title, tagline', (tester) async {
    await pumpLogin(tester);
    final logo = _logoImage();
    expect(logo, findsOneWidget);
    expect(tester.widget<Image>(logo).width, 120);
    expect(tester.widget<Image>(logo).height, 120);
    // No bordered 82x82 box around the logo anymore.
    expect(
      find.byWidgetPredicate((w) =>
          w is Container &&
          w.constraints != null &&
          w.constraints!.maxWidth == 82),
      findsNothing,
    );
    expect(find.text('Hamsiq'), findsOneWidget);
    expect(find.text('مكانك يجمع العالم'), findsOneWidget);
  });

  testWidgets('pill toggle: 56 high, 28 radius, login half active blue',
      (tester) async {
    await pumpLogin(tester);
    final toggle = find.byKey(const Key('authModeToggle'));
    expect(toggle, findsOneWidget);
    expect(tester.getSize(toggle).height, 56);
    final deco =
        tester.widget<Container>(toggle).decoration as BoxDecoration;
    expect(deco.borderRadius, BorderRadius.circular(28));
    // Both halves present: login is the active (blue) one, signup is
    // the dark half. 'تسجيل الدخول' also labels the login button.
    expect(find.text('تسجيل الدخول'), findsNWidgets(2));
    expect(find.text('إنشاء حساب'), findsOneWidget);
    final blueHalves = find.byWidgetPredicate((w) =>
        w is Container &&
        w.decoration is BoxDecoration &&
        (w.decoration as BoxDecoration).color == HamsiqTheme.accent);
    expect(blueHalves, findsOneWidget);
    expect(
      find.descendant(
        of: blueHalves,
        matching: find.text('تسجيل الدخول'),
      ),
      findsOneWidget,
    );
  });

  testWidgets('heading 32, subtitle, pill inputs 60 high / 28 radius',
      (tester) async {
    await pumpLogin(tester);
    final heading = find.text('مرحباً بعودتك');
    expect(heading, findsOneWidget);
    expect(
      tester.widget<Text>(heading).style?.fontSize,
      32,
    );
    expect(find.text('سجّل دخولك للمتابعة إلى همسيق'), findsOneWidget);
    expect(_pillInputs(), findsNWidgets(2));
    // Person icon on the username field, lock + eye on the password.
    expect(find.byIcon(Icons.person_outline_rounded), findsOneWidget);
    expect(find.byIcon(Icons.lock_outline_rounded), findsOneWidget);
    expect(find.byIcon(Icons.visibility_off_outlined), findsOneWidget);
  });

  testWidgets('login button is a 60pt pill with arrow icon',
      (tester) async {
    await pumpLogin(tester);
    final button = find.widgetWithText(ElevatedButton, 'تسجيل الدخول');
    expect(button, findsOneWidget);
    expect(tester.getSize(button).height, 60);
    expect(find.byIcon(Icons.login), findsOneWidget);
    final shape =
        tester.widget<ElevatedButton>(button).style?.shape?.resolve({});
    expect(shape, isA<RoundedRectangleBorder>());
    expect(
      (shape as RoundedRectangleBorder).borderRadius,
      BorderRadius.circular(28),
    );
  });

  testWidgets('Google button kept below the login button with or-divider',
      (tester) async {
    await pumpLogin(tester);
    final loginButton =
        find.widgetWithText(ElevatedButton, 'تسجيل الدخول');
    final googleButton =
        find.widgetWithText(ElevatedButton, 'المتابعة مع Google');
    expect(googleButton, findsOneWidget);
    expect(find.text('أو'), findsOneWidget);
    expect(
      tester.getTopLeft(googleButton).dy,
      greaterThan(tester.getTopLeft(loginButton).dy),
    );
  });

  testWidgets('toggle switches login <-> signup in place', (tester) async {
    await pumpLogin(tester);
    expect(find.text('مرحباً بعودتك'), findsOneWidget);
    await tester.tap(find.text('إنشاء حساب'));
    await tester.pump();
    expect(find.text('إنشاء حساب جديد'), findsOneWidget);
    expect(
      find.widgetWithText(TextField, 'البريد الإلكتروني'),
      findsOneWidget,
    );
    expect(_pillInputs(), findsNWidgets(3));
    expect(find.text('المتابعة مع Google'), findsOneWidget);
    // Back via the toggle's login half (first 'تسجيل الدخول' in the
    // tree; the second is the bottom switch row).
    await tester.tap(find.text('تسجيل الدخول').first);
    await tester.pump();
    expect(find.text('مرحباً بعودتك'), findsOneWidget);
    expect(_pillInputs(), findsNWidgets(2));
  });
}
