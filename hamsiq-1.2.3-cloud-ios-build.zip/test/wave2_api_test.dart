// Unit tests for Wave 2 (Instagram features).
// Pure / offline only: translation direction, mute/snooze activity,
// feed filters, Close Friends story filtering, scheduled-post due
// checks, model parsing for the new columns. No Supabase session or
// network is needed here.

import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/models.dart';
import 'package:hamsiq/services/stories_api.dart';
import 'package:hamsiq/services/wave2_api.dart';

PostItem _post({
  required int id,
  required String userId,
  String createdAt = '2026-11-15T10:00:00+00:00',
}) =>
    PostItem(
      id: id,
      userId: userId,
      caption: 'p$id',
      mediaType: 'image',
      isReel: false,
      createdAt: DateTime.parse(createdAt),
    );

StoryItem _story({
  required int id,
  required String userId,
  bool closeFriends = false,
}) =>
    StoryItem(
      id: id,
      userId: userId,
      mediaType: 'image',
      createdAt: DateTime.parse('2026-11-15T10:00:00+00:00'),
      isCloseFriends: closeFriends,
    );

void main() {
  group('translation direction', () {
    test('Arabic text translates to English', () {
      expect(translationPairFor('مرحبا كيف حالك'), 'ar|en');
    });

    test('English text translates to Arabic', () {
      expect(translationPairFor('hello, how are you?'), 'en|ar');
    });

    test('mixed text with any Arabic goes to English', () {
      expect(translationPairFor('hello مرحبا'), 'ar|en');
    });
  });

  group('mute / snooze activity', () {
    final now = DateTime.utc(2026, 11, 15, 12);
    test('null snooze_until is an indefinite mute', () {
      expect(isMuteActive(null, now), isTrue);
    });

    test('future snooze is active', () {
      expect(
        isMuteActive(DateTime.utc(2026, 12, 15, 12), now),
        isTrue,
      );
    });

    test('expired snooze is inactive', () {
      expect(
        isMuteActive(DateTime.utc(2026, 11, 1, 12), now),
        isFalse,
      );
    });
  });

  group('feed filters', () {
    final posts = [
      _post(id: 1, userId: 'u1'),
      _post(id: 2, userId: 'u2'),
      _post(id: 3, userId: 'u3'),
    ];

    test('muted accounts are removed from the feed', () {
      final visible = filterMutedPosts(posts, {'u2'});
      expect(visible.map((p) => p.id).toList(), [1, 3]);
    });

    test('no muted accounts leaves the feed unchanged', () {
      expect(filterMutedPosts(posts, {}).length, 3);
    });

    test('favourites filter keeps only favourite authors', () {
      final fav = filterFavouritePosts(posts, {'u1', 'u3'});
      expect(fav.map((p) => p.id).toList(), [1, 3]);
    });

    test('favourites filter with no favourites is empty', () {
      expect(filterFavouritePosts(posts, {}), isEmpty);
    });
  });

  group('Close Friends story filtering', () {
    const me = 'me';
    final stories = [
      _story(id: 1, userId: 'u1'),
      _story(id: 2, userId: 'u2', closeFriends: true),
      _story(id: 3, userId: 'u3', closeFriends: true),
      _story(id: 4, userId: me, closeFriends: true),
    ];

    test('public stories always pass; Close Friends only for listed me', () {
      final visible =
          StoriesApi.filterCloseFriendsStories(stories, {'u2'}, me);
      expect(visible.map((s) => s.id).toList(), [1, 2, 4]);
    });

    test('with no Close Friends owners, only public + my own pass', () {
      final visible = StoriesApi.filterCloseFriendsStories(stories, {}, me);
      expect(visible.map((s) => s.id).toList(), [1, 4]);
    });
  });

  group('scheduled posts', () {
    test('past publish time is due', () {
      expect(
        isScheduledDue(
          DateTime.utc(2026, 11, 15, 11),
          DateTime.utc(2026, 11, 15, 12),
        ),
        isTrue,
      );
    });

    test('future publish time is not due', () {
      expect(
        isScheduledDue(
          DateTime.utc(2026, 11, 16, 11),
          DateTime.utc(2026, 11, 15, 12),
        ),
        isFalse,
      );
    });
  });

  group('Wave 2 model parsing', () {
    test('PostItem.fromMap parses hide_like_count, comments_disabled, alt_text', () {
      final p = PostItem.fromMap({
        'id': 7,
        'user_id': 'u1',
        'caption': 'c',
        'media_type': 'image',
        'is_reel': false,
        'created_at': '2026-11-15T10:00:00+00:00',
        'hide_like_count': true,
        'comments_disabled': true,
        'alt_text': 'a cat on a roof',
      });
      expect(p.hideLikeCount, isTrue);
      expect(p.commentsDisabled, isTrue);
      expect(p.altText, 'a cat on a roof');
    });

    test('PostItem.fromMap defaults the Wave 2 options off', () {
      final p = PostItem.fromMap({
        'id': 8,
        'user_id': 'u1',
        'caption': 'c',
        'media_type': 'image',
        'is_reel': false,
        'created_at': '2026-11-15T10:00:00+00:00',
      });
      expect(p.hideLikeCount, isFalse);
      expect(p.commentsDisabled, isFalse);
      expect(p.altText, isNull);
    });

    test('StoryItem.fromMap parses is_close_friends', () {
      final s = StoryItem.fromMap({
        'id': 3,
        'user_id': 'u1',
        'media_type': 'image',
        'created_at': '2026-11-15T10:00:00+00:00',
        'is_close_friends': true,
      });
      expect(s.isCloseFriends, isTrue);
    });

    test('PostDraft.fromMap parses a draft row', () {
      final d = PostDraft.fromMap({
        'id': 5,
        'caption': 'draft text',
        'media_url': 'https://example.com/x.jpg',
        'media_type': 'image',
        'is_reel': false,
        'created_at': '2026-11-15T10:00:00+00:00',
        'updated_at': '2026-11-15T11:00:00+00:00',
      });
      expect(d.caption, 'draft text');
      expect(d.mediaUrl, 'https://example.com/x.jpg');
    });

    test('ScheduledPost.fromMap parses publish_at + published', () {
      final s = ScheduledPost.fromMap({
        'id': 6,
        'caption': 'later',
        'media_type': 'image',
        'is_reel': false,
        'publish_at': '2026-11-16T10:00:00+00:00',
        'published': false,
        'created_at': '2026-11-15T10:00:00+00:00',
      });
      expect(s.published, isFalse);
      expect(s.publishAt, DateTime.parse('2026-11-16T10:00:00+00:00'));
    });
  });
}
