// Unit tests for the H-04 media-storage fix (2026-11-16).
// Pure / offline only: routing constants, path building, signed-URL
// shape, and a source audit of the two edited upload files. No
// Supabase session or network is needed here — the existing tests
// (wave2_api_test.dart etc.) follow the same offline pattern, and
// there is no storage-client mock in this repo to reuse.
//
// What is asserted:
//   * new chat/video/audio uploads target the PRIVATE 'private-media'
//     bucket (never 'chat-media');
//   * returned URLs are signed (short-lived, token-bearing), never
//     plain public URLs;
//   * uploads land under the uploader's own id folder (the
//     owner-folder policy requirement);
//   * avatars are untouched: no avatar code was rerouted through
//     private-media, and the web app's avatar upload still targets
//     the public 'avatars' bucket.

import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/services/media_api.dart';
import 'package:hamsiq/services/messages_api.dart';

/// Read a repo file relative to the package root (flutter test runs
/// with the package root as the working directory).
String _read(String relativePath) => File(relativePath).readAsStringSync();

void main() {
  group('H-04 routing constants', () {
    test('DM media targets the private bucket, not chat-media', () {
      expect(MessagesApi.chatMediaBucket, 'private-media');
      expect(MessagesApi.chatMediaBucket, isNot('chat-media'));
    });

    test('video/audio uploads target the private bucket', () {
      expect(MediaApi.bucket, 'private-media');
      expect(MediaApi.bucket, isNot('chat-media'));
    });

    test('signed URLs are short-lived (1 hour)', () {
      expect(MessagesApi.signedUrlTtlSeconds, 3600);
      expect(MediaApi.signedUrlTtlSeconds, 3600);
      expect(MessagesApi.signedUrlTtlSeconds, lessThanOrEqualTo(3600));
      expect(MediaApi.signedUrlTtlSeconds, greaterThan(0));
    });
  });

  group('uploader-folder paths', () {
    test('DM media path is "<uploader-id>/<millis>.<ext>"', () {
      expect(
        MessagesApi.chatMediaPath('user-1', 1731599999999, 'jpg'),
        'user-1/1731599999999.jpg',
      );
      expect(
        MessagesApi.chatMediaPath('user-1', 1731599999999, 'm4a'),
        startsWith('user-1/'),
      );
    });

    test('video/audio path is "<uploader-id>/<prefix>-<millis>.<ext>"', () {
      expect(
        MediaApi.pathForUser('user-2', 'story', 'mp4', 1731599999999),
        'user-2/story-1731599999999.mp4',
      );
      expect(
        MediaApi.pathForUser('user-2', 'voice', 'm4a', 1731599999999),
        startsWith('user-2/'),
      );
    });
  });

  group('signed vs public URLs', () {
    test('a Supabase signed URL is recognised as signed', () {
      const signed =
          'https://xyz.supabase.co/storage/v1/object/sign/private-media/'
          'user-1/1731599999999.jpg?token=eyJhbGciOiJIUzI1NiJ9.test';
      expect(MessagesApi.isSignedUrl(signed), isTrue);
    });

    test('a plain public URL is NOT a signed URL', () {
      const public =
          'https://xyz.supabase.co/storage/v1/object/public/chat-media/'
          'user-1/1731599999999.jpg';
      expect(MessagesApi.isSignedUrl(public), isFalse);
      expect(MessagesApi.isSignedUrl(''), isFalse);
    });
  });

  group('source audit: no chat-media writes remain', () {
    test('messages_api.dart uploads to private-media with signed URLs', () {
      final src = _read('lib/services/messages_api.dart');
      expect(src, contains("from(chatMediaBucket)"));
      expect(src, contains('createSignedUrl'));
      expect(src, isNot(contains("from('chat-media')")));
      expect(src, isNot(contains('getPublicUrl')));
    });

    test('media_api.dart uploads to private-media with signed URLs', () {
      final src = _read('lib/services/media_api.dart');
      expect(src, contains('from(bucket)'));
      expect(src, contains('createSignedUrl'));
      expect(src, isNot(contains("from('chat-media')")));
      expect(src, isNot(contains("'chat-media'")));
      expect(src, isNot(contains('getPublicUrl')));
    });
  });

  group('Api.uploadImage routing (coordinator patch)', () {
    test('avatar paths stay public in chat-media, others go private', () {
      final src = _read('lib/services/supabase_service.dart');
      expect(src, contains("fileName.startsWith('avatar-')"));
      expect(src, contains("final bucket = isAvatar ? 'chat-media' : 'private-media';"));
      expect(src, contains('createSignedUrl('));
      expect(src, contains('3600'));
      // No unconditional public upload remains in uploadImage.
      expect(src, isNot(contains("from('chat-media').uploadBinary")));
    });
  });

  group('avatars stay public (untouched by this fix)', () {
    test('neither edited file reroutes avatars', () {
      final messagesSrc = _read('lib/services/messages_api.dart');
      final mediaSrc = _read('lib/services/media_api.dart');
      expect(messagesSrc, isNot(contains("'avatars'")));
      expect(mediaSrc, isNot(contains("'avatars'")));
    });

    test('web app avatar upload still targets the public avatars bucket',
        () {
      final webIndex = File('../chat-app/index.html');
      expect(
        webIndex.existsSync(),
        isTrue,
        reason: 'web app index.html not found at ../chat-app/index.html',
      );
      final src = webIndex.readAsStringSync();
      expect(src, contains("uploadMedia(file, 'avatars'"));
    });
  });
}
