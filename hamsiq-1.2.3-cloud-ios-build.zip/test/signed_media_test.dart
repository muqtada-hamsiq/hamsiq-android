// Unit tests for the H-04 re-sign-on-render helper (2026-11-16).
// Pure / offline only: signed-URL parsing, JWT expiry decoding, and
// needsResign decisions, the ensureFreshUrl chain (server-side
// `resign-media` Edge Function first, direct Storage signing as
// fallback, original URL as last resort — all through injectable
// test seams, no Supabase session or network), plus source audits
// that EVERY render site routes stored media through the helper:
// DM/voice/view-once, stories, reels (+ voiceover), Blend, feed,
// post detail, profile grid, collections, Discover grid, drafts,
// insights, channels and collab invites. The live recipient
// re-sign case stays covered by the staging test script
// (see staging-h04-test.sh).

import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/services/media_api.dart';

/// Read a repo file relative to the package root (flutter test runs
/// with the package root as the working directory).
String _read(String relativePath) => File(relativePath).readAsStringSync();

/// Fake Supabase signed URL whose token carries [exp] (unix seconds).
/// Token shape mirrors the real one: header.payload.signature, the
/// payload holding `exp` (+ `url`, as the real token does).
String _fakeSignedUrl({
  required int exp,
  String bucket = 'private-media',
  String path = 'user-1/1731599999999.jpg',
}) {
  String b64(Map<String, dynamic> m) =>
      base64Url.encode(utf8.encode(jsonEncode(m))).replaceAll('=', '');
  final token =
      '${b64({'alg': 'HS256', 'typ': 'JWT'})}.${b64({'exp': exp, 'url': '$bucket/$path'})}.sig';
  return 'https://xyz.supabase.co/storage/v1/object/sign/'
      '$bucket/$path?token=$token';
}

void main() {
  group('parseSignedUrl', () {
    test('splits a signed URL into bucket + path', () {
      final parsed = MediaApi.parseSignedUrl(
        _fakeSignedUrl(exp: 1731603600),
      );
      expect(parsed, isNotNull);
      expect(parsed!.bucket, 'private-media');
      expect(parsed.path, 'user-1/1731599999999.jpg');
    });

    test('keeps nested paths intact', () {
      final parsed = MediaApi.parseSignedUrl(
        _fakeSignedUrl(exp: 1731603600, path: 'user-1/sub/file.m4a'),
      );
      expect(parsed?.path, 'user-1/sub/file.m4a');
    });

    test('rejects public URLs, empty strings and garbage', () {
      const public =
          'https://xyz.supabase.co/storage/v1/object/public/chat-media/'
          'user-1/1731599999999.jpg';
      expect(MediaApi.parseSignedUrl(public), isNull);
      expect(MediaApi.parseSignedUrl(''), isNull);
      expect(MediaApi.parseSignedUrl('not a url'), isNull);
      // Signed path shape but no token: not a usable signed URL.
      expect(
        MediaApi.parseSignedUrl(
          'https://xyz.supabase.co/storage/v1/object/sign/private-media/user-1/x.jpg',
        ),
        isNull,
      );
    });
  });

  group('signedUrlExpiry', () {
    test('reads the JWT exp claim as UTC', () {
      const exp = 1731603600;
      expect(
        MediaApi.signedUrlExpiry(_fakeSignedUrl(exp: exp)),
        DateTime.fromMillisecondsSinceEpoch(exp * 1000, isUtc: true),
      );
    });

    test('returns null without a readable exp', () {
      String b64(Map<String, dynamic> m) =>
          base64Url.encode(utf8.encode(jsonEncode(m))).replaceAll('=', '');
      // Token with no exp claim.
      final noExp =
          '${b64({'alg': 'HS256'})}.${b64({'url': 'private-media/x.jpg'})}.sig';
      expect(
        MediaApi.signedUrlExpiry(
          'https://xyz.supabase.co/storage/v1/object/sign/private-media/x.jpg?token=$noExp',
        ),
        isNull,
      );
      // Not a JWT at all.
      expect(
        MediaApi.signedUrlExpiry(
          'https://xyz.supabase.co/storage/v1/object/sign/private-media/x.jpg?token=abc',
        ),
        isNull,
      );
      // Public URL: no token.
      expect(
        MediaApi.signedUrlExpiry(
          'https://xyz.supabase.co/storage/v1/object/public/chat-media/x.jpg',
        ),
        isNull,
      );
    });
  });

  group('needsResign', () {
    // Fixed "now": 2024-11-14 12:00:00 UTC (1731585600).
    final now = DateTime.fromMillisecondsSinceEpoch(
      1731585600 * 1000,
      isUtc: true,
    );

    test('expired signed URL needs a re-sign', () {
      expect(
        MediaApi.needsResign(
          _fakeSignedUrl(exp: 1731582000),
          now: now,
        ),
        isTrue,
      );
    });

    test('URL expiring inside the 5-minute margin needs a re-sign', () {
      expect(
        MediaApi.needsResign(
          _fakeSignedUrl(exp: 1731585600 + 120),
          now: now,
        ),
        isTrue,
      );
    });

    test('URL expiring just outside the margin does not', () {
      expect(
        MediaApi.needsResign(
          _fakeSignedUrl(exp: 1731585600 + 360),
          now: now,
        ),
        isFalse,
      );
    });

    test('fresh signed URL (1h) does not need a re-sign', () {
      expect(
        MediaApi.needsResign(
          _fakeSignedUrl(exp: 1731585600 + 3600),
          now: now,
        ),
        isFalse,
      );
    });

    test('public URL never needs a re-sign', () {
      const public =
          'https://xyz.supabase.co/storage/v1/object/public/chat-media/'
          'user-1/1731599999999.jpg';
      expect(MediaApi.needsResign(public, now: now), isFalse);
    });

    test('custom margin is honoured', () {
      final url = _fakeSignedUrl(exp: 1731585600 + 600);
      expect(
        MediaApi.needsResign(url, margin: const Duration(minutes: 5), now: now),
        isFalse,
      );
      expect(
        MediaApi.needsResign(url, margin: const Duration(minutes: 15), now: now),
        isTrue,
      );
    });
  });

  group('ensureFreshUrl: Edge Function first, direct fallback', () {
    // Expired long ago, so needsResign is true with real wall time.
    final expired = _fakeSignedUrl(exp: 1000000000);
    const freshSigned =
        'https://xyz.supabase.co/storage/v1/object/sign/private-media/'
        'user-1/1731599999999.jpg?token=fresh-token';
    const directSigned =
        'https://xyz.supabase.co/storage/v1/object/sign/private-media/'
        'user-1/1731599999999.jpg?token=direct-token';

    test('200 from resign-media returns the new URL', () async {
      Map<String, dynamic>? seenBody;
      final out = await MediaApi.ensureFreshUrl(
        expired,
        resignInvoker: (body) async {
          seenBody = body;
          return {'signedUrl': freshSigned};
        },
        directSigner: (_, __) async => directSigned,
      );
      expect(out, freshSigned);
      // The function is called with exactly the parsed bucket + path.
      expect(seenBody, {'bucket': 'private-media', 'path': 'user-1/1731599999999.jpg'});
    });

    test('403 from resign-media falls back to direct signing', () async {
      var directCalled = false;
      final out = await MediaApi.ensureFreshUrl(
        expired,
        resignInvoker: (_) async => throw Exception('403'),
        directSigner: (bucket, path) async {
          directCalled = true;
          expect(bucket, 'private-media');
          expect(path, 'user-1/1731599999999.jpg');
          return directSigned;
        },
      );
      expect(out, directSigned);
      expect(directCalled, isTrue);
    });

    test('malformed 200 body (no signedUrl) falls back to direct', () async {
      final out = await MediaApi.ensureFreshUrl(
        expired,
        resignInvoker: (_) async => {'ok': true},
        directSigner: (_, __) async => directSigned,
      );
      expect(out, directSigned);
    });

    test('total failure returns the original URL unchanged', () async {
      final out = await MediaApi.ensureFreshUrl(
        expired,
        resignInvoker: (_) async => throw Exception('500'),
        directSigner: (_, __) async => throw Exception('policy denied'),
      );
      expect(out, expired);
    });

    test('fresh signed URL makes no function or storage call', () async {
      final nowSec = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      final fresh = _fakeSignedUrl(exp: nowSec + 3600);
      var called = false;
      final out = await MediaApi.ensureFreshUrl(
        fresh,
        resignInvoker: (_) async {
          called = true;
          return {'signedUrl': freshSigned};
        },
        directSigner: (_, __) async {
          called = true;
          return directSigned;
        },
      );
      expect(out, fresh);
      expect(called, isFalse);
    });

    test('public URL is returned unchanged with no calls', () async {
      const public =
          'https://xyz.supabase.co/storage/v1/object/public/chat-media/'
          'user-1/1731599999999.jpg';
      var called = false;
      final out = await MediaApi.ensureFreshUrl(
        public,
        resignInvoker: (_) async {
          called = true;
          return {'signedUrl': freshSigned};
        },
        directSigner: (_, __) async {
          called = true;
          return directSigned;
        },
      );
      expect(out, public);
      expect(called, isFalse);
    });

    test('non-private bucket skips the function, uses direct only', () async {
      final other = _fakeSignedUrl(
        exp: 1000000000,
        bucket: 'chat-media',
        path: 'user-1/1731599999999.jpg',
      );
      var functionCalled = false;
      final out = await MediaApi.ensureFreshUrl(
        other,
        resignInvoker: (_) async {
          functionCalled = true;
          return {'signedUrl': freshSigned};
        },
        directSigner: (_, __) async => directSigned,
      );
      expect(out, directSigned);
      expect(functionCalled, isFalse);
    });
  });

  group('source audit: every render site re-signs on render', () {
    test('media_api.dart routes through resign-media first', () {
      final src = _read('lib/services/media_api.dart');
      expect(src, contains("resignFunctionName = 'resign-media'"));
      expect(src, contains('functions.invoke(resignFunctionName'));
      expect(src, contains('typedef MediaResignInvoker'));
      expect(src, contains('typedef MediaDirectSigner'));
      // Fallback + last resort are still present.
      expect(src, contains('createSignedUrl(path, signedUrlTtlSeconds)'));
      expect(src, contains('return url;'));
      // The old recipient gap is closed, not just documented.
      expect(src, isNot(contains('HONEST GAP')));
      expect(src, isNot(contains('server-side re-sign (Edge Function')));
    });

    test('stories viewer re-signs video + image, highlights re-sign covers', () {
      final src = _read('lib/screens/stories_screen.dart');
      expect(src, contains('MediaApi.ensureFreshUrl(story.mediaUrl!)'));
      expect(src, contains('VideoPlayerController.networkUrl(Uri.parse(fresh))'));
      expect(src, isNot(contains('VideoPlayerController.networkUrl(Uri.parse(story.mediaUrl!))')));
      expect('SignedMediaImage('.allMatches(src).length, 2);
      expect('Image.network('.allMatches(src).length, 0);
    });

    test('reels re-sign video + voiceover before playback', () {
      final src = _read('lib/screens/reels_screen.dart');
      expect('MediaApi.ensureFreshUrl'.allMatches(src).length,
          greaterThanOrEqualTo(3));
      expect(src, contains('MediaApi.ensureFreshUrl(post.mediaUrl!)'));
      expect(src, contains('MediaApi.ensureFreshUrl(url)'));
      expect(src, contains('VideoPlayerController.networkUrl(Uri.parse(fresh))'));
      expect(src, isNot(contains('Uri.parse(post.mediaUrl!)')));
      expect(src, isNot(contains('UrlSource(url)')));
      expect(src, contains('UrlSource(fresh)'));
    });

    test('blend re-signs before creating its video controller', () {
      final src = _read('lib/screens/blend_screen.dart');
      expect(src, contains('MediaApi.ensureFreshUrl(url)'));
      expect(src, contains('VideoPlayerController.networkUrl(Uri.parse(fresh))'));
      expect(src, isNot(contains('VideoPlayerController.networkUrl(Uri.parse(url))')));
    });

    test('feed / post detail / channels / collab use SignedMediaImage', () {
      for (final file in [
        'lib/screens/feed_screen.dart',
        'lib/screens/post_detail_screen.dart',
        'lib/screens/channels_screen.dart',
        'lib/screens/collab_invites_screen.dart',
      ]) {
        final src = _read(file);
        expect(src, contains('SignedMediaImage('), reason: file);
      }
      // Post detail's only raw Image.network is the public Giphy
      // picker, not stored media.
      final detail = _read('lib/screens/post_detail_screen.dart');
      expect('Image.network('.allMatches(detail).length, 1);
      expect(detail, contains('curatedGifUrls'));
      for (final file in [
        'lib/screens/feed_screen.dart',
        'lib/screens/channels_screen.dart',
        'lib/screens/collab_invites_screen.dart',
      ]) {
        expect('Image.network('.allMatches(_read(file)).length, 0,
            reason: file);
      }
    });

    test('profile grid / reposts / reorder / collections / discover use it', () {
      for (final file in [
        'lib/screens/profile_screen.dart',
        'lib/widgets/profile_extra_tabs.dart',
        'lib/screens/collections_screen.dart',
        'lib/screens/home_shell.dart',
      ]) {
        final src = _read(file);
        expect(src, contains('SignedMediaImage('), reason: file);
        expect('Image.network('.allMatches(src).length, 0, reason: file);
      }
      expect('SignedMediaImage('.allMatches(
          _read('lib/screens/collections_screen.dart')).length, 2);
      expect('SignedMediaImage('.allMatches(
          _read('lib/widgets/profile_extra_tabs.dart')).length, 2);
    });

    test('drafts / insights use SignedMediaImage', () {
      for (final file in [
        'lib/screens/drafts_screen.dart',
        'lib/screens/insights_screen.dart',
      ]) {
        final src = _read(file);
        expect(src, contains('SignedMediaImage('), reason: file);
        expect('Image.network('.allMatches(src).length, 0, reason: file);
      }
      expect('SignedMediaImage('.allMatches(
          _read('lib/screens/drafts_screen.dart')).length, 2);
    });

    test('shared-post card in DMs uses SignedMediaImage', () {
      final src = _read('lib/widgets/shared_post_card.dart');
      expect('SignedMediaImage('.allMatches(src).length, 2);
      expect('Image.network('.allMatches(src).length, 0);
    });

    test('deliberately untouched: public avatars + Giphy GIFs only', () {
      // Avatars live in the public chat-media bucket — no signing.
      final common = _read('lib/widgets/common.dart');
      expect(common, contains('class AvatarWidget'));
      // Comment GIFs are public Giphy URLs, never stored media.
      final comments = _read('lib/widgets/comments_sheet.dart');
      expect(comments, contains('curatedGifUrls'));
      expect(comments, contains('gifUrl!'));
    });
  });

  group('source audit: DM render sites call ensureFreshUrl', () {
    test('media_api.dart exposes the re-sign helper', () {
      final src = _read('lib/services/media_api.dart');
      expect(src, contains('static Future<String> ensureFreshUrl'));
      expect(src, contains('static bool needsResign'));
      expect(src, contains('static DateTime? signedUrlExpiry'));
      expect(src, contains('static ({String bucket, String path})? parseSignedUrl'));
      expect(src, contains('createSignedUrl('));
      expect(src, contains('signedUrlTtlSeconds'));
    });

    test('common.dart defines the SignedMediaImage widget', () {
      final src = _read('lib/widgets/common.dart');
      expect(src, contains('class SignedMediaImage'));
      expect(src, contains('MediaApi.ensureFreshUrl'));
      expect(src, contains('MediaApi.needsResign'));
    });

    test('chats_screen.dart re-signs at every DM media site', () {
      final src = _read('lib/screens/chats_screen.dart');
      // Image thumbnail + view-once thumbnail use the widget.
      expect('SignedMediaImage('.allMatches(src).length, greaterThanOrEqualTo(2));
      // Voice bubble + full-screen viewers call the helper directly.
      expect('MediaApi.ensureFreshUrl'.allMatches(src).length,
          greaterThanOrEqualTo(3));
      // The only raw Image.network left is the full-screen viewer,
      // which loads the already re-signed URL (variable `fresh`).
      expect('Image.network('.allMatches(src).length, 1);
      expect(src, contains('Image.network(\n                  fresh,'));
    });

    test('story-reply thumbnail re-signs too', () {
      final src = _read('lib/widgets/shared_post_card.dart');
      expect(src, contains('SignedMediaImage('));
    });
  });
}
