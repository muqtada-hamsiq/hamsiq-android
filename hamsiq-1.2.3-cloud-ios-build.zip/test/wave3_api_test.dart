// Unit tests for Wave 3 (Instagram features).
// Pure / offline only: Reels editor overlays + templates, Blend feed
// mixing, channel reaction grouping, collab/blend model parsing.
// No Supabase session or network is needed here.

import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/models.dart';
import 'package:hamsiq/services/wave3_api.dart';

PostItem _post({
  required int id,
  String userId = 'u1',
  String createdAt = '2026-11-15T10:00:00+00:00',
}) =>
    PostItem(
      id: id,
      userId: userId,
      caption: 'p$id',
      mediaType: 'video',
      isReel: true,
      createdAt: DateTime.parse(createdAt),
    );

BlendReel _reel(int id, String source) => BlendReel(
      post: _post(id: id),
      source: source,
    );

void main() {
  group('ReelTextOverlay', () {
    test('fromMap applies defaults for missing fields', () {
      final o = ReelTextOverlay.fromMap({'text': 'hi'});
      expect(o.text, 'hi');
      expect(o.x, 0.5);
      expect(o.y, 0.2);
      expect(o.color, 0xFFFFFFFF);
      expect(o.size, 22);
      expect(o.startSec, 0);
      expect(o.endSec, 3);
    });

    test('toMap round-trips through fromMap', () {
      const o = ReelTextOverlay(
        text: 'عنوان',
        x: 0.3,
        y: 0.7,
        color: 0xFFFFFF00,
        size: 30,
        startSec: 1,
        endSec: 4,
      );
      final back = ReelTextOverlay.fromMap(o.toMap());
      expect(back.text, 'عنوان');
      expect(back.x, 0.3);
      expect(back.y, 0.7);
      expect(back.color, 0xFFFFFF00);
      expect(back.size, 30);
      expect(back.startSec, 1);
      expect(back.endSec, 4);
    });

    test('visibleAt is inclusive on both ends', () {
      const o = ReelTextOverlay(
        text: 'x',
        x: 0.5,
        y: 0.2,
        color: 0xFFFFFFFF,
        size: 22,
        startSec: 2,
        endSec: 5,
      );
      expect(o.visibleAt(1.99), isFalse);
      expect(o.visibleAt(2), isTrue);
      expect(o.visibleAt(3.5), isTrue);
      expect(o.visibleAt(5), isTrue);
      expect(o.visibleAt(5.01), isFalse);
    });

    test('parseReelTextOverlays tolerates null and bad rows', () {
      expect(parseReelTextOverlays(null), isEmpty);
      expect(parseReelTextOverlays('nope'), isEmpty);
      expect(
        parseReelTextOverlays([
          {'text': 'ok', 'x': 0.5, 'y': 0.2},
          'junk',
          {'text': 'also ok'},
        ]).length,
        2,
      );
    });
  });

  group('overlaysVisibleAt', () {
    test('keeps only overlays in the current window', () {
      const overlays = [
        ReelTextOverlay(
          text: 'a',
          x: 0.5,
          y: 0.2,
          color: 0xFFFFFFFF,
          size: 22,
          startSec: 0,
          endSec: 3,
        ),
        ReelTextOverlay(
          text: 'b',
          x: 0.5,
          y: 0.8,
          color: 0xFFFFFFFF,
          size: 22,
          startSec: 6,
          endSec: 9,
        ),
      ];
      expect(
        overlaysVisibleAt(overlays, 1).map((o) => o.text).toList(),
        ['a'],
      );
      expect(
        overlaysVisibleAt(overlays, 7).map((o) => o.text).toList(),
        ['b'],
      );
      expect(overlaysVisibleAt(overlays, 4.5), isEmpty);
    });
  });

  group('reel templates', () {
    test('three built-in templates with unique ids', () {
      expect(reelTemplates.length, 3);
      final ids = reelTemplates.map((t) => t.id).toSet();
      expect(ids.length, 3);
      expect(ids, containsAll(['title', 'quote', 'before_after']));
    });

    test('templateById resolves known ids and null/unknown to null', () {
      expect(templateById('title')?.nameAr, 'عنوان وخاتمة');
      expect(templateById('quote')?.overlays.length, 1);
      expect(templateById(null), isNull);
      expect(templateById('nope'), isNull);
    });

    test('every template overlay has text, start < end, in-bounds xy', () {
      for (final t in reelTemplates) {
        expect(t.overlays, isNotEmpty);
        for (final o in t.overlays) {
          expect(o.text.trim(), isNotEmpty);
          expect(o.startSec, lessThan(o.endSec));
          expect(o.x, inInclusiveRange(0.0, 1.0));
          expect(o.y, inInclusiveRange(0.0, 1.0));
        }
      }
    });
  });

  group('collab', () {
    test('maxCollaborators is Instagram’s 5', () {
      expect(maxCollaborators, 5);
    });

    test('PostCollaborator.fromMap parses status helpers', () {
      final c = PostCollaborator.fromMap({
        'post_id': 7,
        'user_id': 'u2',
        'status': 'pending',
        'invited_by': 'u1',
        'created_at': '2026-11-15T10:00:00+00:00',
      });
      expect(c.postId, 7);
      expect(c.isPending, isTrue);
      expect(c.isAccepted, isFalse);
    });
  });

  group('channel reactions', () {
    test('reaction emoji set is fixed and non-empty', () {
      expect(channelReactionEmojis, isNotEmpty);
      expect(channelReactionEmojis, contains('❤️'));
      expect(channelReactionEmojis.toSet().length,
          channelReactionEmojis.length);
    });

    test('groupReactions counts per emoji', () {
      final reactions = [
        ChannelReaction(
          channelPostId: 1,
          userId: 'a',
          emoji: '❤️',
          createdAt: DateTime.utc(2026, 11, 15),
        ),
        ChannelReaction(
          channelPostId: 1,
          userId: 'b',
          emoji: '❤️',
          createdAt: DateTime.utc(2026, 11, 15),
        ),
        ChannelReaction(
          channelPostId: 1,
          userId: 'c',
          emoji: '😂',
          createdAt: DateTime.utc(2026, 11, 15),
        ),
      ];
      expect(groupReactions(reactions), {'❤️': 2, '😂': 1});
      expect(groupReactions([]), isEmpty);
    });

    test('ChannelPost.fromMap defaults media_type to text', () {
      final p = ChannelPost.fromMap({
        'id': 3,
        'channel_id': 1,
        'author_id': 'u1',
        'body': 'hello',
        'created_at': '2026-11-15T10:00:00+00:00',
      });
      expect(p.mediaType, 'text');
      expect(p.mediaUrl, isNull);
    });
  });

  group('Blend helpers', () {
    BlendState blend({
      String a = 'me',
      String b = 'peer',
      String status = 'pending',
      String by = 'me',
    }) =>
        BlendState(
          id: 1,
          userA: a,
          userB: b,
          status: status,
          createdBy: by,
          createdAt: DateTime.utc(2026, 11, 15),
        );

    test('blendPeerId returns the other side', () {
      expect(blendPeerId(blend(), 'me'), 'peer');
      expect(blendPeerId(blend(), 'peer'), 'me');
    });

    test('blendForPeer finds the row in either direction', () {
      final rows = [blend(), blend(a: 'x', b: 'y')];
      expect(blendForPeer(rows, 'peer', 'me')?.userB, 'peer');
      expect(blendForPeer(rows, 'me', 'peer')?.userA, 'me');
      expect(blendForPeer(rows, 'nobody', 'me'), isNull);
    });

    test('waitingOnPeer / waitingOnMe split pending invites', () {
      expect(blend().waitingOnPeer('me'), isTrue);
      expect(blend().waitingOnMe('me'), isFalse);
      expect(blend(by: 'peer').waitingOnMe('me'), isTrue);
      expect(blend(by: 'peer').waitingOnPeer('me'), isFalse);
      expect(blend(status: 'active').waitingOnPeer('me'), isFalse);
    });

    test('mixBlendReels round-robins and dedupes by post id', () {
      final mixed = mixBlendReels(
        [_reel(1, 'peer'), _reel(2, 'peer'), _reel(3, 'peer')],
        [_reel(4, 'me'), _reel(5, 'me')],
        [_reel(2, 'both'), _reel(6, 'shared')],
      );
      final ids = mixed.map((r) => r.post.id).toList();
      // Round-robin: peer, me, both/shared, peer, me, both/shared...
      // (post 2 is skipped the second time — it was already added).
      expect(ids, [1, 4, 2, 5, 6, 3]);
      // Post 2 (liked by both) appears once — first added from the
      // both/shared list in round 0, so it keeps the 'both' label.
      expect(ids.where((id) => id == 2).length, 1);
      expect(mixed.firstWhere((r) => r.post.id == 2).source, 'both');
    });

    test('mixBlendReels handles empty lists', () {
      expect(mixBlendReels([], [], []), isEmpty);
      expect(
        mixBlendReels([_reel(9, 'peer')], [], []).map((r) => r.post.id),
        [9],
      );
    });
  });

  group('Wave 3 model parsing', () {
    test('PostItem.fromMap parses reel editor columns', () {
      final p = PostItem.fromMap({
        'id': 42,
        'user_id': 'u1',
        'caption': 'reel',
        'media_url': 'https://x/v.mp4',
        'media_type': 'video',
        'is_reel': true,
        'created_at': '2026-11-15T10:00:00+00:00',
        'reel_text_overlays': [
          {
            'text': 'hi',
            'x': 0.5,
            'y': 0.2,
            'color': 4294967295,
            'size': 22,
            'start': 0,
            'end': 3,
          },
        ],
        'reel_voiceover_url': 'https://x/v.m4a',
        'reel_template': 'title',
      });
      expect(p.reelTextOverlays.length, 1);
      expect(p.reelTextOverlays.first.text, 'hi');
      expect(p.reelVoiceoverUrl, 'https://x/v.m4a');
      expect(p.reelTemplate, 'title');
    });

    test('PostItem.fromMap defaults Wave 3 columns off', () {
      final p = PostItem.fromMap({
        'id': 43,
        'user_id': 'u1',
        'caption': 'plain',
        'media_type': 'image',
        'is_reel': false,
        'created_at': '2026-11-15T10:00:00+00:00',
      });
      expect(p.reelTextOverlays, isEmpty);
      expect(p.reelVoiceoverUrl, isNull);
      expect(p.reelTemplate, isNull);
    });
  });
}
