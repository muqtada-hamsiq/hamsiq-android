// Google sign-in tests (native Flutter app).
//
// Runs with NO live OAuth and NO network: the Google provider is NOT
// configured on prod or staging, so no real Google round-trip is
// possible from here, and none is faked. What IS pinned here:
//   * the post-OAuth setup-gate decision table (profile-complete ->
//     home; missing username -> setup; duplicate-email -> link flow),
//   * the redirect contract (custom scheme on native; preview origin
//     on web — the web branch cannot run under flutter test, kIsWeb is
//     false on the VM, so only the native branch is asserted),
//   * identity-conflict detection (AuthException code/message
//     `identity_already_exists`) and generic-only error mapping (a
//     server message containing an email must never surface it),
//   * the setup-form validation (same username/password rules as
//     signup — pinned to agree with auth_screen's validators),
//   * completeSetup's ordering and short-circuits with injected fakes
//     (re-check -> set password -> upsert profile -> save session),
//   * the new AppStrings keys in ar + en,
//   * the setup/link screens: live username check, submit wiring, and
//     NO skip path on the setup screen (no back button),
//   * the parent's side note: the login password field accepts a
//     direct tap and Tab moves focus username -> password (framework
//     level), i.e. no focus/disabled defect in auth_screen.dart.
// The live checks (provider enablement, browser round-trip, deep-link
// return, linkIdentity against a real account) still need the Google
// Cloud OAuth client + the provider enabled in Supabase — see the
// Google section of goals/hamsiq/hidden_files/prod-deploy-progress.md.

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/models.dart';
import 'package:hamsiq/screens/auth_screen.dart';
import 'package:hamsiq/screens/google_setup_screen.dart';
import 'package:hamsiq/services/app_strings.dart';
import 'package:hamsiq/services/google_auth.dart';
import 'package:hamsiq/services/supabase_service.dart';
import 'package:hamsiq/theme.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

HamsiqProfile _profile({String username = 'muqtada'}) => HamsiqProfile(
      id: 'user-1',
      username: username,
      displayName: 'Muqtada',
      avatar: '😀',
      bio: '',
      verified: false,
      isAdmin: false,
      approved: true,
      isPrivate: false,
    );

User _googleUser({Map<String, dynamic>? metadata}) => User(
      id: 'google-user-1',
      appMetadata: const {'provider': 'google'},
      userMetadata: metadata ??
          const {
            'full_name': 'Muqtada Test',
            'avatar_url': 'https://example.com/avatar.png',
          },
      aud: 'authenticated',
      createdAt: '2026-01-01T00:00:00Z',
    );

void main() {
  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: Api.supabaseUrl,
      publishableKey: Api.supabaseAnonKey,
    );
  });

  setUp(() => AppStrings.lang.value = 'ar');
  tearDown(() => AppStrings.lang.value = 'ar');

  group('setup-gate decision', () {
    test('profile with a username -> go home', () {
      expect(
        decideGooglePostAuth(
          profile: _profile(),
          duplicateEmailDetected: false,
        ),
        GoogleSetupDecision.goHome,
      );
    });

    test('no profile -> setup', () {
      expect(
        decideGooglePostAuth(
          profile: null,
          duplicateEmailDetected: false,
        ),
        GoogleSetupDecision.needsSetup,
      );
    });

    test('profile with an empty username -> setup, never home', () {
      expect(
        decideGooglePostAuth(
          profile: _profile(username: ''),
          duplicateEmailDetected: false,
        ),
        GoogleSetupDecision.needsSetup,
      );
      expect(
        decideGooglePostAuth(
          profile: _profile(username: '   '),
          duplicateEmailDetected: false,
        ),
        GoogleSetupDecision.needsSetup,
      );
    });

    test('duplicate email + no profile -> link flow, no new profile', () {
      expect(
        decideGooglePostAuth(
          profile: null,
          duplicateEmailDetected: true,
        ),
        GoogleSetupDecision.needsLink,
      );
    });

    test('duplicate email + complete profile -> home (profile wins)', () {
      // Auto-link case: the session already IS the existing account.
      expect(
        decideGooglePostAuth(
          profile: _profile(),
          duplicateEmailDetected: true,
        ),
        GoogleSetupDecision.goHome,
      );
    });
  });

  group('redirect contract', () {
    test('native redirect uses the registered custom scheme', () {
      expect(googleAuthScheme, 'com.hamsiq.app');
      expect(googleAuthRedirectUri, 'com.hamsiq.app://login-callback');
      // flutter test runs on the VM (kIsWeb == false): native branch.
      expect(kIsWeb, isFalse);
      expect(googleRedirectTo(), 'com.hamsiq.app://login-callback');
    });

    test('web redirect is the published preview origin', () {
      expect(
        googleWebRedirectUrl,
        'https://muqtada-hamsiq.github.io/hamsiq-android/',
      );
    });
  });

  group('GoogleProfileInfo.fromUser', () {
    test('prefills full_name + avatar_url, never the email', () {
      final info = GoogleProfileInfo.fromUser(_googleUser());
      expect(info.displayName, 'Muqtada Test');
      expect(info.avatarUrl, 'https://example.com/avatar.png');
    });

    test('falls back to name/picture keys', () {
      final info = GoogleProfileInfo.fromUser(
        _googleUser(metadata: const {
          'name': 'Fallback Name',
          'picture': 'https://example.com/pic.png',
        }),
      );
      expect(info.displayName, 'Fallback Name');
      expect(info.avatarUrl, 'https://example.com/pic.png');
    });

    test('empty metadata -> empty name, null avatar', () {
      final info = GoogleProfileInfo.fromUser(
        _googleUser(metadata: const {}),
      );
      expect(info.displayName, isEmpty);
      expect(info.avatarUrl, isNull);
    });
  });

  group('identity-conflict detection', () {
    test('AuthException code identity_already_exists -> conflict', () {
      expect(
        isGoogleIdentityConflict(
          const AuthException(
            'Identity already exists',
            code: 'identity_already_exists',
          ),
        ),
        isTrue,
      );
    });

    test('message containing the code -> conflict (URL error path)', () {
      expect(
        isGoogleIdentityConflict(
          Exception('callback failed: identity_already_exists'),
        ),
        isTrue,
      );
    });

    test('other AuthExceptions are not conflicts', () {
      expect(
        isGoogleIdentityConflict(
          const AuthException('bad code', code: 'bad_oauth_callback'),
        ),
        isFalse,
      );
      expect(
        isGoogleIdentityConflict(
          const AuthException(
            'manual linking disabled',
            code: 'manual_linking_disabled',
          ),
        ),
        isFalse,
      );
      expect(isGoogleIdentityConflict(Exception('boom')), isFalse);
    });
  });

  group('error mapping never surfaces an email or server detail', () {
    test('a server message containing an email stays generic', () {
      const leaky = AuthException(
        'user victim@example.com already exists (id 123)',
        code: 'email_exists',
      );
      final out = friendlyGoogleError(leaky);
      expect(out, isNot(contains('victim@example.com')));
      expect(out, isNot(contains('@')));
      expect(out, AppStrings.t('genericError'));
    });

    test('provider not configured -> googleUnavailable', () {
      expect(
        friendlyGoogleError(
          const AuthException('x', code: 'provider_disabled'),
        ),
        AppStrings.t('googleUnavailable'),
      );
      expect(
        friendlyGoogleError(
          const AuthException('x', code: 'oauth_provider_not_supported'),
        ),
        AppStrings.t('googleUnavailable'),
      );
    });

    test('network failure -> no-connection message', () {
      expect(
        friendlyGoogleError(Exception('SocketException: failed host lookup')),
        AppStrings.t('authNoConnection'),
      );
    });
  });

  group('setup-form validation', () {
    test('valid form -> null', () {
      expect(
        validateGoogleSetup(
          username: 'muqtada_1',
          password: 'Passw0rd',
          confirmPassword: 'Passw0rd',
        ),
        isNull,
      );
    });

    test('empty fields -> fillAllFields', () {
      expect(
        validateGoogleSetup(
          username: '',
          password: 'Passw0rd',
          confirmPassword: 'Passw0rd',
        ),
        'fillAllFields',
      );
    });

    test('bad username chars -> authInvalidUsernameChars', () {
      expect(
        validateGoogleSetup(
          username: 'bad name!',
          password: 'Passw0rd',
          confirmPassword: 'Passw0rd',
        ),
        'authInvalidUsernameChars',
      );
    });

    test('short username -> authUsernameMin3', () {
      expect(
        validateGoogleSetup(
          username: 'ab',
          password: 'Passw0rd',
          confirmPassword: 'Passw0rd',
        ),
        'authUsernameMin3',
      );
    });

    test('weak password -> authWeakPassword', () {
      expect(
        validateGoogleSetup(
          username: 'muqtada',
          password: 'short',
          confirmPassword: 'short',
        ),
        'authWeakPassword',
      );
      expect(
        validateGoogleSetup(
          username: 'muqtada',
          password: 'password',
          confirmPassword: 'password',
        ),
        'authWeakPassword',
      );
    });

    test('mismatched confirmation -> passwordMismatch', () {
      expect(
        validateGoogleSetup(
          username: 'muqtada',
          password: 'Passw0rd',
          confirmPassword: 'Passw0rd2',
        ),
        'passwordMismatch',
      );
    });

    test('agrees with auth_screen validators on a battery of inputs', () {
      // The rule is duplicated in google_auth.dart by design (service
      // must not import the screen layer); this pins the two copies.
      const usernames = [
        'muqtada',
        'ab',
        'bad name!',
        'user_name-1.2',
        'مقتدى',
        '',
      ];
      for (final u in usernames) {
        final key = validateGoogleSetup(
          username: u,
          password: 'Passw0rd',
          confirmPassword: 'Passw0rd',
        );
        if (u.isEmpty) {
          expect(key, 'fillAllFields', reason: 'username "$u"');
        } else if (!isValidUsername(u)) {
          expect(key, 'authInvalidUsernameChars', reason: 'username "$u"');
        } else if (u.length < 3) {
          expect(key, 'authUsernameMin3', reason: 'username "$u"');
        } else {
          expect(key, isNull, reason: 'username "$u"');
        }
      }
      const passwords = ['short', 'password', '12345678', 'Passw0rd', 'p4ss'];
      for (final p in passwords) {
        final key = validateGoogleSetup(
          username: 'muqtada',
          password: p,
          confirmPassword: p,
        );
        expect(
          key,
          isStrongPassword(p) ? isNull : 'authWeakPassword',
          reason: 'password "$p"',
        );
      }
    });
  });

  group('completeSetup ordering + short-circuits (fakes)', () {
    test('valid -> check, set password, upsert, save session, in order',
        () async {
      final calls = <String>[];
      final profile = await GoogleAuth.completeSetup(
        username: 'Muqtada',
        displayName: 'Muqtada Test',
        password: 'Passw0rd',
        confirmPassword: 'Passw0rd',
        avatarUrl: 'https://example.com/a.png',
        checkUsername: (u) async {
          calls.add('check:$u');
          return true;
        },
        setPassword: (p) async {
          calls.add('setPassword');
        },
        upsertProfile: (
            {required String username,
            required String displayName,
            String? avatarUrl}) async {
          calls.add('upsert:$username:$displayName:$avatarUrl');
          return _profile(username: username);
        },
        saveSession: () async {
          calls.add('saveSession');
        },
      );
      expect(profile.username, 'muqtada');
      expect(calls, [
        'check:muqtada',
        'setPassword',
        'upsert:muqtada:Muqtada Test:https://example.com/a.png',
        'saveSession',
      ]);
    });

    test('taken username -> usernameTaken, password never set', () async {
      var setPasswordCalled = false;
      await expectLater(
        GoogleAuth.completeSetup(
          username: 'taken',
          displayName: 'Taken',
          password: 'Passw0rd',
          confirmPassword: 'Passw0rd',
          checkUsername: (_) async => false,
          setPassword: (_) async {
            setPasswordCalled = true;
          },
          upsertProfile: (
              {required String username,
              required String displayName,
              String? avatarUrl}) async =>
              _profile(username: username),
          saveSession: () async {},
        ),
        throwsA(
          isA<GoogleSetupException>()
              .having((e) => e.messageKey, 'messageKey', 'usernameTaken'),
        ),
      );
      expect(setPasswordCalled, isFalse);
    });

    test('inconclusive check -> genericError, password never set', () async {
      var setPasswordCalled = false;
      await expectLater(
        GoogleAuth.completeSetup(
          username: 'muqtada',
          displayName: 'Muqtada',
          password: 'Passw0rd',
          confirmPassword: 'Passw0rd',
          checkUsername: (_) async => null,
          setPassword: (_) async {
            setPasswordCalled = true;
          },
          upsertProfile: (
              {required String username,
              required String displayName,
              String? avatarUrl}) async =>
              _profile(username: username),
          saveSession: () async {},
        ),
        throwsA(
          isA<GoogleSetupException>()
              .having((e) => e.messageKey, 'messageKey', 'genericError'),
        ),
      );
      expect(setPasswordCalled, isFalse);
    });

    test('weak password -> authWeakPassword, username never checked',
        () async {
      var checkCalled = false;
      await expectLater(
        GoogleAuth.completeSetup(
          username: 'muqtada',
          displayName: 'Muqtada',
          password: 'weak',
          confirmPassword: 'weak',
          checkUsername: (_) async {
            checkCalled = true;
            return true;
          },
          setPassword: (_) async {},
          upsertProfile: (
              {required String username,
              required String displayName,
              String? avatarUrl}) async =>
              _profile(username: username),
          saveSession: () async {},
        ),
        throwsA(
          isA<GoogleSetupException>().having(
              (e) => e.messageKey, 'messageKey', 'authWeakPassword'),
        ),
      );
      expect(checkCalled, isFalse);
    });

    test('rate-limit from the checker propagates as its key', () async {
      await expectLater(
        GoogleAuth.completeSetup(
          username: 'muqtada',
          displayName: 'Muqtada',
          password: 'Passw0rd',
          confirmPassword: 'Passw0rd',
          checkUsername: (_) async =>
              throw const GoogleSetupException('authTooManyAttempts'),
          setPassword: (_) async {},
          upsertProfile: (
              {required String username,
              required String displayName,
              String? avatarUrl}) async =>
              _profile(username: username),
          saveSession: () async {},
        ),
        throwsA(
          isA<GoogleSetupException>().having(
              (e) => e.messageKey, 'messageKey', 'authTooManyAttempts'),
        ),
      );
    });

    test('empty display name falls back to the username', () async {
      String? seenDisplayName;
      await GoogleAuth.completeSetup(
        username: 'muqtada',
        displayName: '   ',
        password: 'Passw0rd',
        confirmPassword: 'Passw0rd',
        checkUsername: (_) async => true,
        setPassword: (_) async {},
        upsertProfile: (
            {required String username,
            required String displayName,
            String? avatarUrl}) async {
          seenDisplayName = displayName;
          return _profile(username: username);
        },
        saveSession: () async {},
      );
      expect(seenDisplayName, 'muqtada');
    });
  });

  group('new AppStrings keys', () {
    const keys = [
      'googleContinue',
      'googleOr',
      'googleSetupTitle',
      'googleSetupBody',
      'googleConfirmPassword',
      'googleUsernameAvailable',
      'googleUsernameChecking',
      'googleLinkTitle',
      'googleLinkBody',
      'googleLinkButton',
      'googleWaiting',
      'googleUnavailable',
      // New login design keys (user order 2026-11-16).
      'authLoginTitle',
      'authLoginSubtitle',
      'authEnterUsername',
      'authEnterPassword',
      'authFieldRequired',
      'authNoAccount',
      'authCreateNow',
      'authHaveAccount',
    ];

    test('all resolve to non-empty strings in ar and en', () {
      for (final key in keys) {
        AppStrings.lang.value = 'ar';
        final ar = AppStrings.t(key);
        expect(ar, isNotEmpty, reason: 'ar[$key]');
        expect(ar, isNot(key), reason: 'ar[$key] fell back to the key');
        AppStrings.lang.value = 'en';
        final en = AppStrings.t(key);
        expect(en, isNotEmpty, reason: 'en[$key]');
        expect(en, isNot(key), reason: 'en[$key] fell back to the key');
      }
    });

    test('the two languages actually differ for the new keys', () {
      final same = <String>[];
      for (final key in keys) {
        AppStrings.lang.value = 'ar';
        final ar = AppStrings.t(key);
        AppStrings.lang.value = 'en';
        if (AppStrings.t(key) == ar) same.add(key);
      }
      expect(same, isEmpty, reason: 'identical in ar/en: $same');
    });
  });

  group('Google button on the auth screen', () {
    testWidgets('shows on the login tab and on the signup tab',
        (tester) async {
      AppStrings.lang.value = 'ar';
      await tester.pumpWidget(
        MaterialApp(
          theme: HamsiqTheme.dark,
          home: AuthScreen(onAuthed: () {}),
        ),
      );
      await tester.pump();
      expect(find.text('المتابعة مع Google'), findsOneWidget);
      await tester.tap(find.text('أنشئ حساب جديد'));
      await tester.pump();
      expect(find.text('المتابعة مع Google'), findsOneWidget);
    });
  });

  group('login password field focus (parent side note)', () {
    testWidgets('password field accepts a direct tap + text',
        (tester) async {
      AppStrings.lang.value = 'ar';
      await tester.pumpWidget(
        MaterialApp(
          theme: HamsiqTheme.dark,
          home: AuthScreen(onAuthed: () {}),
        ),
      );
      await tester.pump();
      // Mockup-match login design: plain TextFormFields with the
      // short 'اسم المستخدم' / 'كلمة المرور' hints.
      final passwordField =
          find.widgetWithText(TextField, 'كلمة المرور');
      expect(passwordField, findsOneWidget);
      await tester.tap(passwordField);
      await tester.pump();
      await tester.enterText(passwordField, 'secret123');
      await tester.pump();
      // The field is enabled, focusable and takes input: no covering
      // widget, no disabled-until-username-valid gate in the code.
      expect(
        tester.widget<TextField>(passwordField).controller?.text,
        'secret123',
      );
    });

    testWidgets('Tab moves focus username -> password', (tester) async {
      AppStrings.lang.value = 'ar';
      await tester.pumpWidget(
        MaterialApp(
          theme: HamsiqTheme.dark,
          home: AuthScreen(onAuthed: () {}),
        ),
      );
      await tester.pump();
      await tester.tap(
          find.widgetWithText(TextField, 'اسم المستخدم'));
      await tester.pump();
      await tester.sendKeyEvent(LogicalKeyboardKey.tab);
      await tester.pump();
      final editables = find.byType(EditableText);
      expect(editables, findsNWidgets(2));
      final passwordEditable =
          tester.widget<EditableText>(editables.at(1));
      expect(passwordEditable.focusNode.hasFocus, isTrue);
    });
  });

  group('Google setup screen widgets', () {
    Future<void> pumpSetup(
      WidgetTester tester, {
      GoogleUsernameChecker? checkUsername,
      GoogleCompleteSetup? completeSetup,
      void Function()? onCompleted,
    }) async {
      AppStrings.lang.value = 'ar';
      await tester.pumpWidget(
        MaterialApp(
          theme: HamsiqTheme.dark,
          home: GoogleSetupScreen(
            initialDisplayName: 'Muqtada Test',
            initialAvatarUrl: null,
            onCompleted: onCompleted ?? () {},
            checkUsername: checkUsername,
            completeSetup: completeSetup,
          ),
        ),
      );
      await tester.pump();
    }

    testWidgets('prefills the Google display name', (tester) async {
      await pumpSetup(tester);
      expect(find.text('Muqtada Test'), findsOneWidget);
      expect(find.text('أكمل حسابك'), findsOneWidget);
    });

    testWidgets('has NO skip/back path', (tester) async {
      await pumpSetup(tester);
      expect(find.text('رجوع'), findsNothing);
    });

    testWidgets('live check shows "taken" for a taken username',
        (tester) async {
      await pumpSetup(
        tester,
        checkUsername: (_) async => false,
      );
      await tester.enterText(
        find.widgetWithText(TextField, 'اسم المستخدم'),
        'takenname',
      );
      await tester.pump(const Duration(milliseconds: 700));
      await tester.pump();
      expect(find.text('اسم المستخدم محجوز'), findsOneWidget);
    });

    testWidgets('live check shows "available" for a free username',
        (tester) async {
      await pumpSetup(
        tester,
        checkUsername: (_) async => true,
      );
      await tester.enterText(
        find.widgetWithText(TextField, 'اسم المستخدم'),
        'freename',
      );
      await tester.pump(const Duration(milliseconds: 700));
      await tester.pump();
      expect(find.text('اسم المستخدم متاح'), findsOneWidget);
    });

    testWidgets('submit calls completeSetup and then onCompleted',
        (tester) async {
      var completed = false;
      final seen = <String, String?>{};
      await pumpSetup(
        tester,
        checkUsername: (_) async => true,
        completeSetup: (
            {required String username,
            required String displayName,
            required String password,
            required String confirmPassword,
            String? avatarUrl}) async {
          seen['username'] = username;
          seen['displayName'] = displayName;
          return _profile(username: username);
        },
        onCompleted: () {
          completed = true;
        },
      );
      await tester.enterText(
        find.widgetWithText(TextField, 'اسم المستخدم'),
        'muqtada',
      );
      await tester.enterText(
        find.widgetWithText(TextField, 'كلمة المرور (8 أحرف، حرف ورقم)'),
        'Passw0rd',
      );
      await tester.enterText(
        find.widgetWithText(TextField, 'تأكيد كلمة المرور'),
        'Passw0rd',
      );
      await tester.tap(find.text('حفظ'));
      await tester.pump();
      expect(seen['username'], 'muqtada');
      expect(seen['displayName'], 'Muqtada Test');
      expect(completed, isTrue);
    });

    testWidgets('weak password is rejected offline with the rule message',
        (tester) async {
      var setupCalled = false;
      await pumpSetup(
        tester,
        completeSetup: (
            {required String username,
            required String displayName,
            required String password,
            required String confirmPassword,
            String? avatarUrl}) async {
          setupCalled = true;
          return _profile(username: username);
        },
      );
      await tester.enterText(
        find.widgetWithText(TextField, 'اسم المستخدم'),
        'muqtada',
      );
      await tester.enterText(
        find.widgetWithText(TextField, 'كلمة المرور (8 أحرف، حرف ورقم)'),
        'weak',
      );
      await tester.enterText(
        find.widgetWithText(TextField, 'تأكيد كلمة المرور'),
        'weak',
      );
      await tester.tap(find.text('حفظ'));
      await tester.pump();
      expect(setupCalled, isFalse);
      expect(
        find.text('كلمة المرور ضعيفة: 8 أحرف على الأقل، حرف ورقم'),
        findsOneWidget,
      );
    });
  });

  group('Google link screen widgets', () {
    testWidgets('shows the link copy, fields and a back button',
        (tester) async {
      AppStrings.lang.value = 'ar';
      await tester.pumpWidget(
        MaterialApp(
          theme: HamsiqTheme.dark,
          home: GoogleLinkScreen(
            onLinkWithPassword: (_, __) async => null,
            onBack: () {},
          ),
        ),
      );
      await tester.pump();
      expect(find.text('ربط حساب Google'), findsOneWidget);
      expect(
        find.widgetWithText(TextField, 'البريد الإلكتروني'),
        findsOneWidget,
      );
      expect(
        find.widgetWithText(TextField, 'كلمة المرور'),
        findsOneWidget,
      );
      expect(find.text('تسجيل الدخول وربط Google'), findsOneWidget);
      expect(find.text('رجوع'), findsOneWidget);
    });

    testWidgets('invalid email is rejected offline', (tester) async {
      var linked = false;
      AppStrings.lang.value = 'ar';
      await tester.pumpWidget(
        MaterialApp(
          theme: HamsiqTheme.dark,
          home: GoogleLinkScreen(
            onLinkWithPassword: (_, __) async {
              linked = true;
              return null;
            },
            onBack: () {},
          ),
        ),
      );
      await tester.pump();
      await tester.enterText(
        find.widgetWithText(TextField, 'البريد الإلكتروني'),
        'not-an-email',
      );
      await tester.enterText(
        find.widgetWithText(TextField, 'كلمة المرور'),
        'Passw0rd',
      );
      await tester.tap(find.text('تسجيل الدخول وربط Google'));
      await tester.pump();
      expect(linked, isFalse);
      expect(
        find.text('البريد الإلكتروني مو صحيح، تأكد منه وأعد كتابته'),
        findsOneWidget,
      );
    });
  });
}
