// Hamsiq audit fix H-01 — secure-login tests.
//
// These tests run with NO Supabase initialization and NO network: the
// service's invoker / applySession seams are faked, so they pin the
// client-side contract of the secure-login Edge Function:
//   * one identical generic error for unknown user vs wrong password,
//   * rate-limit threshold logic,
//   * session tokens applied on success,
//   * an email can never appear in a client-visible response.
// The live checks (deploy, curl, real login, 429 after 6 failures) still
// need a staging Supabase project — see supabase/secure-login-README.md.

import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/services/secure_login.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

void main() {
  // A valid success body, exactly as the Edge Function returns it.
  Map<String, dynamic> successBody({
    String accessToken = 'access-token-abc',
    String refreshToken = 'refresh-token-xyz',
    String userId = 'user-id-123',
    String username = 'muqtada',
  }) =>
      {
        'access_token': accessToken,
        'refresh_token': refreshToken,
        'user': {'id': userId, 'username': username},
      };

  group('generic error: unknown user vs wrong password', () {
    test('both failures produce the IDENTICAL message', () async {
      // Simulate the two server paths: the function returns 401 for
      // both, with different internal details that must never leak.
      Future<Map<String, dynamic>> unknownUser(
        Map<String, dynamic> _,
      ) async =>
          throw const FunctionsHttpException(
            status: 401,
            details: {'error': 'user not found'},
          );
      Future<Map<String, dynamic>> wrongPassword(
        Map<String, dynamic> _,
      ) async =>
          throw const FunctionsHttpException(
            status: 401,
            details: {'error': 'invalid password'},
          );

      Future<String> messageFor(SecureLoginInvoker invoker) async {
        try {
          await SecureLogin.loginWithUsername(
            'someone',
            'wrongpass123',
            invoker: invoker,
            applySession: ({
              required String accessToken,
              required String refreshToken,
            }) async {},
          );
        } on SecureLoginException catch (e) {
          return e.message;
        }
        throw StateError('expected SecureLoginException');
      }

      final unknownMsg = await messageFor(unknownUser);
      final wrongPassMsg = await messageFor(wrongPassword);
      expect(unknownMsg, secureLoginGenericError);
      expect(wrongPassMsg, secureLoginGenericError);
      expect(unknownMsg, wrongPassMsg);
      // And neither message contains the server's internal detail.
      expect(unknownMsg.contains('not found'), isFalse);
      expect(wrongPassMsg.contains('password'), isFalse);
    });

    test('other server statuses also map to the generic message', () async {
      for (final status in [400, 403, 500]) {
        try {
          await SecureLogin.loginWithUsername(
            'someone',
            'wrongpass123',
            invoker: (_) async => throw FunctionsHttpException(
              status: status,
              details: 'internal boom',
            ),
            applySession:
                ({required String accessToken, required String refreshToken}) async {},
          );
          fail('expected SecureLoginException for $status');
        } on SecureLoginException catch (e) {
          expect(e.message, secureLoginGenericError);
          expect(e.rateLimited, isFalse);
        }
      }
    });

    test('network failure maps to the generic message (no raw error)', () async {
      try {
        await SecureLogin.loginWithUsername(
          'someone',
          'wrongpass123',
          invoker: (_) async => throw const FunctionsFetchException(
            details: 'SocketException: Failed host lookup',
          ),
          applySession:
              ({required String accessToken, required String refreshToken}) async {},
        );
        fail('expected SecureLoginException');
      } on SecureLoginException catch (e) {
        expect(e.message, secureLoginGenericError);
        expect(e.message.contains('SocketException'), isFalse);
      }
    });

    test('empty username/password fail generic without invoking', () async {
      var invoked = false;
      for (final args in [
        ('', 'somepass'),
        ('someone', ''),
        ('   ', 'somepass'),
      ]) {
        try {
          await SecureLogin.loginWithUsername(
            args.$1,
            args.$2,
            invoker: (_) async {
              invoked = true;
              return successBody();
            },
            applySession:
                ({required String accessToken, required String refreshToken}) async {},
          );
          fail('expected SecureLoginException for ${args.$1}/${args.$2}');
        } on SecureLoginException catch (e) {
          expect(e.message, secureLoginGenericError);
        }
      }
      expect(invoked, isFalse);
    });
  });

  group('rate-limit threshold logic', () {
    test('threshold constants match the server (sql-v36 + index.ts)', () {
      expect(secureLoginMaxFailuresPerUser, 5);
      expect(secureLoginMaxFailuresPerIp, 10);
      expect(secureLoginRateLimitWindow, const Duration(minutes: 15));
    });

    test('decision function: block exactly at the limit', () {
      expect(
        isLoginRateLimited(failuresInWindow: 4, maxFailures: 5),
        isFalse,
      );
      expect(
        isLoginRateLimited(failuresInWindow: 5, maxFailures: 5),
        isTrue,
      );
      expect(
        isLoginRateLimited(failuresInWindow: 6, maxFailures: 5),
        isTrue,
      );
      expect(
        isLoginRateLimited(failuresInWindow: 9, maxFailures: 10),
        isFalse,
      );
      expect(
        isLoginRateLimited(failuresInWindow: 10, maxFailures: 10),
        isTrue,
      );
      expect(
        isLoginRateLimited(failuresInWindow: 0, maxFailures: 5),
        isFalse,
      );
    });

    test('HTTP 429 maps to the rate-limit message, not the generic one',
        () async {
      try {
        await SecureLogin.loginWithUsername(
          'someone',
          'wrongpass123',
          invoker: (_) async => throw const FunctionsHttpException(
            status: 429,
            details: {'error': 'Invalid username or password'},
          ),
          applySession:
              ({required String accessToken, required String refreshToken}) async {},
        );
        fail('expected SecureLoginException');
      } on SecureLoginException catch (e) {
        expect(e.message, secureLoginRateLimitError);
        expect(e.rateLimited, isTrue);
        // The 429 body stays generic server-side; only the status
        // distinguishes it, so existence still cannot leak.
        expect(e.message, isNot(secureLoginGenericError));
      }
    });
  });

  group('session tokens applied on success', () {
    test('returned tokens are passed to setSession unchanged', () async {
      String? capturedAccess;
      String? capturedRefresh;
      final response = await SecureLogin.loginWithUsername(
        'Muqtada',
        'correct-pass-1',
        invoker: (_) async => successBody(),
        applySession: ({
          required String accessToken,
          required String refreshToken,
        }) async {
          capturedAccess = accessToken;
          capturedRefresh = refreshToken;
        },
      );
      expect(capturedAccess, 'access-token-abc');
      expect(capturedRefresh, 'refresh-token-xyz');
      expect(response.accessToken, capturedAccess);
      expect(response.refreshToken, capturedRefresh);
      expect(response.userId, 'user-id-123');
      expect(response.username, 'muqtada');
    });

    test('username is normalized (trim + lowercase) before invoking',
        () async {
      Map<String, dynamic>? sentBody;
      await SecureLogin.loginWithUsername(
        '  Muqtada ',
        'correct-pass-1',
        invoker: (body) async {
          sentBody = body;
          return successBody();
        },
        applySession:
            ({required String accessToken, required String refreshToken}) async {},
      );
      expect(sentBody?['username'], 'muqtada');
      expect(sentBody?.containsKey('email'), isFalse);
      expect(sentBody?.keys, ['username', 'password']);
    });
  });

  group('email never present in the client-visible response', () {
    test('response shape has exactly the allowed keys', () {
      final body = successBody();
      expect(body.keys.toSet(), {'access_token', 'refresh_token', 'user'});
      expect(
        (body['user'] as Map<String, dynamic>).keys.toSet(),
        {'id', 'username'},
      );
      final response = SecureLoginResponse.fromJson(body);
      expect(response.accessToken, isNotEmpty);
      expect(response.refreshToken, isNotEmpty);
      expect(response.userId, isNotEmpty);
      expect(response.username, isNotEmpty);
    });

    test('a body containing an email key is rejected wholesale', () {
      final body = successBody()
        ..['email'] = 'victim@example.com'
        ..['user'] = {
          'id': 'user-id-123',
          'username': 'muqtada',
          'email': 'victim@example.com',
        };
      expect(
        () => SecureLoginResponse.fromJson(body),
        throwsA(
          isA<SecureLoginException>().having(
            (e) => e.message,
            'message',
            secureLoginGenericError,
          ),
        ),
      );
    });

    test('loginWithUsername never applies a session from an email-bearing body',
        () async {
      var applied = false;
      try {
        await SecureLogin.loginWithUsername(
          'someone',
          'correct-pass-1',
          invoker: (_) async => successBody()
            ..['email'] = 'victim@example.com',
          applySession: ({
            required String accessToken,
            required String refreshToken,
          }) async {
            applied = true;
          },
        );
        fail('expected SecureLoginException');
      } on SecureLoginException catch (e) {
        expect(e.message, secureLoginGenericError);
      }
      expect(applied, isFalse);
    });

    test('missing/empty tokens or user fields are rejected', () {
      for (final bad in [
        successBody()..remove('access_token'),
        successBody(accessToken: ''),
        successBody()..remove('refresh_token'),
        successBody()..remove('user'),
        successBody(userId: ''),
        successBody(username: ''),
        <String, dynamic>{'error': 'Invalid username or password'},
      ]) {
        expect(
          () => SecureLoginResponse.fromJson(bad),
          throwsA(isA<SecureLoginException>()),
          reason: 'should reject $bad',
        );
      }
    });
  });

  group('auth_screen wiring (source assertions)', () {
    test('login uses SecureLogin, not the email-leaking RPC path', () {
      final src = File(
        'lib/screens/auth_screen.dart',
      ).readAsStringSync();
      expect(src.contains("import '../services/secure_login.dart';"), isTrue);
      expect(src.contains('SecureLogin.loginWithUsername'), isTrue);
      expect(src.contains('Api.loginWithUsername'), isFalse);
      // H-01 closed: neither the login nor the signup flow references
      // the old RPC anywhere in this file (signup uses the
      // check-username Edge Function, which returns only a boolean).
      expect('get_email_by_username'.allMatches(src).length, 0);
      expect(src.contains('KNOWN REMAINING H-01 EXPOSURE'), isFalse);
      expect(src.contains('check-username'), isTrue);
    });

    test('login handler in auth_screen calls no RPC and no sign-in itself',
        () {
      final src = File(
        'lib/screens/auth_screen.dart',
      ).readAsStringSync();
      // The login handler must not resolve anything itself: the Edge
      // Function does the lookup and the sign-in server-side.
      final loginBlock = src.substring(
        src.indexOf('Future<void> _doLogin()'),
        src.indexOf('Future<void> _doSignup()'),
      );
      expect(loginBlock.contains('SecureLogin.loginWithUsername'), isTrue);
      expect(loginBlock.contains('get_email_by_username'), isFalse);
      expect(loginBlock.contains('client.rpc'), isFalse);
      expect(loginBlock.contains('signInWithPassword'), isFalse);
    });
  });
}
