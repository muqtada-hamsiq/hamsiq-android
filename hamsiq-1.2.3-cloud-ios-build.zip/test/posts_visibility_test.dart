// H-02 (critical) — private-account posts must be enforced SERVER-side.
//
// The real enforcement is the posts SELECT policy in sql-v32.sql, so
// these tests assert on the migration text itself: the policy must
// contain every required condition, use the exact table/column names
// from the combined schema (v4..v31), never query its own table
// (42P17 recursion), and must not be the old bare is_approved()-only
// rule. The client proves nothing about visibility beyond that on
// purpose: Api.fetchFeed intentionally has NO client-side author
// filtering (the server is the enforcement point), so the Dart-side
// tests below assert the Phase-1 shortcut is gone and the feed still
// reads plain latest-posts. Live role-based behaviour (anonymous,
// approved non-follower / follower, owner, blocked, admin) can only
// be proven against a staging Supabase project — see the verification
// block at the end of sql-v32.sql.
//
// Pure file tests — no network, no Supabase session. Run from the
// package root (flutter test), where sql-v32.sql lives.

import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/models.dart';

/// The CREATE POLICY statement for the posts SELECT policy.
/// Anchored to a line-start match: the file header quotes the old
/// policy text inside `--` comments, so a bare indexOf would find
/// the quote instead of the real statement.
String _postsSelectPolicy(String sql) {
  const marker = '\ncreate policy "posts visible to approved"';
  final start = sql.indexOf(marker);
  expect(start, isNot(-1), reason: 'sql-v32.sql must recreate the posts SELECT policy');
  final end = sql.indexOf(');', start);
  expect(end, isNot(-1), reason: 'posts SELECT policy statement must terminate');
  return sql.substring(start, end);
}

void main() {
  late String sql;
  late String policy;

  setUpAll(() {
    final file = File('sql-v32.sql');
    expect(file.existsSync(), isTrue,
        reason: 'sql-v32.sql must exist at the package root');
    sql = file.readAsStringSync();
    policy = _postsSelectPolicy(sql);
  });

  group('sql-v32.sql — H-02 posts SELECT policy', () {
    test('policy is dropped before recreation (idempotent re-run)', () {
      const drop = '\ndrop policy if exists "posts visible to approved"';
      const create = '\ncreate policy "posts visible to approved"';
      expect(sql.contains(drop), isTrue);
      expect(sql.indexOf(drop), lessThan(sql.indexOf(create)));
    });

    test('policy still requires an approved account', () {
      expect(policy.contains('public.is_approved()'), isTrue);
    });

    test('owner can always see their own posts', () {
      expect(policy.contains('auth.uid() = user_id'), isTrue);
    });

    test('admin can see every post', () {
      expect(policy.contains('public.is_admin()'), isTrue);
    });

    test('private authors: public profile OR follower', () {
      expect(policy.contains('post_author_is_private'), isTrue);
      expect(policy.contains('is_following'), isTrue);
      // The private branch must be "not private OR following" —
      // a pending follow request (no follows row yet) sees nothing.
      expect(
        policy.contains('not public.post_author_is_private(user_id)'),
        isTrue,
      );
      expect(
        policy.contains('public.is_following(auth.uid(), user_id)'),
        isTrue,
      );
    });

    test('blocked users see nothing (either direction)', () {
      expect(policy.contains('is_blocked_between'), isTrue);
      expect(
        policy.contains(
            'not public.is_blocked_between(auth.uid(), user_id)'),
        isTrue,
      );
    });

    test('policy is NOT the old bare is_approved()-only rule', () {
      expect(
        sql.contains(
            'for select using (\n  public.is_approved()\n);'),
        isFalse,
        reason: 'the old H-02 policy text must be gone',
      );
      // The policy body must contain more than the approval check.
      expect(policy.contains('is_following'), isTrue);
      expect(policy.contains('post_author_is_private'), isTrue);
    });

    test('policy never queries its own table (no 42P17 recursion)', () {
      expect(policy.contains('from public.posts'), isFalse);
      expect(policy.contains('from posts'), isFalse);
    });
  });

  group('sql-v32.sql — SECURITY DEFINER helpers', () {
    test('helpers exist, are SECURITY DEFINER, and pin search_path', () {
      for (final name in [
        'post_author_is_private',
        'is_following',
        'is_blocked_between',
      ]) {
        expect(sql.contains('function public.$name('), isTrue,
            reason: 'helper $name must be defined');
        final start = sql.indexOf('function public.$name(');
        final body = sql.substring(start, sql.indexOf(r'$$;', start));
        expect(body.contains('security definer'), isTrue,
            reason: '$name must be SECURITY DEFINER');
        expect(body.contains('set search_path = pg_catalog, public'),
            isTrue,
            reason: '$name must pin search_path (H-05 convention)');
      }
    });

    test('helpers use the exact schema table/column names', () {
      // profiles.is_private (sql-v9), follows(follower_id, following_id)
      // and blocks(blocker_id, blocked_id) (both sql-v5) — copied from
      // the combined schema v4..v31, never guessed.
      expect(sql.contains('public.profiles'), isTrue);
      expect(sql.contains('is_private'), isTrue);
      expect(sql.contains('public.follows'), isTrue);
      expect(sql.contains('follower_id'), isTrue);
      expect(sql.contains('following_id'), isTrue);
      expect(sql.contains('public.blocks'), isTrue);
      expect(sql.contains('blocker_id'), isTrue);
      expect(sql.contains('blocked_id'), isTrue);
    });

    test('block check covers both directions', () {
      final start = sql.indexOf('function public.is_blocked_between(');
      final body = sql.substring(start, sql.indexOf(r'$$;', start));
      expect(
        body.contains(
            '(b.blocker_id = p_user_id and b.blocked_id = p_other_id)'),
        isTrue,
      );
      expect(
        body.contains(
            '(b.blocker_id = p_other_id and b.blocked_id = p_user_id)'),
        isTrue,
      );
    });

    test('helpers are executable by the roles that read posts', () {
      expect(
        sql.contains(
            'grant execute on function public.post_author_is_private(uuid)'),
        isTrue,
      );
      expect(
        sql.contains(
            'grant execute on function public.is_following(uuid, uuid)'),
        isTrue,
      );
      expect(
        sql.contains(
            'grant execute on function public.is_blocked_between(uuid, uuid)'),
        isTrue,
      );
    });
  });

  group('Api.fetchFeed — Phase-1 shortcut is gone', () {
    late String dart;

    setUpAll(() {
      dart = File('lib/services/supabase_service.dart').readAsStringSync();
    });

    test('the "private authors still show" comment is removed', () {
      expect(dart.contains('private authors are kept'), isFalse);
      expect(dart.contains('their posts still show'), isFalse);
      expect(dart.contains('kept simple in Phase 1'), isFalse);
    });

    test('fetchFeed documents server-side enforcement (sql-v32)', () {
      final start = dart.indexOf('static Future<List<PostItem>> fetchFeed');
      expect(start, isNot(-1));
      final commentStart = dart.indexOf('/// Latest posts first');
      expect(commentStart, isNot(-1));
      expect(commentStart, lessThan(start));
      final comment = dart.substring(commentStart, start);
      expect(comment.contains('sql-v32'), isTrue);
      expect(comment.contains('H-02'), isTrue);
    });

    test('fetchFeed still reads plain latest posts (no client filter)', () {
      final start = dart.indexOf('static Future<List<PostItem>> fetchFeed');
      final end = dart.indexOf('static Future<List<PostItem>> fetchUserPosts');
      final fn = dart.substring(start, end);
      expect(fn.contains(".from('posts')"), isTrue);
      expect(fn.contains(".order('created_at'"), isTrue);
      expect(fn.contains('.limit(limit)'), isTrue);
      // No client-side author/privacy filtering may sneak back in:
      // the server decides visibility.
      expect(fn.contains('is_private'), isFalse);
      expect(fn.contains('isPrivate'), isFalse);
      expect(fn.contains('.where('), isFalse);
    });
  });

  group('PostItem — feed rows still carry the author id', () {
    test('fromMap preserves user_id for the author-attach step', () {
      final p = PostItem.fromMap({
        'id': 42,
        'user_id': 'author-1',
        'caption': 'hello',
        'media_url': 'https://example.com/42.jpg',
        'media_type': 'image',
        'is_reel': false,
        'created_at': DateTime.now().toIso8601String(),
      });
      expect(p.id, 42);
      expect(p.userId, 'author-1');
      expect(p.author, isNull);
    });
  });
}
