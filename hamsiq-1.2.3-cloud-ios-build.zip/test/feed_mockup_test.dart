// Feed mockup-match tests (2026-11-16, mockup file 1: feed).
// The feed card itself is a private widget, so the card geometry and
// the bookmark wiring are asserted against the source (same pattern as
// profile_header_redesign_test.dart); the AppBar brand row is a real
// widget test. All data stays real — no mock users/posts anywhere.
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamsiq/models.dart';
import 'package:hamsiq/screens/feed_screen.dart';
import 'package:hamsiq/services/app_strings.dart';
import 'package:hamsiq/services/supabase_service.dart';
import 'package:hamsiq/theme.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

HamsiqProfile _me() => HamsiqProfile(
      id: 'test-user',
      username: 'testuser',
      displayName: 'Test User',
      avatar: '😀',
      bio: '',
      verified: false,
      isAdmin: false,
      approved: true,
      isPrivate: false,
    );

void main() {
  late String feedSrc;
  late String storiesSrc;
  late String bellSrc;
  late String shellSrc;

  setUpAll(() async {
    TestWidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    await Supabase.initialize(
      url: Api.supabaseUrl,
      publishableKey: Api.supabaseAnonKey,
    );
    AppStrings.lang.value = 'ar';
    feedSrc = File('lib/screens/feed_screen.dart').readAsStringSync();
    storiesSrc =
        File('lib/screens/stories_screen.dart').readAsStringSync();
    bellSrc = File('lib/screens/notifications_screen.dart')
        .readAsStringSync();
    shellSrc =
        File('lib/screens/home_shell.dart').readAsStringSync();
  });

  String appBarBlock() {
    final start = feedSrc.indexOf('appBar: AppBar(');
    final end = feedSrc.indexOf('body: Column(');
    return feedSrc.substring(start, end);
  }

  String postCardBlock() {
    final start = feedSrc.indexOf('class _PostCard');
    final end = feedSrc.indexOf('class _PostMedia');
    return feedSrc.substring(start, end);
  }

  String postMediaBlock() {
    return feedSrc.substring(feedSrc.indexOf('class _PostMedia'));
  }

  String storyCircleBlock() {
    final start = storiesSrc.indexOf('class _StoryCircle');
    return storiesSrc.substring(start);
  }

  group('AppBar brand row (mockup file 1)', () {
    test('logo 38x38 + Hamsiq + 18pt verified badge', () {
      final bar = appBarBlock();
      expect(bar, contains('width: 38'));
      expect(bar, contains('height: 38'));
      expect(bar, contains("Text(\n              'Hamsiq'"));
      expect(bar, contains('const VerifiedTick(size: 18)'));
    });

    test('actions are bell + send only — no Blend icon in the AppBar',
        () {
      final bar = appBarBlock();
      expect(bar, contains('NotificationsBellButton()'));
      expect(bar, contains('Icons.send_outlined'));
      expect(bar, isNot(contains('Icons.people_alt_outlined')));
      expect(bar, isNot(contains('_openBlendPicker')));
    });

    test('Blend entry point is kept intact, just unreachable', () {
      expect(feedSrc, contains('Future<void> _openBlendPicker()'));
      expect(feedSrc, contains('BlendScreen(peer: peer)'));
      expect(feedSrc, contains("import 'blend_screen.dart';"));
    });

    testWidgets('verified badge renders next to Hamsiq in the AppBar',
        (tester) async {
      await tester.pumpWidget(MaterialApp(
        theme: HamsiqTheme.dark,
        home: Scaffold(
          body: FeedScreen(
            me: _me(),
            refreshTick: ValueNotifier<int>(0),
            onOpenChats: () {},
          ),
        ),
      ));
      await tester.pump();
      expect(find.byIcon(Icons.verified), findsOneWidget);
      expect(
        tester.widget<Icon>(find.byIcon(Icons.verified)).size,
        18,
      );
    });
  });

  group('bell unread dot is blue', () {
    test('dot colour is the accent blue, never red', () {
      final bell = bellSrc.substring(
        bellSrc.indexOf('class _NotificationsBellButtonState'),
        bellSrc.indexOf('class NotificationsScreen'),
      );
      expect(bell, contains('color: HamsiqTheme.accent,'));
      expect(bell, isNot(contains('Colors.redAccent')));
      expect(bell, contains('width: 10'));
      expect(bell, contains('height: 10'));
    });
  });

  group('post card action bar (mockup file 1)', () {
    test('header row ends with a "..." that opens the post', () {
      final card = postCardBlock();
      final headerEnd = card.indexOf("Icons.more_horiz");
      expect(headerEnd, greaterThanOrEqualTo(0));
      expect(card, contains("tooltip: AppStrings.t('postOptions')"));
      expect(card, contains('onPressed: onOpenPost,'));
    });

    test('action bar sits in its own bordered pill (radius 24)', () {
      final card = postCardBlock();
      expect(card, contains('BorderRadius.circular(24)'));
      expect(card, contains('border: Border.all(color: HamsiqTheme.line)'));
    });

    test('bookmark toggle at the far end, after a Spacer', () {
      final card = postCardBlock();
      final share = card.indexOf('Icons.send_outlined');
      final spacer = card.indexOf('const Spacer(),');
      final bookmark = card.indexOf('Icons.bookmark_border');
      expect(share, greaterThanOrEqualTo(0));
      expect(spacer, greaterThan(share));
      expect(bookmark, greaterThan(spacer));
      expect(
        card,
        contains('saved ? Icons.bookmark : Icons.bookmark_border'),
      );
      expect(card, contains('onToggleSave'));
      expect(card, contains("tooltip: AppStrings.t('save')"));
    });

    test('bookmark is wired to the real save function, not a stub', () {
      // _toggleSave mirrors post_detail_screen.dart: saving opens the
      // collections sheet then re-checks isSaved; unsaving calls
      // CollectionsApi.toggleSave(id, false).
      expect(feedSrc, contains('Future<void> _toggleSave(PostItem post)'));
      expect(feedSrc, contains('showAddToCollectionSheet(context, post)'));
      expect(feedSrc, contains('CollectionsApi.isSaved(post.id)'));
      expect(feedSrc, contains('CollectionsApi.toggleSave(post.id, false)'));
      expect(feedSrc, contains('CollectionsApi.fetchSavedPostIds()'));
      expect(feedSrc, isNot(contains('// TODO')));
    });

    test('like / comment / share order kept before the bookmark', () {
      final card = postCardBlock();
      final like = card.indexOf('Icons.favorite');
      final comment = card.indexOf('Icons.chat_bubble_outline');
      final share = card.indexOf('Icons.send_outlined');
      final bookmark = card.indexOf('Icons.bookmark_border');
      expect(like, greaterThanOrEqualTo(0));
      expect(comment, greaterThan(like));
      expect(share, greaterThan(comment));
      expect(bookmark, greaterThan(share));
    });
  });

  group('post media corners radius 16', () {
    test('image ClipRRect and video tile both radius 16', () {
      final media = postMediaBlock();
      expect(media, contains('BorderRadius.circular(16)'));
      expect(media, isNot(contains('BorderRadius.circular(12)')));
    });
  });

  group('story glow rings (mockup file 1)', () {
    test('unseen ring is a blue gradient with a soft blue shadow', () {
      final circle = storyCircleBlock();
      expect(circle, contains('LinearGradient('));
      expect(circle, contains('HamsiqTheme.accentDark'));
      expect(circle, contains('BoxShadow('));
      expect(circle, contains('blurRadius: 12'));
      expect(circle, contains('spreadRadius: 1'));
      // The plain 2.5px border survives only for seen / Close-Friends.
      expect(circle, contains('width: 2.5'));
    });
  });

  group('bottom-nav centre + keeps its blue glow', () {
    test('46x46 blue circle with a blue shadow', () {
      final plus = shellSrc.substring(
        shellSrc.indexOf('width: 46,'),
        shellSrc.indexOf("label: '',"),
      );
      expect(plus, contains('height: 46'));
      expect(plus, contains('color: HamsiqTheme.accent'));
      expect(plus, contains('BoxShadow('));
      expect(plus, contains('blurRadius: 12'));
      expect(plus, contains('Icons.add, color: Colors.white, size: 28'));
    });
  });
}
