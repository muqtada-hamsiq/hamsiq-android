-- sql-v29.sql — Hamsiq native v1.2.0 Wave 1 (Instagram features)
-- Run in the Supabase SQL Editor AFTER sql-v28.sql. Idempotent: safe to
-- run twice. The native app (~/workspace/hamsiq-native) reads/writes
-- every object below; run this BEFORE building the v1.2.0 APK.
--
-- What already existed (NOT duplicated here — verified in the schema):
--   * public.reposts (sql-v9) — repost rows already exist; Wave 1 only
--     adds the client-side repost action + Reposts tab. No new table.
--   * public.notifications (sql-v9) — columns id, user_id, actor_id,
--     type, post_id, created_at, is_read. Wave 1 reuses it for the new
--     types 'like' | 'comment' | 'follow' | 'message' (existing type was
--     'mention'). No new column except the recipient toggle below.
--   * public.saved_posts (sql-v16) — reused as the base "Saved" store;
--     collections below organise saved posts into named folders.
--   * public.posts already has an ADMIN-ONLY update policy (sql-v20,
--     "admin updates posts"). Wave 1 adds an OWNER update policy so a
--     user can pin / reorder their own posts.
--
-- New in this file:
--   1) profiles.notif_comments boolean (comment notifications toggle;
--      v9 already added notif_messages / notif_likes / notif_followers /
--      notif_mentions — comment notifications had no toggle).
--   2) comments.parent_id (threaded replies) + comments.gif_url
--      (curated-GIF comments) + comments.is_pinned (pinned comments).
--      Pinning goes through the SECURITY DEFINER function
--      set_comment_pinned() — there is deliberately NO comments UPDATE
--      policy, so nobody can edit another comment's body through the API.
--   3) posts.is_pinned (max 3 per user, enforced client-side in
--      ShareApi.setPostPinned) + posts.grid_order (profile grid reorder).
--   4) story_views — one real DB row per (story, viewer); the viewer
--      list + count come from this table, never from session memory.
--   5) collections + collection_posts — named save folders.
--
-- RLS HARD RULES (learned 2026-11-14, 42P17): no policy whose qual or
-- with_check queries its OWN table. Policies below use auth.uid() and
-- the SECURITY DEFINER helpers public.is_approved() / public.is_admin()
-- (they query profiles bypassing RLS), or subqueries on DIFFERENT
-- tables only. Every table a policy references is created BEFORE the
-- policy. New columns are added BEFORE any policy/function that uses
-- them.
--
-- Message types used by Wave 1 (no schema change — messages.message_type
-- is free text, sql-v4; same pattern as 'poll' in sql-v28):
--   * 'shared_post'  — body = <post id as text> (like poll body = poll id)
--   * 'story_reply'  — body = JSON {"story_id": <id>, "text": "<reply>"},
--     media_url = the story's media URL (thumbnail for the DM card)

-- ============ 1) profiles.notif_comments ============
alter table public.profiles
  add column if not exists notif_comments boolean not null default true;

-- ============ 2) comments: threading + GIF + pin ============
alter table public.comments
  add column if not exists parent_id bigint references public.comments(id) on delete cascade;
alter table public.comments
  add column if not exists gif_url text;
alter table public.comments
  add column if not exists is_pinned boolean not null default false;
create index if not exists idx_comments_parent on public.comments(parent_id);
create index if not exists idx_comments_pinned on public.comments(post_id, is_pinned);

-- Pin / unpin a comment. Only the post owner or the comment's own author
-- may pin it; at most 3 pinned comments per post (Instagram limit, per
-- the 2026 inventory — Help Center says 3, one round-up claims 5).
-- SECURITY DEFINER so no comments UPDATE policy is needed at all.
create or replace function public.set_comment_pinned(
  p_comment_id bigint,
  p_pinned boolean
)
returns void language plpgsql security definer as $$
declare
  v_me uuid := auth.uid();
  v_post_id bigint;
  v_author_id uuid;
  v_owner_id uuid;
  v_pinned_count int;
begin
  if v_me is null then raise exception 'not authenticated'; end if;
  select c.post_id, c.author_id into v_post_id, v_author_id
    from public.comments c where c.id = p_comment_id;
  if v_post_id is null then raise exception 'no such comment'; end if;
  select p.user_id into v_owner_id from public.posts p where p.id = v_post_id;
  if v_me <> v_owner_id and v_me <> v_author_id
     and not exists (select 1 from public.profiles p where p.id = v_me and p.is_admin) then
    raise exception 'only the post owner or the comment author can pin';
  end if;
  if p_pinned then
    select count(*) into v_pinned_count from public.comments
      where post_id = v_post_id and is_pinned = true and id <> p_comment_id;
    if v_pinned_count >= 3 then raise exception 'at most 3 pinned comments'; end if;
  end if;
  update public.comments set is_pinned = p_pinned where id = p_comment_id;
end;
$$;
grant execute on function public.set_comment_pinned(bigint, boolean) to authenticated;

-- ============ 3) posts: pinned posts + grid order ============
alter table public.posts
  add column if not exists is_pinned boolean not null default false;
alter table public.posts
  add column if not exists grid_order int not null default 0;
create index if not exists idx_posts_pinned on public.posts(user_id, is_pinned);
create index if not exists idx_posts_grid_order on public.posts(user_id, grid_order);

-- Owner UPDATE policy (the admin-only one from sql-v20 stays as-is;
-- permissive policies OR together). Lets a user pin/unpin and reorder
-- their OWN posts. Caption edits are not offered by the client.
drop policy if exists "owners update own posts" on public.posts;
create policy "owners update own posts" on public.posts for update
  using (auth.uid() = user_id or public.is_admin())
  with check (auth.uid() = user_id or public.is_admin());

-- ============ 4) story_views ============
create table if not exists public.story_views (
  id bigint generated always as identity primary key,
  story_id bigint not null references public.stories(id) on delete cascade,
  viewer_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (story_id, viewer_id)
);
create index if not exists idx_story_views_story on public.story_views(story_id);
create index if not exists idx_story_views_viewer on public.story_views(viewer_id);
alter table public.story_views enable row level security;

-- Select: the viewer themself, the story owner, or an admin. The
-- subquery reads public.stories (a DIFFERENT table) — never story_views.
drop policy if exists "story_views_select" on public.story_views;
create policy "story_views_select" on public.story_views for select using (
  auth.uid() = viewer_id
  or auth.uid() = (select s.user_id from public.stories s where s.id = story_views.story_id)
  or public.is_admin()
);
-- Insert: I record only my own view, on a story that exists.
drop policy if exists "story_views_insert" on public.story_views;
create policy "story_views_insert" on public.story_views for insert with check (
  auth.uid() = viewer_id
  and public.is_approved()
  and exists (select 1 from public.stories s where s.id = story_views.story_id)
);
-- Delete: my own view, the story owner, or an admin.
drop policy if exists "story_views_delete" on public.story_views;
create policy "story_views_delete" on public.story_views for delete using (
  auth.uid() = viewer_id
  or auth.uid() = (select s.user_id from public.stories s where s.id = story_views.story_id)
  or public.is_admin()
);

-- ============ 5) collections + collection_posts ============
create table if not exists public.collections (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  cover_url text,
  created_at timestamptz not null default now()
);
create index if not exists idx_collections_user on public.collections(user_id);
alter table public.collections enable row level security;

drop policy if exists "collections_select" on public.collections;
create policy "collections_select" on public.collections for select using (
  public.is_approved()
);
drop policy if exists "collections_insert" on public.collections;
create policy "collections_insert" on public.collections for insert with check (
  auth.uid() = user_id and public.is_approved()
);
drop policy if exists "collections_update" on public.collections;
create policy "collections_update" on public.collections for update using (
  auth.uid() = user_id
) with check (auth.uid() = user_id);
drop policy if exists "collections_delete" on public.collections;
create policy "collections_delete" on public.collections for delete using (
  auth.uid() = user_id
);

create table if not exists public.collection_posts (
  collection_id bigint not null references public.collections(id) on delete cascade,
  post_id bigint not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (collection_id, post_id)
);
create index if not exists idx_collection_posts_collection on public.collection_posts(collection_id);
create index if not exists idx_collection_posts_post on public.collection_posts(post_id);
alter table public.collection_posts enable row level security;

-- Select: any approved user (a collection's posts are the owner's saved
-- posts, already visible under the posts/saved_posts policies).
drop policy if exists "collection_posts_select" on public.collection_posts;
create policy "collection_posts_select" on public.collection_posts for select using (
  public.is_approved()
);
-- Insert/delete: only the collection's owner. The subquery reads
-- public.collections (a DIFFERENT table) — never collection_posts.
drop policy if exists "collection_posts_insert" on public.collection_posts;
create policy "collection_posts_insert" on public.collection_posts for insert with check (
  exists (select 1 from public.collections c
          where c.id = collection_posts.collection_id and c.user_id = auth.uid())
);
drop policy if exists "collection_posts_delete" on public.collection_posts;
create policy "collection_posts_delete" on public.collection_posts for delete using (
  exists (select 1 from public.collections c
          where c.id = collection_posts.collection_id and c.user_id = auth.uid())
);

-- ============ 6) realtime for the new tables ============
do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'story_views') then
    execute 'alter publication supabase_realtime add table public.story_views';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'collections') then
    execute 'alter publication supabase_realtime add table public.collections';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'collection_posts') then
    execute 'alter publication supabase_realtime add table public.collection_posts';
  end if;
end $$;

-- ============ verification (run after the above) ============
-- select table_name from information_schema.tables where table_schema='public'
--   and table_name in ('story_views','collections','collection_posts');
-- select column_name from information_schema.columns where table_schema='public'
--   and ((table_name='comments' and column_name in ('parent_id','gif_url','is_pinned'))
--     or (table_name='posts' and column_name in ('is_pinned','grid_order'))
--     or (table_name='profiles' and column_name='notif_comments'));
-- select tablename, policyname from pg_policies where schemaname='public'
--   and tablename in ('story_views','collections','collection_posts','posts')
--   order by tablename, policyname;
-- select proname from pg_proc where pronamespace='public'::regnamespace
--   and proname='set_comment_pinned';
