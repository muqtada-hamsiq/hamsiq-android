# Hamsiq Native (Flutter) — Android

Native Android rebuild of Hamsiq. The Capacitor wrapper APK (v42) was
rejected by the user on 2026-11-15 (heavy/slow, camera dead, calls refused,
browser better), so this is a fresh native lineage: **no WebView anywhere**.

- Package: `com.hamsiq.app` — app name Hamsiq
- Version: **1.2.2 (versionCode 6)** — delivered 2026-11-16 (see
  "Release APK (v1.2.2)" below). Previous: 1.2.1 = versionCode 5,
  1.2.0 = versionCode 4, 1.1.0 = versionCode 3, 1.0.1 = versionCode 2,
  1.0 = versionCode 1. Same Drive fileId
  `166pbLNLCriysHUlD8NSXu4a34LaT6Vjk` serves every version; content is
  replaced in place, same download link.
- Distribution: direct APK install, **no Play Store upload**
- Backend: the SAME Supabase project as the web app (`muqtada-chat`,
  https://yjmqmkvefabiuxtbmetm.supabase.co) — same tables, same anon key
  (already public in the web app). Never use the service_role key.
- iPhone comes later — do not touch the iOS IPA.

## Environment (this VM)

- Flutter SDK: 3.50.0 stable, installed at `~/flutter`
  (tarball `flutter_linux_3.50.0-stable.tar.xz`, sha256
  `6ea2d806fd57269ae783e6788e2a81fc26eaad782f1e0d0ff38623bb765ff9f5`).
  Add to PATH: `export PATH="$HOME/flutter/bin:$PATH"`
- Android SDK: `~/workspace/hamsiq-android/tools/android-sdk`
  (platforms 34 + 35 + **36** (platform-36_r02.zip, sha1
  `2c1a80dd4d9f7d0e6dd336ec603d9b5c55a6f576`), build-tools 34.0.0 +
  **36.1.0** (build-tools_r36.1_linux.zip, sha1
  `936a0d6bd5ae3e2118a7567dddbc95ff67ed46e9`))
  `export ANDROID_HOME=$HOME/workspace/hamsiq-android/tools/android-sdk`
  NOTE: sdkmanager cannot fetch the remote manifest through the proxy
  ("Failed to download any source lists") — platform 36 + build-tools 36.1
  were installed MANUALLY from dl.google.com (curl works through the
  proxy; Java/sdkmanager does not). If a future component is needed, fetch
  the URL from https://dl.google.com/android/repository/repository2-1.xml
  and unzip it by hand. Same for the NDK: Flutter 3.50's Gradle plugin
  REQUIRES NDK 28.2.13676358 (its auto-install declines the license with
  no stdin) — install manually: download
  https://dl.google.com/android/repository/android-ndk-r28c-linux.zip
  (722,261,334 bytes, sha1 a7b54a5de87fecd125a17d54f73c446199e72a64),
  unzip into $ANDROID_HOME/ndk/28.2.13676358/ (the zip's top folder is
  android-ndk-r28c/). Removing the ndkVersion line from build.gradle.kts
  does NOT help — the Flutter Gradle plugin enforces it.
- Java: Temurin JDK 21.0.13 at `~/workspace/tools/jdk-21.0.13+9`
  (`export JAVA_HOME=$HOME/workspace/tools/jdk-21.0.13+9`). The VM
  restarted on 2026-11-15 ~08:05 and wiped the system JDK
  (/usr/lib/jvm) — a JDK under ~ survives restarts, /usr/lib does not.
  The Hatch egress CA (/usr/local/share/ca-certificates/hatch-egress-ca.crt)
  MUST be imported into this JDK's cacerts or Gradle downloads fail with
  PKIX errors:
  `keytool -importcert -noprompt -trustcacerts -alias hatch-egress-ca
  -file /usr/local/share/ca-certificates/hatch-egress-ca.crt
  -keystore $JAVA_HOME/lib/security/cacerts -storepass changeit`
- **The egress CA ROTATES.** If a build fails with PKIX
  "Signature does not match", the JDK cacerts holds a stale CA: compare
  `openssl x509 -in /usr/local/share/ca-certificates/hatch-egress-ca.crt
  -noout -fingerprint -sha256` against the keystore entry (`keytool -list
  -alias hatch-egress-ca`); if they differ, delete the alias and re-import
  (happened 2026-11-15: old 66:89:D0:82…, then 0F:4B:60:72…; rotated
  AGAIN 2026-11-15 ~15:30 — current C7:D4:E2:99…, re-imported into the
  Temurin cacerts before the v1.2.0 build).
- Gradle downloads go through the local proxy
  `~/workspace/hamsiq-android/tools/local-proxy.py` on 127.0.0.1:3129 —
  restart it after a VM restart (it dies with the VM):
  `cd ~/workspace/hamsiq-android/tools && nohup python3 local-proxy.py > /tmp/local-proxy.log 2>&1 &`
  The proxy settings also live in `android/gradle.properties`.
- `/tmp` is a 512 MB tmpfs — NEVER download large files there; use
  `~/workspace/tmp` instead (that is what killed the first Flutter download).
- No KVM (`/dev/kvm` missing) and no emulator binary in the SDK, so no
  Android emulator can run on this VM. Boot is verified with
  `flutter test` (widget test pumping the app) + `flutter analyze` +
  code-level boot-path review. A real-phone test by the user is still owed
  for every build.

## Build

```sh
export PATH="$HOME/flutter/bin:$PATH"
export ANDROID_HOME=$HOME/workspace/hamsiq-android/tools/android-sdk
export JAVA_HOME=$HOME/workspace/tools/jdk-21.0.13+9
# REQUIRED — two separate JVM flags, both needed (found 2026-11-15 after
# hours of Gradle failures; do not remove either):
# 1. GRADLE_OPTS preferIPv4Stack: this VM resolves `localhost` to `::1`
#    first, but the Gradle daemon listens on IPv4 127.0.0.1 only — without
#    it every build dies in ~3 s with "Could not dispatch a message to the
#    daemon" / "Connection reset by peer".
# 2. JAVA_TOOL_OPTIONS (proxy + IPv4): systemProp.* and -D flags in
#    android/gradle.properties do NOT reach the daemon JVM in this
#    environment (verified with jinfo: the daemon has no http.proxyHost at
#    all, and a Gradle init script never loads) — so dependency downloads
#    connect directly and get reset by the egress firewall. The JVM picks
#    up JAVA_TOOL_OPTIONS itself at startup, which DOES put the proxy on
#    the daemon JVM. Keep it free of '|' characters in GRADLE_OPTS (gradlew
#    expands that unquoted and a pipe breaks the script); the '|' form is
#    fine inside JAVA_TOOL_OPTIONS and gradle.properties where no shell
#    parses it.
export GRADLE_OPTS="-Djava.net.preferIPv4Stack=true"
export JAVA_TOOL_OPTIONS="-Djava.net.preferIPv4Stack=true -Dhttp.proxyHost=127.0.0.1 -Dhttp.proxyPort=3129 -Dhttps.proxyHost=127.0.0.1 -Dhttps.proxyPort=3129 -Dhttp.nonProxyHosts=localhost -Dhttps.nonProxyHosts=localhost"
cd ~/workspace/hamsiq-native
flutter pub get
flutter analyze
flutter build apk --release
```

Signing: `android/keystore.properties` (generated, git-ignored) points at
the SAME release keystore as the Capacitor APK
(`~/workspace/hamsiq-android/hamsiq-release.keystore`, alias `hamsiq`);
passwords are read from `~/workspace/hamsiq-android/KEYSTORE_INFO.md`
and never printed anywhere. `apksigner verify` must exit 0.
Since 2026-11-16 (H-08b) a release build FAILS LOUDLY when
`android/keystore.properties` is missing (GradleException in
`android/app/build.gradle.kts`) instead of silently signing with the
debug key. Debug builds are unaffected.

## Theme (FINAL — user's orders, 2026-11-15)

- **True black + Instagram blue ONLY.** Background pure black #000000,
  cards/panels near-black (#0A0A0A / #111111), texts and icons white.
  The single accent colour is Instagram blue **#0095F6** (primary buttons,
  active icons, links, sent-message bubbles with #0064E0 as the second
  gradient stop). **Gold #D4AF37 and purple #A78BFA are REMOVED entirely**
  from the native app — including the gold + create button (now blue).
  No third colour. All of this lives in `lib/theme.dart`
  (`HamsiqTheme.accent`); there is no `gold`/`purple` constant left.
- **Font: Tajawal** (bundled in `assets/fonts/`, Regular 400 / Medium 500 /
  Bold 700 / ExtraBold 800, from google/fonts). Set as the app-wide
  `fontFamily` in the theme. No runtime font download.
- **Primary buttons** (login, next, OK, post, save, retry, follow):
  Instagram-blue background #0095F6, white text, Tajawal Bold 17px
  (via the global `elevatedButtonTheme` in `lib/theme.dart`).
  **Secondary buttons**: dark grey (#111111 panel2) filled with white
  text (camera/gallery pickers, the "أتابعه" following state) or
  transparent with white text (cancel). Destructive actions stay red
  (logout). Links stay Instagram blue.

## Release APK (v1.0.0 — BUILT 2026-11-15 09:01 UTC)

- File: `Hamsiq-native-1.0.apk` (60,173,774 bytes / 60.2 MB)
- SHA-256: `86a884aa0af80679b38ecfdac268ec49b05a9604674274652513c5c40ac03327`
- `apksigner verify` exits 0 (v2 scheme, 1 signer). Signer certificate
  SHA-256 `1db8a62a7724079f64e1cc8ffeaf3bea54bdae200fb8832df78d214f000ac578`
  — IDENTICAL to the Capacitor APK, i.e. the same release keystore
  (`hamsiq-release.keystore`, alias `hamsiq`); it installs as an update
  over the old APK.
- `aapt2 dump badging`: package `com.hamsiq.app`, versionCode 1,
  versionName 1.0.0, label "Hamsiq", compileSdk 36.
- Final checks on the shipped code: `flutter analyze` = 10 info notices
  only (0 errors, 0 warnings — all the same material.dart deprecation
  notice); `flutter test` = 4/4 passed (boots to login screen; auth form;
  signup tab + empty-submit rejection offline; forgot-password screen).
- Auth path verified live against the real Supabase project (no user
  credentials used): RPC `get_email_by_username('m')` → HTTP 200; auth
  token endpoint with a wrong password → 400 `invalid_credentials`.

## Release APK (v1.0.1 — BUILT 2026-11-15 09:56 UTC, versionCode 2)

- File: `Hamsiq-native-1.0.1.apk` (61,576,662 bytes / 61.6 MB)
- SHA-256: `a48cd536e04949bb72e842ab342e80eb8e5c23b9e4650be041fdd3211debbef0`
- `apksigner verify` exits 0 (same release keystore, signer cert
  `1db8a62a...` identical to v1.0.0). `aapt2 dump badging`: package
  `com.hamsiq.app`, versionCode 2, versionName 1.0.1.
- **Bug fix — forgot-password "invalid format" on a real phone:** the
  app sent the email with invisible characters (zero-width space etc.)
  that Dart's `trim()` does not strip; Supabase rejected it with
  `AuthApiException: Unable to validate email address: invalid format`
  even though the same email is valid (verified by curl against the live
  Auth endpoint, HTTP 200). Fix: new `cleanEmail()` strips ALL
  invisible/control chars (U+200B/C/D, U+FEFF, U+200E/F, U+00A0, U+2060,
  bidi controls, C0/C1 controls) then trims — applied in `_doForgot` /
  `_doSignup` AND inside `Api.signUp` / `Api.verifySignupOtp` /
  `Api.resetPassword`; client-side `isValidEmail()` check before calling
  the API; new `friendlyAuthError()` mapper — raw exception text is never
  shown anymore (invalid format → friendly Arabic, invalid credentials →
  "اسم المستخدم أو كلمة المرور غلط", network → "ماكو اتصال بالإنترنت...").
  Verified by a standalone Dart check (ZWSP case passes).
- **Official logo (user's order):** `assets/logo.png` (1024×1024, the new
  metallic-H logo; its white canvas corners were made transparent by
  flood-fill from the borders — original preserved in
  `assets/logo-official-original.jpg`). Launcher icons regenerated with
  `dart run flutter_launcher_icons` (black adaptive background); the new
  icon was visually confirmed inside the APK (192px legacy + 432px
  adaptive foreground both show the new H logo). The logo also shows at
  the top of the login screen (96×96, ClipRRect radius 24, above the
  "Hamsiq" wordmark). Colors unchanged (black + Instagram blue).
- Tests: `flutter analyze` = 10 info notices only (0 errors); `flutter
  test` = 4/4 passed (the signup test needed `ensureVisible` after the
  logo made the form taller than the 800×600 test viewport — real phones
  scroll, this is test-only).
- Delivered by replacing the content of the same Google Drive file
  (fileId `166pbLNLCriysHUlD8NSXu4a34LaT6Vjk`, renamed to
  `Hamsiq-native-1.0.1.apk`); the existing download link
  (`drive.usercontent.google.com/download?id=...&export=download&confirm=t`)
  was verified to serve the new APK byte-identically (SHA-256 match).

## Phase 1 (this build)

- Supabase init + session persistence
- Auth: username+password login (email via `get_email_by_username` RPC),
  signup (email+username+password, 8-digit OTP in-app), forgot password
  (reset link by email, opened in the browser, then login in-app)
- Main shell: bottom nav Home / Discover / + Create / Reels / Profile
- Home feed: real posts (latest first), real likes
- Chats: real DM list + thread view (text, polling every 4 s), bottom nav
  hidden inside a thread (full-screen route)
- Profile: real stats + posts grid, edit (name/bio/photo via native
  camera/gallery -> chat-media bucket), follow/unfollow, logout
- Create: text + photo (native camera via image_picker — the key fix
  vs the wrapper, whose WebView never got camera permission)
- Discover: user search + latest post photos grid
- Reels: vertical video player (video_player)

## Phase 2 (status 2026-11-16 — built except the blocked items)

- BUILT in v1.1.0: stories, groups, polls, real comments/likes, full
  Settings, complete DMs, in-app camera. (The old "not built yet" note
  for these was stale — corrected 2026-11-16, H-08.)
- STILL BLOCKED (never faked): voice/video calls (no verified free
  TURN; needs his Cloudflare account), licensed music library, admin dashboard.
- Push notifications: the native FCM client is BUILT and verified in a
  release APK (see "Push notifications" below) — the end-to-end send
  test is still blocked on the staging service-account secret (parent
  browser step, not a build step).

## Push notifications (native FCM client — code-complete 2026-11-16, NOT live yet)

- Firebase project **"Hamsiq" (hamsiq-ab146)** exists. What is WIRED
  in this repo: `firebase_core` 4.15.2, `firebase_messaging` 16.7.1,
  `flutter_local_notifications` 19.5.0, `app_settings` 9.0.1
  (`pubspec.yaml` / `pubspec.lock`); `lib/services/push_service.dart`
  (PushService + payload/route/composition + test seams);
  `lib/services/push_navigation.dart` (tap routing); init wired in
  `lib/main.dart` after `Supabase.initialize` + `AccountStore.init()`
  (navigator key on the MaterialApp); token re-registration on home
  mount (login / account switch / Google-setup completion);
  `POST_NOTIFICATIONS` in `AndroidManifest.xml`; the permission
  rationale (once after login) + Settings push row (re-request, or
  opens the system notification-settings page when permanently
  denied); `public.device_tokens` upsert (user_id, token,
  platform='android', updated_at), token refresh, delete on sign-out;
  foreground suppression for the thread already on screen; background
  handler + tap routing (DM by peer id, group by group id, call invite
  → caller's DM thread until a real call screen exists).
- google-services.json IS WIRED (2026-11-16): `android/app/google-services.json`
  (project hamsiq-ab146, number 121201015088, app ID
  `1:121201015088:android:50ef82e15fc0d89b9130f5`, package
  `com.hamsiq.app` — verified against the file); the google-services
  Gradle plugin 4.4.4 is applied (`android/settings.gradle.kts` +
  `android/app/build.gradle.kts`). The plugin ran in the release
  build: generated values contain google_app_id / project_id
  (hamsiq-ab146) / gcm_defaultSenderId, and the merged manifest
  registers FirebaseInitProvider, FirebaseMessagingService and
  FirebaseInstanceIdReceiver; the APK dex contains FirebaseMessaging
  (26 refs in classes5.dex). No google-services plugin errors.
- VERIFICATION-ONLY release build (2026-11-16 ~14:35, NOT delivered,
  NOT uploaded): `flutter build apk --release` exit 0 (Gradle 551.5s),
  `build/app/outputs/flutter-apk/app-release.apk`, 72,381,694 bytes,
  SHA-256 `d415a344574b97d1cf8cee743d75a452d4ec740cf64b5242774b537124e46e6a`,
  `apksigner verify` exit 0 (v2 scheme, 1 signer), signer cert SHA-256
  `1db8a62a7724079f64e1cc8ffeaf3bea54bdae200fb8832df78d214f000ac578` —
  IDENTICAL to the v1.2.2 release key. aapt2: package `com.hamsiq.app`,
  versionCode 6, versionName 1.2.2. No WebView widget/dependency in the
  app (the two "WebView" matches in lib are comments); one
  `Landroid/webkit/WebView;` type reference sits in classes.dex from
  a transitive library, not from any Flutter plugin jar.
- Build fixes needed along the way (2026-11-16, all in-repo now):
  1. The egress CA had rotated again (file 42:5F:E8:09… vs keystore
     59:32:1A:E7…) — re-imported into the Temurin cacerts; the local
     proxy on 127.0.0.1:3129 had died with the VM and was restarted.
  2. `app_settings` 6.1.1 failed the build twice: it hardcodes
     compileSdk 33 (its androidx deps demand 34+) AND requires SDK
     Platform 33, which was not installed. Fixed by (a) installing
     platform-33 manually (see "Platform 33" note below) and (b)
     upgrading to `app_settings` 9.0.1 (compileSdk 36, same
     `openAppSettings(type:)` API).
  3. `flutter_local_notifications` needs core library desugaring:
     `isCoreLibraryDesugaringEnabled = true` +
     `coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")`
     in `android/app/build.gradle.kts`.
  (Earlier failed builds: 25m44s platform-33 missing; 7m12s
  desugaring; 12m35s app_settings AAR metadata.)
- Data-payload contract (data-only FCM, NO `notification` payload
  server-side): `type` ('message'|'call_invite'), `sender_id`,
  `sender_name`, `chat_type` ('dm'|'group'), `thread_peer_id` (dm),
  `group_id` (group), `message_id`, `preview` (nullable),
  `message_kind` ('text'|'image'|'voice'|'video'|'file'|...),
  `call_id` (call_invite). The client composes title/body from these
  + its own locale. The token value is never logged.
- What STILL needs doing before push works end-to-end:
  1. Create the `public.device_tokens` table (server worker owns it):
     `user_id uuid`, `token text`, `platform text`,
     `updated_at timestamptz` — the client upserts on the
     `(user_id, token)` primary key and deletes by `token` on sign-out
     (RLS: users may only read/write their own rows).
  2. STAGING SEND TEST — BLOCKED on a parent browser step: the
     `FIREBASE_SERVICE_ACCOUNT_JSON` secret does NOT exist on staging
     (secrets list has only PUSH_TRIGGER_SECRET + the auto-provided
     keys). A Firebase service account must be created in the Firebase
     console and its JSON stored as that secret before any send test.
  3. Real-phone test: install the verified APK, login → permission
     rationale appears once → allow → Settings push row shows
     "enabled" → send a data-only test message from the server worker
     → notification arrives with the sender's name; tap opens the
     right thread; no banner while the thread is already open; sign
     out → the token row is gone.
  4. Flip `notifHint` in `lib/services/app_strings.dart` (it still
     says push does not exist in this version) when the push APK
     ships — not before, this build was verification-only.
- Until the APK ships, the app degrades silently without the json:
  `Firebase.initializeApp()` throws, `PushService.init()` catches it,
  the Settings row shows "not available in this build yet", and the
  app behaves exactly as before (in-app notifications only).
- Tests: `test/push_service_test.dart` (46 tests, fakes only — no real
  FCM): payload contract, permission granted/denied/never-ask-again,
  token upsert/refresh/sign-out delete, foreground suppression,
  background composition per kind, tap routing, init failure → app
  still boots, rationale dialog, ar+en keys.
  Checks at delivery: `flutter analyze` 0 errors / 0 warnings;
  `flutter test` 370/370 passed (final run 2026-11-16 ~14:40, after
  the app_settings 9.0.1 upgrade; the 2 profile_header_redesign
  failures seen in the earlier run were fixed by the concurrent
  redesign work, not by this task).

## Quality bar (user's words, 2026-11-15)

"اتعب عليه تعب قوي اريد يطلع نتيجة مثل الشركات العالمية ماريد شيء
فاشل فقط انتضار... اذا متكدر كلي لتخليني انتضر" — do NOT report the APK
as ready with known defects; `flutter analyze` clean, release build
succeeds, boot verified as far as technically possible, login exercised
against the real Supabase project if any test path exists. If a blocker
cannot be solved, STOP and report it honestly — never deliver a broken
APK hoping he will not notice.

## Known notes

- `flutter analyze` reports 10 info-level `deprecated_member_use` notices:
  `package:flutter/material.dart` is deprecated in favour of
  `package:material_ui/material_ui.dart` — but that package does NOT exist
  in this SDK, so the imports stay as they are. The app compiles fine.
  (The 4 `use_build_context_synchronously` infos from the edit-profile
  dialog were fixed 2026-11-15: dialog-context uses are guarded by
  `dialogCtx.mounted`, State-context uses by `mounted`.)
- Gradle daemon: this VM resolves `localhost` to `::1` FIRST (see
  /etc/hosts), but the Gradle daemon listens on IPv4 127.0.0.1 only, so
  the launcher JVM must run with
  `GRADLE_OPTS="-Djava.net.preferIPv4Stack=true"` or every build dies in
  ~3 s with "Could not dispatch a message to the daemon". The daemon
  itself already gets the flag via `org.gradle.jvmargs`. Plain localhost
  TCP between processes works fine (verified with a Python socket test) —
  it is purely the IPv6-first localhost resolution.
- Gradle proxy: `systemProp.*` and `-D` flags in `android/gradle.properties`
  do NOT reach the daemon JVM here (verified with `jinfo`: no
  `http.proxyHost` on the daemon; a `~/.gradle/init.d` init script never
  loads either). Without the proxy, dependency downloads connect directly
  and get "Connection reset" from the egress firewall (direct egress is
  blocked; curl without the proxy returns 000). The working mechanism is
  `JAVA_TOOL_OPTIONS` (see Build section) — the JVM applies it at startup.
  The proxy itself is the local forwarder on 127.0.0.1:3129. AGP note: the
  main app uses AGP 9.3.1 (cached) but the `app_links` plugin's buildscript
  requires AGP 9.2.1 — that download is what fails first when the proxy
  is missing.
- Build-tools: the SDK must contain BOTH 36.1.0 (main app, AGP 9.3.1) AND
  36.0.0 (the `app_links` plugin, AGP 9.2.1). 36.0.0 was installed manually
  2026-11-15: `build-tools_r36_linux.zip` (63,737,259 bytes, sha1
  `b0b6376977657e8ad9b969bacf4093601da2c6fb` from repository2-1.xml) unzipped
  into `$ANDROID_HOME/build-tools/36.0.0/` — note the zip nests everything
  under an `android-16/` folder; move its contents up one level so the
  tools sit directly in `36.0.0/` (same layout as 34.0.0). If Gradle ever
  complains a build-tools version is missing / licences not accepted,
  install that exact version by hand the same way (sdkmanager cannot fetch
  the manifest through the proxy).
- Platform 33 (installed manually 2026-11-16, same pattern): the
  `app_settings` 6.1.1 plugin compiled against android-33, so the first
  Firebase release build failed with "platforms;android-33 ... licences
  have not been accepted" (the SDK only had 34/35/36). Fix:
  `platform-33-ext3_r03.zip` (67,334,237 bytes, sha1
  `394bc86d8d3452aa4d419b67743025a6fb2cd9d0` from repository2-1.xml,
  downloaded with curl through the proxy into `~/workspace/tmp/`)
  unzipped into `$ANDROID_HOME/platforms/android-33/` — the zip nests
  everything under an `android-13/` folder; move its contents up one
  level (android.jar + source.properties directly in `android-33/`,
  Pkg.Revision=3, ApiLevel=33). Licences were already accepted
  (`licenses/android-sdk-license` existed). The plugin was then
  upgraded to `app_settings` 9.0.1 (compileSdk 36) anyway, but
  platform-33 stays installed: any future plugin compiled against 33
  needs it.
- CMake: the `:jni` native step needs CMake 3.22.1, installed manually
  2026-11-15: `cmake-3.22.1-linux.zip` (22,308,647 bytes, sha1
  `fd0a48b4a758310df8c7aa51f59840ed48fe7ed8`) unzipped into
  `$ANDROID_HOME/cmake/3.22.1/` (bin/doc/share at the top level, no
  nesting). `cmake --version` → 3.22.1.
- Supabase auth path verified live (2026-11-15, no user credentials used):
  RPC `get_email_by_username('m')` returns HTTP 200 with the account email;
  the auth token endpoint returns 400 `invalid_credentials` for a wrong
  password — both prove the client reaches the real project. A full login
  with a real account is untested (no test-account password exists in the
  project files); a real-phone test by the user is still owed.

## v1.2.0 (built 2026-11-15 — superseded by 1.2.2)

- User order 2026-11-15 17:48: delete the clutter, rebuild Settings + features from scratch, Instagram features only. Direction change 17:50: NO intermediate versions — one final APK only.
- Step 1 (Agent A): audit found Restrict/تقييد does NOT exist in the native app (his example came from the web app); no block/report either. Deleted: Settings account-info dialog, read-receipts/typing/online toggles, whole Sessions & devices section, web-app link row, red sign-out button from profile body. Profile actions now exactly Follow/Unfollow + Message + Share (other) / Edit + Settings gear (own).
- Step 2 (Agent A): Settings rebuilt from zero — Account (edit profile, change password), Privacy (is_private, dm_privacy, comment_privacy, mention_privacy), Notifications (4 in-app-only toggles, honestly labelled), Language, About 1.2.0, Logout with confirm. Every control on a real column.
- Wave 1 (Agent B): share post/Reel into DM, comment + message-bell notifications, real story_views table, story replies as DMs, pinned/threaded comments + curated-GIF picker (GIF *search* blocked: Tenor keyless 403, Giphy needs a key), Collections, Reposts tab, pinned posts (max 3), grid reorder. SQL: sql-v29.sql.
- Wave 2 (Agent C): vanish mode, view-once, unsend, chat themes, drafts, scheduled posts (app-open only), Close Friends, Favourites feed, mute/snooze, profile QR (qr_flutter 4.1.0), Insights (labelled estimates), hide-likes/comments-off/alt-text, in-thread translate (MyMemory). SQL: sql-v30.sql. Honest limits: Close Friends client-side only; view-once wipes the row URL, not the storage object.
- Wave 3 (Agent D): Reels editor (text overlays, voiceover, 3 templates), Collab posts (max 5, RPCs), broadcast channels, Blend. SQL: sql-v31.sql. Coordinator wired co-authored posts into the profile grid as a 4th "تعاون" tab.
- BLOCKED (never faked): voice/video calls (no verified free TURN; needs his Cloudflare account), closed-app push (needs Firebase + his Google account), licensed music library, shopping/payments, IG Live (RTMP infra), Meta AI, Threads/Facebook cross-post, Teen/Family Center.
- BEFORE the APK is built/published: run sql-v29.sql, sql-v30.sql, sql-v31.sql IN ORDER in the Supabase SQL Editor (browser task) and verify with the SELECTs at the end of each file. Then build + verify + replace the Drive file (same link).
- Release build DONE 2026-11-15 ~15:44 (1185s; first attempt failed on a rotated egress CA — re-imported C7:D4:E2:99… into the Temurin cacerts; also the first command missed JAVA_HOME and fell back to the system JDK). APK verified: Hamsiq-native-1.2.0.apk, 69,271,615 bytes, SHA-256 1614cae08e294d683037df978ba85d670a21aedc88bca978bebdd39e6b3253d7, aapt2 com.hamsiq.app versionCode 4 versionName 1.2.0, apksigner exit 0 (v2 true), signer cert identical to 1.1.0, libflutter.so + libapp.so present, 0 webview mentions. Superseded: the same Drive link now serves 1.2.2.
- Verification at code-complete: flutter analyze 0 errors / 0 warnings; flutter test 66/66 passed.

## Release APK (v1.2.1 — DELIVERED 2026-11-16 01:17, versionCode 5)

- Comments as an Instagram-style bottom sheet (opens over the post, no
  navigation into the post detail screen); cleaned-up profile; Edit as
  two compact buttons; login-screen RTL fixed.
- Delivered by replacing the content of the same Google Drive file
  (fileId `166pbLNLCriysHUlD8NSXu4a34LaT6Vjk`).

## Release APK (v1.2.2 — DELIVERED 2026-11-16 ~09:42, versionCode 6)

- File: `Hamsiq-native-1.2.2.apk` (70,697,277 bytes / 70.7 MB)
- SHA-256: `11014f432731175e02e7430c246c3d95aea6cdfaae52b6a6b95bb08de131af91`
- Delivered by replacing the content of the same Google Drive file
  (fileId `166pbLNLCriysHUlD8NSXu4a34LaT6Vjk`, renamed to
  `Hamsiq-native-1.2.2.apk`); web preview updated to 1.2.2.
- Fixes from the user's 09:00–09:02 feedback on the 1.2.1 preview:
  (1) Edit/Share button text rendering oversized on his iPhone — fixed
  with TextScaler.noScaling on the button labels; (2) Instagram-exact
  account switcher — own-profile username shows a small down-chevron,
  tapping opens a bottom sheet with saved accounts + "+ إضافة حساب",
  max 5 accounts, Add account opens login with a back button that
  returns to the current account's home WITHOUT logging out;
  (3) profile settings gear replaced by a hamburger (☰) icon.
- Checks at delivery: `flutter analyze` 0 errors / 0 warnings;
  `flutter test` 87/87 passed.
- Source + Supabase schema for 1.2.2 were handed to him the same day
  (`~/workspace/your_files/hamsiq-1.2.2-source.zip`,
  `~/workspace/your_files/hamsiq-supabase-schema-v4-v31.sql`).
- Audit fixes H-01–H-08 (2026-11-16) are saved as source + migrations
  only — NO new APK is built from them until all 8 are done, per his
  order (fix everything, save only, then continue development toward
  one final update).
