-- sql-v36.sql — Hamsiq audit fix H-01 (critical: email disclosure)
-- Run in the Supabase SQL Editor AFTER sql-v31.sql. Idempotent: safe to
-- run twice. Run this BEFORE deploying the secure-login Edge Function
-- (supabase/functions/secure-login/index.ts), which reads/writes this table.
--
-- Background (verified from sql-v10 in the v4..v31 schema dump):
--   get_email_by_username(p_username text) is SECURITY DEFINER, returns
--   u.email from auth.users, and is granted EXECUTE to anon AND
--   authenticated — anyone who knows a username gets the email without
--   logging in. The Flutter login screen used to call it, then sign in
--   with the returned email client-side.
--
-- The fix moves the whole login server-side into the secure-login Edge
-- Function: it resolves username -> id via public.profiles with the
-- service-role client, fetches the email with auth.admin.getUserById(),
-- signs in server-side, and returns ONLY the session tokens + {id,
-- username} to the client. The email never leaves the server.
--
-- New in this file:
--   1) public.login_attempts — audit log + rate-limit store for the
--      secure-login function. Columns:
--        id           bigint identity, primary key
--        username     text, normalized (trimmed, lowercased) by the caller
--        ip           text, client IP from x-forwarded-for (or 'unknown')
--        success      boolean, default false
--        attempted_at timestamptz, default now()
--      NOTE: the task brief listed username / ip / attempted_at. `success`
--      is added deliberately: the rate limit counts FAILED attempts only.
--      Without it, 5 legitimate successful logins in 15 minutes would
--      lock the account out — the limit must not punish real logins.
--      `id` is the primary key the count queries need for head:true.
--   2) Indexes on (username, attempted_at) and (ip, attempted_at) for the
--      two rate-limit lookups (5 failures / username / 15 min, 10 failures
--      / IP / 15 min — thresholds must match the Edge Function and
--      lib/services/secure_login.dart).
--   3) RLS ENABLED with deliberately NO policies: only the service-role
--      client (which bypasses RLS) may read/write this table — the Edge
--      Function. anon and authenticated get NOTHING, so login-attempt
--      history (usernames + IPs) can never be read from the client.
--
-- This migration does NOT drop or alter get_email_by_username(). The old
-- RPC stays in the database untouched until the new flow is proven in
-- staging; only then is it revoked/dropped (separate step, separate
-- approval). The Flutter login screen no longer calls it.

create table if not exists public.login_attempts (
  id bigint generated always as identity primary key,
  username text not null,
  ip text not null default 'unknown',
  success boolean not null default false,
  attempted_at timestamptz not null default now()
);

create index if not exists login_attempts_username_idx
  on public.login_attempts (username, attempted_at desc);

create index if not exists login_attempts_ip_idx
  on public.login_attempts (ip, attempted_at desc);

alter table public.login_attempts enable row level security;

-- No policies on purpose: service_role bypasses RLS and is the only
-- reader/writer (the secure-login Edge Function). anon/authenticated
-- must never read login-attempt history.

-- Optional housekeeping (run manually or via pg_cron, NOT automatically):
-- old rows are only needed for the 15-minute window; prune anything
-- older than 24h so the table does not grow forever:
--   delete from public.login_attempts
--    where attempted_at < now() - interval '24 hours';

-- ============ verification (run after the above) ============
-- select table_name from information_schema.tables
--  where table_schema = 'public' and table_name = 'login_attempts';
-- select column_name, data_type, column_default
--   from information_schema.columns
--  where table_schema = 'public' and table_name = 'login_attempts'
--  order by ordinal_position;
-- select indexname from pg_indexes
--  where schemaname = 'public' and tablename = 'login_attempts';
-- -- RLS on, zero policies (service_role only):
-- select relname, relrowsecurity from pg_class
--  where relname = 'login_attempts';
-- select tablename, policyname from pg_policies
--  where schemaname = 'public' and tablename = 'login_attempts';
-- -- Old RPC untouched (still exists, still granted — removal is a
-- -- separate step after staging proves the new flow):
-- select proname, prosecdef from pg_proc
--  where pronamespace = 'public'::regnamespace
--    and proname = 'get_email_by_username';
-- select grantee from information_schema.routine_privileges
--  where routine_schema = 'public'
--    and routine_name = 'get_email_by_username';
