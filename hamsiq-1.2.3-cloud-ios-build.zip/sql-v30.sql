-- sql-v30.sql — Hamsiq native v1.2.0 Wave 2 (Instagram features)
-- Run in the Supabase SQL Editor AFTER sql-v29.sql. Idempotent: safe to
-- run twice. The native app (~/workspace/hamsiq-native) reads/writes
-- every object below; run this BEFORE building the v1.2.0 APK.
--
-- New in this file:
--   1) messages.view_once / viewed_once / vanish (booleans) + three
--      SECURITY DEFINER functions: unsend_message, mark_view_once_seen,
--      purge_vanish_messages. Deletes go through functions because
--      there is no client-safe messages DELETE policy.
--   2) vanish_chats — my per-chat vanish toggle (same shape as
--      muted_chats / archived_chats, sql-v14).
--   3) chat_themes — my per-chat accent colour (user_id, peer_id, color).
--   4) close_friends — my Close Friends list (people I follow).
--   5) stories.is_close_friends — Close Friends stories (green ring).
--   6) favourites — my favourite accounts (Favourites feed filter).
--   7) muted_accounts — mute / snooze an account (snooze_until null =
--      indefinite mute; a future timestamp = snoozed until then).
--   8) post_drafts + scheduled_posts — drafts and scheduled posts.
--      Scheduled posts publish ONLY while the app is open (the app
--      checks for due posts on feed load); there is no server cron.
--   9) posts.hide_like_count / comments_disabled / alt_text — per-post
--      options (the v29 owner UPDATE policy already allows the owner
--      to write them; no new posts policy is needed).
--  10) Insights needs NOTHING new: it reads posts / post_likes /
--      follows / stories / story_views, which already exist.
--
-- RLS HARD RULES (learned 2026-11-14, 42P17): no policy whose qual or
-- with_check queries its OWN table. Policies below use auth.uid() and
-- the SECURITY DEFINER helpers public.is_approved() / public.is_admin()
-- (they query profiles bypassing RLS), or subqueries on DIFFERENT
-- tables only. Every table a policy references is created BEFORE the
-- policy. New columns are added BEFORE any function that uses them.
--
-- Honest limits (also shown in the app UI):
--   * Vanish mode / view-once do NOT prevent screenshots or copies
--     made outside the app.
--   * Close Friends visibility is enforced client-side in the app;
--     the stories table's existing select policy (is_approved()) still
--     allows an API-level read. Tightening that policy is a separate
--     server change, not done here.
--   * A view-once message's media URL is wiped from the row when first
--     opened; the storage object itself is not deleted by the function.

-- ============ 1) messages: view-once + vanish columns ============
alter table public.messages
  add column if not exists view_once boolean not null default false;
alter table public.messages
  add column if not exists viewed_once boolean not null default false;
alter table public.messages
  add column if not exists vanish boolean not null default false;
create index if not exists idx_messages_vanish on public.messages(vanish, read);

-- Unsend: delete one of MY messages for everyone. Only the sender may
-- call it (sender_id = auth.uid()), enforced inside the function so no
-- messages DELETE policy is needed at all.
create or replace function public.unsend_message(p_message_id bigint)
returns void language plpgsql security definer as $$
declare
  v_me uuid := auth.uid();
  v_sender uuid;
begin
  if v_me is null then raise exception 'not authenticated'; end if;
  select m.sender_id into v_sender from public.messages m where m.id = p_message_id;
  if v_sender is null then raise exception 'no such message'; end if;
  if v_sender <> v_me then raise exception 'only the sender can unsend'; end if;
  delete from public.messages where id = p_message_id;
end;
$$;
grant execute on function public.unsend_message(bigint) to authenticated;

-- View-once seen: only the RECEIVER may mark it, only once, and only
-- for a real view-once image/video. Wipes the media URL from the row
-- so the message renders as expired for everyone afterwards.
create or replace function public.mark_view_once_seen(p_message_id bigint)
returns void language plpgsql security definer as $$
declare
  v_me uuid := auth.uid();
  v_row record;
begin
  if v_me is null then raise exception 'not authenticated'; end if;
  select m.receiver_id, m.message_type, m.view_once, m.viewed_once
    into v_row from public.messages m where m.id = p_message_id;
  if v_row.receiver_id is null then raise exception 'no such message'; end if;
  if v_row.receiver_id <> v_me then raise exception 'only the receiver can open a view-once message'; end if;
  if not v_row.view_once then raise exception 'not a view-once message'; end if;
  if v_row.viewed_once then return; end if;
  if v_row.message_type not in ('image', 'video') then raise exception 'view-once applies to photos and videos only'; end if;
  update public.messages set viewed_once = true, media_url = null where id = p_message_id;
end;
$$;
grant execute on function public.mark_view_once_seen(bigint) to authenticated;

-- Vanish purge: delete the vanish messages in my thread with p_peer_id
-- that have already been read (both directions). Called by the app
-- when leaving a vanish thread. No messages DELETE policy is needed.
create or replace function public.purge_vanish_messages(p_peer_id uuid)
returns void language plpgsql security definer as $$
declare
  v_me uuid := auth.uid();
begin
  if v_me is null then raise exception 'not authenticated'; end if;
  delete from public.messages m
    where m.vanish = true and m.read = true
      and ((m.sender_id = v_me and m.receiver_id = p_peer_id)
        or (m.sender_id = p_peer_id and m.receiver_id = v_me));
end;
$$;
grant execute on function public.purge_vanish_messages(uuid) to authenticated;

-- ============ 2) vanish_chats (my per-chat vanish toggle) ============
create table if not exists public.vanish_chats (
  user_id uuid not null references public.profiles(id) on delete cascade,
  chat_kind text not null default 'dm',
  chat_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, chat_kind, chat_id)
);
alter table public.vanish_chats enable row level security;

drop policy if exists "vanish_chats_owner" on public.vanish_chats;
create policy "vanish_chats_owner" on public.vanish_chats for all using (
  auth.uid() = user_id
) with check (
  auth.uid() = user_id
);

-- ============ 3) chat_themes (my per-chat accent colour) ============
create table if not exists public.chat_themes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  peer_id uuid not null references public.profiles(id) on delete cascade,
  color bigint not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, peer_id)
);
alter table public.chat_themes enable row level security;

drop policy if exists "chat_themes_owner" on public.chat_themes;
create policy "chat_themes_owner" on public.chat_themes for all using (
  auth.uid() = user_id
) with check (
  auth.uid() = user_id
);

-- ============ 4) close_friends (my Close Friends list) ============
create table if not exists public.close_friends (
  user_id uuid not null references public.profiles(id) on delete cascade,
  friend_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, friend_id)
);
create index if not exists idx_close_friends_friend on public.close_friends(friend_id);
alter table public.close_friends enable row level security;

-- Select: the owner, or the friend named on the row (so the story bar
-- can check "am I on this owner's list?"). No self-table subquery.
drop policy if exists "close_friends_select" on public.close_friends;
create policy "close_friends_select" on public.close_friends for select using (
  auth.uid() = user_id or auth.uid() = friend_id
);
drop policy if exists "close_friends_write" on public.close_friends;
create policy "close_friends_write" on public.close_friends for all using (
  auth.uid() = user_id
) with check (
  auth.uid() = user_id
);

-- ============ 5) stories.is_close_friends ============
alter table public.stories
  add column if not exists is_close_friends boolean not null default false;
create index if not exists idx_stories_close_friends on public.stories(user_id, is_close_friends);

-- ============ 6) favourites (my favourite accounts) ============
create table if not exists public.favourites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  favourite_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, favourite_id)
);
alter table public.favourites enable row level security;

drop policy if exists "favourites_owner" on public.favourites;
create policy "favourites_owner" on public.favourites for all using (
  auth.uid() = user_id
) with check (
  auth.uid() = user_id
);

-- ============ 7) muted_accounts (mute / snooze) ============
create table if not exists public.muted_accounts (
  user_id uuid not null references public.profiles(id) on delete cascade,
  muted_id uuid not null references public.profiles(id) on delete cascade,
  snooze_until timestamptz,
  created_at timestamptz not null default now(),
  primary key (user_id, muted_id)
);
alter table public.muted_accounts enable row level security;

drop policy if exists "muted_accounts_owner" on public.muted_accounts;
create policy "muted_accounts_owner" on public.muted_accounts for all using (
  auth.uid() = user_id
) with check (
  auth.uid() = user_id
);

-- ============ 8) post_drafts + scheduled_posts ============
create table if not exists public.post_drafts (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  caption text not null default '',
  media_url text,
  media_type text not null default 'image',
  is_reel boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_post_drafts_user on public.post_drafts(user_id);
alter table public.post_drafts enable row level security;

drop policy if exists "post_drafts_owner" on public.post_drafts;
create policy "post_drafts_owner" on public.post_drafts for all using (
  auth.uid() = user_id
) with check (
  auth.uid() = user_id
);

create table if not exists public.scheduled_posts (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  caption text not null default '',
  media_url text,
  media_type text not null default 'image',
  is_reel boolean not null default false,
  publish_at timestamptz not null,
  published boolean not null default false,
  published_post_id bigint references public.posts(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists idx_scheduled_posts_due on public.scheduled_posts(user_id, publish_at, published);
alter table public.scheduled_posts enable row level security;

drop policy if exists "scheduled_posts_owner" on public.scheduled_posts;
create policy "scheduled_posts_owner" on public.scheduled_posts for all using (
  auth.uid() = user_id
) with check (
  auth.uid() = user_id
);

-- ============ 9) posts: per-post options ============
alter table public.posts
  add column if not exists hide_like_count boolean not null default false;
alter table public.posts
  add column if not exists comments_disabled boolean not null default false;
alter table public.posts
  add column if not exists alt_text text;
-- No new posts policy: the v29 owner UPDATE policy ("owners update
-- own posts") already lets the owner write these columns.

-- ============ 10) realtime for the new tables ============
do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'vanish_chats') then
    execute 'alter publication supabase_realtime add table public.vanish_chats';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'chat_themes') then
    execute 'alter publication supabase_realtime add table public.chat_themes';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'close_friends') then
    execute 'alter publication supabase_realtime add table public.close_friends';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'favourites') then
    execute 'alter publication supabase_realtime add table public.favourites';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'muted_accounts') then
    execute 'alter publication supabase_realtime add table public.muted_accounts';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'post_drafts') then
    execute 'alter publication supabase_realtime add table public.post_drafts';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'scheduled_posts') then
    execute 'alter publication supabase_realtime add table public.scheduled_posts';
  end if;
end $$;

-- ============ verification (run after the above) ============
-- select table_name from information_schema.tables where table_schema='public'
--   and table_name in ('vanish_chats','chat_themes','close_friends','favourites',
--     'muted_accounts','post_drafts','scheduled_posts');
-- select column_name from information_schema.columns where table_schema='public'
--   and ((table_name='messages' and column_name in ('view_once','viewed_once','vanish'))
--     or (table_name='stories' and column_name='is_close_friends')
--     or (table_name='posts' and column_name in ('hide_like_count','comments_disabled','alt_text')));
-- select tablename, policyname from pg_policies where schemaname='public'
--   and tablename in ('vanish_chats','chat_themes','close_friends','favourites',
--     'muted_accounts','post_drafts','scheduled_posts')
--   order by tablename, policyname;
-- select proname from pg_proc where pronamespace='public'::regnamespace
--   and proname in ('unsend_message','mark_view_once_seen','purge_vanish_messages');
