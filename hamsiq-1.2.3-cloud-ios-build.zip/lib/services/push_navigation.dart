// Hamsiq native — tap navigation for push notifications.
//
// Lives apart from push_service.dart on purpose: the screens import
// push_service.dart (for the active-thread tracker), so if the service
// itself imported the screens there would be an import cycle. This
// file imports both sides and is wired in main.dart:
//   PushService.instance.navigator = AppPushNavigator();
//
// Routing follows the data-payload contract (see push_service.dart):
// DM -> the peer's thread, group -> the group thread, call_invite ->
// the caller's DM thread until the calls workstream ships a real
// incoming-call screen (calls are still blocked on Cloudflare TURN).
// Every lookup is best-effort: a missing profile/group just drops the
// tap instead of crashing or opening a broken screen.

import 'package:flutter/material.dart';

import '../screens/chats_screen.dart';
import '../screens/groups_screen.dart';
import 'groups_api.dart';
import 'push_service.dart';
import 'supabase_service.dart';

class AppPushNavigator implements PushNavigator {
  @override
  Future<void> openRoute(PushRoute route) async {
    final nav = PushService.navigatorKey.currentState;
    if (nav == null) return;
    try {
      switch (route.kind) {
        case 'dm':
          final peerId = route.peerId;
          if (peerId == null) return;
          final peer = await Api.fetchProfile(peerId);
          if (peer == null) return;
          await nav.push(
            MaterialPageRoute(builder: (_) => ThreadScreen(peer: peer)),
          );
        case 'group':
          final groupId = route.groupId;
          if (groupId == null) return;
          final groups = await GroupsApi.fetchMyGroups();
          GroupInfo? group;
          for (final g in groups) {
            if (g.id == groupId) {
              group = g;
              break;
            }
          }
          if (group == null) return;
          await nav.push(
            MaterialPageRoute(
              builder: (_) => GroupThreadScreen(group: group!),
            ),
          );
        case 'call':
          // No incoming-call screen exists yet — open the caller's DM
          // thread so the user lands on the conversation, or the chats
          // list when the sender is unknown.
          final senderId = route.senderId;
          if (senderId == null) {
            await nav.push(
              MaterialPageRoute(builder: (_) => const ChatsScreen()),
            );
            return;
          }
          final peer = await Api.fetchProfile(senderId);
          if (peer == null) return;
          await nav.push(
            MaterialPageRoute(builder: (_) => ThreadScreen(peer: peer)),
          );
      }
    } catch (_) {
      // A tap must never crash the app.
    }
  }
}
