// Hamsiq native — push notifications (native FCM client).
//
// Wired 2026-11-16 against Firebase project "Hamsiq" (hamsiq-ab146).
// STATUS: code-complete, NOT yet live — google-services.json has NOT
// been wired (no google-services Gradle plugin, no json file). Until
// the coordinator wires it, Firebase.initializeApp() throws at startup,
// init() catches it, and the app behaves exactly as before (in-app
// notifications only). Nothing here ever throws out of init(): a
// missing/broken Firebase setup degrades silently, never a crash and
// never a blocked login or home screen.
//
// DATA PAYLOAD CONTRACT (must match the server worker exactly —
// data-only FCM messages, NO `notification` payload server-side):
//   type           'message' | 'call_invite'
//   sender_id      auth user id of the sender
//   sender_name    display name (used as the notification title)
//   chat_type      'dm' | 'group'
//   thread_peer_id DM peer user id (dm only)
//   group_id       group id (group only)
//   message_id     message row id (used as the notification id seed)
//   preview        text preview, nullable (text messages)
//   message_kind   'text' | 'image' | 'voice' | 'video' | 'file' | ...
//   call_id        call id (call_invite only)
// The CLIENT composes title/body from these + its own locale. The FCM
// token value is NEVER logged.
//
// Test seams follow the google_auth.dart pattern: every platform call
// goes through an injectable backend (PushMessagingBackend,
// PushLocalNotifications, DeviceTokenStore, PushNavigator,
// PushSettingsOpener, PushAskedStore) so test/push_service_test.dart
// runs with fakes and never touches real FCM.

import 'dart:async';
import 'dart:convert';

import 'package:app_settings/app_settings.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../theme.dart';
import 'app_strings.dart';
import 'supabase_service.dart';

/// Local-notification channel id for messages + call invites.
const String pushChannelId = 'hamsiq_messages';

/// SharedPreferences key: the post-login rationale has been shown once.
const String pushAskedPrefsKey = 'hamsiq_push_asked';

// ---------------------------------------------------------------------------
// Payload + route (pure, unit-testable)
// ---------------------------------------------------------------------------

/// The data-only FCM payload, parsed defensively: FCM delivers every
/// data value as a string, but toString() keeps us safe if a value
/// ever arrives as a number.
class PushPayload {
  final String type; // 'message' | 'call_invite'
  final String? senderId;
  final String senderName;
  final String chatType; // 'dm' | 'group'
  final String? threadPeerId;
  final int? groupId;
  final String? messageId;
  final String? preview;
  final String messageKind; // 'text' | 'image' | 'voice' | ...
  final String? callId;

  const PushPayload({
    required this.type,
    this.senderId,
    required this.senderName,
    required this.chatType,
    this.threadPeerId,
    this.groupId,
    this.messageId,
    this.preview,
    required this.messageKind,
    this.callId,
  });

  factory PushPayload.fromData(Map<String, dynamic> data) {
    String? s(Object? v) => v?.toString();
    int? groupId;
    final rawGroup = s(data['group_id']);
    if (rawGroup != null && rawGroup.isNotEmpty) {
      groupId = int.tryParse(rawGroup);
    }
    return PushPayload(
      type: s(data['type']) ?? 'message',
      senderId: s(data['sender_id']),
      senderName: s(data['sender_name']) ?? '',
      chatType: s(data['chat_type']) ?? 'dm',
      threadPeerId: s(data['thread_peer_id']),
      groupId: groupId,
      messageId: s(data['message_id']),
      preview: s(data['preview']),
      messageKind: s(data['message_kind']) ?? 'text',
      callId: s(data['call_id']),
    );
  }

  Map<String, dynamic> toJson() => {
        'type': type,
        if (senderId != null) 'sender_id': senderId,
        'sender_name': senderName,
        'chat_type': chatType,
        if (threadPeerId != null) 'thread_peer_id': threadPeerId,
        if (groupId != null) 'group_id': groupId.toString(),
        if (messageId != null) 'message_id': messageId,
        if (preview != null) 'preview': preview,
        'message_kind': messageKind,
        if (callId != null) 'call_id': callId,
      };
}

/// Where a notification tap should land. Equality is by kind + target
/// so the foreground-suppression check ("am I already viewing this
/// thread?") is a plain ==.
class PushRoute {
  final String kind; // 'dm' | 'group' | 'call'
  final String? peerId;
  final int? groupId;
  final String? callId;
  final String? senderId;

  const PushRoute.dm(this.peerId)
      : kind = 'dm',
        groupId = null,
        callId = null,
        senderId = null;

  const PushRoute.group(this.groupId)
      : kind = 'group',
        peerId = null,
        callId = null,
        senderId = null;

  const PushRoute.call(this.callId, {this.senderId})
      : kind = 'call',
        peerId = null,
        groupId = null;

  /// Route for a payload, or null when the payload carries no usable
  /// target (a call invite without a call id, a dm without a peer...).
  /// Call invites route to the call screen by call id; until the calls
  /// workstream ships a real call screen, the navigator falls back to
  /// the caller's DM thread (see push_navigation.dart).
  static PushRoute? fromPayload(PushPayload p) {
    if (p.type == 'call_invite') {
      if (p.callId == null || p.callId!.isEmpty) return null;
      return PushRoute.call(p.callId, senderId: p.senderId);
    }
    if (p.chatType == 'group') {
      if (p.groupId == null) return null;
      return PushRoute.group(p.groupId);
    }
    if (p.threadPeerId == null || p.threadPeerId!.isEmpty) return null;
    return PushRoute.dm(p.threadPeerId);
  }

  @override
  bool operator ==(Object other) =>
      other is PushRoute &&
      kind == other.kind &&
      peerId == other.peerId &&
      groupId == other.groupId &&
      callId == other.callId;

  @override
  int get hashCode => Object.hash(kind, peerId, groupId, callId);
}

/// Composed notification title/body. Title is always the sender name
/// (or the app name when the payload has none); the body is the text
/// preview for text messages and a localized media label otherwise.
class PushNotificationContent {
  final String title;
  final String body;

  const PushNotificationContent({required this.title, required this.body});
}

PushNotificationContent composeNotificationContent(PushPayload p) {
  final name = p.senderName.trim();
  final title = name.isEmpty ? AppStrings.t('appName') : name;
  if (p.type == 'call_invite') {
    return PushNotificationContent(
      title: title,
      body: AppStrings.t('pushIncomingCall'),
    );
  }
  final preview = p.preview?.trim();
  switch (p.messageKind) {
    case 'text':
      return PushNotificationContent(
        title: title,
        body: (preview == null || preview.isEmpty)
            ? AppStrings.t('pushNewMessage')
            : preview,
      );
    case 'image':
      return PushNotificationContent(
        title: title,
        body: AppStrings.t('imagePlaceholder'),
      );
    case 'voice':
      return PushNotificationContent(
        title: title,
        body: AppStrings.t('voiceMessagePlaceholder'),
      );
    case 'video':
      return PushNotificationContent(
        title: title,
        body: AppStrings.t('videoPlaceholder'),
      );
    case 'file':
      return PushNotificationContent(
        title: title,
        body: AppStrings.t('fileLabel'),
      );
    default:
      return PushNotificationContent(
        title: title,
        body: (preview == null || preview.isEmpty)
            ? AppStrings.t('pushNewMessage')
            : preview,
      );
  }
}

/// Stable local-notification id for a payload, seeded by message/call
/// id so re-delivery updates the same notification instead of stacking.
int pushNotificationId(PushPayload p) {
  final key = p.messageId ?? p.callId ?? p.senderId ?? '';
  final id = key.hashCode & 0x7fffffff;
  return id == 0 ? 1 : id;
}

// ---------------------------------------------------------------------------
// Permission status
// ---------------------------------------------------------------------------

enum PushPermissionStatus {
  granted,
  denied,
  permanentlyDenied,
  notDetermined,
}

// ---------------------------------------------------------------------------
// Backends (test seams)
// ---------------------------------------------------------------------------

/// FCM surface PushService needs. The real implementation wraps
/// FirebaseMessaging; tests inject a fake.
abstract class PushMessagingBackend {
  Future<PushPermissionStatus> requestPermission();
  Future<String?> getToken();
  Stream<String> get onTokenRefresh;
  Stream<Map<String, dynamic>> get onMessage;
  Stream<Map<String, dynamic>> get onMessageOpenedApp;
  Future<Map<String, dynamic>?> getInitialMessage();
}

class FirebasePushMessaging implements PushMessagingBackend {
  FirebaseMessaging get _fcm => FirebaseMessaging.instance;

  @override
  Future<PushPermissionStatus> requestPermission() async {
    final settings = await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    switch (settings.authorizationStatus) {
      case AuthorizationStatus.authorized:
      case AuthorizationStatus.provisional:
        return PushPermissionStatus.granted;
      case AuthorizationStatus.denied:
        return PushPermissionStatus.denied;
      case AuthorizationStatus.deniedPermanently:
        return PushPermissionStatus.permanentlyDenied;
      case AuthorizationStatus.notDetermined:
        return PushPermissionStatus.notDetermined;
    }
  }

  @override
  Future<String?> getToken() => _fcm.getToken();

  @override
  Stream<String> get onTokenRefresh => _fcm.onTokenRefresh;

  @override
  Stream<Map<String, dynamic>> get onMessage =>
      FirebaseMessaging.onMessage.map((m) => m.data);

  @override
  Stream<Map<String, dynamic>> get onMessageOpenedApp =>
      FirebaseMessaging.onMessageOpenedApp.map((m) => m.data);

  @override
  Future<Map<String, dynamic>?> getInitialMessage() async {
    final m = await _fcm.getInitialMessage();
    return m?.data;
  }
}

/// Local-notification surface PushService needs (foreground display +
/// tap callback + the Android 13+ enabled check).
abstract class PushLocalNotifications {
  Future<void> initialize({required void Function(String? payload) onTap});
  Future<void> show({
    required int id,
    required String title,
    required String body,
    String? payload,
  });
  Future<bool?> areNotificationsEnabled();
}

class FlutterPushLocalNotifications implements PushLocalNotifications {
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  @override
  Future<void> initialize({
    required void Function(String? payload) onTap,
  }) async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(
      settings,
      onDidReceiveNotificationResponse: (r) => onTap(r.payload),
    );
  }

  NotificationDetails _details() => NotificationDetails(
        android: AndroidNotificationDetails(
          pushChannelId,
          AppStrings.t('appName'),
          channelDescription: AppStrings.t('pushNotifications'),
          importance: Importance.max,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
        ),
      );

  @override
  Future<void> show({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    await _plugin.show(id, title, body, _details(), payload: payload);
  }

  @override
  Future<bool?> areNotificationsEnabled() async {
    final android = _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    return android?.areNotificationsEnabled();
  }
}

/// public.device_tokens rows. Upsert relies on the table's primary key
/// (user_id, token) — the server worker owns that table; see README.
abstract class DeviceTokenStore {
  Future<void> upsert({required String userId, required String token});
  Future<void> deleteToken(String token);
  Future<void> deleteForUser(String userId);
}

class SupabaseDeviceTokenStore implements DeviceTokenStore {
  @override
  Future<void> upsert({required String userId, required String token}) async {
    await Api.client.from('device_tokens').upsert({
      'user_id': userId,
      'token': token,
      'platform': 'android',
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  @override
  Future<void> deleteToken(String token) async {
    await Api.client.from('device_tokens').delete().eq('token', token);
  }

  @override
  Future<void> deleteForUser(String userId) async {
    await Api.client.from('device_tokens').delete().eq('user_id', userId);
  }
}

/// Opens the destination for a tap. Implemented in
/// push_navigation.dart (kept out of this file so this service never
/// imports screens — screens import this service for the thread
/// tracker, and a service->screen import would be a cycle).
abstract class PushNavigator {
  Future<void> openRoute(PushRoute route);
}

/// Opens the system notification-settings page for this app (used when
/// the permission is permanently denied — the system dialog will not
/// show again, so the user must enable it by hand).
abstract class PushSettingsOpener {
  Future<void> openNotificationSettings();
}

class AppSettingsPushSettingsOpener implements PushSettingsOpener {
  @override
  Future<void> openNotificationSettings() =>
      AppSettings.openAppSettings(type: AppSettingsType.notification);
}

/// "Have we already asked once?" flag for the post-login rationale.
/// Real storage is SharedPreferences; tests inject an in-memory store.
abstract class PushAskedStore {
  Future<bool> wasAsked();
  Future<void> markAsked();
}

class SharedPrefsPushAskedStore implements PushAskedStore {
  @override
  Future<bool> wasAsked() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(pushAskedPrefsKey) ?? false;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<void> markAsked() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(pushAskedPrefsKey, true);
    } catch (_) {
      // Best-effort only: a failed write just means we may ask again.
    }
  }
}

// ---------------------------------------------------------------------------
// Background handler (top-level, runs in its own isolate)
// ---------------------------------------------------------------------------

/// FCM background entry point. Must stay top-level and must never
/// throw. It cannot use PushService.instance (a fresh isolate has no
/// initialized singleton) so it builds its own local-notifications
/// plugin and composes from the data payload with the same pure
/// functions the foreground path uses. Language falls back to Arabic
/// here: the background isolate has no loaded preferences.
@pragma('vm:entry-point')
Future<void> pushBackgroundHandler(RemoteMessage message) async {
  try {
    final payload = PushPayload.fromData(message.data);
    final content = composeNotificationContent(payload);
    final plugin = FlutterLocalNotificationsPlugin();
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    await plugin.initialize(
      const InitializationSettings(android: androidInit),
    );
    await plugin.show(
      pushNotificationId(payload),
      content.title,
      content.body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          pushChannelId,
          AppStrings.t('appName'),
          channelDescription: AppStrings.t('pushNotifications'),
          importance: Importance.max,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
        ),
      ),
      payload: jsonEncode(message.data),
    );
  } catch (_) {
    // A background failure must never crash the isolate.
  }
}

// ---------------------------------------------------------------------------
// PushService
// ---------------------------------------------------------------------------

class PushService {
  /// Navigator key the app's MaterialApp must use (wired in main.dart)
  /// so notification taps can navigate without a BuildContext.
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();

  static final PushService instance = PushService._();

  PushMessagingBackend? _messaging;
  PushLocalNotifications? _local;
  DeviceTokenStore? _tokens;
  PushNavigator? _navigator;
  PushSettingsOpener? _settingsOpener;
  PushAskedStore? _askedStore;
  final String? Function() _currentUserIdProvider;

  bool _initialized = false;
  bool _available = false;
  String? _currentToken;
  String? _currentUserId;

  /// Last known permission state (null = never checked). The Settings
  /// screen listens to this to render the push row.
  final ValueNotifier<PushPermissionStatus?> permissionStatus =
      ValueNotifier<PushPermissionStatus?>(null);

  /// The thread currently on screen, or null. Thread screens set this
  /// in initState and clear it in dispose; foreground messages for the
  /// open thread are suppressed (no banner for the conversation already
  /// on screen). Call invites are never suppressed — there is no call
  /// screen to be "already viewing" yet.
  final ValueNotifier<PushRoute?> activeRoute =
      ValueNotifier<PushRoute?>(null);

  PushService._() : _currentUserIdProvider = _defaultCurrentUserId;

  /// Test constructor: backends are injected and init() is still the
  /// entry point that wires the listeners (tests drive init with the
  /// fakes). [currentUserId] fixes the signed-in user for the test.
  PushService.forTest({
    PushMessagingBackend? messaging,
    PushLocalNotifications? local,
    DeviceTokenStore? tokens,
    PushNavigator? navigator,
    PushSettingsOpener? settingsOpener,
    PushAskedStore? askedStore,
    String? currentUserId,
  })  : _messaging = messaging,
        _local = local,
        _tokens = tokens,
        _navigator = navigator,
        _settingsOpener = settingsOpener,
        _askedStore = askedStore,
        _currentUserIdProvider = (() => currentUserId);

  static String? _defaultCurrentUserId() =>
      Api.client.auth.currentUser?.id;

  /// The navigator used for tap routing. main.dart assigns the real
  /// AppPushNavigator; until then taps are dropped (never a crash).
  set navigator(PushNavigator navigator) => _navigator = navigator;

  bool get available => _available;

  /// AppStrings key for the Settings push-row subtitle.
  String statusSubtitleKey() {
    if (!_available) return 'pushUnavailable';
    switch (permissionStatus.value) {
      case PushPermissionStatus.granted:
        return 'pushEnabled';
      case PushPermissionStatus.permanentlyDenied:
        return 'pushDeniedSettings';
      case PushPermissionStatus.denied:
      case PushPermissionStatus.notDetermined:
      case null:
        return 'pushDisabled';
    }
  }

  /// One-time setup. Call from main() after Supabase.initialize +
  /// session restore. NEVER throws: on web it returns silently (the
  /// web preview must keep building), and when Firebase is unavailable
  /// (no google-services.json yet) it marks itself unavailable and the
  /// app runs exactly as before.
  ///
  /// [firebaseInitializer] is a test seam: pass a throwing function to
  /// simulate the missing-google-services.json startup failure.
  Future<void> init({
    PushMessagingBackend? messaging,
    PushLocalNotifications? local,
    DeviceTokenStore? tokens,
    PushNavigator? navigator,
    PushSettingsOpener? settingsOpener,
    PushAskedStore? askedStore,
    Future<void> Function()? firebaseInitializer,
  }) async {
    if (_initialized) return;
    _initialized = true;
    // NOTE: _navigator is deliberately NOT part of testMode — main.dart
    // assigns the real AppPushNavigator before init(), and that must
    // not skip the real Firebase.initializeApp() below.
    final testMode = messaging != null ||
        local != null ||
        tokens != null ||
        navigator != null ||
        settingsOpener != null ||
        askedStore != null ||
        firebaseInitializer != null ||
        _messaging != null ||
        _local != null ||
        _tokens != null ||
        _settingsOpener != null ||
        _askedStore != null;
    if (!testMode) {
      // Real path.
      if (kIsWeb) return;
      try {
        await Firebase.initializeApp();
      } catch (_) {
        // Firebase unavailable (google-services.json not wired yet, or
        // any other startup failure) — degrade silently.
        return;
      }
    } else if (firebaseInitializer != null) {
      try {
        await firebaseInitializer();
      } catch (_) {
        // Simulated startup failure — the app still boots.
        return;
      }
    }
    _available = true;
    _messaging = messaging ?? _messaging ?? FirebasePushMessaging();
    _local = local ?? _local ?? FlutterPushLocalNotifications();
    _tokens = tokens ?? _tokens ?? SupabaseDeviceTokenStore();
    _navigator = navigator ?? _navigator;
    _settingsOpener =
        settingsOpener ?? _settingsOpener ?? AppSettingsPushSettingsOpener();
    _askedStore = askedStore ?? _askedStore ?? SharedPrefsPushAskedStore();

    try {
      await _local!.initialize(onTap: handleLocalNotificationTap);
    } catch (_) {
      // Local notifications unavailable — FCM listeners still wire up;
      // foreground messages just cannot display.
    }
    try {
      _messaging!.onMessage.listen((data) {
        unawaited(handleForegroundMessage(data));
      });
      _messaging!.onMessageOpenedApp.listen((data) {
        unawaited(handleTap(data));
      });
      _messaging!.onTokenRefresh.listen((newToken) {
        unawaited(_onTokenRefresh(newToken));
      });
      final initial = await _messaging!.getInitialMessage();
      if (initial != null) unawaited(handleTap(initial));
    } catch (_) {
      // Listener wiring is best-effort; token registration below can
      // still succeed.
    }
    if (!testMode) {
      try {
        FirebaseMessaging.onBackgroundMessage(pushBackgroundHandler);
      } catch (_) {
        // Background delivery unavailable — foreground still works.
      }
      Api.client.auth.onAuthStateChange.listen((data) {
        if (data.event == AuthChangeEvent.signedIn ||
            data.event == AuthChangeEvent.tokenRefreshed) {
          unawaited(registerToken());
        } else if (data.event == AuthChangeEvent.signedOut) {
          unawaited(unregisterToken());
        }
      });
      // A persisted session is already restored by Supabase.initialize,
      // so a returning user registers immediately.
      await registerToken();
    }
  }

  /// Called when home becomes visible (login, account switch, Google
  /// setup completion): registers this device's token for the current
  /// account. Safe to call repeatedly — a re-register for the same
  /// user + token is skipped. Never throws.
  Future<void> onSignedIn() async {
    if (!_available) return;
    await registerToken();
  }

  /// areNotificationsEnabled, false on any failure (e.g. the platform
  /// plugin is unavailable on an unsupported platform). A failure here
  /// must never abort the permission flow or turn into a wrong status.
  Future<bool> _areNotificationsEnabled() async {
    try {
      return await _local?.areNotificationsEnabled() == true;
    } catch (_) {
      return false;
    }
  }

  /// Post-login permission prompt, shown AT MOST ONCE per device: a
  /// short localized rationale dialog, then the system permission
  /// request. No-op on web, when Firebase is unavailable, when already
  /// asked, or when notifications are already enabled. Never throws.
  Future<void> maybeRequestPermission(BuildContext context) async {
    if (!_available) return;
    try {
      if (await _askedStore?.wasAsked() == true) return;
      if (await _areNotificationsEnabled()) {
        permissionStatus.value = PushPermissionStatus.granted;
        await _askedStore?.markAsked();
        return;
      }
      if (!context.mounted) return;
      final enable = await showPushRationaleDialog(context);
      if (!context.mounted) return;
      await _askedStore?.markAsked();
      if (enable != true) return;
      await requestPermission();
    } catch (_) {
      // Never block login/home on the permission flow.
    }
  }

  /// The rationale dialog itself (separate so widget tests can drive
  /// it). Returns true when the user taps "enable".
  Future<bool?> showPushRationaleDialog(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('pushRationaleTitle')),
        content: Text(AppStrings.t('pushRationaleBody')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            style: TextButton.styleFrom(foregroundColor: Colors.white),
            child: Text(AppStrings.t('pushLater')),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(AppStrings.t('pushEnable')),
          ),
        ],
      ),
    );
  }

  /// Request the system notification permission (Android 13+
  /// POST_NOTIFICATIONS). Maps the result; a denial AFTER we have
  /// already asked once is treated as permanently denied (the system
  /// will not show the dialog again), which is what the Settings row
  /// uses to offer opening app settings instead. Never throws.
  Future<PushPermissionStatus> requestPermission() async {
    if (!_available || _messaging == null) {
      return PushPermissionStatus.notDetermined;
    }
    try {
      if (await _areNotificationsEnabled()) {
        permissionStatus.value = PushPermissionStatus.granted;
        return PushPermissionStatus.granted;
      }
      final status = await _messaging!.requestPermission();
      final wasAsked = await _askedStore?.wasAsked() ?? false;
      final resolved = status == PushPermissionStatus.denied && wasAsked
          ? PushPermissionStatus.permanentlyDenied
          : status;
      await _askedStore?.markAsked();
      permissionStatus.value = resolved;
      return resolved;
    } catch (_) {
      return permissionStatus.value ?? PushPermissionStatus.notDetermined;
    }
  }

  /// Settings-row tap: re-request the permission, or open the system
  /// notification-settings page when it is permanently denied. Never
  /// throws, no-op while Firebase is unavailable.
  Future<void> requestPermissionFromSettings() async {
    if (!_available) return;
    try {
      if (permissionStatus.value == PushPermissionStatus.permanentlyDenied) {
        await _settingsOpener?.openNotificationSettings();
        return;
      }
      final status = await requestPermission();
      if (status == PushPermissionStatus.permanentlyDenied) {
        await _settingsOpener?.openNotificationSettings();
      }
    } catch (_) {
      // Settings must never crash on the push row.
    }
  }

  /// Fetch the FCM token and upsert it into public.device_tokens for
  /// the current user. Skips when the same user + token is already
  /// registered. The token value is never logged. Never throws.
  Future<void> registerToken() async {
    if (!_available || _messaging == null) return;
    try {
      final userId = _currentUserIdProvider();
      if (userId == null) return;
      final token = await _messaging!.getToken();
      if (token == null || token.isEmpty) return;
      if (_currentUserId == userId && _currentToken == token) return;
      await _tokens?.upsert(userId: userId, token: token);
      _currentUserId = userId;
      _currentToken = token;
    } catch (_) {
      // Registration is best-effort; push just stays off.
    }
  }

  /// Delete this device's token row: called on sign-out (and by the
  /// auth-state listener). Deletes by token when known, otherwise all
  /// rows for the cached user. Never throws.
  Future<void> unregisterToken() async {
    final token = _currentToken;
    final userId = _currentUserId;
    _currentToken = null;
    _currentUserId = null;
    if (!_available || _tokens == null) return;
    try {
      if (token != null && token.isNotEmpty) {
        await _tokens!.deleteToken(token);
      } else if (userId != null) {
        await _tokens!.deleteForUser(userId);
      }
    } catch (_) {
      // Best-effort only.
    }
  }

  /// Token rotation: drop the old row, upsert the new token for the
  /// current user. Never throws.
  Future<void> _onTokenRefresh(String newToken) async {
    try {
      final userId = _currentUserIdProvider();
      if (userId == null || newToken.isEmpty) return;
      final old = _currentToken;
      if (old != null && old.isNotEmpty && old != newToken) {
        try {
          await _tokens?.deleteToken(old);
        } catch (_) {}
      }
      await _tokens?.upsert(userId: userId, token: newToken);
      _currentUserId = userId;
      _currentToken = newToken;
    } catch (_) {}
  }

  /// The thread currently on screen (set/cleared by ThreadScreen and
  /// GroupThreadScreen). Clearing only removes the route when it is
  /// still the active one, so dispose order can never clobber a newer
  /// thread.
  void setActiveThread(PushRoute route) {
    activeRoute.value = route;
  }

  void clearActiveThread(PushRoute route) {
    if (activeRoute.value == route) activeRoute.value = null;
  }

  /// Foreground message: show a local notification UNLESS the user is
  /// already viewing that thread/call. Never throws.
  Future<void> handleForegroundMessage(Map<String, dynamic> data) async {
    if (!_available) return;
    try {
      final payload = PushPayload.fromData(data);
      final route = PushRoute.fromPayload(payload);
      if (route != null && route == activeRoute.value) return;
      await _showLocalNotification(payload, data);
    } catch (_) {}
  }

  /// Background-isolate equivalent of [handleForegroundMessage] minus
  /// the suppression check (there is no active thread in the
  /// background isolate). Kept as a method so tests can drive the same
  /// composition; the real top-level handler is [pushBackgroundHandler].
  Future<void> handleBackgroundMessage(Map<String, dynamic> data) async {
    if (!_available) return;
    try {
      final payload = PushPayload.fromData(data);
      await _showLocalNotification(payload, data);
    } catch (_) {}
  }

  Future<void> _showLocalNotification(
    PushPayload payload,
    Map<String, dynamic> data,
  ) async {
    final content = composeNotificationContent(payload);
    await _local?.show(
      id: pushNotificationId(payload),
      title: content.title,
      body: content.body,
      payload: jsonEncode(data),
    );
  }

  /// Notification tap (from onMessageOpenedApp / initialMessage /
  /// local-notification tap): navigate to the right screen. Never
  /// throws.
  Future<void> handleTap(Map<String, dynamic> data) async {
    try {
      final payload = PushPayload.fromData(data);
      final route = PushRoute.fromPayload(payload);
      if (route == null) return;
      await _navigator?.openRoute(route);
    } catch (_) {}
  }

  /// Local-notification tap payload is the JSON-encoded FCM data map.
  Future<void> handleLocalNotificationTap(String? payload) async {
    if (payload == null || payload.isEmpty) return;
    try {
      final data = jsonDecode(payload);
      if (data is Map<String, dynamic>) await handleTap(data);
    } catch (_) {}
  }
}
