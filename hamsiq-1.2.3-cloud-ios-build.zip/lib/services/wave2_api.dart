// Hamsiq native — Wave 2 API (Instagram features, sql-v30).
// One home for the Wave 2 features that do not belong to an existing
// API file: favourites, mute/snooze, Close Friends list, post drafts,
// scheduled posts, chat themes, basic Insights, in-thread translation.
//
// Tables (all sql-v30, all owner-scoped RLS — auth.uid() = user_id,
// no policy ever queries its own table):
//   favourites (user_id, favourite_id), muted_accounts (user_id,
//   muted_id, snooze_until), close_friends (user_id, friend_id),
//   post_drafts, scheduled_posts, chat_themes (user_id, peer_id, color).
// Insights reads only tables that already exist (posts, post_likes,
// follows, stories, story_views) — nothing new is stored for it.
//
// Honest limits, repeated in the UI wherever they apply:
//   * Scheduled posts publish ONLY while the app is open (there is no
//     server-side scheduler). publishDueScheduledPosts is called on
//     feed load and from the Drafts screen.
//   * Translation uses the free keyless MyMemory API — an external
//     service; the translated text leaves the device to their servers.
//     MyMemory's free tier is rate-limited; a failure shows an error,
//     never a fake translation.

import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models.dart';
import 'supabase_service.dart';

// ---------------------------------------------------------------------------
// Pure helpers (unit testable without a session)
// ---------------------------------------------------------------------------

/// Which MyMemory language pair to request for [text]: Arabic text is
/// translated to English, anything else to Arabic.
String translationPairFor(String text) {
  final hasArabic = RegExp(r'[\u0600-\u06FF]').hasMatch(text);
  return hasArabic ? 'ar|en' : 'en|ar';
}

/// Is a mute/snooze row still active? A null [snoozeUntil] is an
/// indefinite mute; a future date is an active snooze; a past date
/// means the snooze expired (the account is unmuted again).
bool isMuteActive(DateTime? snoozeUntil, DateTime now) {
  if (snoozeUntil == null) return true;
  return snoozeUntil.isAfter(now);
}

/// Feed posts with muted/snoozed accounts removed.
List<PostItem> filterMutedPosts(List<PostItem> posts, Set<String> mutedIds) {
  if (mutedIds.isEmpty) return posts;
  return posts.where((p) => !mutedIds.contains(p.userId)).toList();
}

/// Feed posts by favourite accounts only.
List<PostItem> filterFavouritePosts(
  List<PostItem> posts,
  Set<String> favouriteIds,
) {
  return posts.where((p) => favouriteIds.contains(p.userId)).toList();
}

/// Is a scheduled post due to publish at [now]?
bool isScheduledDue(DateTime publishAt, DateTime now) =>
    !publishAt.isAfter(now);

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------

class PostDraft {
  final int id;
  final String caption;
  final String? mediaUrl;
  final String mediaType;
  final bool isReel;
  final DateTime createdAt;
  final DateTime updatedAt;

  PostDraft({
    required this.id,
    required this.caption,
    this.mediaUrl,
    required this.mediaType,
    required this.isReel,
    required this.createdAt,
    required this.updatedAt,
  });

  factory PostDraft.fromMap(Map<String, dynamic> m) => PostDraft(
        id: (m['id'] as num).toInt(),
        caption: (m['caption'] ?? '') as String,
        mediaUrl: m['media_url'] as String?,
        mediaType: (m['media_type'] ?? 'image') as String,
        isReel: (m['is_reel'] ?? false) as bool,
        createdAt: DateTime.parse(m['created_at'] as String),
        updatedAt: DateTime.parse(
          (m['updated_at'] ?? m['created_at']) as String,
        ),
      );
}

class ScheduledPost {
  final int id;
  final String caption;
  final String? mediaUrl;
  final String mediaType;
  final bool isReel;
  final DateTime publishAt;
  final bool published;
  final int? publishedPostId;
  final DateTime createdAt;

  ScheduledPost({
    required this.id,
    required this.caption,
    this.mediaUrl,
    required this.mediaType,
    required this.isReel,
    required this.publishAt,
    required this.published,
    this.publishedPostId,
    required this.createdAt,
  });

  factory ScheduledPost.fromMap(Map<String, dynamic> m) => ScheduledPost(
        id: (m['id'] as num).toInt(),
        caption: (m['caption'] ?? '') as String,
        mediaUrl: m['media_url'] as String?,
        mediaType: (m['media_type'] ?? 'image') as String,
        isReel: (m['is_reel'] ?? false) as bool,
        publishAt: DateTime.parse(m['publish_at'] as String),
        published: (m['published'] ?? false) as bool,
        publishedPostId: m['published_post_id'] == null
            ? null
            : (m['published_post_id'] as num).toInt(),
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

class MutedAccount {
  final String mutedId;
  final DateTime? snoozeUntil;
  final DateTime createdAt;
  HamsiqProfile? profile;

  MutedAccount({
    required this.mutedId,
    this.snoozeUntil,
    required this.createdAt,
    this.profile,
  });

  factory MutedAccount.fromMap(Map<String, dynamic> m) => MutedAccount(
        mutedId: m['muted_id'] as String,
        snoozeUntil: m['snooze_until'] == null
            ? null
            : DateTime.parse(m['snooze_until'] as String),
        createdAt: DateTime.parse(m['created_at'] as String),
      );

  bool get isActive => isMuteActive(snoozeUntil, DateTime.now());
  bool get isSnooze => snoozeUntil != null;
}

class InsightsData {
  final int postsCount;
  final int totalLikes;
  final double avgLikesPerPost;
  final int followers;
  final int following;
  final int newFollowers7d;
  final int newFollowers30d;
  final bool followersGrowthAvailable;
  final int totalStoryViews;
  final PostItem? topPost;

  InsightsData({
    required this.postsCount,
    required this.totalLikes,
    required this.avgLikesPerPost,
    required this.followers,
    required this.following,
    required this.newFollowers7d,
    required this.newFollowers30d,
    required this.followersGrowthAvailable,
    required this.totalStoryViews,
    this.topPost,
  });
}

class Wave2Api {
  // ---------------- favourites ----------------

  static Future<Set<String>> fetchMyFavouriteIds() async {
    try {
      final rows = await Api.client
          .from('favourites')
          .select('favourite_id')
          .eq('user_id', Api.myId);
      return {
        for (final r in (rows as List)) r['favourite_id'] as String,
      };
    } catch (_) {
      return {};
    }
  }

  static Future<bool> isFavourite(String userId) async =>
      (await fetchMyFavouriteIds()).contains(userId);

  static Future<void> setFavourite(String userId, bool favourite) async {
    if (favourite) {
      await Api.client.from('favourites').upsert({
        'user_id': Api.myId,
        'favourite_id': userId,
      });
    } else {
      await Api.client
          .from('favourites')
          .delete()
          .eq('user_id', Api.myId)
          .eq('favourite_id', userId);
    }
  }

  // ---------------- mute / snooze accounts ----------------

  /// Active muted account ids (indefinite mutes + unexpired snoozes).
  static Future<Set<String>> fetchActiveMutedIds() async {
    final accounts = await fetchMutedAccounts();
    return {
      for (final a in accounts)
        if (a.isActive) a.mutedId,
    };
  }

  static Future<List<MutedAccount>> fetchMutedAccounts() async {
    try {
      final rows = await Api.client
          .from('muted_accounts')
          .select()
          .eq('user_id', Api.myId)
          .order('created_at', ascending: false);
      final accounts = (rows as List)
          .map((r) => MutedAccount.fromMap(r as Map<String, dynamic>))
          .toList();
      if (accounts.isEmpty) return accounts;
      final profiles =
          await Api.fetchProfiles(accounts.map((a) => a.mutedId).toList());
      for (final a in accounts) {
        a.profile = profiles[a.mutedId];
      }
      return accounts;
    } catch (_) {
      return [];
    }
  }

  /// Mute an account's posts/stories. [snoozeDays] snoozes for that
  /// many days (30 = Instagram's snooze); null = mute until unmuted.
  static Future<void> muteAccount(String userId, {int? snoozeDays}) async {
    final row = <String, dynamic>{
      'user_id': Api.myId,
      'muted_id': userId,
    };
    if (snoozeDays != null) {
      row['snooze_until'] = DateTime.now()
          .add(Duration(days: snoozeDays))
          .toUtc()
          .toIso8601String();
    }
    await Api.client.from('muted_accounts').upsert(row);
  }

  static Future<void> unmuteAccount(String userId) async {
    await Api.client
        .from('muted_accounts')
        .delete()
        .eq('user_id', Api.myId)
        .eq('muted_id', userId);
  }

  // ---------------- Close Friends list ----------------

  static Future<Set<String>> fetchMyCloseFriendIds() async {
    try {
      final rows = await Api.client
          .from('close_friends')
          .select('friend_id')
          .eq('user_id', Api.myId);
      return {
        for (final r in (rows as List)) r['friend_id'] as String,
      };
    } catch (_) {
      return {};
    }
  }

  static Future<void> setCloseFriend(String friendId, bool onList) async {
    if (onList) {
      await Api.client.from('close_friends').upsert({
        'user_id': Api.myId,
        'friend_id': friendId,
      });
    } else {
      await Api.client
          .from('close_friends')
          .delete()
          .eq('user_id', Api.myId)
          .eq('friend_id', friendId);
    }
  }

  // ---------------- post drafts ----------------

  static Future<List<PostDraft>> fetchMyDrafts() async {
    final rows = await Api.client
        .from('post_drafts')
        .select()
        .eq('user_id', Api.myId)
        .order('updated_at', ascending: false);
    return (rows as List)
        .map((r) => PostDraft.fromMap(r as Map<String, dynamic>))
        .toList();
  }

  /// Create or update a draft. Returns the saved draft.
  static Future<PostDraft> saveDraft({
    int? id,
    required String caption,
    String? mediaUrl,
    String mediaType = 'image',
    bool isReel = false,
  }) async {
    final row = <String, dynamic>{
      'user_id': Api.myId,
      'caption': caption,
      'media_url': mediaUrl,
      'media_type': mediaType,
      'is_reel': isReel,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };
    if (id == null) {
      final rows =
          await Api.client.from('post_drafts').insert(row).select();
      return PostDraft.fromMap((rows as List).first as Map<String, dynamic>);
    }
    final rows = await Api.client
        .from('post_drafts')
        .update(row)
        .eq('id', id)
        .eq('user_id', Api.myId)
        .select();
    return PostDraft.fromMap((rows as List).first as Map<String, dynamic>);
  }

  static Future<void> deleteDraft(int id) async {
    await Api.client
        .from('post_drafts')
        .delete()
        .eq('id', id)
        .eq('user_id', Api.myId);
  }

  /// Publish a draft as a real post, then delete the draft.
  static Future<PostItem> publishDraft(PostDraft draft) async {
    final post = await Api.createPost(
      caption: draft.caption,
      mediaUrl: draft.mediaUrl,
      mediaType: draft.mediaType,
      isReel: draft.isReel,
    );
    await deleteDraft(draft.id);
    return post;
  }

  // ---------------- scheduled posts ----------------

  /// Schedule a post for [publishAt] (must be in the future).
  /// Honest limit: it publishes only while the app is open — see
  /// publishDueScheduledPosts.
  static Future<ScheduledPost> schedulePost({
    required String caption,
    String? mediaUrl,
    String mediaType = 'image',
    bool isReel = false,
    required DateTime publishAt,
  }) async {
    if (!publishAt.isAfter(DateTime.now())) {
      throw Exception('اختر وقتاً في المستقبل');
    }
    final rows = await Api.client.from('scheduled_posts').insert({
      'user_id': Api.myId,
      'caption': caption,
      'media_url': mediaUrl,
      'media_type': mediaType,
      'is_reel': isReel,
      'publish_at': publishAt.toUtc().toIso8601String(),
    }).select();
    return ScheduledPost.fromMap((rows as List).first as Map<String, dynamic>);
  }

  static Future<List<ScheduledPost>> fetchMyScheduled() async {
    final rows = await Api.client
        .from('scheduled_posts')
        .select()
        .eq('user_id', Api.myId)
        .order('publish_at', ascending: true);
    return (rows as List)
        .map((r) => ScheduledPost.fromMap(r as Map<String, dynamic>))
        .toList();
  }

  static Future<void> cancelScheduled(int id) async {
    await Api.client
        .from('scheduled_posts')
        .delete()
        .eq('id', id)
        .eq('user_id', Api.myId);
  }

  /// Publish every due scheduled post (publish_at <= now, not yet
  /// published) and mark it published. Callers: feed load + Drafts
  /// screen. Returns how many were published. Best-effort per post —
  /// one failure must not block the others.
  static Future<int> publishDueScheduledPosts() async {
    late final List<ScheduledPost> due;
    try {
      final all = await fetchMyScheduled();
      final now = DateTime.now();
      due = all
          .where((s) => !s.published && isScheduledDue(s.publishAt, now))
          .toList();
    } catch (_) {
      return 0;
    }
    var published = 0;
    for (final s in due) {
      try {
        final post = await Api.createPost(
          caption: s.caption,
          mediaUrl: s.mediaUrl,
          mediaType: s.mediaType,
          isReel: s.isReel,
        );
        await Api.client
            .from('scheduled_posts')
            .update({'published': true, 'published_post_id': post.id})
            .eq('id', s.id)
            .eq('user_id', Api.myId);
        published++;
      } catch (_) {
        // Leave it pending; the next app-open check retries it.
      }
    }
    return published;
  }

  // ---------------- chat themes ----------------

  /// Per-chat accent colours (the sender's bubble + send icon). Blue
  /// is the default (0xFF0095F6) when no theme is saved.
  static const List<int> themeColors = [
    0xFF0095F6, // أزرق (الافتراضي)
    0xFF7B61FF, // بنفسجي
    0xFFE1306C, // وردي
    0xFFF58529, // برتقالي
    0xFF00B578, // أخضر
    0xFF00A5CF, // تركوازي
  ];

  static const List<String> themeColorNames = [
    'أزرق',
    'بنفسجي',
    'وردي',
    'برتقالي',
    'أخضر',
    'تركوازي',
  ];

  /// My saved theme colour for this peer, or null for the default blue.
  static Future<int?> fetchChatTheme(String peerId) async {
    try {
      final rows = await Api.client
          .from('chat_themes')
          .select('color')
          .eq('user_id', Api.myId)
          .eq('peer_id', peerId)
          .limit(1);
      if ((rows as List).isEmpty) return null;
      return (rows.first['color'] as num).toInt();
    } catch (_) {
      return null;
    }
  }

  static Future<void> setChatTheme(String peerId, int color) async {
    await Api.client.from('chat_themes').upsert({
      'user_id': Api.myId,
      'peer_id': peerId,
      'color': color,
    });
  }

  // ---------------- post options (sql-v30 columns on posts) ----------------

  /// Hide/show like counts, enable/disable comments, set alt text.
  /// Only the post owner can change these (the v29 owner UPDATE
  /// policy enforces it server-side too).
  static Future<void> setPostOptions(
    int postId, {
    bool? hideLikeCount,
    bool? commentsDisabled,
    String? altText,
  }) async {
    final patch = <String, dynamic>{};
    if (hideLikeCount != null) patch['hide_like_count'] = hideLikeCount;
    if (commentsDisabled != null) {
      patch['comments_disabled'] = commentsDisabled;
    }
    if (altText != null) patch['alt_text'] = altText.trim();
    if (patch.isEmpty) return;
    await Api.client
        .from('posts')
        .update(patch)
        .eq('id', postId)
        .eq('user_id', Api.myId);
  }

  // ---------------- basic Insights ----------------

  /// Views/likes/followers from existing data only. The numbers are
  /// labelled as estimates in the UI: post views are not stored per
  /// post (only story views exist), so "views" here means story views.
  static Future<InsightsData> fetchInsights() async {
    final posts = await Api.fetchUserPosts(Api.myId);
    final results = await Future.wait([
      Api.countFollowers(Api.myId),
      Api.countFollowing(Api.myId),
    ]);
    final followers = results[0];
    final following = results[1];

    var totalLikes = 0;
    PostItem? top;
    for (final p in posts) {
      totalLikes += p.likeCount;
      if (top == null || p.likeCount > top.likeCount) top = p;
    }

    // Follower growth from follows.created_at (best-effort: if the
    // column/query fails, growth is reported as unavailable, not zero).
    var new7 = 0;
    var new30 = 0;
    var growthAvailable = false;
    try {
      final rows = await Api.client
          .from('follows')
          .select('created_at')
          .eq('following_id', Api.myId);
      final now = DateTime.now();
      for (final r in (rows as List)) {
        final created = DateTime.tryParse(r['created_at'] as String? ?? '');
        if (created == null) continue;
        if (now.difference(created).inDays < 7) new7++;
        if (now.difference(created).inDays < 30) new30++;
      }
      growthAvailable = true;
    } catch (_) {
      growthAvailable = false;
    }

    // Story views: my story ids, then real story_views rows (sql-v29).
    var storyViews = 0;
    try {
      final storyRows = await Api.client
          .from('stories')
          .select('id')
          .eq('user_id', Api.myId)
          .limit(200);
      final ids = [
        for (final r in (storyRows as List)) (r['id'] as num).toInt(),
      ];
      if (ids.isNotEmpty) {
        final viewRows = await Api.client
            .from('story_views')
            .select('id')
            .inFilter('story_id', ids);
        storyViews = (viewRows as List).length;
      }
    } catch (_) {
      storyViews = 0;
    }

    return InsightsData(
      postsCount: posts.length,
      totalLikes: totalLikes,
      avgLikesPerPost:
          posts.isEmpty ? 0 : totalLikes / posts.length,
      followers: followers,
      following: following,
      newFollowers7d: new7,
      newFollowers30d: new30,
      followersGrowthAvailable: growthAvailable,
      totalStoryViews: storyViews,
      topPost: top,
    );
  }

  // ---------------- in-thread translation (MyMemory, free, keyless) ----------------

  /// Translate [text] via the free keyless MyMemory API
  /// (api.mymemory.translated.net — same service the web app uses).
  /// Arabic text -> English, anything else -> Arabic (see
  /// translationPairFor). Throws a friendly error when the service
  /// is unreachable or rate-limited; the caller shows the error
  /// instead of inventing a translation.
  static Future<String> translateText(String text) async {
    final clean = text.trim();
    if (clean.isEmpty) throw Exception('لا يوجد نص لترجمته');
    final pair = translationPairFor(clean);
    final uri = Uri.parse(
      'https://api.mymemory.translated.net/get'
      '?q=${Uri.encodeComponent(clean)}&langpair=$pair',
    );
    // package:http (not dart:io HttpClient, which does not exist on
    // web). Same GET, same 20s timeout, same responses on both
    // platforms. A network failure arrives as http.ClientException on
    // both (on Android the underlying SocketException is wrapped in
    // it by package:http), so one catch covers both.
    try {
      final response = await http.get(uri).timeout(
        const Duration(seconds: 20),
      );
      if (response.statusCode != 200) {
        throw Exception('تعذّرت الترجمة (خدمة MyMemory غير متاحة الآن)');
      }
      final decoded =
          jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      final data = decoded['responseData'] as Map<String, dynamic>?;
      final translated = (data?['translatedText'] as String?)?.trim();
      if (translated == null || translated.isEmpty) {
        throw Exception('تعذّرت الترجمة — حاول لاحقاً');
      }
      return translated;
    } on http.ClientException {
      throw Exception('لا يوجد اتصال بالإنترنت');
    }
  }
}
