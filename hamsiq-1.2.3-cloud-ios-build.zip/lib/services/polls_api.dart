// Hamsiq native — polls API layer.
// Schema (web app sql-v28, do not invent columns):
//   polls: id uuid, thread_kind text ('dm' | 'group'),
//     dm_peer_id uuid (nullable), group_id bigint (nullable),
//     question text, created_by uuid, created_at timestamptz.
//   poll_options: id uuid, poll_id uuid, option_text text,
//     position int (0-based).
//   poll_votes: id uuid, poll_id uuid, option_id uuid, user_id uuid,
//     created_at timestamptz; unique (poll_id, user_id) — one vote per
//     user, changeable by upserting on that conflict.
// A poll message in the messages table has message_type = 'poll' and
// body = the poll id (uuid string). That is the ONLY identification rule:
// the coordinator renders any message with message_type == 'poll' via
// PollCard(pollId: message.body).
// RLS (sql-v28): polls insert needs auth.uid() = created_by; select for
// creator / dm peer / group members. poll_votes insert needs
// auth.uid() = user_id + membership; update/delete own rows only —
// voting is an upsert on (poll_id, user_id), exactly like the web app.

import 'supabase_service.dart';

/// One poll option with its live vote count (filled by fetchPoll).
class PollOptionData {
  final String id;
  final String pollId;
  final String text;
  final int position;
  int voteCount;

  PollOptionData({
    required this.id,
    required this.pollId,
    required this.text,
    required this.position,
    this.voteCount = 0,
  });

  factory PollOptionData.fromMap(Map<String, dynamic> m) => PollOptionData(
        id: m['id'] as String,
        pollId: m['poll_id'] as String,
        text: (m['option_text'] ?? '') as String,
        position: (m['position'] as num?)?.toInt() ?? 0,
      );
}

/// A poll with its options, vote counts and my current vote (if any).
class PollData {
  final String id;
  final String threadKind; // 'dm' | 'group'
  final String? dmPeerId;
  final int? groupId;
  final String question;
  final String createdBy;
  final DateTime createdAt;
  final List<PollOptionData> options;

  /// The option id I voted for, or null if I have not voted.
  String? myVoteOptionId;

  PollData({
    required this.id,
    required this.threadKind,
    this.dmPeerId,
    this.groupId,
    required this.question,
    required this.createdBy,
    required this.createdAt,
    required this.options,
    this.myVoteOptionId,
  });

  int get totalVotes =>
      options.fold(0, (sum, o) => sum + o.voteCount);

  double shareOf(PollOptionData option) {
    if (totalVotes == 0) return 0;
    return option.voteCount / totalVotes;
  }
}

class PollsApi {
  /// Create a poll in a DM thread ([dmPeerId]) or a group ([groupId]) —
  /// exactly one must be given. [options] must be 2–4 non-empty strings
  /// (the web app caps at 4). Returns the new poll id (uuid string).
  /// This does NOT post the poll message into the thread; call
  /// [postPollMessage] afterwards (the web app does the same two steps).
  static Future<String> createPoll({
    String? dmPeerId,
    int? groupId,
    required String question,
    required List<String> options,
  }) async {
    final q = question.trim();
    if (q.isEmpty) throw Exception('اكتب سؤال الاستطلاع');
    final clean = options.map((o) => o.trim()).where((o) => o.isNotEmpty).toList();
    if (clean.length < 2) throw Exception('أضف خيارين على الأقل');
    if (clean.length > 4) throw Exception('أربعة خيارات كحد أقصى');
    final isGroup = groupId != null;
    if (isGroup == (dmPeerId != null)) {
      throw Exception('حدد محادثة واحدة للاستطلاع');
    }
    final rows = await Api.client.from('polls').insert({
      'thread_kind': isGroup ? 'group' : 'dm',
      'dm_peer_id': isGroup ? null : dmPeerId,
      'group_id': isGroup ? groupId : null,
      'question': q,
      'created_by': Api.myId,
    }).select('id');
    final pollId = (rows as List).first['id'] as String;
    final optionRows = clean
        .asMap()
        .entries
        .map((e) => {
              'poll_id': pollId,
              'option_text': e.value,
              'position': e.key,
            })
        .toList();
    await Api.client.from('poll_options').insert(optionRows);
    return pollId;
  }

  /// Post a poll into a thread: a messages row with
  /// message_type = 'poll' and body = [pollId]. For a group pass
  /// [groupId] (receiver_id stays null, per the group-message rule);
  /// for a DM pass [dmPeerId] (receiver_id = peer).
  static Future<void> postPollMessage({
    String? dmPeerId,
    int? groupId,
    required String pollId,
  }) async {
    final isGroup = groupId != null;
    if (isGroup == (dmPeerId != null)) {
      throw Exception('حدد محادثة واحدة للاستطلاع');
    }
    await Api.client.from('messages').insert({
      'sender_id': Api.myId,
      'receiver_id': isGroup ? null : dmPeerId,
      'group_id': isGroup ? groupId : null,
      'body': pollId,
      'message_type': 'poll',
    });
  }

  /// Load a poll with its options (ordered by position), live vote
  /// counts per option, and my current vote.
  static Future<PollData> fetchPoll(String pollId) async {
    final pollRows = await Api.client
        .from('polls')
        .select()
        .eq('id', pollId)
        .limit(1);
    if ((pollRows as List).isEmpty) {
      throw Exception('الاستطلاع غير موجود');
    }
    final Map<String, dynamic> p = pollRows.first;
    final optionRows = await Api.client
        .from('poll_options')
        .select()
        .eq('poll_id', pollId)
        .order('position', ascending: true);
    final options = (optionRows as List)
        .map((r) => PollOptionData.fromMap(r as Map<String, dynamic>))
        .toList();
    final voteRows = await Api.client
        .from('poll_votes')
        .select('poll_id,option_id,user_id')
        .eq('poll_id', pollId);
    String? myVote;
    for (final r in (voteRows as List)) {
      final optionId = r['option_id'] as String;
      for (final o in options) {
        if (o.id == optionId) o.voteCount++;
      }
      if (r['user_id'] == Api.myId) myVote = optionId;
    }
    return PollData(
      id: p['id'] as String,
      threadKind: (p['thread_kind'] as String?) ?? 'dm',
      dmPeerId: p['dm_peer_id'] as String?,
      groupId: (p['group_id'] as num?)?.toInt(),
      question: (p['question'] ?? '') as String,
      createdBy: p['created_by'] as String,
      createdAt: DateTime.parse(p['created_at'] as String),
      options: options,
      myVoteOptionId: myVote,
    );
  }

  /// Vote (or change my vote) for [optionId] in [pollId]. One row per
  /// user per poll: upsert on the unique (poll_id, user_id) conflict,
  /// exactly like the web app's votePoll.
  static Future<void> vote(String pollId, String optionId) async {
    await Api.client.from('poll_votes').upsert(
      {
        'poll_id': pollId,
        'option_id': optionId,
        'user_id': Api.myId,
      },
      onConflict: 'poll_id,user_id',
    );
  }
}
