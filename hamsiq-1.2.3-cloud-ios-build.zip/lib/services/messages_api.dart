// Hamsiq native — Messages (DMs) API.
// Mirrors the web app's messages backend exactly:
//   ~/workspace/chat-app/supabase-schema.sql (base table)
//   ~/workspace/chat-app/sql-v4.sql  (message_type, media_url, lat, lng)
//   ~/workspace/chat-app/sql-v12.sql (reply_to, edited_at, forwarded_from)
//   ~/workspace/chat-app/sql-v14.sql (file_name, file_size, muted_chats,
//                                     archived_chats)
//   ~/workspace/chat-app/sql-v21.sql (mark_thread_read RPC — the direct
//                                     UPDATE "receiver marks read" policy
//                                     was dropped there, so marking read
//                                     MUST go through this RPC)
//   ~/workspace/chat-app/sql-v28.sql (message_type='poll', body=<poll id>)
//
// messages columns used here (all verified in the SQL above):
//   id, sender_id, receiver_id, body, message_type, media_url,
//   created_at, read, reply_to, file_name, file_size, lat, lng.
// message_type values the web app writes: 'text', 'image', 'video',
// 'voice' (body = duration in seconds as text, media_url = audio file),
// 'file' (media_url + file_name + file_size), 'location' (lat/lng,
// body '📍'), 'contact' (body = JSON {id,name,username,avatar}),
// 'poll' (body = poll uuid).
// Media lives in the PRIVATE 'private-media' bucket (H-04 fix,
// 2026-11-16): new DM attachments and voice messages upload to
// "<my-id>/<millis>.<ext>" under the uploader's own folder and the
// stored media_url is a SHORT-LIVED SIGNED URL (1 hour), never a
// public URL. The bucket's owner-folder policy
// (auth.uid() = first folder) means only the uploader can write and
// only a signed URL grants read access. Old rows still point at
// public 'chat-media' URLs — see sql-v35.sql for the migration note.
// The web app still uploads to public chat-media (see the H-04
// report); this file intentionally does NOT mirror it any more.
//
// This file intentionally does NOT use ChatMessage from models.dart:
// that model drops media_url / reply_to / file_name / file_size /
// lat / lng, which the thread needs. DmMessage below carries them.
//
// Deliberately NOT implemented (no backend for it in the SQL):
//   - message editing (edited_at exists but there is no client-safe
//     update path for it in the web app's DM flow)
//   - poll voting UI (polls/poll_options/poll_votes tables exist, but
//     voting is a separate feature; polls render as a label tile)
//   - scheduled messages (scheduled_messages table exists; not wired)
//
// Wave 2 (sql-v30) ADDED: unsend (unsend_message RPC), view-once
// media (messages.view_once / viewed_once), vanish mode
// (messages.vanish + vanish_chats + purge_vanish_messages RPC).

import 'dart:convert';
import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../models.dart';
import 'supabase_service.dart';

/// A DM message with every column the thread renderer needs.
class DmMessage {
  final int id;
  final String senderId;
  final String? receiverId;
  final String? body;
  final String messageType;
  final String? mediaUrl;
  final DateTime createdAt;
  final bool read;
  final int? replyTo;
  final String? fileName;
  final int? fileSize;
  final double? lat;
  final double? lng;
  final DateTime? editedAt;
  // Wave 2 (sql-v30): view-once media + vanish-mode flag. False on
  // every row written before sql-v30 (columns default false).
  final bool viewOnce;
  final bool viewedOnce;
  final bool vanish;

  const DmMessage({
    required this.id,
    required this.senderId,
    this.receiverId,
    this.body,
    required this.messageType,
    this.mediaUrl,
    required this.createdAt,
    required this.read,
    this.replyTo,
    this.fileName,
    this.fileSize,
    this.lat,
    this.lng,
    this.editedAt,
    this.viewOnce = false,
    this.viewedOnce = false,
    this.vanish = false,
  });

  factory DmMessage.fromMap(Map<String, dynamic> m) => DmMessage(
        id: (m['id'] as num).toInt(),
        senderId: m['sender_id'] as String,
        receiverId: m['receiver_id'] as String?,
        body: m['body'] as String?,
        messageType: (m['message_type'] ?? 'text') as String,
        mediaUrl: m['media_url'] as String?,
        createdAt: DateTime.parse(m['created_at'] as String),
        read: (m['read'] ?? false) as bool,
        replyTo:
            m['reply_to'] == null ? null : (m['reply_to'] as num).toInt(),
        fileName: m['file_name'] as String?,
        fileSize:
            m['file_size'] == null ? null : (m['file_size'] as num).toInt(),
        lat: m['lat'] == null ? null : (m['lat'] as num).toDouble(),
        lng: m['lng'] == null ? null : (m['lng'] as num).toDouble(),
        editedAt: m['edited_at'] == null
            ? null
            : DateTime.tryParse(m['edited_at'] as String),
        viewOnce: (m['view_once'] ?? false) as bool,
        viewedOnce: (m['viewed_once'] ?? false) as bool,
        vanish: (m['vanish'] ?? false) as bool,
      );

  /// Voice duration in seconds. The web app stores it as plain text
  /// in body for message_type='voice' (e.g. "12").
  int get voiceSeconds => int.tryParse(body ?? '') ?? 0;
}

class MessagesApi {
  /// Bucket for all NEW DM media (H-04 fix). Private: only the
  /// uploader's own folder is writable and reads need a signed URL.
  /// Avatars are NOT stored here — they stay public by design and
  /// never pass through this class.
  static const chatMediaBucket = 'private-media';

  /// Signed-URL lifetime in seconds (1 hour). The URL stored in
  /// messages.media_url expires after this long; the app must re-sign
  /// on render for older messages (same pattern the web app already
  /// uses for temp files: signed_expires_at + re-sign).
  static const signedUrlTtlSeconds = 3600;

  /// Storage path for one DM attachment: "<userId>/<millis>.<ext>".
  /// The first folder MUST be the uploader's id — the private-media
  /// owner-folder policy rejects any other first folder.
  static String chatMediaPath(String userId, int millis, String ext) =>
      '$userId/$millis.$ext';

  /// True when [url] looks like a Supabase signed URL
  /// (".../object/sign/<path>?token=...") rather than a plain public
  /// URL (".../object/public/<bucket>/<path>"). Used by tests and by
  /// any render path that must decide whether to re-sign.
  static bool isSignedUrl(String url) =>
      url.contains('/object/sign/') && url.contains('token=');

  /// Short label for a chat-list subtitle. Never shows a raw media URL.
  /// [type] is message_type, [body] is the raw body (may be null).
  static String lastMessageLabel(String type, String? body) {
    switch (type) {
      case 'image':
        return '📷 صورة';
      case 'video':
        return '🎬 فيديو';
      case 'voice':
        return '🎤 رسالة صوتية';
      case 'file':
        return '📎 ملف';
      case 'location':
        return '📍 الموقع';
      case 'poll':
        return '📊 استطلاع';
      case 'shared_post':
        return '📤 منشور مشارك';
      case 'story_reply':
        return '💬 رد على قصة';
      case 'contact':
        try {
          final c = jsonDecode(body ?? '') as Map<String, dynamic>;
          final name = (c['name'] as String?)?.trim();
          if (name != null && name.isNotEmpty) return '👤 $name';
        } catch (_) {}
        return '👤 جهة اتصال';
      default:
        final t = (body ?? '').trim();
        return t.isEmpty ? 'رسالة' : t;
    }
  }

  /// Label for a [ChatMessage] (models.dart — no media fields, but the
  /// type alone is enough for every non-text label).
  static String labelForChatMessage(ChatMessage m) =>
      lastMessageLabel(m.messageType, m.body);

  /// Label for a full [DmMessage] (file messages show their real name).
  static String labelFor(DmMessage m) {
    if (m.messageType == 'file') {
      final name = (m.fileName ?? '').trim();
      return name.isEmpty ? '📎 ملف' : '📎 $name';
    }
    return lastMessageLabel(m.messageType, m.body);
  }

  /// DM thread, oldest first — same query shape as Api.fetchThread,
  /// but returns the full DmMessage (with media_url / reply_to / ...).
  static Future<List<DmMessage>> fetchThread(
    String peerId, {
    int limit = 100,
  }) async {
    final myId = Api.myId;
    final rows = await Api.client
        .from('messages')
        .select()
        .or(
          'and(sender_id.eq.$myId,receiver_id.eq.$peerId),'
          'and(sender_id.eq.$peerId,receiver_id.eq.$myId)',
        )
        .order('created_at', ascending: true)
        .limit(limit);
    return (rows as List)
        .map((r) => DmMessage.fromMap(r as Map<String, dynamic>))
        .toList();
  }

  /// Mark a whole DM thread read via the SECURITY DEFINER RPC from
  /// sql-v21. Do NOT use a direct UPDATE here: v21 dropped the
  /// "receiver marks read" UPDATE policy, so Api.markThreadRead's
  /// direct update is rejected by RLS on the live backend.
  static Future<void> markThreadRead(String peerId) async {
    await Api.client.rpc('mark_thread_read', params: {
      'p_peer_id': peerId,
    });
  }

  // ---------------- media upload ----------------

  /// Upload [bytes] to the PRIVATE 'private-media' bucket at
  /// "<my-id>/<millis>.<ext>" (H-04 fix) and return a SHORT-LIVED
  /// SIGNED URL (1 hour). Never a public URL: chat attachments and
  /// voice messages are private to the conversation. Bytes (not
  /// dart:io File) so the same call works on Android and on web.
  static Future<String> _uploadMedia(
    Uint8List bytes,
    String ext,
    String contentType,
  ) async {
    final path = chatMediaPath(
      Api.myId,
      DateTime.now().millisecondsSinceEpoch,
      ext,
    );
    await Api.client.storage.from(chatMediaBucket).uploadBinary(
          path,
          bytes,
          fileOptions: FileOptions(contentType: contentType, upsert: false),
        );
    return Api.client.storage.from(chatMediaBucket).createSignedUrl(
          path,
          signedUrlTtlSeconds,
        );
  }

  static String _extOfName(String fileName, String fallback) {
    final name = fileName.split('/').last;
    final dot = name.lastIndexOf('.');
    if (dot < 0 || dot == name.length - 1) return fallback;
    final ext = name.substring(dot + 1).toLowerCase();
    if (ext.isEmpty || ext.length > 5 || ext.contains('/')) return fallback;
    return ext;
  }

  /// Insert one message row. Only columns that exist on public.messages
  /// are ever sent (see the header comment).
  static Future<DmMessage> _insert(Map<String, dynamic> row) async {
    final rows = await Api.client.from('messages').insert(row).select();
    return DmMessage.fromMap((rows as List).first as Map<String, dynamic>);
  }

  /// Photo (or video) message. [isVideo] picks message_type 'video'
  /// with content type video/mp4; otherwise 'image' with an image
  /// content type. The media uploads to private-media and media_url
  /// holds a 1-hour signed URL (H-04 fix) — NOT the web app's public
  /// chat-media URL any more. [bytes] are the file contents,
  /// [fileName] only decides the extension — both work identically
  /// on Android and on web.
  static Future<DmMessage> sendPhotoMessage(
    String peerId,
    Uint8List bytes, {
    required String fileName,
    bool isVideo = false,
    bool vanish = false,
  }) async {
    final ext = _extOfName(fileName, isVideo ? 'mp4' : 'jpg');
    final contentType = isVideo
        ? 'video/mp4'
        : ext == 'png'
            ? 'image/png'
            : ext == 'webp'
                ? 'image/webp'
                : 'image/jpeg';
    final url = await _uploadMedia(bytes, ext, contentType);
    return _insert({
      'sender_id': Api.myId,
      'receiver_id': peerId,
      'message_type': isVideo ? 'video' : 'image',
      'body': null,
      'media_url': url,
      if (vanish) 'vanish': true,
    });
  }

  /// Voice message. The recording uploads to private-media and the
  /// row stores message_type='voice' with media_url = 1-hour signed
  /// URL (H-04 fix) and body = duration in seconds as text. [bytes]
  /// must be an .m4a recording (the `record` package with
  /// AudioEncoder.aacLc).
  static Future<DmMessage> sendVoiceMessage(
    String peerId,
    Uint8List bytes,
    int durationSeconds,
  ) async {
    final url = await _uploadMedia(bytes, 'm4a', 'audio/mp4');
    return _insert({
      'sender_id': Api.myId,
      'receiver_id': peerId,
      'message_type': 'voice',
      'body': durationSeconds.toString(),
      'media_url': url,
    });
  }

  /// Text reply: same as a text message plus reply_to = the quoted
  /// message's id (messages.reply_to bigint, sql-v12).
  static Future<DmMessage> sendReply(
    String peerId,
    String text,
    int replyToId, {
    bool vanish = false,
  }) async {
    return _insert({
      'sender_id': Api.myId,
      'receiver_id': peerId,
      'message_type': 'text',
      'body': text,
      'reply_to': replyToId,
      if (vanish) 'vanish': true,
    });
  }

  // ---------------- Wave 1: shared posts + story replies ----------------
  //
  // New message_type values (no schema change — message_type is free
  // text, sql-v4; same pattern as 'poll' in sql-v28, body = poll id):
  //   * 'shared_post' — body = <post id as text>. The DM card renders
  //     it via SharedPostCard (widgets/shared_post_card.dart), which
  //     fetches the post with ShareApi.fetchPostById and opens it on tap.
  //   * 'story_reply' — body = JSON {"story_id": <id>, "text": "<reply>"},
  //     media_url = the story's media URL (thumbnail for the DM card).
  // Both also fire a 'message' notification to the peer (best-effort:
  // a notification failure must never fail the send itself).

  /// Share a post/Reel into a 1:1 DM. Reuses the existing messages
  /// insert path ([_insert]) — same RLS as any DM.
  static Future<DmMessage> sendSharedPost(String peerId, int postId) async {
    final message = await _insert({
      'sender_id': Api.myId,
      'receiver_id': peerId,
      'message_type': 'shared_post',
      'body': postId.toString(),
    });
    try {
      await Api.client.from('notifications').insert({
        'user_id': peerId,
        'actor_id': Api.myId,
        'type': 'message',
        'post_id': postId,
      });
    } catch (_) {
      // Notification is best-effort; the share itself already sent.
    }
    return message;
  }

  /// Reply to someone's story: lands as a real DM to the story owner,
  /// quoting the story (story id + text in the JSON body, story media
  /// in media_url so the thread shows the story thumbnail).
  static Future<DmMessage> sendStoryReply(
    String peerId,
    int storyId,
    String text, {
    String? storyMediaUrl,
  }) async {
    final clean = text.trim();
    if (clean.isEmpty) throw Exception('اكتب رداً أولاً');
    final message = await _insert({
      'sender_id': Api.myId,
      'receiver_id': peerId,
      'message_type': 'story_reply',
      'body': jsonEncode({'story_id': storyId, 'text': clean}),
      'media_url': storyMediaUrl,
    });
    try {
      await Api.client.from('notifications').insert({
        'user_id': peerId,
        'actor_id': Api.myId,
        'type': 'message',
      });
    } catch (_) {
      // Notification is best-effort; the reply itself already sent.
    }
    return message;
  }

  /// Parse a 'story_reply' body back into (storyId, text). Returns
  /// nulls when the body is not the expected JSON (e.g. an old message).
  static ({int? storyId, String text}) parseStoryReplyBody(String? body) {
    try {
      final decoded = jsonDecode(body ?? '') as Map<String, dynamic>;
      final id = decoded['story_id'];
      return (
        storyId: id == null ? null : (id as num).toInt(),
        text: (decoded['text'] ?? '') as String,
      );
    } catch (_) {
      return (storyId: null, text: body ?? '');
    }
  }

  // ---------------- mute / archive ----------------
  //
  // muted_chats / archived_chats (sql-v14):
  //   primary key (user_id, chat_kind, chat_id)
  //   chat_kind 'dm', chat_id = peer id as text
  //   RLS: "muted_chats_owner" / "archived_chats_owner" —
  //   for all using (auth.uid() = user_id), so an authenticated user
  //   may insert/select/delete only their own rows. Mute/archive are
  //   implemented as insert (on) / delete (off), exactly like the web
  //   app's toggleMuteChat / toggleArchiveChat.

  static Future<Set<String>> _fetchChatIds(String table) async {
    final rows = await Api.client
        .from(table)
        .select('chat_id')
        .eq('user_id', Api.myId)
        .eq('chat_kind', 'dm');
    return (rows as List).map((r) => r['chat_id'] as String).toSet();
  }

  static Future<Set<String>> fetchMutedPeerIds() =>
      _fetchChatIds('muted_chats');

  static Future<Set<String>> fetchArchivedPeerIds() =>
      _fetchChatIds('archived_chats');

  static Future<bool> isMuted(String peerId) async =>
      (await fetchMutedPeerIds()).contains(peerId);

  static Future<bool> isArchived(String peerId) async =>
      (await fetchArchivedPeerIds()).contains(peerId);

  static Future<void> _setChatState(
    String table,
    String peerId,
    bool on,
  ) async {
    if (on) {
      await Api.client.from(table).upsert({
        'user_id': Api.myId,
        'chat_kind': 'dm',
        'chat_id': peerId,
      });
    } else {
      await Api.client
          .from(table)
          .delete()
          .eq('user_id', Api.myId)
          .eq('chat_kind', 'dm')
          .eq('chat_id', peerId);
    }
  }

  static Future<void> setMuted(String peerId, bool muted) =>
      _setChatState('muted_chats', peerId, muted);

  static Future<void> setArchived(String peerId, bool archived) =>
      _setChatState('archived_chats', peerId, archived);

  // ---------------- Wave 2: vanish mode / view-once / unsend ----------------
  //
  // Tables/columns (sql-v30):
  //   * messages.view_once / viewed_once / vanish (booleans, default
  //     false) — plain columns, no RLS change: the sender writes them
  //     on insert exactly like message_type.
  //   * vanish_chats (user_id, chat_kind, chat_id) — my per-chat vanish
  //     toggle, same shape as muted_chats/archived_chats (sql-v14).
  //   * SECURITY DEFINER functions (sql-v30): unsend_message,
  //     mark_view_once_seen, purge_vanish_messages. Deletes go through
  //     them because there is no client-safe messages DELETE policy.
  //
  // Honest limits, shown in the UI too:
  //   * Vanish / view-once do NOT prevent screenshots or copies made
  //     outside the app. The app never claims otherwise.
  //   * View-once wipes the media URL from the row when first opened;
  //     the storage object itself is not deleted by the function.

  /// Plain text message (used by the thread when vanish mode is on —
  /// Api.sendMessage has no vanish flag and lives in a file this
  /// workstream must not edit).
  static Future<DmMessage> sendTextMessage(
    String peerId,
    String text, {
    bool vanish = false,
  }) async {
    return _insert({
      'sender_id': Api.myId,
      'receiver_id': peerId,
      'message_type': 'text',
      'body': text,
      if (vanish) 'vanish': true,
    });
  }

  /// Photo/video that can be viewed once. The receiver opens it once;
  /// [markViewOnceSeen] then wipes the media URL and the row renders
  /// as expired. The sender still sees their own thumbnail + a
  /// "once" badge (opening it does not consume it).
  static Future<DmMessage> sendViewOnceMessage(
    String peerId,
    Uint8List bytes, {
    required String fileName,
    bool isVideo = false,
  }) async {
    final ext = _extOfName(fileName, isVideo ? 'mp4' : 'jpg');
    final contentType = isVideo
        ? 'video/mp4'
        : ext == 'png'
            ? 'image/png'
            : ext == 'webp'
                ? 'image/webp'
                : 'image/jpeg';
    final url = await _uploadMedia(bytes, ext, contentType);
    return _insert({
      'sender_id': Api.myId,
      'receiver_id': peerId,
      'message_type': isVideo ? 'video' : 'image',
      'body': null,
      'media_url': url,
      'view_once': true,
    });
  }

  /// Mark a view-once message I received as seen: the SECURITY
  /// DEFINER function sets viewed_once=true and clears media_url, so
  /// the message renders as expired for everyone afterwards.
  static Future<void> markViewOnceSeen(int messageId) async {
    await Api.client.rpc('mark_view_once_seen', params: {
      'p_message_id': messageId,
    });
  }

  /// Delete one of MY messages for everyone (unsend). Throws when the
  /// message is not mine — the function enforces sender = auth.uid().
  static Future<void> unsendMessage(int messageId) async {
    await Api.client.rpc('unsend_message', params: {
      'p_message_id': messageId,
    });
  }

  /// Is vanish mode on for this peer (my toggle, vanish_chats)?
  static Future<bool> isVanish(String peerId) async {
    try {
      final rows = await Api.client
          .from('vanish_chats')
          .select('chat_id')
          .eq('user_id', Api.myId)
          .eq('chat_kind', 'dm')
          .eq('chat_id', peerId)
          .limit(1);
      return (rows as List).isNotEmpty;
    } catch (_) {
      // Table missing (sql-v30 not run yet): vanish is off.
      return false;
    }
  }

  static Future<void> setVanish(String peerId, bool on) =>
      _setChatState('vanish_chats', peerId, on);

  /// Delete the vanish messages in this thread that have already been
  /// read (both directions). Called when leaving a vanish thread.
  /// Best-effort: a failure must never block leaving the thread.
  static Future<void> purgeVanishMessages(String peerId) async {
    await Api.client.rpc('purge_vanish_messages', params: {
      'p_peer_id': peerId,
    });
  }
}
