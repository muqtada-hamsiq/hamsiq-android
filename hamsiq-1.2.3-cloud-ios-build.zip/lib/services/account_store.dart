// v1.2.2: multi-account sessions (Instagram-style account switcher).
// Up to 5 accounts can stay logged in on this device. Tokens live in
// flutter_secure_storage (Keystore / EncryptedSharedPreferences on
// Android, Keychain on iOS, localStorage on web) — NEVER in plain
// SharedPreferences. Only non-secret metadata (id, username, display
// name, avatar URL) lives in SharedPreferences. The switcher only ever
// lists accounts that actually logged in on this device — no demo or
// fake accounts.

import 'dart:async';
import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'supabase_service.dart';

/// One saved account: public metadata only — no tokens here.
class SavedAccount {
  final String id;
  final String username;
  final String displayName;
  final String? avatarUrl;

  const SavedAccount({
    required this.id,
    required this.username,
    required this.displayName,
    this.avatarUrl,
  });

  factory SavedAccount.fromJson(Map<String, dynamic> m) => SavedAccount(
        id: m['id'] as String,
        username: (m['username'] ?? '') as String,
        displayName: (m['displayName'] ?? m['username'] ?? '') as String,
        avatarUrl: m['avatarUrl'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'displayName': displayName,
        'avatarUrl': avatarUrl,
      };
}

/// Minimal token-storage abstraction so tests can inject an in-memory
/// store instead of the platform secure storage.
abstract class TokenStorage {
  Future<String?> read(String key);
  Future<void> write(String key, String value);
  Future<void> delete(String key);
}

class SecureTokenStorage implements TokenStorage {
  final FlutterSecureStorage _s = const FlutterSecureStorage();

  @override
  Future<String?> read(String key) => _s.read(key: key);

  @override
  Future<void> write(String key, String value) =>
      _s.write(key: key, value: value);

  @override
  Future<void> delete(String key) => _s.delete(key: key);
}

/// In-memory token storage for tests (never used in production).
class MemoryTokenStorage implements TokenStorage {
  final Map<String, String> _m = {};

  @override
  Future<String?> read(String key) async => _m[key];

  @override
  Future<void> write(String key, String value) async {
    _m[key] = value;
  }

  @override
  Future<void> delete(String key) async {
    _m.remove(key);
  }
}

class AccountStore {
  /// Instagram's limit: at most 5 accounts in the switcher.
  static const int maxAccounts = 5;

  static const String _listKey = 'hamsiq_saved_accounts';
  static const String _currentKey = 'hamsiq_current_account';

  static final AccountStore instance = AccountStore._(
    SecureTokenStorage(),
  );

  final TokenStorage _tokens;

  /// Test seam: when set, switching exchanges the refresh token through
  /// this instead of the real Supabase call. Production passes null.
  final Future<void> Function(String refreshToken)? _refreshSession;

  AccountStore._(this._tokens) : _refreshSession = null;

  /// Testing constructor: in-memory tokens + an injected refresh call.
  AccountStore.forTest({
    required TokenStorage tokenStorage,
    Future<void> Function(String refreshToken)? refreshSession,
  })  : _tokens = tokenStorage,
        _refreshSession = refreshSession;

  bool _listening = false;

  /// Attach the auth-state listener that keeps stored tokens fresh:
  /// Supabase rotates refresh tokens on every refresh, so each
  /// SIGNED_IN / TOKEN_REFRESHED persists the current session again.
  /// Safe to call more than once.
  void init() {
    if (_listening) return;
    _listening = true;
    Api.client.auth.onAuthStateChange.listen((data) {
      if (data.event == AuthChangeEvent.signedIn ||
          data.event == AuthChangeEvent.tokenRefreshed ||
          data.event == AuthChangeEvent.userUpdated) {
        unawaited(saveCurrentSession());
      }
    });
  }

  String _accessKey(String userId) => 'hamsiq_acct_${userId}_access';
  String _refreshKey(String userId) => 'hamsiq_acct_${userId}_refresh';

  Future<List<SavedAccount>> loadAccounts() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_listKey);
    if (raw == null || raw.isEmpty) return [];
    try {
      return (jsonDecode(raw) as List)
          .map((e) => SavedAccount.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<String?> currentAccountId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_currentKey);
  }

  Future<void> _saveList(List<SavedAccount> accounts) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _listKey,
      jsonEncode(accounts.map((a) => a.toJson()).toList()),
    );
  }

  Future<void> _setCurrent(String? userId) async {
    final prefs = await SharedPreferences.getInstance();
    if (userId == null) {
      await prefs.remove(_currentKey);
    } else {
      await prefs.setString(_currentKey, userId);
    }
  }

  /// Store tokens + metadata for an account directly. Used by
  /// [saveCurrentSession] and by tests to seed saved accounts.
  Future<void> addSavedAccount(
    SavedAccount account, {
    required String accessToken,
    required String refreshToken,
  }) async {
    await _tokens.write(_accessKey(account.id), accessToken);
    await _tokens.write(_refreshKey(account.id), refreshToken);
    final accounts = await loadAccounts();
    final i = accounts.indexWhere((a) => a.id == account.id);
    if (i >= 0) {
      accounts[i] = account;
    } else {
      accounts.add(account);
      while (accounts.length > maxAccounts) {
        final current = await currentAccountId();
        final drop = accounts.indexWhere(
          (a) => a.id != current && a.id != account.id,
        );
        if (drop < 0) break;
        accounts.removeAt(drop);
      }
    }
    await _saveList(accounts);
  }

  /// Persist the CURRENT Supabase session (tokens + metadata).
  /// Called after login/signup, on app start (upgrade path), and on
  /// every token refresh (listener). Never throws — a storage failure
  /// must not break login.
  Future<void> saveCurrentSession() async {
    try {
      final session = Api.client.auth.currentSession;
      final user = Api.client.auth.currentUser;
      if (session == null || user == null) return;
      final refresh = session.refreshToken;
      if (refresh == null || refresh.isEmpty) return;
      await _tokens.write(_accessKey(user.id), session.accessToken);
      await _tokens.write(_refreshKey(user.id), refresh);

      final accounts = await loadAccounts();
      final i = accounts.indexWhere((a) => a.id == user.id);
      String username = '';
      String displayName = '';
      String? avatarUrl;
      try {
        final profile = await Api.fetchProfile(user.id);
        if (profile != null) {
          username = profile.username;
          displayName = profile.displayName;
          avatarUrl = profile.avatarUrl;
        }
      } catch (_) {
        // Offline: keep whatever metadata we already have.
      }
      if (username.isEmpty) {
        username =
            ((user.userMetadata?['username'] ?? '') as String).trim();
      }
      if (username.isEmpty && i >= 0) username = accounts[i].username;
      if (username.isEmpty) username = user.id.substring(0, 8);
      if (displayName.isEmpty && i >= 0) {
        displayName = accounts[i].displayName;
      }
      if (displayName.isEmpty) displayName = username;
      avatarUrl ??= i >= 0 ? accounts[i].avatarUrl : null;

      final entry = SavedAccount(
        id: user.id,
        username: username,
        displayName: displayName,
        avatarUrl: avatarUrl,
      );
      if (i >= 0) {
        accounts[i] = entry;
      } else {
        accounts.add(entry);
        while (accounts.length > maxAccounts) {
          final current = await currentAccountId();
          final drop = accounts.indexWhere(
            (a) => a.id != current && a.id != user.id,
          );
          if (drop < 0) break;
          accounts.removeAt(drop);
        }
      }
      await _saveList(accounts);
      await _setCurrent(user.id);
    } catch (_) {
      // Best-effort only.
    }
  }

  /// Switch to a saved account: exchange its stored refresh token for a
  /// fresh session. Throws a friendly message when the stored session
  /// has expired — the stale entry is dropped so it never blocks again.
  Future<void> switchTo(String userId) async {
    final accounts = await loadAccounts();
    SavedAccount? target;
    for (final a in accounts) {
      if (a.id == userId) {
        target = a;
        break;
      }
    }
    if (target == null) {
      throw Exception('الحساب غير محفوظ على هذا الجهاز');
    }
    final refresh = await _tokens.read(_refreshKey(userId));
    if (refresh == null || refresh.isEmpty) {
      await removeAccount(userId);
      throw Exception('انتهت جلسة هذا الحساب، سجّل دخولك من جديد');
    }
    // Keep the outgoing account's tokens fresh before leaving it.
    await saveCurrentSession();
    try {
      if (_refreshSession != null) {
        await _refreshSession(refresh);
      } else {
        final res = await Api.client.auth.refreshSession(refresh);
        if (res.session == null) throw Exception('expired');
      }
    } catch (e) {
      if (e is Exception &&
          e.toString().contains('سجّل دخولك من جديد')) {
        rethrow;
      }
      // Stale/expired stored session — drop it and ask to log in again.
      await removeAccount(userId);
      throw Exception('انتهت جلسة هذا الحساب، سجّل دخولك من جديد');
    }
    await _setCurrent(userId);
    await saveCurrentSession();
  }

  /// Remove one account from the saved list (tokens + metadata).
  Future<void> removeAccount(String userId) async {
    await _tokens.delete(_accessKey(userId));
    await _tokens.delete(_refreshKey(userId));
    final accounts = await loadAccounts();
    accounts.removeWhere((a) => a.id == userId);
    await _saveList(accounts);
    final current = await currentAccountId();
    if (current == userId) await _setCurrent(null);
  }

  /// Full logout of the current account: drop it from the saved list.
  /// Call BEFORE Api.signOut().
  Future<void> logoutCurrent() async {
    final user = Api.client.auth.currentUser;
    if (user != null) await removeAccount(user.id);
  }
}
