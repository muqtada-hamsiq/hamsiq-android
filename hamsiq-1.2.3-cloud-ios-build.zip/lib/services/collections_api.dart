// Hamsiq native — Collections API (Wave 1).
// Tables (sql-v29):
//   * public.collections: id, user_id, name, cover_url, created_at.
//     RLS: select is_approved(); insert/update/delete owner only.
//   * public.collection_posts: PK (collection_id, post_id), created_at.
//     RLS: select is_approved(); insert/delete only the collection owner
//     (subquery on collections, a different table).
//   * public.saved_posts (sql-v16): PK (user_id, post_id). Saving a post
//     into a collection ALSO inserts its saved_posts row, so the Saved
//     area keeps working; removing it from a collection leaves the
//     saved_posts row alone (unsave is a separate explicit action).

import '../models.dart';
import 'supabase_service.dart';

/// One row of public.collections.
class CollectionItem {
  final int id;
  final String userId;
  final String name;
  final String? coverUrl;
  final DateTime createdAt;
  int postCount;

  CollectionItem({
    required this.id,
    required this.userId,
    required this.name,
    this.coverUrl,
    required this.createdAt,
    this.postCount = 0,
  });

  factory CollectionItem.fromMap(Map<String, dynamic> m) => CollectionItem(
        id: (m['id'] as num).toInt(),
        userId: m['user_id'] as String,
        name: (m['name'] ?? '') as String,
        coverUrl: m['cover_url'] as String?,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

class CollectionsApi {
  /// Create one of my collections. Names are trimmed; empty names throw.
  static Future<CollectionItem> createCollection(String name) async {
    final clean = name.trim();
    if (clean.isEmpty) throw Exception('اكتب اسماً للمجموعة');
    if (clean.length > 60) throw Exception('اسم المجموعة طويل جداً');
    final rows = await Api.client.from('collections').insert({
      'user_id': Api.myId,
      'name': clean,
    }).select();
    return CollectionItem.fromMap((rows as List).first as Map<String, dynamic>);
  }

  /// Rename one of my collections.
  static Future<void> renameCollection(int collectionId, String name) async {
    final clean = name.trim();
    if (clean.isEmpty) throw Exception('اكتب اسماً للمجموعة');
    await Api.client
        .from('collections')
        .update({'name': clean})
        .eq('id', collectionId)
        .eq('user_id', Api.myId);
  }

  /// Delete one of my collections (its collection_posts rows cascade).
  static Future<void> deleteCollection(int collectionId) async {
    await Api.client
        .from('collections')
        .delete()
        .eq('id', collectionId)
        .eq('user_id', Api.myId);
  }

  /// My collections, newest first, with post counts attached.
  static Future<List<CollectionItem>> fetchMyCollections() async {
    final rows = await Api.client
        .from('collections')
        .select()
        .eq('user_id', Api.myId)
        .order('created_at', ascending: false);
    final items = (rows as List)
        .map((r) => CollectionItem.fromMap(r as Map<String, dynamic>))
        .toList();
    if (items.isEmpty) return items;
    final ids = items.map((c) => c.id).toList();
    final linkRows = await Api.client
        .from('collection_posts')
        .select('collection_id')
        .inFilter('collection_id', ids);
    final counts = <int, int>{};
    for (final r in (linkRows as List)) {
      final cid = (r['collection_id'] as num).toInt();
      counts[cid] = (counts[cid] ?? 0) + 1;
    }
    for (final c in items) {
      c.postCount = counts[c.id] ?? 0;
    }
    return items;
  }

  /// Posts inside a collection, in the order they were added.
  static Future<List<PostItem>> fetchCollectionPosts(int collectionId) async {
    final linkRows = await Api.client
        .from('collection_posts')
        .select('post_id')
        .eq('collection_id', collectionId)
        .order('created_at', ascending: true);
    final ids = [
      for (final r in (linkRows as List)) (r['post_id'] as num).toInt(),
    ];
    if (ids.isEmpty) return [];
    final rows =
        await Api.client.from('posts').select().inFilter('id', ids);
    final byId = <int, PostItem>{
      for (final r in (rows as List))
        (r['id'] as num).toInt(): PostItem.fromMap(r as Map<String, dynamic>),
    };
    final posts = [for (final id in ids) if (byId.containsKey(id)) byId[id]!];
    if (posts.isEmpty) return posts;
    final authorIds = posts.map((p) => p.userId).toSet().toList();
    final authors = await Api.fetchProfiles(authorIds);
    for (final p in posts) {
      p.author = authors[p.userId];
    }
    return posts;
  }

  /// Add a post to one of my collections. Also saves the post
  /// (saved_posts upsert) so it still appears in "All saved".
  /// Adding the same post twice is a no-op (PK is collection_id+post_id).
  static Future<void> addToCollection(int collectionId, int postId) async {
    await savePost(postId);
    try {
      await Api.client.from('collection_posts').insert({
        'collection_id': collectionId,
        'post_id': postId,
      });
    } catch (_) {
      // Already in this collection — treat as success.
    }
  }

  /// Remove a post from a collection (the saved_posts row is untouched;
  /// use [unsavePost] to remove it from Saved entirely).
  static Future<void> removeFromCollection(
    int collectionId,
    int postId,
  ) async {
    await Api.client
        .from('collection_posts')
        .delete()
        .eq('collection_id', collectionId)
        .eq('post_id', postId);
  }

  /// Which of my collections already contain this post (for checkmarks
  /// in the add-to-collection sheet).
  static Future<Set<int>> fetchCollectionsContainingPost(int postId) async {
    final rows = await Api.client
        .from('collection_posts')
        .select('collection_id')
        .eq('post_id', postId);
    final mine = await fetchMyCollections();
    final myIds = mine.map((c) => c.id).toSet();
    final out = <int>{};
    for (final r in (rows as List)) {
      final cid = (r['collection_id'] as num).toInt();
      if (myIds.contains(cid)) out.add(cid);
    }
    return out;
  }

  // ---------------- saved_posts (sql-v16) ----------------

  static Future<void> savePost(int postId) async {
    await Api.client.from('saved_posts').upsert({
      'user_id': Api.myId,
      'post_id': postId,
    }, onConflict: 'user_id,post_id');
  }

  static Future<void> unsavePost(int postId) async {
    await Api.client
        .from('saved_posts')
        .delete()
        .eq('user_id', Api.myId)
        .eq('post_id', postId);
  }

  static Future<bool> isSaved(int postId) async {
    final rows = await Api.client
        .from('saved_posts')
        .select('post_id')
        .eq('user_id', Api.myId)
        .eq('post_id', postId)
        .limit(1);
    return (rows as List).isNotEmpty;
  }

  /// IDs of my saved posts (one cheap query — drives the feed-card
  /// bookmark toggle so it shows the real saved state).
  static Future<Set<int>> fetchSavedPostIds() async {
    final rows = await Api.client
        .from('saved_posts')
        .select('post_id')
        .eq('user_id', Api.myId)
        .limit(500);
    return {
      for (final r in (rows as List)) (r['post_id'] as num).toInt(),
    };
  }

  /// Toggle save; returns true when the post is saved afterwards.
  static Future<bool> toggleSave(int postId, bool save) async {
    if (save) {
      await savePost(postId);
      return true;
    }
    await unsavePost(postId);
    return false;
  }

  /// All my saved posts, newest saved first.
  static Future<List<PostItem>> fetchSavedPosts() async {
    final savedRows = await Api.client
        .from('saved_posts')
        .select('post_id')
        .eq('user_id', Api.myId)
        .order('created_at', ascending: false)
        .limit(100);
    final ids = [
      for (final r in (savedRows as List)) (r['post_id'] as num).toInt(),
    ];
    if (ids.isEmpty) return [];
    final rows =
        await Api.client.from('posts').select().inFilter('id', ids);
    final byId = <int, PostItem>{
      for (final r in (rows as List))
        (r['id'] as num).toInt(): PostItem.fromMap(r as Map<String, dynamic>),
    };
    final posts = [for (final id in ids) if (byId.containsKey(id)) byId[id]!];
    if (posts.isEmpty) return posts;
    final authorIds = posts.map((p) => p.userId).toSet().toList();
    final authors = await Api.fetchProfiles(authorIds);
    for (final p in posts) {
      p.author = authors[p.userId];
    }
    return posts;
  }
}
