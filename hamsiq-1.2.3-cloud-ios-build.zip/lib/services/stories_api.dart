// Hamsiq native — Stories + Highlights API.
// Mirrors the web app exactly (~/workspace/chat-app/sql-v5.sql,
// sql-v16.sql, sql-v26.sql, index.html loadFeed/openStoryViewer).
//
//   stories: id bigint, user_id uuid, media_url text,
//            media_type text default 'image', created_at timestamptz,
//            expires_at timestamptz default (now() + interval '24 hours')
//   highlights: id bigint, user_id uuid, title text, cover_url text,
//               created_at timestamptz
//   highlight_stories: highlight_id bigint, story_id bigint,
//                      created_at timestamptz, PK (highlight_id, story_id)
//   story_hidden_from: owner_id uuid, hidden_id uuid (v26 — a user hides
//                      their stories FROM the hidden user)
//
// RLS: stories SELECT is enforced server-side (sql-v33.sql, audit
// fix H-03) — a story is visible to its owner, to admins, to any
// approved user when it is not a Close Friends story, and for Close
// Friends stories only to users on the owner's close_friends list
// (blocked users in either direction see nothing). The client-side
// filter below (filterCloseFriendsStories) is kept as defence in
// depth and must match the server rule. Insert into stories needs
// auth.uid() = user_id + approved; delete a story needs owner or admin.
// Wave 1 (sql-v29): story_views is a REAL table now — views are DB rows
// (recordStoryView / fetchStoryViews below), not session memory.

import 'package:supabase_flutter/supabase_flutter.dart';

import '../models.dart';
import 'messages_api.dart';
import 'supabase_service.dart';

/// One story row. `author` is attached by the UI layer via
/// Api.fetchProfiles (same pattern as PostItem.author).
class StoryItem {
  final int id;
  final String userId;
  final String? mediaUrl;
  final String mediaType; // 'image' | 'video'
  final DateTime createdAt;
  final DateTime? expiresAt;
  // Wave 2 (sql-v30): visible only to the owner's Close Friends list
  // (plus the owner). Enforced server-side by the stories SELECT
  // policy (sql-v33.sql, audit fix H-03) and kept as a client-side
  // filter too — see StoriesApi.filterCloseFriendsStories.
  final bool isCloseFriends;
  HamsiqProfile? author;

  StoryItem({
    required this.id,
    required this.userId,
    this.mediaUrl,
    required this.mediaType,
    required this.createdAt,
    this.expiresAt,
    this.isCloseFriends = false,
    this.author,
  });

  factory StoryItem.fromMap(Map<String, dynamic> m) => StoryItem(
        id: (m['id'] as num).toInt(),
        userId: m['user_id'] as String,
        mediaUrl: m['media_url'] as String?,
        mediaType: (m['media_type'] ?? 'image') as String,
        createdAt: DateTime.parse(m['created_at'] as String),
        expiresAt: m['expires_at'] == null
            ? null
            : DateTime.parse(m['expires_at'] as String),
        isCloseFriends: (m['is_close_friends'] ?? false) as bool,
      );

  /// True while the story is still live. Uses expires_at when the DB
  /// gave us one (the column defaults to created_at + 24h); otherwise
  /// falls back to created_at + 24h, exactly like the web app's
  /// expires_at > now() filter.
  bool get isActive {
    final until = expiresAt ?? createdAt.add(const Duration(hours: 24));
    return DateTime.now().isBefore(until);
  }
}

/// One user's active stories, oldest first (chronological viewing order,
/// like Instagram). Built by [StoriesApi.groupByUser].
class UserStories {
  final HamsiqProfile author;
  final List<StoryItem> stories; // oldest -> newest

  UserStories({required this.author, required this.stories});
}

/// One highlights row.
class HighlightItem {
  final int id;
  final String userId;
  final String title;
  final String? coverUrl;
  final DateTime createdAt;

  HighlightItem({
    required this.id,
    required this.userId,
    required this.title,
    this.coverUrl,
    required this.createdAt,
  });

  factory HighlightItem.fromMap(Map<String, dynamic> m) => HighlightItem(
        id: (m['id'] as num).toInt(),
        userId: m['user_id'] as String,
        title: (m['title'] ?? '') as String,
        coverUrl: m['cover_url'] as String?,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

class StoriesApi {
  /// All non-expired stories, newest first (same query as the web app's
  /// loadFeed: stories gt expires_at now, order created_at desc, limit 100).
  /// Users who hid their stories from me (story_hidden_from) are excluded,
  /// like the web app; if that table is unavailable the filter is skipped
  /// rather than hiding every story. Close Friends stories are kept only
  /// for the owner + list members: the server enforces this (sql-v33.sql,
  /// audit fix H-03) and the client-side filter below is defence in depth
  /// using the same rule, so this method never returns a Close Friends
  /// story I may not see.
  static Future<List<StoryItem>> fetchActiveStories({int limit = 100}) async {
    final nowIso = DateTime.now().toUtc().toIso8601String();
    final rows = await Api.client
        .from('stories')
        .select()
        .gt('expires_at', nowIso)
        .order('created_at', ascending: false)
        .limit(limit);
    var stories = (rows as List)
        .map((r) => StoryItem.fromMap(r as Map<String, dynamic>))
        .toList();
    try {
      final hidden = await Api.client
          .from('story_hidden_from')
          .select('owner_id')
          .eq('hidden_id', Api.myId);
      final hiddenIds = {
        for (final r in (hidden as List)) r['owner_id'] as String,
      };
      if (hiddenIds.isNotEmpty) {
        stories = stories.where((s) => !hiddenIds.contains(s.userId)).toList();
      }
    } catch (_) {
      // story_hidden_from missing/unreadable: show all active stories.
    }
    final cfOwners = await fetchCloseFriendOwnerIds();
    return filterCloseFriendsStories(stories, cfOwners, Api.myId);
  }

  /// Active stories of one user, oldest first (viewer order). The same
  /// Close Friends rule as [fetchActiveStories] applies (server-enforced
  /// by sql-v33.sql, client-filtered here as defence in depth): a
  /// non-member never sees another user's Close Friends stories.
  static Future<List<StoryItem>> fetchUserStories(String userId) async {
    final nowIso = DateTime.now().toUtc().toIso8601String();
    final rows = await Api.client
        .from('stories')
        .select()
        .eq('user_id', userId)
        .gt('expires_at', nowIso)
        .order('created_at', ascending: true)
        .limit(50);
    final stories = (rows as List)
        .map((r) => StoryItem.fromMap(r as Map<String, dynamic>))
        .toList();
    final cfOwners = await fetchCloseFriendOwnerIds();
    return filterCloseFriendsStories(stories, cfOwners, Api.myId);
  }

  /// Publish a story. expires_at is NOT sent — the DB defaults it to
  /// now() + 24 hours (sql-v5.sql), exactly like the web app's insert.
  static Future<StoryItem> publishStory(
    String mediaUrl,
    String mediaType,
  ) async {
    final rows = await Api.client.from('stories').insert({
      'user_id': Api.myId,
      'media_url': mediaUrl,
      'media_type': mediaType,
    }).select();
    return StoryItem.fromMap((rows as List).first as Map<String, dynamic>);
  }

  /// Delete my own story (RLS: owner or admin).
  static Future<void> deleteStory(int storyId) async {
    await Api.client.from('stories').delete().eq('id', storyId);
  }

  /// Group flat stories (newest first) into per-user groups, oldest
  /// story first inside each group, newest group first — the shape the
  /// story bar and viewer consume. Authors must be fetched first via
  /// Api.fetchProfiles; users without a profile row are skipped.
  static List<UserStories> groupByUser(
    List<StoryItem> stories,
    Map<String, HamsiqProfile> authors,
  ) {
    final byUser = <String, List<StoryItem>>{};
    for (final s in stories) {
      byUser.putIfAbsent(s.userId, () => []).add(s);
    }
    final out = <UserStories>[];
    for (final entry in byUser.entries) {
      final author = authors[entry.key];
      if (author == null) continue;
      final list = entry.value..sort((a, b) => a.createdAt.compareTo(b.createdAt));
      for (final s in list) {
        s.author = author;
      }
      out.add(UserStories(author: author, stories: list));
    }
    // Newest group first (by the group's latest story).
    out.sort((a, b) => b.stories.last.createdAt.compareTo(a.stories.last.createdAt));
    return out;
  }

  // ---------------- highlights ----------------

  /// Highlights of a user, newest first.
  static Future<List<HighlightItem>> fetchHighlights(String userId) async {
    final rows = await Api.client
        .from('highlights')
        .select()
        .eq('user_id', userId)
        .order('created_at', ascending: false);
    return (rows as List)
        .map((r) => HighlightItem.fromMap(r as Map<String, dynamic>))
        .toList();
  }

  /// Stories saved in a highlight, in the order they were added.
  /// Highlights keep stories even after they expire (same as the web
  /// app: no expires_at filter here), so an expired story row may be
  /// gone from `stories` — missing rows are simply skipped.
  static Future<List<StoryItem>> fetchHighlightStories(int highlightId) async {
    final linkRows = await Api.client
        .from('highlight_stories')
        .select('story_id')
        .eq('highlight_id', highlightId)
        .order('created_at', ascending: true);
    final ids = [
      for (final r in (linkRows as List)) (r['story_id'] as num).toInt(),
    ];
    if (ids.isEmpty) return [];
    final rows =
        await Api.client.from('stories').select('*').inFilter('id', ids);
    final byId = <int, StoryItem>{
      for (final r in (rows as List))
        (r['id'] as num).toInt(): StoryItem.fromMap(r as Map<String, dynamic>),
    };
    return [for (final id in ids) if (byId.containsKey(id)) byId[id]!];
  }

  /// Create one of my highlights.
  static Future<HighlightItem> createHighlight(
    String title, {
    String? coverUrl,
  }) async {
    final rows = await Api.client.from('highlights').insert({
      'user_id': Api.myId,
      'title': title.trim(),
      'cover_url': coverUrl,
    }).select();
    return HighlightItem.fromMap((rows as List).first as Map<String, dynamic>);
  }

  /// Add a story to one of my highlights named [name]: reuses an existing
  /// highlight with that title, otherwise creates it. The highlight's
  /// cover is set from the story's media when it has none yet (same as
  /// the web app's highlight picker). Adding the same story twice is a
  /// no-op (PK is highlight_id + story_id).
  static Future<HighlightItem> addToHighlight(int storyId, String name) async {
    final title = name.trim();
    if (title.isEmpty) throw Exception('اكتب اسماً للأبرز');
    final existing = await fetchHighlights(Api.myId);
    HighlightItem? highlight;
    for (final h in existing) {
      if (h.title == title) {
        highlight = h;
        break;
      }
    }
    String? coverUrl;
    if (highlight == null || highlight.coverUrl == null) {
      final storyRows = await Api.client
          .from('stories')
          .select('media_url')
          .eq('id', storyId)
          .limit(1);
      if ((storyRows as List).isNotEmpty) {
        coverUrl = storyRows.first['media_url'] as String?;
      }
    }
    highlight ??= await createHighlight(title, coverUrl: coverUrl);
    if (highlight.coverUrl == null && coverUrl != null) {
      await Api.client
          .from('highlights')
          .update({'cover_url': coverUrl})
          .eq('id', highlight.id);
      highlight = HighlightItem(
        id: highlight.id,
        userId: highlight.userId,
        title: highlight.title,
        coverUrl: coverUrl,
        createdAt: highlight.createdAt,
      );
    }
    try {
      await Api.client.from('highlight_stories').insert({
        'highlight_id': highlight.id,
        'story_id': storyId,
      });
    } catch (_) {
      // Already in this highlight (unique PK) — treat as success.
    }
    return highlight;
  }

  /// Delete one of my highlights (its highlight_stories rows cascade).
  static Future<void> deleteHighlight(int highlightId) async {
    await Api.client.from('highlights').delete().eq('id', highlightId);
  }

  // ---------------- story views (Wave 1, sql-v29) ----------------
  //
  // public.story_views: id, story_id, viewer_id, created_at,
  // unique (story_id, viewer_id). One REAL DB row per viewer — the
  // viewer list + count come from this table, never from session memory
  // (the old StoryBar _seenUserIds set stays as a ring tint only).
  // RLS: select = viewer / story owner / admin; insert = own view on an
  // existing story; delete = viewer / story owner / admin.

  /// Record that I viewed [storyId]. Idempotent (upsert on the unique
  /// pair); a second view of the same story is a no-op. Failures are
  /// swallowed by the caller — a view must never break story playback.
  static Future<void> recordStoryView(int storyId) async {
    await Api.client.from('story_views').upsert({
      'story_id': storyId,
      'viewer_id': Api.myId,
    }, onConflict: 'story_id,viewer_id');
  }

  /// Who viewed a story, newest view first, with viewer profiles
  /// attached. Only the story owner (or the viewer themself, or admin)
  /// can read these rows under RLS — callers must be the owner.
  static Future<List<StoryView>> fetchStoryViews(int storyId) async {
    final rows = await Api.client
        .from('story_views')
        .select()
        .eq('story_id', storyId)
        .order('created_at', ascending: false);
    final views = (rows as List)
        .map((r) => StoryView.fromMap(r as Map<String, dynamic>))
        .toList();
    if (views.isEmpty) return views;
    final viewerIds = views.map((v) => v.viewerId).toSet().toList();
    final viewers = await Api.fetchProfiles(viewerIds);
    for (final v in views) {
      v.viewer = viewers[v.viewerId];
    }
    return views;
  }

  /// View count for one story (counted from the real rows).
  static Future<int> fetchStoryViewCount(int storyId) async {
    final r = await Api.client
        .from('story_views')
        .select('id')
        .eq('story_id', storyId)
        .count(CountOption.exact);
    return r.count;
  }

  // ---------------- story replies (Wave 1) ----------------
  //
  // The send itself lives in MessagesApi.sendStoryReply (the messages
  // insert path); this is a thin delegate so story UI only imports
  // StoriesApi. The reply lands as a real DM to the story owner.

  static Future<void> replyToStory(
    String ownerId,
    StoryItem story,
    String text,
  ) async {
    final clean = text.trim();
    if (clean.isEmpty) throw Exception('اكتب رداً أولاً');
    await MessagesApi.sendStoryReply(
      ownerId,
      story.id,
      clean,
      storyMediaUrl: story.mediaUrl,
    );
  }

  // ---------------- Close Friends (Wave 2, sql-v30) ----------------
  //
  // public.close_friends: (user_id, friend_id) — my list, people I
  // follow. RLS: the owner reads/writes their own rows; a friend can
  // read the rows that name them (so the story bar can check "am I on
  // this owner's list?"). stories.is_close_friends marks a story.
  //
  // Server-enforced since sql-v33.sql (audit fix H-03): the stories
  // SELECT policy only returns a Close Friends story to its owner, to
  // admins, and to users on the owner's close_friends list (blocked
  // users in either direction see nothing). The client-side filter
  // below (fetchCloseFriendOwnerIds + filterCloseFriendsStories) is
  // kept as defence in depth using the same rule — it must never be
  // weaker than the server policy. A direct API read can no longer
  // fetch a Close Friends story the reader may not see.

  /// Publish a story visible only to my Close Friends (green ring).
  static Future<StoryItem> publishCloseFriendsStory(
    String mediaUrl,
    String mediaType,
  ) async {
    final rows = await Api.client.from('stories').insert({
      'user_id': Api.myId,
      'media_url': mediaUrl,
      'media_type': mediaType,
      'is_close_friends': true,
    }).select();
    return StoryItem.fromMap((rows as List).first as Map<String, dynamic>);
  }

  /// Owner ids whose Close Friends list includes ME. The story bar
  /// keeps a Close Friends story only when its owner is me or in this
  /// set. Returns empty when the table is missing (sql-v30 not run).
  static Future<Set<String>> fetchCloseFriendOwnerIds() async {
    try {
      final rows = await Api.client
          .from('close_friends')
          .select('user_id')
          .eq('friend_id', Api.myId);
      return {
        for (final r in (rows as List)) r['user_id'] as String,
      };
    } catch (_) {
      return {};
    }
  }

  /// Pure helper: keep only the stories I may see — every public story,
  /// plus Close Friends stories from owners who listed me (or my own).
  /// Kept separate so it is unit testable without a session.
  static List<StoryItem> filterCloseFriendsStories(
    List<StoryItem> stories,
    Set<String> ownerIdsIncludingMe,
    String myId,
  ) {
    return stories.where((s) {
      if (!s.isCloseFriends) return true;
      if (s.userId == myId) return true;
      return ownerIdsIncludingMe.contains(s.userId);
    }).toList();
  }
}

/// One row of public.story_views (sql-v29), with the viewer profile
/// attached when available.
class StoryView {
  final int id;
  final int storyId;
  final String viewerId;
  final DateTime createdAt;
  HamsiqProfile? viewer;

  StoryView({
    required this.id,
    required this.storyId,
    required this.viewerId,
    required this.createdAt,
    this.viewer,
  });

  factory StoryView.fromMap(Map<String, dynamic> m) => StoryView(
        id: (m['id'] as num).toInt(),
        storyId: (m['story_id'] as num).toInt(),
        viewerId: m['viewer_id'] as String,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}
