// Android/io implementation of lib/services/platform_file.dart.
// Exactly the behavior the app had before this file existed.

import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

String voiceTempPath(String name) =>
    '${Directory.systemTemp.path}/$name';

Future<void> deleteFileQuietly(String path) async {
  try {
    final f = File(path);
    if (await f.exists()) await f.delete();
  } catch (_) {}
}

VideoPlayerController videoControllerFor(XFile file) =>
    VideoPlayerController.file(File(file.path));

Widget pickedImage(
  XFile file, {
  double? height,
  double? width,
  BoxFit fit = BoxFit.cover,
}) =>
    Image.file(
      File(file.path),
      height: height,
      width: width,
      fit: fit,
    );

Future<Uint8List> readPickedBytes(XFile file) => file.readAsBytes();

Future<Uint8List> readPathBytes(String path) => File(path).readAsBytes();
