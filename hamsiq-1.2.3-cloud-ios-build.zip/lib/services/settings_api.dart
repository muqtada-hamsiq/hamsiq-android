// Hamsiq native — Settings API layer (rebuilt from scratch, v1.2.0).
// Only the functions the new Settings screen needs. Every field written
// here exists in the real Supabase backend — verified against
// ~/workspace/chat-app/supabase-schema.sql + sql-v9.sql + sql-v26.sql
// and the web app's index.html (saveProfileFields / changePassword).
//
// profiles privacy columns (sql-v9): is_private, dm_privacy ('all' |
// 'friends'), notif_messages, notif_likes, notif_followers, notif_mentions.
// profiles privacy columns (sql-v26): comment_privacy, mention_privacy
// ('all' | 'followers' | 'none').
// Change password: web app uses sb.auth.updateUser({ password }) with
// isStrongPassword = length >= 8 && a letter (Latin or Arabic) && a digit.
// NEVER use the service_role key; only the public anon key (in Api).

import 'package:supabase_flutter/supabase_flutter.dart';

import 'supabase_service.dart';

class SettingsApi {
  /// All profiles columns the Settings screen may write. Anything not in
  /// this list is refused by [setPrivacy] — no invented columns, ever.
  static const List<String> privacyFields = [
    'is_private',
    'dm_privacy',
    'comment_privacy',
    'mention_privacy',
    'notif_messages',
    'notif_likes',
    'notif_followers',
    'notif_mentions',
  ];

  /// Allowed values for the text privacy columns (DB CHECK constraints:
  /// sql-v9 profiles_dm_privacy_check, sql-v26
  /// profiles_comment_privacy_chk / profiles_mention_privacy_chk).
  static const Map<String, List<String>> allowedValues = {
    'dm_privacy': ['all', 'friends'],
    'comment_privacy': ['all', 'followers', 'none'],
    'mention_privacy': ['all', 'followers', 'none'],
  };

  static const String _privacySelect = 'is_private,dm_privacy,'
      'comment_privacy,mention_privacy,'
      'notif_messages,notif_likes,notif_followers,notif_mentions';

  /// Read my profiles row's privacy fields (defaults applied by the web
  /// app when a column is null: booleans default true except is_private).
  static Future<Map<String, dynamic>> fetchMyPrivacy() async {
    final rows = await Api.client
        .from('profiles')
        .select(_privacySelect)
        .eq('id', Api.myId)
        .limit(1);
    if (rows.isEmpty) {
      throw Exception('الملف الشخصي غير موجود');
    }
    return Map<String, dynamic>.from(rows.first);
  }

  /// Update exactly one real privacy column on my profiles row.
  /// Throws on an unknown field or an out-of-range value — the UI never
  /// sends one, but the guard keeps a typo from writing a bad column.
  static Future<void> setPrivacy(String field, dynamic value) async {
    if (!privacyFields.contains(field)) {
      throw Exception('حقل غير معروف: $field');
    }
    final allowed = allowedValues[field];
    if (allowed != null && !allowed.contains(value)) {
      throw Exception('قيمة غير صالحة لـ $field: $value');
    }
    await Api.client
        .from('profiles')
        .update({field: value}).eq('id', Api.myId);
  }

  // ---------------- password ----------------

  /// The app's password rule (web: isStrongPassword in index.html):
  /// at least 8 chars, at least one letter (Latin or Arabic) and one digit.
  static bool isStrongPassword(String p) =>
      p.length >= 8 &&
      RegExp(r'[A-Za-z\u0600-\u06FF]').hasMatch(p) &&
      RegExp(r'\d').hasMatch(p);

  /// Change my password (web: sb.auth.updateUser({ password })).
  /// The client-side rule is checked first; Supabase enforces its own
  /// minimum too. Requires a live session — the caller must be logged in.
  static Future<void> changePassword(String newPassword) async {
    if (!isStrongPassword(newPassword)) {
      throw Exception(
        'كلمة المرور ضعيفة: 8 أحرف على الأقل، حرف ورقم واحد على الأقل',
      );
    }
    await Api.client.auth.updateUser(
      UserAttributes(password: newPassword),
    );
  }
}
