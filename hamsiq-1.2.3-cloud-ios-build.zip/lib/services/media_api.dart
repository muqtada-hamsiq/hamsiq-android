// Hamsiq native — media uploads beyond images (video / audio).
// Uploads to the PRIVATE 'private-media' bucket (H-04 fix,
// 2026-11-16) and returns a SHORT-LIVED SIGNED URL (1 hour), never
// a public URL. Images stay in Api.uploadImage — this file only adds
// the two types the camera and voice features need.
//
// Callers (stories, reels, reel voiceover) already build their path
// with uniqueVideoPath / uniqueAudioPath, which prefix the uploader's
// own id — the private-media owner-folder policy requires exactly
// that first folder. uploadVideo / uploadAudio additionally REJECT a
// path whose first folder is not the uploader's id, instead of
// letting the storage policy fail opaquely.
//
// Signed URLs expire after 1 hour, but stories live 24h and
// reels/posts live indefinitely. Every render site re-signs on
// demand — MediaApi.ensureFreshUrl below (H-04 completion,
// 2026-11-16). Primary path: the server-side `resign-media` Edge
// Function, which verifies (with the requester's own JWT, under RLS)
// that the requester can read a row referencing the media and then
// mints a fresh 1-hour URL with the service_role key. That closes
// the recipient gap: the private-media SELECT policy is owner-only,
// so a RECIPIENT cannot re-sign client-side with createSignedUrl,
// but CAN re-sign through the function. Fallback: direct
// createSignedUrl (works for the uploader's own media). If both
// fail, the original URL is returned unchanged (best-effort —
// rendering is never broken by a re-sign failure).
// Avatars are NOT affected: they never pass through this file and
// stay public by design (web app: avatars bucket).

import 'dart:convert';
import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';
import 'supabase_service.dart';

/// Seam for tests: invokes the `resign-media` Edge Function and
/// returns its decoded JSON body. Production uses
/// [SupabaseClient.functions.invoke]. Mirrors the
/// [SecureLoginInvoker] seam in secure_login.dart.
typedef MediaResignInvoker = Future<Map<String, dynamic>> Function(
  Map<String, dynamic> body,
);

/// Seam for tests: mints a signed URL directly from Storage.
/// Production uses [SupabaseStorageClient.createSignedUrl].
typedef MediaDirectSigner = Future<String> Function(
  String bucket,
  String path,
);

class MediaApi {
  /// Bucket for all NEW video/audio uploads (H-04 fix). Private:
  /// only the uploader's own folder is writable and reads need a
  /// signed URL.
  static const bucket = 'private-media';

  /// Name of the server-side re-sign Edge Function
  /// (supabase/functions/resign-media/index.ts).
  static const resignFunctionName = 'resign-media';

  /// Signed-URL lifetime in seconds (1 hour). See the header note:
  /// render paths must re-sign after expiry.
  static const signedUrlTtlSeconds = 3600;

  /// Margin before expiry at which a signed URL is treated as stale
  /// and re-signed on render (5 minutes). A URL that expires
  /// mid-view would otherwise 403 halfway through playback.
  static const resignMargin = Duration(minutes: 5);

  /// Split a Supabase signed URL
  /// (".../storage/v1/object/sign/<bucket>/<path>?token=...") into
  /// its bucket + storage path. Pure. Returns null for public URLs
  /// and anything that is not a signed storage URL.
  static ({String bucket, String path})? parseSignedUrl(String url) {
    final uri = Uri.tryParse(url);
    if (uri == null) return null;
    if ((uri.queryParameters['token'] ?? '').isEmpty) return null;
    final segments = uri.pathSegments;
    final signAt = segments.indexOf('sign');
    if (signAt < 1 || segments[signAt - 1] != 'object') return null;
    if (signAt + 2 >= segments.length) return null;
    final bucket = segments[signAt + 1];
    final path = segments.sublist(signAt + 2).join('/');
    if (bucket.isEmpty || path.isEmpty) return null;
    return (bucket: bucket, path: path);
  }

  /// Expiry of a Supabase signed URL, read from the JWT `exp` claim
  /// in its `token` query parameter. Pure (no verification — the
  /// token is only used to decide WHEN to re-sign, never to grant
  /// access). Returns null when the URL is not a signed URL or the
  /// token has no readable `exp`.
  static DateTime? signedUrlExpiry(String url) {
    final uri = Uri.tryParse(url);
    final token = uri?.queryParameters['token'];
    if (token == null || token.isEmpty) return null;
    final parts = token.split('.');
    if (parts.length != 3) return null;
    try {
      final payload = utf8.decode(
        base64Url.decode(base64Url.normalize(parts[1])),
      );
      final claims = jsonDecode(payload) as Map<String, dynamic>;
      final exp = claims['exp'];
      if (exp is! num) return null;
      return DateTime.fromMillisecondsSinceEpoch(
        exp.toInt() * 1000,
        isUtc: true,
      );
    } catch (_) {
      return null;
    }
  }

  /// True when [url] is a signed URL whose expiry is past, or within
  /// [margin] of [now]. Public URLs and signed URLs with an
  /// unreadable expiry return false (nothing to re-sign, or nothing
  /// we can tell — the render falls back to the URL as stored).
  static bool needsResign(
    String url, {
    Duration margin = resignMargin,
    DateTime? now,
  }) {
    final expiry = signedUrlExpiry(url);
    if (expiry == null) return false;
    final at = (now ?? DateTime.now()).toUtc();
    return !expiry.isAfter(at.add(margin));
  }

  /// Re-sign-on-render (H-04 completion): return a fresh signed URL
  /// for [url] when it is expired or about to expire, otherwise
  /// return [url] unchanged (no extra network call for fresh or
  /// public URLs).
  ///
  /// Primary path: the server-side `resign-media` Edge Function
  /// (via [SupabaseClient.functions.invoke], with the user's JWT
  /// attached automatically). It verifies under RLS that the caller
  /// can read a row referencing the media, so a RECIPIENT can
  /// re-sign media sent to them — the case direct Storage signing
  /// cannot serve (private-media SELECT is owner-only).
  ///
  /// Fallback: direct [SupabaseStorageClient.createSignedUrl]
  /// (works for the uploader's own media). If both fail, the
  /// original URL is returned unchanged — best-effort, rendering is
  /// never broken by a re-sign failure (the stale URL 403s only if
  /// it really is expired).
  ///
  /// [resignInvoker] / [directSigner] are test seams (mirroring
  /// SecureLoginInvoker): when both are supplied, no Supabase
  /// client is touched, so the whole chain is unit-testable offline.
  /// [client] overrides the default [Api.client] for the same reason.
  static Future<String> ensureFreshUrl(
    String url, {
    Duration margin = resignMargin,
    SupabaseClient? client,
    MediaResignInvoker? resignInvoker,
    MediaDirectSigner? directSigner,
  }) async {
    if (!needsResign(url, margin: margin)) return url;
    final parsed = parseSignedUrl(url);
    if (parsed == null) return url;
    // Resolved lazily: when the test seams are provided, the client
    // is never touched (no Supabase.instance access in tests).
    SupabaseClient resolveClient() => client ?? Api.client;
    // 1) Server-side re-sign — only for the private-media bucket,
    // the only bucket the function ever signs.
    if (parsed.bucket == bucket) {
      try {
        final invoke =
            resignInvoker ?? _defaultResignInvoker(resolveClient());
        final data = await invoke(
          {'bucket': parsed.bucket, 'path': parsed.path},
        );
        final signed = data['signedUrl'];
        if (signed is String && signed.isNotEmpty) return signed;
        // Malformed 200 body (no signedUrl): fall through to direct.
      } catch (_) {
        // 401/403/500/network: fall through to direct signing.
      }
    }
    // 2) Direct Storage signing (uploader's own media).
    try {
      final sign = directSigner ?? _defaultDirectSigner(resolveClient());
      return await sign(parsed.bucket, parsed.path);
    } catch (_) {
      return url;
    }
  }

  static MediaResignInvoker _defaultResignInvoker(SupabaseClient c) {
    return (Map<String, dynamic> body) async {
      final res = await c.functions.invoke(resignFunctionName, body: body);
      final data = res.data;
      if (data is! Map<String, dynamic>) {
        throw Exception('resign-media returned no JSON body');
      }
      return data;
    };
  }

  static MediaDirectSigner _defaultDirectSigner(SupabaseClient c) {
    return (String bucket, String path) =>
        c.storage.from(bucket).createSignedUrl(path, signedUrlTtlSeconds);
  }

  /// Pure path builder: "<userId>/<prefix>-<millis>.<ext>".
  /// The first folder MUST be the uploader's id (owner-folder
  /// policy). Kept pure (takes [userId] explicitly) so tests can
  /// assert the folder rule without a signed-in session.
  static String pathForUser(
    String userId,
    String prefix,
    String ext,
    int millis,
  ) =>
      '$userId/$prefix-$millis.$ext';

  /// Upload mp4 video bytes (camera clip, story, reel). Returns the
  /// 1-hour SIGNED URL, or null on failure (same contract as
  /// Api.uploadImage). Bytes (not dart:io File) so the same call
  /// works on Android and web.
  static Future<String?> uploadVideo(Uint8List bytes, String path) async {
    _requireOwnFolder(path);
    await Api.client.storage.from(bucket).uploadBinary(
          path,
          bytes,
          fileOptions: const FileOptions(
            contentType: 'video/mp4',
            upsert: false,
          ),
        );
    return Api.client.storage.from(bucket).createSignedUrl(
          path,
          signedUrlTtlSeconds,
        );
  }

  /// Upload audio bytes (voice message, .m4a from the record plugin).
  /// Returns the 1-hour SIGNED URL, or null on failure.
  static Future<String?> uploadAudio(Uint8List bytes, String path) async {
    _requireOwnFolder(path);
    await Api.client.storage.from(bucket).uploadBinary(
          path,
          bytes,
          fileOptions: const FileOptions(
            contentType: 'audio/mp4',
            upsert: false,
          ),
        );
    return Api.client.storage.from(bucket).createSignedUrl(
          path,
          signedUrlTtlSeconds,
        );
  }

  /// Unique storage path for a video, e.g. "<myId>/story-1731599999999.mp4".
  static String uniqueVideoPath(String prefix) => pathForUser(
        Api.myId,
        prefix,
        'mp4',
        DateTime.now().millisecondsSinceEpoch,
      );

  /// Unique storage path for an audio file, e.g. "<myId>/voice-....m4a".
  static String uniqueAudioPath(String prefix) => pathForUser(
        Api.myId,
        prefix,
        'm4a',
        DateTime.now().millisecondsSinceEpoch,
      );

  /// Guard: the private-media owner-folder policy only allows writes
  /// under the uploader's own id. Fail fast with a readable error
  /// instead of a bare storage-policy rejection.
  static void _requireOwnFolder(String path) {
    final firstFolder = path.split('/').first;
    if (firstFolder.isEmpty || firstFolder != Api.myId) {
      throw Exception(
        'Media upload path must start with the uploader id folder',
      );
    }
  }
}
