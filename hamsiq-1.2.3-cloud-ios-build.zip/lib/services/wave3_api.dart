// Hamsiq native — Wave 3 API (Instagram features, sql-v31).
// One home for the Wave 3 features that do not belong to an existing
// API file: Reels editor data (text overlays / voiceover / templates),
// Collab posts (up to 5 collaborators), broadcast channels, and Blend.
//
// Tables (all sql-v31, RLS hard rules respected — auth.uid() and
// SECURITY DEFINER helpers only, no policy queries its own table):
//   posts.reel_text_overlays (jsonb) / reel_voiceover_url /
//     reel_template — Reels editor data on the post row itself; the
//     v29 owner UPDATE policy already allows the owner to write them.
//   post_collaborators (post_id, user_id, status, invited_by) —
//     invites via invite_collaborator() RPC, accept/decline via
//     respond_collab_invite() RPC (no INSERT/UPDATE policy at all).
//   channels / channel_members / channel_posts / channel_reactions —
//     broadcast channels: only the channel OWNER posts; members react.
//   blends (user_a, user_b, status, created_by) — Blend opt-in;
//     accept/decline via respond_blend_invite() RPC, end via
//     end_blend() RPC (no UPDATE policy). The Blend feed itself needs
//     no new table: it mixes reels both friends liked (post_likes) +
//     reels shared in their DM (messages 'shared_post').
//
// Honest limits, repeated in the UI wherever they apply:
//   * Collab: a post shows on a collaborator's profile only once the
//     profile grid reads post_collaborators — fetchCoAuthoredPosts
//     provides the data; the profile screen wires it in a later step.
//     The post detail screen already shows the co-authors.
//   * Channels are public/discoverable (Instagram: public channels);
//     anyone approved can READ a channel — membership only matters
//     for reacting, and only the owner posts (Instagram also lets
//     invited collaborators post; not faked here).
//   * Blend refreshes when the screen opens; there is no daily server
//     refresh. Instagram's >1,000-followers channel-creation gate is
//     NOT enforced here.

import '../models.dart';
import 'app_strings.dart';
import 'supabase_service.dart';

// ---------------------------------------------------------------------------
// Pure helpers (unit testable without a session)
// ---------------------------------------------------------------------------

/// Instagram's collaborator limit (inventory §6: up to 5 collaborators,
/// 6 profiles total including the author).
const int maxCollaborators = 5;

/// Emoji a channel member can react with (Instagram channel reactions
/// are a small fixed set; the full keyboard is not offered here).
const List<String> channelReactionEmojis = [
  '❤️',
  '😂',
  '😮',
  '😢',
  '😡',
  '👍',
];

/// Text overlays visible at [positionSec] seconds into the video.
List<ReelTextOverlay> overlaysVisibleAt(
  List<ReelTextOverlay> overlays,
  double positionSec,
) =>
    overlays.where((o) => o.visibleAt(positionSec)).toList();

/// A built-in Reel template: preset timed text slots. These are real
/// layouts applied to the user's own video — no "AI" generation, no
/// fake rendering; the user edits every placeholder text afterwards.
class ReelTemplate {
  final String id;
  final String nameAr;
  // H-06 Part 2: English template name, shown in English mode.
  final String nameEn;
  final String descriptionAr;
  final List<ReelTextOverlay> overlays;

  const ReelTemplate({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.descriptionAr,
    required this.overlays,
  });

  /// Display name in the current language (English in English mode).
  /// NOTE: the editor dropdown/toast in lib/screens/reels_editor_screen.dart
  /// still read `nameAr` directly — they need a one-line swap each to
  /// `t.name` (that file is outside the H-06 Part 2 scope).
  String get name => AppStrings.isArabic ? nameAr : nameEn;
}

/// The built-in templates (timed text slots, standard transitions
/// between the slots — the video itself is the user's own clip).
const List<ReelTemplate> reelTemplates = [
  ReelTemplate(
    id: 'title',
    nameAr: 'عنوان وخاتمة',
    nameEn: 'Title & outro',
    descriptionAr: 'عنوان أعلى الفيديو أول 3 ثوانٍ، وخاتمة أسفله',
    overlays: [
      ReelTextOverlay(
        text: 'عنوان الريلز',
        x: 0.5,
        y: 0.12,
        color: 0xFFFFFFFF,
        size: 30,
        startSec: 0,
        endSec: 3,
      ),
      ReelTextOverlay(
        text: 'تابعوني للمزيد',
        x: 0.5,
        y: 0.85,
        color: 0xFFFFFFFF,
        size: 20,
        startSec: 6,
        endSec: 9,
      ),
    ],
  ),
  ReelTemplate(
    id: 'quote',
    nameAr: 'اقتباس',
    nameEn: 'Quote',
    descriptionAr: 'اقتباس في منتصف الفيديو طوال مدته',
    overlays: [
      ReelTextOverlay(
        text: 'اكتب اقتباسك هنا',
        x: 0.5,
        y: 0.45,
        color: 0xFFFFFFFF,
        size: 26,
        startSec: 0,
        endSec: 15,
      ),
    ],
  ),
  ReelTemplate(
    id: 'before_after',
    nameAr: 'قبل / بعد',
    nameEn: 'Before / After',
    descriptionAr: '«قبل» أول 3 ثوانٍ ثم «بعد» لباقي الفيديو',
    overlays: [
      ReelTextOverlay(
        text: 'قبل',
        x: 0.5,
        y: 0.12,
        color: 0xFFFFFFFF,
        size: 30,
        startSec: 0,
        endSec: 3,
      ),
      ReelTextOverlay(
        text: 'بعد',
        x: 0.5,
        y: 0.12,
        color: 0xFFFFFFFF,
        size: 30,
        startSec: 3,
        endSec: 9,
      ),
    ],
  ),
];

/// Template by id, or null for null / unknown ids (plain reel).
ReelTemplate? templateById(String? id) {
  if (id == null) return null;
  for (final t in reelTemplates) {
    if (t.id == id) return t;
  }
  return null;
}

/// The other participant of a Blend row (the peer for [myId]).
String blendPeerId(BlendState blend, String myId) =>
    blend.userA == myId ? blend.userB : blend.userA;

/// The Blend row (if any) between me and [peerId] in [blends].
BlendState? blendForPeer(
  List<BlendState> blends,
  String peerId,
  String myId,
) {
  for (final b in blends) {
    if ((b.userA == myId && b.userB == peerId) ||
        (b.userA == peerId && b.userB == myId)) {
      return b;
    }
  }
  return null;
}

/// Mix the Blend feed: round-robin through the reels each side liked,
/// the reels both liked, and the reels shared in the DM — one mixed
/// feed, deduplicated by post id (a reel liked by both appears once).
List<BlendReel> mixBlendReels(
  List<BlendReel> peerLiked,
  List<BlendReel> myLiked,
  List<BlendReel> bothAndShared,
) {
  final seen = <int>{};
  final out = <BlendReel>[];
  var i = 0;
  while (i < peerLiked.length ||
      i < myLiked.length ||
      i < bothAndShared.length) {
    for (final list in [peerLiked, myLiked, bothAndShared]) {
      if (i < list.length && seen.add(list[i].post.id)) {
        out.add(list[i]);
      }
    }
    i++;
  }
  return out;
}

/// Group channel reactions into counts per emoji.
Map<String, int> groupReactions(List<ChannelReaction> reactions) {
  final counts = <String, int>{};
  for (final r in reactions) {
    counts[r.emoji] = (counts[r.emoji] ?? 0) + 1;
  }
  return counts;
}

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------

class PostCollaborator {
  final int postId;
  final String userId;
  final String status; // 'pending' | 'accepted' | 'declined'
  final String invitedBy;
  final DateTime createdAt;
  HamsiqProfile? profile;

  PostCollaborator({
    required this.postId,
    required this.userId,
    required this.status,
    required this.invitedBy,
    required this.createdAt,
    this.profile,
  });

  factory PostCollaborator.fromMap(Map<String, dynamic> m) =>
      PostCollaborator(
        postId: (m['post_id'] as num).toInt(),
        userId: m['user_id'] as String,
        status: (m['status'] ?? 'pending') as String,
        invitedBy: m['invited_by'] as String,
        createdAt: DateTime.parse(m['created_at'] as String),
      );

  bool get isPending => status == 'pending';
  bool get isAccepted => status == 'accepted';
}

/// A pending collab invite addressed to me, with the post + inviter.
class PendingCollabInvite {
  final PostCollaborator invite;
  final PostItem post;
  HamsiqProfile? inviter;

  PendingCollabInvite({
    required this.invite,
    required this.post,
    this.inviter,
  });
}

class ChannelInfo {
  final int id;
  final String ownerId;
  final String name;
  final String description;
  final DateTime createdAt;
  HamsiqProfile? owner;
  int memberCount;
  bool joinedByMe;

  ChannelInfo({
    required this.id,
    required this.ownerId,
    required this.name,
    required this.description,
    required this.createdAt,
    this.owner,
    this.memberCount = 0,
    this.joinedByMe = false,
  });

  factory ChannelInfo.fromMap(Map<String, dynamic> m) => ChannelInfo(
        id: (m['id'] as num).toInt(),
        ownerId: m['owner_id'] as String,
        name: (m['name'] ?? '') as String,
        description: (m['description'] ?? '') as String,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

class ChannelReaction {
  final int channelPostId;
  final String userId;
  final String emoji;
  final DateTime createdAt;

  ChannelReaction({
    required this.channelPostId,
    required this.userId,
    required this.emoji,
    required this.createdAt,
  });

  factory ChannelReaction.fromMap(Map<String, dynamic> m) =>
      ChannelReaction(
        channelPostId: (m['channel_post_id'] as num).toInt(),
        userId: m['user_id'] as String,
        emoji: (m['emoji'] ?? '❤️') as String,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

class ChannelPost {
  final int id;
  final int channelId;
  final String authorId;
  final String body;
  final String? mediaUrl;
  final String mediaType;
  final DateTime createdAt;
  HamsiqProfile? author;
  Map<String, int> reactionCounts;
  String? myReaction;

  ChannelPost({
    required this.id,
    required this.channelId,
    required this.authorId,
    required this.body,
    this.mediaUrl,
    required this.mediaType,
    required this.createdAt,
    this.author,
    Map<String, int>? reactionCounts,
    this.myReaction,
  }) : reactionCounts = reactionCounts ?? {};

  factory ChannelPost.fromMap(Map<String, dynamic> m) => ChannelPost(
        id: (m['id'] as num).toInt(),
        channelId: (m['channel_id'] as num).toInt(),
        authorId: m['author_id'] as String,
        body: (m['body'] ?? '') as String,
        mediaUrl: m['media_url'] as String?,
        mediaType: (m['media_type'] ?? 'text') as String,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

class BlendState {
  final int id;
  final String userA;
  final String userB;
  final String status; // 'pending' | 'active' | 'declined' | 'ended'
  final String createdBy;
  final DateTime createdAt;

  BlendState({
    required this.id,
    required this.userA,
    required this.userB,
    required this.status,
    required this.createdBy,
    required this.createdAt,
  });

  factory BlendState.fromMap(Map<String, dynamic> m) => BlendState(
        id: (m['id'] as num).toInt(),
        userA: m['user_a'] as String,
        userB: m['user_b'] as String,
        status: (m['status'] ?? 'pending') as String,
        createdBy: m['created_by'] as String,
        createdAt: DateTime.parse(m['created_at'] as String),
      );

  bool get isPending => status == 'pending';
  bool get isActive => status == 'active';

  /// True when *I* sent the invite and am waiting for the peer.
  bool waitingOnPeer(String myId) => isPending && createdBy == myId;

  /// True when the *peer* invited me and I have to answer.
  bool waitingOnMe(String myId) => isPending && createdBy != myId;
}

/// One reel in the Blend feed: which side(s) it came from.
/// [source]: 'peer' | 'me' | 'both' | 'shared'.
class BlendReel {
  final PostItem post;
  final String source;

  BlendReel({required this.post, required this.source});
}

// ---------------------------------------------------------------------------
// API
// ---------------------------------------------------------------------------

class Wave3Api {
  // ---------------- shared helpers ----------------

  /// Attach authors + like counts/counts to posts, same shape as
  /// Api._attachAuthorsAndLikes (private there, so repeated here).
  static Future<void> _attachAuthorsAndLikes(List<PostItem> posts) async {
    if (posts.isEmpty) return;
    final authorIds = posts.map((p) => p.userId).toSet().toList();
    final authors = await Api.fetchProfiles(authorIds);
    final ids = posts.map((p) => p.id).toList();
    final likeRows = await Api.client
        .from('post_likes')
        .select('post_id,user_id')
        .inFilter('post_id', ids);
    final counts = <int, int>{};
    final mine = <int>{};
    for (final r in (likeRows as List)) {
      final pid = (r['post_id'] as num).toInt();
      counts[pid] = (counts[pid] ?? 0) + 1;
      if (r['user_id'] == Api.myId) mine.add(pid);
    }
    for (final p in posts) {
      p.author = authors[p.userId];
      p.likeCount = counts[p.id] ?? 0;
      p.likedByMe = mine.contains(p.id);
    }
  }

  /// Best-effort in-app notification for an invite (type is free text
  /// in the DB; the notifications screen shows unknown types with a
  /// generic label). A notification failure must never fail the invite.
  static Future<void> _notifyInvite({
    required String recipientId,
    required String type,
    int? postId,
  }) async {
    if (recipientId == Api.myId) return;
    try {
      await Api.client.from('notifications').insert({
        'user_id': recipientId,
        'actor_id': Api.myId,
        'type': type,
        'post_id': postId,
      });
    } catch (_) {
      // Best-effort only.
    }
  }

  // ---------------- Reels editor ----------------

  /// Publish a reel created in the Reels editor: my video + timed text
  /// overlays + optional recorded voiceover + optional template id.
  /// The overlays/voiceover/template ride on the post row (sql-v31);
  /// the Reels tab renders them on playback.
  static Future<PostItem> createReelPost({
    required String caption,
    required String videoUrl,
    List<ReelTextOverlay> overlays = const [],
    String? voiceoverUrl,
    String? templateId,
  }) async {
    final rows = await Api.client.from('posts').insert({
      'user_id': Api.myId,
      'caption': caption,
      'media_url': videoUrl,
      'media_type': 'video',
      'is_reel': true,
      'reel_text_overlays': [for (final o in overlays) o.toMap()],
      'reel_voiceover_url': voiceoverUrl,
      'reel_template': templateId,
    }).select();
    final post =
        PostItem.fromMap((rows as List).first as Map<String, dynamic>);
    post.author = await Api.fetchProfile(Api.myId);
    return post;
  }

  // ---------------- Collab posts ----------------

  /// Invite [userId] to co-author [postId]. Server-enforced (RPC):
  /// only the post owner, max 5 collaborators, no self-invite, no
  /// duplicates. Throws the server's friendly message on violation.
  static Future<void> inviteCollaborator(int postId, String userId) async {
    await Api.client.rpc(
      'invite_collaborator',
      params: {'p_post_id': postId, 'p_user_id': userId},
    );
    await _notifyInvite(
      recipientId: userId,
      type: 'collab_invite',
      postId: postId,
    );
  }

  /// All collaborators on a post (pending + accepted + declined),
  /// with their profiles attached.
  static Future<List<PostCollaborator>> fetchPostCollaborators(
    int postId,
  ) async {
    final rows = await Api.client
        .from('post_collaborators')
        .select()
        .eq('post_id', postId)
        .order('created_at', ascending: true);
    final collabs = (rows as List)
        .map((r) => PostCollaborator.fromMap(r as Map<String, dynamic>))
        .toList();
    if (collabs.isEmpty) return collabs;
    final profiles = await Api.fetchProfiles(
      collabs.map((c) => c.userId).toList(),
    );
    for (final c in collabs) {
      c.profile = profiles[c.userId];
    }
    return collabs;
  }

  /// My pending collab invites, with the post + inviter attached.
  static Future<List<PendingCollabInvite>> fetchMyPendingInvites() async {
    final rows = await Api.client
        .from('post_collaborators')
        .select()
        .eq('user_id', Api.myId)
        .eq('status', 'pending')
        .order('created_at', ascending: false);
    final invites = (rows as List)
        .map((r) => PostCollaborator.fromMap(r as Map<String, dynamic>))
        .toList();
    if (invites.isEmpty) return [];
    final postIds = invites.map((i) => i.postId).toList();
    final postRows = await Api.client
        .from('posts')
        .select()
        .inFilter('id', postIds);
    final posts = <int, PostItem>{
      for (final r in (postRows as List))
        (r['id'] as num).toInt(): PostItem.fromMap(r as Map<String, dynamic>),
    };
    final postList = posts.values.toList();
    await _attachAuthorsAndLikes(postList);
    final inviters = await Api.fetchProfiles(
      invites.map((i) => i.invitedBy).toSet().toList(),
    );
    final out = <PendingCollabInvite>[];
    for (final invite in invites) {
      final post = posts[invite.postId];
      if (post == null) continue;
      out.add(PendingCollabInvite(
        invite: invite,
        post: post,
        inviter: inviters[invite.invitedBy],
      ));
    }
    return out;
  }

  /// Accept (true) or decline (false) my invite on [postId].
  static Future<void> respondToCollabInvite(int postId, bool accept) async {
    await Api.client.rpc(
      'respond_collab_invite',
      params: {'p_post_id': postId, 'p_accept': accept},
    );
  }

  /// Remove a collaborator (post owner) or withdraw my own invite.
  /// The RLS delete policy allows the owner or the invitee.
  static Future<void> removeCollaborator(int postId, String userId) async {
    await Api.client
        .from('post_collaborators')
        .delete()
        .eq('post_id', postId)
        .eq('user_id', userId);
  }

  /// Posts a user co-authors (accepted invites only), newest first —
  /// the data the profile grid needs to show co-authored posts. The
  /// profile screen wires this in a later step; the post detail screen
  /// already shows the co-authors.
  static Future<List<PostItem>> fetchCoAuthoredPosts(String userId) async {
    final rows = await Api.client
        .from('post_collaborators')
        .select('post_id')
        .eq('user_id', userId)
        .eq('status', 'accepted')
        .order('created_at', ascending: false)
        .limit(60);
    final postIds = [
      for (final r in (rows as List)) (r['post_id'] as num).toInt(),
    ];
    if (postIds.isEmpty) return [];
    final postRows = await Api.client
        .from('posts')
        .select()
        .inFilter('id', postIds)
        .order('created_at', ascending: false);
    final posts = (postRows as List)
        .map((r) => PostItem.fromMap(r as Map<String, dynamic>))
        .toList();
    await _attachAuthorsAndLikes(posts);
    return posts;
  }

  // ---------------- broadcast channels ----------------

  /// All public channels, newest first, with member counts, owners,
  /// and whether I joined each one.
  static Future<List<ChannelInfo>> fetchChannels() async {
    final rows = await Api.client
        .from('channels')
        .select()
        .order('created_at', ascending: false)
        .limit(100);
    final channels = (rows as List)
        .map((r) => ChannelInfo.fromMap(r as Map<String, dynamic>))
        .toList();
    if (channels.isEmpty) return channels;
    final memberRows = await Api.client
        .from('channel_members')
        .select('channel_id,user_id');
    final counts = <int, int>{};
    final mine = <int>{};
    for (final r in (memberRows as List)) {
      final cid = (r['channel_id'] as num).toInt();
      counts[cid] = (counts[cid] ?? 0) + 1;
      if (r['user_id'] == Api.myId) mine.add(cid);
    }
    final owners = await Api.fetchProfiles(
      channels.map((c) => c.ownerId).toSet().toList(),
    );
    for (final c in channels) {
      c.owner = owners[c.ownerId];
      c.memberCount = counts[c.id] ?? 0;
      c.joinedByMe = mine.contains(c.id);
    }
    return channels;
  }

  /// Create a channel. I am added as a member automatically
  /// (best-effort — the channel itself is what matters).
  static Future<ChannelInfo> createChannel({
    required String name,
    String description = '',
  }) async {
    final cleanName = name.trim();
    if (cleanName.isEmpty) throw Exception('اكتب اسماً للقناة');
    final rows = await Api.client.from('channels').insert({
      'owner_id': Api.myId,
      'name': cleanName,
      'description': description.trim(),
    }).select();
    final channel =
        ChannelInfo.fromMap((rows as List).first as Map<String, dynamic>);
    channel.owner = await Api.fetchProfile(Api.myId);
    channel.joinedByMe = true;
    try {
      await Api.client.from('channel_members').insert({
        'channel_id': channel.id,
        'user_id': Api.myId,
      });
      channel.memberCount = 1;
    } catch (_) {
      channel.memberCount = 0;
    }
    return channel;
  }

  static Future<void> joinChannel(int channelId) async {
    await Api.client.from('channel_members').insert({
      'channel_id': channelId,
      'user_id': Api.myId,
    });
  }

  static Future<void> leaveChannel(int channelId) async {
    await Api.client
        .from('channel_members')
        .delete()
        .eq('channel_id', channelId)
        .eq('user_id', Api.myId);
  }

  /// Channel posts, newest first, with authors + reaction counts +
  /// my own reaction on each post.
  static Future<List<ChannelPost>> fetchChannelPosts(int channelId) async {
    final rows = await Api.client
        .from('channel_posts')
        .select()
        .eq('channel_id', channelId)
        .order('created_at', ascending: false)
        .limit(100);
    final posts = (rows as List)
        .map((r) => ChannelPost.fromMap(r as Map<String, dynamic>))
        .toList();
    if (posts.isEmpty) return posts;
    final authors = await Api.fetchProfiles(
      posts.map((p) => p.authorId).toSet().toList(),
    );
    final ids = posts.map((p) => p.id).toList();
    final reactionRows = await Api.client
        .from('channel_reactions')
        .select()
        .inFilter('channel_post_id', ids);
    final byPost = <int, List<ChannelReaction>>{};
    for (final r in (reactionRows as List)) {
      final reaction =
          ChannelReaction.fromMap(r as Map<String, dynamic>);
      byPost.putIfAbsent(reaction.channelPostId, () => []).add(reaction);
    }
    for (final p in posts) {
      p.author = authors[p.authorId];
      final reactions = byPost[p.id] ?? [];
      p.reactionCounts = groupReactions(reactions);
      for (final r in reactions) {
        if (r.userId == Api.myId) p.myReaction = r.emoji;
      }
    }
    return posts;
  }

  /// Post to a channel. Only the channel owner can post (RLS enforces
  /// it server-side); the UI hides the composer from everyone else.
  static Future<ChannelPost> postToChannel({
    required int channelId,
    required String body,
    String? mediaUrl,
    String mediaType = 'text',
  }) async {
    final clean = body.trim();
    if (clean.isEmpty && (mediaUrl == null || mediaUrl.isEmpty)) {
      throw Exception('اكتب شيئاً أو أرفق صورة');
    }
    final rows = await Api.client.from('channel_posts').insert({
      'channel_id': channelId,
      'author_id': Api.myId,
      'body': clean,
      'media_url': mediaUrl,
      'media_type': mediaUrl == null ? 'text' : mediaType,
    }).select();
    final post =
        ChannelPost.fromMap((rows as List).first as Map<String, dynamic>);
    post.author = await Api.fetchProfile(Api.myId);
    return post;
  }

  /// Delete one of my channel posts (or any post in my own channel).
  static Future<void> deleteChannelPost(int postId) async {
    await Api.client.from('channel_posts').delete().eq('id', postId);
  }

  /// React with [emoji] (replaces my previous reaction on this post).
  static Future<void> reactToChannelPost(int postId, String emoji) async {
    if (!channelReactionEmojis.contains(emoji)) {
      throw Exception('تفاعل غير مدعوم');
    }
    await Api.client.from('channel_reactions').upsert(
      {
        'channel_post_id': postId,
        'user_id': Api.myId,
        'emoji': emoji,
      },
      onConflict: 'channel_post_id,user_id',
    );
  }

  /// Remove my reaction from a channel post.
  static Future<void> removeChannelReaction(int postId) async {
    await Api.client
        .from('channel_reactions')
        .delete()
        .eq('channel_post_id', postId)
        .eq('user_id', Api.myId);
  }

  /// Members of a channel, with profiles attached.
  static Future<List<HamsiqProfile>> fetchChannelMembers(
    int channelId,
  ) async {
    final rows = await Api.client
        .from('channel_members')
        .select('user_id')
        .eq('channel_id', channelId)
        .order('created_at', ascending: true)
        .limit(200);
    final ids = [
      for (final r in (rows as List)) r['user_id'] as String,
    ];
    if (ids.isEmpty) return [];
    final profiles = await Api.fetchProfiles(ids);
    return [for (final id in ids) if (profiles.containsKey(id)) profiles[id]!];
  }

  // ---------------- Blend ----------------

  /// The latest Blend row between me and [peerId] (any status), or
  /// null when no Blend was ever started.
  static Future<BlendState?> fetchBlendWith(String peerId) async {
    final myId = Api.myId;
    final rows = await Api.client
        .from('blends')
        .select()
        .or(
          'and(user_a.eq.$myId,user_b.eq.$peerId),'
          'and(user_a.eq.$peerId,user_b.eq.$myId)',
        )
        .order('created_at', ascending: false)
        .limit(1);
    if ((rows as List).isEmpty) return null;
    return BlendState.fromMap((rows as List).first as Map<String, dynamic>);
  }

  /// Invite [peerId] to a Blend. Throws when a pending/active Blend
  /// already exists between us (the screen offers to end/re-request
  /// instead of creating a duplicate).
  static Future<BlendState> requestBlend(String peerId) async {
    if (peerId == Api.myId) throw Exception('لا يمكنك بدء Blend مع نفسك');
    final existing = await fetchBlendWith(peerId);
    if (existing != null &&
        (existing.isPending || existing.isActive)) {
      throw Exception('يوجد Blend بالفعل مع هذا الصديق');
    }
    final rows = await Api.client.from('blends').insert({
      'user_a': Api.myId,
      'user_b': peerId,
      'status': 'pending',
      'created_by': Api.myId,
    }).select();
    final blend =
        BlendState.fromMap((rows as List).first as Map<String, dynamic>);
    await _notifyInvite(recipientId: peerId, type: 'blend_invite');
    return blend;
  }

  /// Accept (true) or decline (false) a Blend invite sent to me.
  static Future<void> respondBlend(int blendId, bool accept) async {
    await Api.client.rpc(
      'respond_blend_invite',
      params: {'p_blend_id': blendId, 'p_accept': accept},
    );
  }

  /// End a Blend (either participant).
  static Future<void> endBlend(int blendId) async {
    await Api.client.rpc('end_blend', params: {'p_blend_id': blendId});
  }

  /// The shared Blend feed: reels I liked + reels the peer liked +
  /// reels shared in our DM, mixed into one feed (newest first within
  /// each source, round-robin across sources — see mixBlendReels).
  /// Only works for an active Blend; callers check the status first.
  static Future<List<BlendReel>> fetchBlendReels(String peerId) async {
    final myId = Api.myId;
    final myLikeRows = await Api.client
        .from('post_likes')
        .select('post_id')
        .eq('user_id', myId)
        .limit(100);
    final peerLikeRows = await Api.client
        .from('post_likes')
        .select('post_id')
        .eq('user_id', peerId)
        .limit(100);
    final myLiked = {
      for (final r in (myLikeRows as List)) (r['post_id'] as num).toInt(),
    };
    final peerLiked = {
      for (final r in (peerLikeRows as List)) (r['post_id'] as num).toInt(),
    };
    // Reels shared in our DM (message_type='shared_post', body = post id).
    final sharedRows = await Api.client
        .from('messages')
        .select('body')
        .eq('message_type', 'shared_post')
        .or(
          'and(sender_id.eq.$myId,receiver_id.eq.$peerId),'
          'and(sender_id.eq.$peerId,receiver_id.eq.$myId)',
        )
        .limit(100);
    final sharedIds = <int>{};
    for (final r in (sharedRows as List)) {
      final id = int.tryParse((r['body'] ?? '').toString().trim());
      if (id != null) sharedIds.add(id);
    }
    final allIds = {...myLiked, ...peerLiked, ...sharedIds}.toList();
    if (allIds.isEmpty) return [];
    final postRows = await Api.client
        .from('posts')
        .select()
        .inFilter('id', allIds)
        .eq('is_reel', true)
        .order('created_at', ascending: false)
        .limit(100);
    final posts = (postRows as List)
        .map((r) => PostItem.fromMap(r as Map<String, dynamic>))
        .toList();
    await _attachAuthorsAndLikes(posts);
    final peerOnly = <BlendReel>[];
    final myOnly = <BlendReel>[];
    final bothAndShared = <BlendReel>[];
    for (final p in posts) {
      final likedMe = myLiked.contains(p.id);
      final likedPeer = peerLiked.contains(p.id);
      if (likedMe && likedPeer) {
        bothAndShared.add(BlendReel(post: p, source: 'both'));
      } else if (likedPeer) {
        peerOnly.add(BlendReel(post: p, source: 'peer'));
      } else if (likedMe) {
        myOnly.add(BlendReel(post: p, source: 'me'));
      } else if (sharedIds.contains(p.id)) {
        bothAndShared.add(BlendReel(post: p, source: 'shared'));
      }
    }
    return mixBlendReels(peerOnly, myOnly, bothAndShared);
  }
}
