// Hamsiq native — Share / Repost / Pin / Grid-order API (Wave 1).
// Tables (all real, verified in ~/workspace/chat-app):
//   * public.reposts (sql-v9): id, user_id, post_id, created_at,
//     unique (user_id, post_id). RLS: select is_approved(); insert
//     auth.uid() = user_id + approved; delete auth.uid() = user_id.
//   * public.posts.is_pinned / grid_order (sql-v29). Pinning uses the
//     owner UPDATE policy added in sql-v29 ("owners update own posts");
//     the admin-only policy from sql-v20 stays as-is.
//   * public.follows (sql-v5) for the share picker (people I follow).
//
// Sending the share itself lives in MessagesApi.sendSharedPost
// (messages_api.dart, message_type='shared_post', body=<post id>) —
// this file only finds the people and handles repost/pin/reorder.

import '../models.dart';
import 'supabase_service.dart';

class ShareApi {
  /// Instagram's pinned-post limit (inventory report §1/§7: Help Center
  /// says 3; one 2026 round-up claims 5 — 3 is the verified figure).
  static const int maxPinnedPosts = 3;

  /// Pure helper: profile-grid order — pinned posts first (newest pinned
  /// first), then grid_order ascending, then newest first. Kept separate
  /// so it is unit testable without a session.
  static List<PostItem> orderPostsForGrid(List<PostItem> posts) {
    final sorted = List<PostItem>.of(posts);
    sorted.sort((a, b) {
      if (a.isPinned != b.isPinned) return a.isPinned ? -1 : 1;
      if (a.isPinned && b.isPinned) {
        return b.createdAt.compareTo(a.createdAt);
      }
      if (a.gridOrder != b.gridOrder) {
        return a.gridOrder.compareTo(b.gridOrder);
      }
      return b.createdAt.compareTo(a.createdAt);
    });
    return sorted;
  }

  /// One post by id, with author + like count attached (used by the
  /// shared-post DM card). Returns null when the post is gone.
  static Future<PostItem?> fetchPostById(int postId) async {
    final rows = await Api.client
        .from('posts')
        .select()
        .eq('id', postId)
        .limit(1);
    if ((rows as List).isEmpty) return null;
    final post =
        PostItem.fromMap((rows as List).first as Map<String, dynamic>);
    post.author = await Api.fetchProfile(post.userId);
    final likeRows = await Api.client
        .from('post_likes')
        .select('post_id,user_id')
        .eq('post_id', postId);
    var count = 0;
    var mine = false;
    for (final r in (likeRows as List)) {
      count++;
      if (r['user_id'] == Api.myId) mine = true;
    }
    post.likeCount = count;
    post.likedByMe = mine;
    return post;
  }

  // ---------------- share picker targets ----------------

  /// People I follow (the share sheet's first list), newest follows
  /// first. Follows rows carry following_id; profiles are fetched in one
  /// query, exactly like Api._attachAuthorsAndLikes does.
  static Future<List<HamsiqProfile>> fetchFollowing() async {
    final rows = await Api.client
        .from('follows')
        .select('following_id')
        .eq('follower_id', Api.myId)
        .order('created_at', ascending: false)
        .limit(100);
    final ids = [
      for (final r in (rows as List)) r['following_id'] as String,
    ];
    if (ids.isEmpty) return [];
    final profiles = await Api.fetchProfiles(ids);
    return [for (final id in ids) if (profiles.containsKey(id)) profiles[id]!];
  }

  /// Search people by username for the share sheet (same query as
  /// Api.searchUsers, reused here so the sheet does not duplicate it).
  static Future<List<HamsiqProfile>> searchPeople(String query) async {
    final q = query.trim();
    if (q.isEmpty) return [];
    return Api.searchUsers(q);
  }

  // ---------------- reposts (table exists since sql-v9) ----------------

  /// Repost / un-repost a post. Returns true when the post is reposted
  /// afterwards. The unique (user_id, post_id) makes a double-tap safe.
  static Future<bool> toggleRepost(int postId, bool repost) async {
    if (repost) {
      await Api.client.from('reposts').upsert({
        'user_id': Api.myId,
        'post_id': postId,
      }, onConflict: 'user_id,post_id');
      return true;
    } else {
      await Api.client
          .from('reposts')
          .delete()
          .eq('user_id', Api.myId)
          .eq('post_id', postId);
      return false;
    }
  }

  static Future<bool> isReposted(int postId) async {
    final rows = await Api.client
        .from('reposts')
        .select('id')
        .eq('user_id', Api.myId)
        .eq('post_id', postId)
        .limit(1);
    return (rows as List).isNotEmpty;
  }

  /// Post ids I have reposted (for the repost button state on cards).
  static Future<Set<int>> fetchMyRepostedPostIds() async {
    final rows = await Api.client
        .from('reposts')
        .select('post_id')
        .eq('user_id', Api.myId);
    return {
      for (final r in (rows as List)) (r['post_id'] as num).toInt(),
    };
  }

  /// The posts a user reposted, newest repost first — the Reposts tab.
  /// Authors + likes are attached the same way Api.fetchFeed does.
  static Future<List<PostItem>> fetchUserReposts(String userId) async {
    final repostRows = await Api.client
        .from('reposts')
        .select('post_id,created_at')
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(60);
    final postIds = [
      for (final r in (repostRows as List)) (r['post_id'] as num).toInt(),
    ];
    if (postIds.isEmpty) return [];
    final rows = await Api.client
        .from('posts')
        .select()
        .inFilter('id', postIds);
    final byId = <int, PostItem>{
      for (final r in (rows as List))
        (r['id'] as num).toInt(): PostItem.fromMap(r as Map<String, dynamic>),
    };
    final posts = [
      for (final id in postIds) if (byId.containsKey(id)) byId[id]!,
    ];
    if (posts.isEmpty) return posts;
    final authorIds = posts.map((p) => p.userId).toSet().toList();
    final authors = await Api.fetchProfiles(authorIds);
    final likeRows = await Api.client
        .from('post_likes')
        .select('post_id,user_id')
        .inFilter('post_id', postIds);
    final counts = <int, int>{};
    final mine = <int>{};
    for (final r in (likeRows as List)) {
      final pid = (r['post_id'] as num).toInt();
      counts[pid] = (counts[pid] ?? 0) + 1;
      if (r['user_id'] == Api.myId) mine.add(pid);
    }
    for (final p in posts) {
      p.author = authors[p.userId];
      p.likeCount = counts[p.id] ?? 0;
      p.likedByMe = mine.contains(p.id);
    }
    return posts;
  }

  // ---------------- pinned posts (posts.is_pinned, sql-v29) ----------------

  /// A user's pinned posts, newest pinned first.
  static Future<List<PostItem>> fetchPinnedPosts(String userId) async {
    final rows = await Api.client
        .from('posts')
        .select()
        .eq('user_id', userId)
        .eq('is_pinned', true)
        .order('created_at', ascending: false)
        .limit(maxPinnedPosts);
    final posts = (rows as List)
        .map((r) => PostItem.fromMap(r as Map<String, dynamic>))
        .toList();
    if (posts.isEmpty) return posts;
    final author = await Api.fetchProfile(userId);
    for (final p in posts) {
      p.author = author;
    }
    return posts;
  }

  /// Pin / unpin one of MY posts. Enforces the 3-pin limit client-side
  /// (the DB column is a plain boolean; the check reads my current
  /// pinned posts first). Throws when the limit is hit.
  static Future<void> setPostPinned(int postId, bool pinned) async {
    if (pinned) {
      final current = await fetchPinnedPosts(Api.myId);
      final already =
          current.any((p) => p.id == postId) || current.length < maxPinnedPosts;
      if (!already) {
        throw Exception(
          'يمكنك تثبيت $maxPinnedPosts منشورات كحد أقصى — ألغِ تثبيت منشور أولاً',
        );
      }
    }
    await Api.client
        .from('posts')
        .update({'is_pinned': pinned})
        .eq('id', postId)
        .eq('user_id', Api.myId);
  }

  // ---------------- profile grid order (posts.grid_order, sql-v29) ----------------

  /// My posts in grid order (pinned first, then grid_order, then newest)
  /// — the order profile_screen.dart should render instead of the raw
  /// created_at order from Api.fetchUserPosts.
  static Future<List<PostItem>> fetchOrderedUserPosts(String userId) async {
    final posts = await Api.fetchUserPosts(userId);
    return orderPostsForGrid(posts);
  }

  /// Save a new grid order for MY posts: [orderedPostIds] in the order
  /// the owner dragged them to. grid_order is 0..n in that order; posts
  /// not listed keep their old value. Only my own posts are touched
  /// (the eq on user_id + the RLS owner policy both enforce it).
  static Future<void> reorderGrid(
    String userId,
    List<int> orderedPostIds,
  ) async {
    if (userId != Api.myId) {
      throw Exception('يمكنك إعادة ترتيب شبكتك أنت فقط');
    }
    for (var i = 0; i < orderedPostIds.length; i++) {
      await Api.client
          .from('posts')
          .update({'grid_order': i})
          .eq('id', orderedPostIds[i])
          .eq('user_id', Api.myId);
    }
  }
}
