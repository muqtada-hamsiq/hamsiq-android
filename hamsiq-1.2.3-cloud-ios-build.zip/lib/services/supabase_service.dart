// Hamsiq native — Supabase API layer.
// Same backend as the web app: Supabase project muqtada-chat.
// Tables/columns/RPCs mirror ~/workspace/chat-app/index.html exactly.
// NEVER use the service_role key; only the public anon key (already shipped
// in the web app) is used here.

import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';
import '../models.dart';

/// Strip every invisible / zero-width / directional / control character
/// from an email, then trim. Dart's trim() does NOT remove characters like
/// U+200B (zero-width space), U+200C/U+200D, U+FEFF (BOM), U+200E/U+200F
/// (LRM/RLM) or U+00A0 (non-breaking space) — but Supabase Auth rejects
/// an email containing any of them with "Unable to validate email
/// address: invalid format". Real phones (autofill, copy/paste, keyboards)
/// can inject exactly these characters invisibly, so clean every email
/// at every entry point (defense in depth: call sites AND the Api methods).
String cleanEmail(String s) {
  const invisible = r'[\u200B\u200C\u200D\uFEFF\u200E\u200F\u00A0\u2060'
      r'\u202A-\u202E\u2061-\u2064\u180E\u061C\u0000-\u001F\u007F]';
  return s.replaceAll(RegExp(invisible), '').trim();
}

/// Simple client-side email shape check (used before calling the API so a
/// mistyped address fails fast with a friendly message, not a raw error).
bool isValidEmail(String s) =>
    RegExp(r'^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$')
        .hasMatch(s);

class Api {
  static const supabaseUrl = 'https://yjmqmkvefabiuxtbmetm.supabase.co';
  // Public anon (publishable) key — copied from the web app's index.html.
  static const supabaseAnonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlqbXFta3ZlZmFiaXV4dGJtZXRtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ2MDY3NjUsImV4cCI6MjExMDE4Mjc2NX0.KNqj1XouCNQBV0XLkSfIFeFsb8N6y9RUY5_qpN5jCgI';

  static SupabaseClient get client => Supabase.instance.client;
  static String get myId => client.auth.currentUser!.id;
  static bool get isLoggedIn => client.auth.currentUser != null;

  // ---------------- auth ----------------

  /// Signup: email + username + password. Supabase sends the 8-digit code;
  /// the caller then calls [verifySignupOtp]. Returns true when a session
  /// was created immediately (email confirm disabled), false when the OTP
  /// screen must be shown.
  static Future<bool> signUp({
    required String email,
    required String username,
    required String password,
  }) async {
    final r = await client.auth.signUp(
      email: cleanEmail(email),
      password: password,
      data: {'username': username.trim().toLowerCase()},
    );
    if (r.user == null) throw Exception('تعذر إنشاء الحساب');
    return r.session != null;
  }

  static Future<void> verifySignupOtp(String email, String code) async {
    final r = await client.auth.verifyOTP(
      email: cleanEmail(email),
      token: code.trim(),
      type: OtpType.signup,
    );
    if (r.user == null) throw Exception('رمز غير صحيح');
  }

  static Future<void> resetPassword(String email) async {
    await client.auth.resetPasswordForEmail(
      cleanEmail(email),
      redirectTo: 'https://muqtada-pages.neocities.org/',
    );
  }

  /// Load my profile; create it if missing (same as the web app's
  /// ensureProfile: username from user_metadata, approved:true).
  static Future<HamsiqProfile> ensureMyProfile() async {
    final user = client.auth.currentUser!;
    final existing = await fetchProfile(user.id);
    if (existing != null) return existing;
    final uname = ((user.userMetadata?['username'] ?? '') as String)
        .trim()
        .toLowerCase();
    if (uname.isEmpty) {
      throw Exception('أكمل ملفك الشخصي من المتصفح أولاً');
    }
    await client.from('profiles').insert({
      'id': user.id,
      'username': uname,
      'display_name': uname,
      'avatar': '😀',
      'bio': '',
      'approved': true,
    });
    final created = await fetchProfile(user.id);
    if (created == null) throw Exception('تعذر إنشاء الملف الشخصي');
    return created;
  }

  static Future<void> signOut() async => client.auth.signOut();

  /// Create the profile row for a Google (OAuth) user after the setup
  /// screen, or fill in the username of an existing row that has none.
  /// Never creates a second row for the same auth user id: the insert is
  /// keyed by id, and an existing row is updated instead. A row that
  /// already has a username is returned untouched (the post-OAuth gate
  /// should have sent that user home already).
  static Future<HamsiqProfile> upsertGoogleProfile({
    required String username,
    required String displayName,
    String? avatarUrl,
  }) async {
    final user = client.auth.currentUser!;
    final existing = await fetchProfile(user.id);
    final uname = username.trim().toLowerCase();
    final name = displayName.trim().isEmpty ? uname : displayName.trim();
    final avatar = (avatarUrl ?? '').trim();
    if (existing != null) {
      if (existing.username.trim().isNotEmpty) return existing;
      await client.from('profiles').update({
        'username': uname,
        'display_name': name,
        if (avatar.isNotEmpty) 'avatar_url': avatar,
      }).eq('id', user.id);
    } else {
      await client.from('profiles').insert({
        'id': user.id,
        'username': uname,
        'display_name': name,
        'avatar': '😀',
        if (avatar.isNotEmpty) 'avatar_url': avatar,
        'bio': '',
        'approved': true,
      });
    }
    final created = await fetchProfile(user.id);
    if (created == null) throw Exception('تعذر إنشاء الملف الشخصي');
    return created;
  }

  // ---------------- profiles ----------------

  static Future<HamsiqProfile?> fetchProfile(String id) async {
    final rows = await client.from('profiles').select().eq('id', id).limit(1);
    if ((rows as List).isEmpty) return null;
    return HamsiqProfile.fromMap(rows.first);
  }

  static Future<Map<String, HamsiqProfile>> fetchProfiles(
    List<String> ids,
  ) async {
    if (ids.isEmpty) return {};
    final rows = await client
        .from('profiles')
        .select('id,username,display_name,avatar,avatar_url,bio,verified,is_admin,approved,is_private')
        .inFilter('id', ids);
    final out = <String, HamsiqProfile>{};
    for (final r in (rows as List)) {
      final p = HamsiqProfile.fromMap(r as Map<String, dynamic>);
      out[p.id] = p;
    }
    return out;
  }

  static Future<List<HamsiqProfile>> searchUsers(String q) async {
    final rows = await client
        .from('profiles')
        .select('id,username,display_name,avatar,avatar_url,bio,verified,is_admin,approved,is_private')
        .ilike('username', '%$q%')
        .limit(20);
    return (rows as List)
        .map((r) => HamsiqProfile.fromMap(r as Map<String, dynamic>))
        .toList();
  }

  static Future<void> updateMyProfile({
    String? displayName,
    String? bio,
    String? avatarUrl,
  }) async {
    final patch = <String, dynamic>{};
    if (displayName != null) patch['display_name'] = displayName;
    if (bio != null) patch['bio'] = bio;
    if (avatarUrl != null) patch['avatar_url'] = avatarUrl;
    if (patch.isEmpty) return;
    await client.from('profiles').update(patch).eq('id', myId);
  }

  // ---------------- follows ----------------

  static Future<int> countFollowers(String userId) async {
    final r = await client
        .from('follows')
        .select('id')
        .eq('following_id', userId)
        .count(CountOption.exact);
    return r.count;
  }

  static Future<int> countFollowing(String userId) async {
    final r = await client
        .from('follows')
        .select('id')
        .eq('follower_id', userId)
        .count(CountOption.exact);
    return r.count;
  }

  static Future<bool> isFollowing(String userId) async {
    final rows = await client
        .from('follows')
        .select('id')
        .eq('follower_id', myId)
        .eq('following_id', userId)
        .limit(1);
    return (rows as List).isNotEmpty;
  }

  static Future<void> setFollowing(String userId, bool follow) async {
    if (follow) {
      await client.from('follows').insert({
        'follower_id': myId,
        'following_id': userId,
      });
    } else {
      await client
          .from('follows')
          .delete()
          .eq('follower_id', myId)
          .eq('following_id', userId);
    }
  }

  // ---------------- posts / feed ----------------

  /// Latest posts first (same query shape as the web app's loadFeed:
  /// posts order created_at desc limit 60, authors fetched separately).
  /// Visibility is enforced by the server (sql-v32.sql, audit fix
  /// H-02): a post is visible to its owner, to admins, to any approved
  /// user when the author's profile is not private, and — for private
  /// authors — only to approved followers; users blocked in either
  /// direction see nothing. The feed just reads the latest posts, so
  /// there is no client-side visibility filtering here.
  static Future<List<PostItem>> fetchFeed({int limit = 60}) async {
    final rows = await client
        .from('posts')
        .select()
        .order('created_at', ascending: false)
        .limit(limit);
    final posts = (rows as List)
        .map((r) => PostItem.fromMap(r as Map<String, dynamic>))
        .toList();
    await _attachAuthorsAndLikes(posts);
    return posts;
  }

  static Future<List<PostItem>> fetchUserPosts(String userId) async {
    final rows = await client
        .from('posts')
        .select()
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(60);
    final posts = (rows as List)
        .map((r) => PostItem.fromMap(r as Map<String, dynamic>))
        .toList();
    await _attachAuthorsAndLikes(posts);
    return posts;
  }

  static Future<void> _attachAuthorsAndLikes(List<PostItem> posts) async {
    if (posts.isEmpty) return;
    final authorIds = posts.map((p) => p.userId).toSet().toList();
    final authors = await fetchProfiles(authorIds);
    final ids = posts.map((p) => p.id).toList();
    final likeRows = await client
        .from('post_likes')
        .select('post_id,user_id')
        .inFilter('post_id', ids);
    final counts = <int, int>{};
    final mine = <int>{};
    for (final r in (likeRows as List)) {
      final pid = (r['post_id'] as num).toInt();
      counts[pid] = (counts[pid] ?? 0) + 1;
      if (r['user_id'] == myId) mine.add(pid);
    }
    for (final p in posts) {
      p.author = authors[p.userId];
      p.likeCount = counts[p.id] ?? 0;
      p.likedByMe = mine.contains(p.id);
    }
  }

  static Future<void> setLiked(int postId, bool like) async {
    if (like) {
      await client.from('post_likes').insert({
        'post_id': postId,
        'user_id': myId,
      });
    } else {
      await client
          .from('post_likes')
          .delete()
          .eq('post_id', postId)
          .eq('user_id', myId);
    }
  }

  static Future<PostItem> createPost({
    required String caption,
    String? mediaUrl,
    String? mediaType,
    bool isReel = false,
  }) async {
    final rows = await client.from('posts').insert({
      'user_id': myId,
      'caption': caption,
      'media_url': mediaUrl,
      'media_type': mediaType ?? 'image',
      'is_reel': isReel,
    }).select();
    final post = PostItem.fromMap((rows as List).first as Map<String, dynamic>);
    final me = await fetchProfile(myId);
    post.author = me;
    return post;
  }

  // ---------------- storage ----------------

  /// Upload image bytes. Bytes (not dart:io File) so the same call
  /// works on Android and on web (XFile.readAsBytes on both). Returns
  /// the URL, or null on failure.
  /// H-04 fix: non-avatar images go to the PRIVATE 'private-media'
  /// bucket (uploader's own folder) and return a 1-hour SIGNED URL.
  /// Avatar paths ('<my-id>/avatar-...') stay PUBLIC in chat-media,
  /// exactly as before — avatars are public by design.
  static Future<String?> uploadImage(Uint8List bytes, String path) async {
    final ext = path.split('.').last.toLowerCase();
    final contentType = ext == 'png'
        ? 'image/png'
        : ext == 'webp'
            ? 'image/webp'
            : 'image/jpeg';
    final fileName = path.split('/').last;
    final isAvatar = fileName.startsWith('avatar-');
    final bucket = isAvatar ? 'chat-media' : 'private-media';
    await client.storage.from(bucket).uploadBinary(
          path,
          bytes,
          fileOptions: FileOptions(contentType: contentType, upsert: false),
        );
    if (isAvatar) {
      return client.storage.from(bucket).getPublicUrl(path);
    }
    return client.storage.from(bucket).createSignedUrl(
          path,
          3600, // 1 hour; render paths must re-sign after expiry
        );
  }

  static String uniqueImagePath(String prefix) =>
      '$myId/$prefix-${DateTime.now().millisecondsSinceEpoch}.jpg';

  // ---------------- chats (DMs) ----------------

  /// DM thread list, same derivation as the web app's loadChats: all
  /// messages involving me (limit 200, newest first), grouped by peer,
  /// plus accepted friends without messages yet.
  static Future<List<ChatRow>> fetchChatList() async {
    final rows = await client
        .from('messages')
        .select()
        .or('sender_id.eq.$myId,receiver_id.eq.$myId')
        .order('created_at', ascending: false)
        .limit(200);
    final peers = <String, ChatMessage>{};
    final unread = <String, int>{};
    for (final r in (rows as List)) {
      final m = ChatMessage.fromMap(r as Map<String, dynamic>);
      final peerId = m.senderId == myId ? (m.receiverId ?? '') : m.senderId;
      if (peerId.isEmpty) continue;
      peers.putIfAbsent(peerId, () => m);
      if (m.receiverId == myId && !m.read) {
        unread[peerId] = (unread[peerId] ?? 0) + 1;
      }
    }
    final friendRows = await client
        .from('friendships')
        .select('user_id,friend_id')
        .or('user_id.eq.$myId,friend_id.eq.$myId')
        .eq('status', 'accepted');
    final friendIds = <String>{};
    for (final f in (friendRows as List)) {
      final uid = f['user_id'] as String;
      final fid = f['friend_id'] as String;
      friendIds.add(uid == myId ? fid : uid);
    }
    final ids = {...peers.keys, ...friendIds}.toList();
    final profiles = await fetchProfiles(ids);
    final out = <ChatRow>[];
    for (final id in ids) {
      final p = profiles[id];
      if (p == null) continue;
      out.add(ChatRow(
        peer: p,
        last: peers[id],
        unread: unread[id] ?? 0,
      ));
    }
    out.sort((a, b) {
      final at = a.last?.createdAt.millisecondsSinceEpoch ?? 0;
      final bt = b.last?.createdAt.millisecondsSinceEpoch ?? 0;
      return bt.compareTo(at);
    });
    return out;
  }

  static Future<List<ChatMessage>> fetchThread(
    String peerId, {
    int limit = 100,
  }) async {
    final rows = await client
        .from('messages')
        .select()
        .or(
          'and(sender_id.eq.$myId,receiver_id.eq.$peerId),'
          'and(sender_id.eq.$peerId,receiver_id.eq.$myId)',
        )
        .order('created_at', ascending: true)
        .limit(limit);
    return (rows as List)
        .map((r) => ChatMessage.fromMap(r as Map<String, dynamic>))
        .toList();
  }

  static Future<ChatMessage> sendMessage(String peerId, String body) async {
    final rows = await client.from('messages').insert({
      'sender_id': myId,
      'receiver_id': peerId,
      'body': body,
      'message_type': 'text',
    }).select();
    return ChatMessage.fromMap((rows as List).first as Map<String, dynamic>);
  }

  /// Mark a DM thread read via the SECURITY DEFINER RPC
  /// mark_thread_read(p_peer_id) — the direct UPDATE on messages lost its
  /// RLS policy in sql-v21, so the old direct UPDATE is rejected live.
  static Future<void> markThreadRead(String peerId) async {
    await client.rpc('mark_thread_read', params: {'p_peer_id': peerId});
  }
}
