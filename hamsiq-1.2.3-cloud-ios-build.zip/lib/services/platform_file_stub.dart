// Web implementation of lib/services/platform_file.dart (default when
// dart:io is unavailable). On web, image_picker / record return blob
// URLs as XFile.path, and there is no on-disk file to delete.

import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

/// Web: the record plugin ignores the path and returns a blob URL, so
/// any name works.
String voiceTempPath(String name) => name;

/// Web: nothing on disk to delete.
Future<void> deleteFileQuietly(String path) async {}

/// Web: XFile.path is a blob URL — play it as a network URL.
VideoPlayerController videoControllerFor(XFile file) =>
    VideoPlayerController.networkUrl(Uri.parse(file.path));

/// Web: XFile.path is a blob URL — Image.network displays it.
Widget pickedImage(
  XFile file, {
  double? height,
  double? width,
  BoxFit fit = BoxFit.cover,
}) =>
    Image.network(
      file.path,
      height: height,
      width: width,
      fit: fit,
    );

/// Bytes of a picked/recorded file. XFile.readAsBytes works on both
/// platforms (on web it fetches the blob URL).
Future<Uint8List> readPickedBytes(XFile file) => file.readAsBytes();

/// Bytes of a file recorded by the `record` plugin (path is a blob URL
/// on web, a real path on Android).
Future<Uint8List> readPathBytes(String path) => XFile(path).readAsBytes();
