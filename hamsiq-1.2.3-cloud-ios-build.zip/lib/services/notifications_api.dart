// Hamsiq native — Notifications API (Wave 1).
// Reads the REAL public.notifications table (sql-v9):
//   id bigint, user_id uuid (recipient), actor_id uuid, type text,
//   post_id bigint nullable, created_at timestamptz, is_read boolean.
// Wave 1 types: 'like' | 'comment' | 'follow' | 'mention' (v9) |
// 'message'. No new notification columns were needed; sql-v29 only adds
// the recipient toggle profiles.notif_comments (v9 already had
// notif_messages / notif_likes / notif_followers / notif_mentions).
//
// Gating: the list (and the unread count) shows only the types whose
// notif_* toggle is ON for the recipient. The toggles live in Settings
// (another agent owns settings_screen.dart); this file only READS them.
// There is deliberately NO push: these are in-app notifications only,
// and no code here may imply closed-app push exists (see app_strings
// 'notifHint').

import '../models.dart';
import 'supabase_service.dart';

/// One row of public.notifications, with the actor's profile attached.
class NotificationItem {
  final int id;
  final String userId;
  final String actorId;
  final String type; // like | comment | follow | mention | message
  final int? postId;
  final DateTime createdAt;
  final bool isRead;
  HamsiqProfile? actor;

  NotificationItem({
    required this.id,
    required this.userId,
    required this.actorId,
    required this.type,
    this.postId,
    required this.createdAt,
    required this.isRead,
    this.actor,
  });

  factory NotificationItem.fromMap(Map<String, dynamic> m) =>
      NotificationItem(
        id: (m['id'] as num).toInt(),
        userId: m['user_id'] as String,
        actorId: m['actor_id'] as String,
        type: (m['type'] ?? 'mention') as String,
        postId: m['post_id'] == null ? null : (m['post_id'] as num).toInt(),
        createdAt: DateTime.parse(m['created_at'] as String),
        isRead: (m['is_read'] ?? false) as bool,
      );

  NotificationItem copyWithRead(bool read) => NotificationItem(
        id: id,
        userId: userId,
        actorId: actorId,
        type: type,
        postId: postId,
        createdAt: createdAt,
        isRead: read,
        actor: actor,
      );
}

class NotificationsApi {
  /// All notification types Wave 1 writes.
  static const List<String> types = [
    'like',
    'comment',
    'follow',
    'mention',
    'message',
  ];

  /// Recipient toggle column per type (profiles columns from sql-v9 +
  /// sql-v29 notif_comments). The Settings screen owns writing these.
  static const Map<String, String> toggleColumnForType = {
    'like': 'notif_likes',
    'comment': 'notif_comments',
    'follow': 'notif_followers',
    'mention': 'notif_mentions',
    'message': 'notif_messages',
  };

  /// Pure helper: keep only the notifications whose type is enabled in
  /// [toggles] (toggle column -> on/off; a missing toggle means ON).
  /// Kept separate so it is unit testable without a session.
  static List<NotificationItem> filterByToggles(
    List<NotificationItem> items,
    Map<String, bool> toggles,
  ) {
    return items.where((n) {
      final column = toggleColumnForType[n.type];
      if (column == null) return true;
      return toggles[column] ?? true;
    }).toList();
  }

  /// Arabic label per type (screen text; app_strings holds the settings
  /// labels — these are notification-feed sentences, built in the UI).
  static String typeLabel(String type) {
    switch (type) {
      case 'like':
        return 'أعجب بمنشورك';
      case 'comment':
        return 'علّق على منشورك';
      case 'follow':
        return 'بدأ بمتابعتك';
      case 'mention':
        return 'أشار إليك';
      case 'message':
        return 'أرسل لك رسالة';
      default:
        return 'تفاعل معك';
    }
  }

  /// My notification toggles. notif_comments is read separately in a
  /// try/catch: it only exists after sql-v29 runs, and a missing column
  /// must not break the whole notifications screen.
  static Future<Map<String, bool>> fetchMyToggles() async {
    final toggles = <String, bool>{
      'notif_messages': true,
      'notif_likes': true,
      'notif_followers': true,
      'notif_mentions': true,
      'notif_comments': true,
    };
    try {
      final rows = await Api.client
          .from('profiles')
          .select('notif_messages,notif_likes,notif_followers,notif_mentions')
          .eq('id', Api.myId)
          .limit(1);
      if ((rows as List).isNotEmpty) {
        final r = rows.first;
        for (final k in [
          'notif_messages',
          'notif_likes',
          'notif_followers',
          'notif_mentions',
        ]) {
          if (r[k] is bool) toggles[k] = r[k] as bool;
        }
      }
    } catch (_) {
      // Profiles unreadable: fall back to all-on rather than hiding
      // every notification.
    }
    try {
      final rows = await Api.client
          .from('profiles')
          .select('notif_comments')
          .eq('id', Api.myId)
          .limit(1);
      if ((rows as List).isNotEmpty) {
        final v = rows.first['notif_comments'];
        if (v is bool) toggles['notif_comments'] = v;
      }
    } catch (_) {
      // sql-v29 not yet run: comment notifications stay enabled.
    }
    return toggles;
  }

  /// My notifications, newest first, with actor profiles attached,
  /// filtered by my notif_* toggles.
  static Future<List<NotificationItem>> fetchMyNotifications({
    int limit = 100,
  }) async {
    final toggles = await fetchMyToggles();
    final rows = await Api.client
        .from('notifications')
        .select()
        .eq('user_id', Api.myId)
        .order('created_at', ascending: false)
        .limit(limit);
    var items = (rows as List)
        .map((r) => NotificationItem.fromMap(r as Map<String, dynamic>))
        .toList();
    items = filterByToggles(items, toggles);
    if (items.isEmpty) return items;
    final actorIds = items.map((n) => n.actorId).toSet().toList();
    final actors = await Api.fetchProfiles(actorIds);
    for (final n in items) {
      n.actor = actors[n.actorId];
    }
    return items;
  }

  /// Unread count, after the same toggle filter as the list — this is
  /// what the bell's unread dot shows.
  static Future<int> fetchUnreadCount() async {
    final items = await fetchMyNotifications(limit: 200);
    return items.where((n) => !n.isRead).length;
  }

  /// Mark one notification read (RLS: recipient or admin).
  static Future<void> markRead(int notificationId) async {
    await Api.client
        .from('notifications')
        .update({'is_read': true})
        .eq('id', notificationId)
        .eq('user_id', Api.myId);
  }

  /// Mark all my notifications read.
  static Future<void> markAllRead() async {
    await Api.client
        .from('notifications')
        .update({'is_read': true})
        .eq('user_id', Api.myId)
        .eq('is_read', false);
  }

  /// Insert a notification for [recipientId] from me. No-op when the
  /// recipient is me (liking/commenting on my own post notifies nobody).
  /// Throws on bad input; callers that must not fail the main action
  /// should catch. The insert RLS (sql-v9) requires auth.uid() =
  /// actor_id + is_approved().
  static Future<void> notify({
    required String recipientId,
    required String type,
    int? postId,
  }) async {
    if (recipientId == Api.myId) return;
    if (!types.contains(type)) throw Exception('نوع إشعار غير معروف: $type');
    await Api.client.from('notifications').insert({
      'user_id': recipientId,
      'actor_id': Api.myId,
      'type': type,
      'post_id': postId,
    });
  }

  static Future<void> notifyLike(String recipientId, int postId) =>
      notify(recipientId: recipientId, type: 'like', postId: postId);

  static Future<void> notifyComment(String recipientId, int postId) =>
      notify(recipientId: recipientId, type: 'comment', postId: postId);

  static Future<void> notifyFollow(String recipientId) =>
      notify(recipientId: recipientId, type: 'follow');

  static Future<void> notifyMessage(String recipientId) =>
      notify(recipientId: recipientId, type: 'message');
}
