// Hamsiq native — Google sign-in (optional, via Supabase OAuth).
//
// No google_sign_in package, no OAuth client ID/secret anywhere in the
// app: the provider configuration lives server-side in Supabase Auth.
// The app only launches the Supabase authorize URL and observes the
// result on the auth-state stream.
//
// Verified against the installed SDK (supabase_flutter 2.18.3, gotrue
// 2.27.3, from supabase_flutter ^2.9.0):
//   * `signInWithOAuth` / `linkIdentity` return Future<bool> — whether
//     the browser was launched. They NEVER return the auth result, and
//     a try/catch around the launch can NEVER see the OAuth outcome.
//     The session arrives later: supabase_flutter's SupabaseAuth
//     observes the deep link (AppLinks) and calls getSessionFromUrl,
//     which notifies AuthChangeEvent.signedIn. Callers MUST therefore
//     listen to onAuthStateChange while a Google round-trip is pending
//     (see AuthScreen.initState). On web the redirect reloads the page,
//     so the pending flag is lost — main.dart's restore path routes a
//     signed-in session with no complete profile to the setup screen.
//   * OAuth callback errors arrive IN THE URL: getSessionFromUrl throws
//     AuthException(code: <url `error` param>, statusCode: <error_code>)
//     and supabase_flutter forwards it as an error on the auth-state
//     stream. The launch call itself stays silent.
//   * Deep link: the custom scheme below is registered in
//     android/app/src/main/AndroidManifest.xml
//     (com.hamsiq.app://login-callback), the documented supabase_flutter
//     pattern. Web uses the published preview origin instead (kIsWeb).
//
// Identity linking — verified GoTrue behaviour (docs + gotrue 2.27.3
// error codes; live OAuth is NOT testable here because the Google
// provider is not configured on prod or staging — see the report):
//   * DEFAULT (this project — manual linking NOT enabled): GoTrue
//     AUTOMATICALLY links identities that share a verified email into
//     ONE auth.users row ("Supabase Auth automatically links identities
//     with the same email address to a single user"). An email+password
//     account that signs in with Google for the same address therefore
//     signs into THAT user: fetchProfile finds the existing profile and
//     the gate goes home. No second profile can ever be created —
//     upsertGoogleProfile is keyed by auth user id.
//   * ONLY when "Allow manual linking" is enabled server-side does the
//     OAuth sign-in for an already-registered email FAIL instead, with
//     AuthException code `identity_already_exists` (gotrue ErrorCode).
//     That error arrives on the auth-state stream (see above) and the
//     app routes to the link screen: the user signs in with their
//     existing password first, then linkIdentity(google) attaches the
//     Google identity to the SAME user id. linkIdentity itself requires
//     manual linking to be enabled (otherwise `manual_linking_disabled`).
//   * Hamsiq email accounts are OTP-confirmed at signup, so the GoTrue
//     rule that removes UNCONFIRMED identities when a new identity
//     links does not apply to them — a Google link cannot silently drop
//     a confirmed password identity.
//   * `profiles` has no email column and RLS forbids reading other
//     users' rows, so the client CANNOT (and must not try to) detect a
//     duplicate by email. The duplicate is detected only by the server:
//     either the session IS the existing user (auto-link) or the
//     callback errors with identity_already_exists (manual linking).
//     decideGooglePostAuth's duplicateEmailDetected flag exists for the
//     decision table and tests; in production it is always false at the
//     post-session gate, because a duplicate never yields a session.

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models.dart';
import 'account_store.dart';
import 'app_strings.dart';
import 'supabase_service.dart';

/// Custom-scheme redirect for native. Registered as an intent-filter in
/// AndroidManifest.xml (scheme com.hamsiq.app, host login-callback).
const String googleAuthScheme = 'com.hamsiq.app';
const String googleAuthRedirectUri = 'com.hamsiq.app://login-callback';

/// Web redirect: the published Flutter web preview origin. The browser
/// returns here after Google, the page reloads, and main.dart routes the
/// restored session to the setup gate.
const String googleWebRedirectUrl =
    'https://muqtada-hamsiq.github.io/hamsiq-android/';

/// Platform-aware redirectTo for signInWithOAuth / linkIdentity.
String googleRedirectTo() =>
    kIsWeb ? googleWebRedirectUrl : googleAuthRedirectUri;

/// Display name + avatar prefilled from the Google account's user_metadata
/// (keys `full_name`/`name` and `avatar_url`/`picture`, as Supabase maps
/// them from Google). The email is deliberately NOT exposed here: the
/// setup screen never needs to show it, and no email may reach the UI.
class GoogleProfileInfo {
  final String displayName;
  final String? avatarUrl;

  const GoogleProfileInfo({required this.displayName, this.avatarUrl});

  factory GoogleProfileInfo.fromUser(User user) {
    final md = user.userMetadata ?? {};
    var name = (md['full_name'] as String?)?.trim() ?? '';
    if (name.isEmpty) name = (md['name'] as String?)?.trim() ?? '';
    var avatar = (md['avatar_url'] as String?) ?? (md['picture'] as String?);
    if (avatar != null && avatar.trim().isEmpty) avatar = null;
    return GoogleProfileInfo(displayName: name, avatarUrl: avatar);
  }
}

/// Outcome of the post-OAuth gate (see decideGooglePostAuth).
enum GoogleSetupDecision {
  /// Profile row exists with a username — go home as normal.
  goHome,

  /// New Google user (or profile without a username) — must complete
  /// the setup screen. Must NOT reach home before this.
  needsSetup,

  /// The Google email already owns a different account (only when
  /// manual linking is enabled server-side) — route to the link flow:
  /// password sign-in first, then linkIdentity. Never create a profile.
  needsLink,
}

/// Pure setup-gate decision. A complete profile always wins: if the
/// profile exists with a username, the session already IS the right
/// account (auto-linked), whatever the duplicate flag says.
GoogleSetupDecision decideGooglePostAuth({
  required HamsiqProfile? profile,
  required bool duplicateEmailDetected,
}) {
  if (profile != null && profile.username.trim().isNotEmpty) {
    return GoogleSetupDecision.goHome;
  }
  if (duplicateEmailDetected) return GoogleSetupDecision.needsLink;
  return GoogleSetupDecision.needsSetup;
}

/// True when [e] is the GoTrue `identity_already_exists` failure: the
/// Google identity belongs to an email already registered under a
/// different user id (only possible with manual linking enabled).
/// Matches both the AuthException.code and a message containing the code,
/// because getSessionFromUrl puts the URL `error` param in `code` and
/// the `error_description` in the message.
bool isGoogleIdentityConflict(Object e) {
  if (e is AuthException && e.code == 'identity_already_exists') {
    return true;
  }
  final m = e.toString().toLowerCase();
  return m.contains('identity_already_exists') ||
      m.contains('identity already exists');
}

/// Map a Google-flow failure to a user-facing string. Every branch
/// returns an AppStrings value only — never a server detail, never an
/// email (a server message could contain one). The identity-conflict
/// case is NOT an error string: the caller routes it to the link screen
/// via [isGoogleIdentityConflict] instead.
String friendlyGoogleError(Object e) {
  final m = e.toString().toLowerCase();
  if (m.contains('provider_disabled') ||
      m.contains('oauth_provider_not_supported') ||
      m.contains('provider not supported')) {
    return AppStrings.t('googleUnavailable');
  }
  if (m.contains('socketexception') ||
      m.contains('failed host lookup') ||
      m.contains('network') ||
      m.contains('connection')) {
    return AppStrings.t('authNoConnection');
  }
  return AppStrings.t('genericError');
}

/// Password rule for the setup screen — MUST match isStrongPassword in
/// lib/screens/auth_screen.dart (min 8 chars, a letter, a digit).
/// Duplicated here (same MUST-match convention as the rate-limit
/// constants) so this service stays independent of the screen layer;
/// test/google_auth_test.dart pins the two implementations to agree.
bool _isStrongPassword(String p) =>
    p.length >= 8 &&
    RegExp(r'[A-Za-z\u0600-\u06FF]').hasMatch(p) &&
    RegExp(r'\d').hasMatch(p);

/// Username character rule — MUST match isValidUsername in
/// lib/screens/auth_screen.dart. Pinned to agree by the same test.
bool _isValidUsername(String u) =>
    RegExp(r'^[A-Za-z0-9_.\u0600-\u06FF-]+$').hasMatch(u);

/// Pure setup-form validation. Returns the AppStrings KEY of the first
/// problem, or null when the form is valid. Keys (not translated text)
/// so the caller translates at read time like the rest of the app.
String? validateGoogleSetup({
  required String username,
  required String password,
  required String confirmPassword,
}) {
  final u = username.trim().toLowerCase();
  if (u.isEmpty || password.isEmpty || confirmPassword.isEmpty) {
    return 'fillAllFields';
  }
  if (!_isValidUsername(u)) return 'authInvalidUsernameChars';
  if (u.length < 3) return 'authUsernameMin3';
  if (!_isStrongPassword(password)) return 'authWeakPassword';
  if (password != confirmPassword) return 'passwordMismatch';
  return null;
}

/// Thrown by [GoogleAuth.completeSetup]. [messageKey] is an AppStrings
/// key — the UI translates it; no raw message ever reaches the user.
class GoogleSetupException implements Exception {
  final String messageKey;

  const GoogleSetupException(this.messageKey);

  @override
  String toString() => messageKey;
}

/// Seam types so completeSetup is unit-testable without Supabase.
typedef GoogleOAuthLauncher = Future<bool> Function({
  required String redirectTo,
});
typedef GoogleUsernameChecker = Future<bool?> Function(String username);
typedef GooglePasswordSetter = Future<void> Function(String password);
typedef GoogleProfileUpserter = Future<HamsiqProfile> Function({
  required String username,
  required String displayName,
  String? avatarUrl,
});
typedef GoogleSessionSaver = Future<void> Function();

/// Completing the setup screen: (username, displayName, password,
/// avatarUrl) plus the seams completeSetup needs. Declared so the setup
/// screen can inject fakes in widget tests.
typedef GoogleCompleteSetup = Future<HamsiqProfile> Function({
  required String username,
  required String displayName,
  required String password,
  required String confirmPassword,
  String? avatarUrl,
});

class GoogleAuth {
  /// Launch the Google OAuth round-trip in the system browser. Returns
  /// whether the browser was launched — NOT whether sign-in succeeded
  /// (see the file header). The caller observes onAuthStateChange.
  static Future<bool> startSignIn({GoogleOAuthLauncher? launcher}) async {
    final launch = launcher ?? _defaultSignInLauncher;
    return launch(redirectTo: googleRedirectTo());
  }

  static GoogleOAuthLauncher get _defaultSignInLauncher =>
      ({required String redirectTo}) => Supabase.instance.client.auth
          .signInWithOAuth(OAuthProvider.google, redirectTo: redirectTo);

  /// Attach the Google identity to the CURRENTLY signed-in user (link
  /// flow — the user signed in with their password first). Returns
  /// whether the browser was launched. Requires "Allow manual linking"
  /// server-side; without it GoTrue answers `manual_linking_disabled`.
  static Future<bool> linkGoogle({GoogleOAuthLauncher? launcher}) async {
    final launch = launcher ?? _defaultLinkLauncher;
    return launch(redirectTo: googleRedirectTo());
  }

  static GoogleOAuthLauncher get _defaultLinkLauncher =>
      ({required String redirectTo}) => Supabase.instance.client.auth
          .linkIdentity(OAuthProvider.google, redirectTo: redirectTo);

  /// Live username-availability check through the check-username Edge
  /// Function — the SAME path (and contract) as signup:
  /// exactly {"available": bool}, nothing else. Returns null when the
  /// answer is inconclusive (malformed body, network error) so the
  /// caller blocks with the generic error instead of proceeding.
  /// A 429 throws GoogleSetupException('authTooManyAttempts').
  static Future<bool?> checkUsernameAvailability(String username) async {
    try {
      final res = await Supabase.instance.client.functions.invoke(
        'check-username',
        body: {'username': username.trim().toLowerCase()},
      );
      final data = res.data;
      if (data is! Map<String, dynamic>) return null;
      if (data.length != 1 || !data.containsKey('available')) return null;
      final v = data['available'];
      if (v is! bool) return null;
      return v;
    } on FunctionsHttpException catch (e) {
      if (e.status == 429) {
        throw const GoogleSetupException('authTooManyAttempts');
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  /// Complete the Google setup screen, in order:
  /// validate -> authoritative username re-check -> set the password
  /// (updateUser) -> create/fill the profile row -> record the session
  /// in AccountStore. The username is re-checked at submit time even
  /// though the screen live-checks it: the live check is advisory only.
  /// Throws [GoogleSetupException] with an AppStrings key on any
  /// validation, availability, or rate-limit failure.
  static Future<HamsiqProfile> completeSetup({
    required String username,
    required String displayName,
    required String password,
    required String confirmPassword,
    String? avatarUrl,
    GoogleUsernameChecker? checkUsername,
    GooglePasswordSetter? setPassword,
    GoogleProfileUpserter? upsertProfile,
    GoogleSessionSaver? saveSession,
  }) async {
    final errorKey = validateGoogleSetup(
      username: username,
      password: password,
      confirmPassword: confirmPassword,
    );
    if (errorKey != null) throw GoogleSetupException(errorKey);
    final uname = username.trim().toLowerCase();
    final name = displayName.trim().isEmpty ? uname : displayName.trim();

    final check = checkUsername ?? checkUsernameAvailability;
    final available = await check(uname);
    if (available == null) {
      throw const GoogleSetupException('genericError');
    }
    if (!available) {
      throw const GoogleSetupException('usernameTaken');
    }

    final setPass = setPassword ?? _defaultSetPassword;
    await setPass(password);

    final upsert = upsertProfile ?? _defaultUpsertProfile;
    final profile = await upsert(
      username: uname,
      displayName: name,
      avatarUrl: avatarUrl,
    );

    final save = saveSession ?? _defaultSaveSession;
    await save();
    return profile;
  }

  static GooglePasswordSetter get _defaultSetPassword =>
      (String password) => Supabase.instance.client.auth
          .updateUser(UserAttributes(password: password));

  static GoogleProfileUpserter get _defaultUpsertProfile =>
      ({
        required String username,
        required String displayName,
        String? avatarUrl,
      }) =>
          Api.upsertGoogleProfile(
            username: username,
            displayName: displayName,
            avatarUrl: avatarUrl,
          );

  static GoogleSessionSaver get _defaultSaveSession =>
      () => AccountStore.instance.saveCurrentSession();
}
