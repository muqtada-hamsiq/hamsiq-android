// Hamsiq native — groups API layer.
// Schema (web app, do not invent columns):
//   groups (sql-v4): id bigint, name text, avatar_url text,
//     created_by uuid, created_at timestamptz, is_public bool (sql-v13).
//     The creator is auto-added as admin by the add_group_creator trigger.
//   group_members (sql-v4): group_id bigint, user_id uuid,
//     role text default 'member', joined_at timestamptz; PK (group_id, user_id).
//   messages (supabase-schema.sql + sql-v4): group messages have
//     group_id set and receiver_id NULL (RLS enforces exactly that).
// RLS (sql-v4): groups visible to creator or members; insert needs
// approved + auth.uid() = created_by; group_members insert needs approved
// + caller is admin or the group creator (creator qualifies right after
// creating the group, so createGroup works in two calls).

import '../models.dart';
import 'supabase_service.dart';

/// One group row, plus the bits the list UI needs (member count and the
/// latest message). Built from groups + group_members + messages only.
class GroupInfo {
  final int id;
  final String name;
  final String? avatarUrl;
  final String? createdBy;
  final DateTime createdAt;
  final bool isPublic;
  int memberCount;
  GroupMessage? lastMessage;

  GroupInfo({
    required this.id,
    required this.name,
    this.avatarUrl,
    this.createdBy,
    required this.createdAt,
    this.isPublic = false,
    this.memberCount = 0,
    this.lastMessage,
  });

  factory GroupInfo.fromMap(Map<String, dynamic> m) => GroupInfo(
        id: (m['id'] as num).toInt(),
        name: (m['name'] ?? '') as String,
        avatarUrl: m['avatar_url'] as String?,
        createdBy: m['created_by'] as String?,
        createdAt: DateTime.parse(m['created_at'] as String),
        isPublic: (m['is_public'] ?? false) as bool,
      );
}

/// One membership row with the member's profile attached.
class GroupMember {
  final int groupId;
  final String userId;
  final String role; // 'admin' | 'member'
  final DateTime joinedAt;
  HamsiqProfile? profile;

  GroupMember({
    required this.groupId,
    required this.userId,
    required this.role,
    required this.joinedAt,
    this.profile,
  });

  factory GroupMember.fromMap(Map<String, dynamic> m) => GroupMember(
        groupId: (m['group_id'] as num).toInt(),
        userId: m['user_id'] as String,
        role: (m['role'] ?? 'member') as String,
        joinedAt: DateTime.parse(m['joined_at'] as String),
      );
}

/// A message inside a group. Same messages table as DMs; group messages
/// have group_id set and receiver_id null. body may be null (media/poll
/// messages) — it falls back to '' here; callers check [messageType].
/// Poll messages: message_type == 'poll' and body == the poll id (uuid).
class GroupMessage {
  final int id;
  final String senderId;
  final int groupId;
  final String body;
  final String messageType; // 'text' | 'poll' | 'image' | 'video' | ...
  final DateTime createdAt;

  GroupMessage({
    required this.id,
    required this.senderId,
    required this.groupId,
    required this.body,
    required this.messageType,
    required this.createdAt,
  });

  factory GroupMessage.fromMap(Map<String, dynamic> m) => GroupMessage(
        id: (m['id'] as num).toInt(),
        senderId: m['sender_id'] as String,
        groupId: (m['group_id'] as num).toInt(),
        body: (m['body'] ?? '') as String,
        messageType: (m['message_type'] ?? 'text') as String,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

class GroupsApi {
  /// Groups I belong to (via group_members), newest activity first.
  /// Same derivation as the web app's loadChats group section.
  static Future<List<GroupInfo>> fetchMyGroups() async {
    final gm = await Api.client
        .from('group_members')
        .select('group_id')
        .eq('user_id', Api.myId);
    final gids = (gm as List)
        .map((r) => (r['group_id'] as num).toInt())
        .toList();
    if (gids.isEmpty) return [];
    final rows = await Api.client
        .from('groups')
        .select()
        .inFilter('id', gids)
        .order('created_at', ascending: false);
    final groups = (rows as List)
        .map((r) => GroupInfo.fromMap(r as Map<String, dynamic>))
        .toList();
    // Member counts (one query for all my groups).
    final allMembers = await Api.client
        .from('group_members')
        .select('group_id')
        .inFilter('group_id', gids);
    final counts = <int, int>{};
    for (final r in (allMembers as List)) {
      final gid = (r['group_id'] as num).toInt();
      counts[gid] = (counts[gid] ?? 0) + 1;
    }
    // Latest message per group (one query, newest first, first wins).
    final msgRows = await Api.client
        .from('messages')
        .select()
        .inFilter('group_id', gids)
        .order('created_at', ascending: false)
        .limit(200);
    final lastByGroup = <int, GroupMessage>{};
    for (final r in (msgRows as List)) {
      final m = GroupMessage.fromMap(r as Map<String, dynamic>);
      lastByGroup.putIfAbsent(m.groupId, () => m);
    }
    for (final g in groups) {
      g.memberCount = counts[g.id] ?? 0;
      g.lastMessage = lastByGroup[g.id];
    }
    groups.sort((a, b) {
      final at = a.lastMessage?.createdAt.millisecondsSinceEpoch ?? 0;
      final bt = b.lastMessage?.createdAt.millisecondsSinceEpoch ?? 0;
      if (at != bt) return bt.compareTo(at);
      return b.createdAt.compareTo(a.createdAt);
    });
    return groups;
  }

  /// Create a group and add [memberIds] as members. The creator is
  /// auto-added as admin by the DB trigger — do not pass my own id.
  /// Returns the new group id (bigint).
  static Future<int> createGroup(String name, List<String> memberIds) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) throw Exception('اكتب اسم المجموعة');
    if (memberIds.isEmpty) throw Exception('اختر عضواً واحداً على الأقل');
    final rows = await Api.client.from('groups').insert({
      'name': trimmed,
      'created_by': Api.myId,
    }).select('id');
    final gid = ((rows as List).first['id'] as num).toInt();
    final memberRows = memberIds
        .map((uid) => {'group_id': gid, 'user_id': uid, 'role': 'member'})
        .toList();
    await Api.client.from('group_members').insert(memberRows);
    return gid;
  }

  /// Members of a group with their profiles attached.
  static Future<List<GroupMember>> fetchGroupMembers(int groupId) async {
    final rows = await Api.client
        .from('group_members')
        .select('group_id,user_id,role,joined_at')
        .eq('group_id', groupId)
        .order('joined_at', ascending: true);
    final members = (rows as List)
        .map((r) => GroupMember.fromMap(r as Map<String, dynamic>))
        .toList();
    final profiles = await Api.fetchProfiles(
      members.map((m) => m.userId).toList(),
    );
    for (final m in members) {
      m.profile = profiles[m.userId];
    }
    return members;
  }

  /// Group messages, oldest first. Includes poll messages
  /// (message_type 'poll', body = poll id) — the thread renders those
  /// with PollCard.
  static Future<List<GroupMessage>> fetchGroupMessages(
    int groupId, {
    int limit = 100,
  }) async {
    final rows = await Api.client
        .from('messages')
        .select()
        .eq('group_id', groupId)
        .order('created_at', ascending: true)
        .limit(limit);
    return (rows as List)
        .map((r) => GroupMessage.fromMap(r as Map<String, dynamic>))
        .toList();
  }

  /// Send a text message to a group: group_id set, receiver_id null
  /// (the messages insert RLS policy requires exactly that).
  static Future<GroupMessage> sendGroupMessage(
    int groupId,
    String text,
  ) async {
    final body = text.trim();
    if (body.isEmpty) throw Exception('اكتب رسالة أولاً');
    final rows = await Api.client.from('messages').insert({
      'sender_id': Api.myId,
      'receiver_id': null,
      'group_id': groupId,
      'body': body,
      'message_type': 'text',
    }).select();
    return GroupMessage.fromMap((rows as List).first as Map<String, dynamic>);
  }

  /// People I follow (follows.follower_id = me), as profiles — the
  /// member picker for creating a group. The web app picks from
  /// accepted friends; the native brief is "people I follow".
  static Future<List<HamsiqProfile>> fetchFollowing() async {
    final rows = await Api.client
        .from('follows')
        .select('following_id')
        .eq('follower_id', Api.myId)
        .limit(200);
    final ids = (rows as List)
        .map((r) => r['following_id'] as String)
        .toList();
    if (ids.isEmpty) return [];
    final profiles = await Api.fetchProfiles(ids);
    final out = ids
        .map((id) => profiles[id])
        .whereType<HamsiqProfile>()
        .toList();
    out.sort((a, b) => a.displayName.compareTo(b.displayName));
    return out;
  }
}
