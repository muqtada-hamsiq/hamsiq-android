// Hamsiq native — secure username login (audit finding H-01 fix).
//
// The old login called the SECURITY DEFINER RPC get_email_by_username()
// (granted EXECUTE to anon) and received the account's email in the app —
// anyone who knew a username could harvest the email without logging in.
// This service replaces that path: it calls the secure-login Edge Function
// (supabase/functions/secure-login/index.ts), which resolves the username,
// fetches the email and signs in entirely server-side, and returns ONLY
// the session tokens + {id, username}. There is no email anywhere on this
// client path — never in a request, never in a response, never in an
// error message.
//
// Error contract (mirrors the Edge Function):
//   * Every auth failure — unknown username, wrong password, malformed
//     input, server error — throws SecureLoginException with the SAME
//     generic Arabic message. The caller must never learn which of those
//     happened. The function body itself is also one generic message.
//   * Rate limiting is signalled ONLY by HTTP 429 (body stays generic),
//     mapped here to a "too many attempts" message. A 429 does not leak
//     account existence: the server records attempts for unknown
//     usernames too.
//   * Network failures (FunctionsFetchException, status 0) are also
//     mapped to the generic message so no raw exception ever reaches the
//     user; the auth screen's friendlyAuthError passes our Arabic
//     messages through unchanged.

import 'package:supabase_flutter/supabase_flutter.dart';

/// The ONE message every login failure shows. Never varies between
/// "unknown user" and "wrong password" — that distinction is exactly
/// what H-01 was leaking (via the email) and must not come back.
const String secureLoginGenericError =
    'اسم المستخدم أو كلمة المرور غير صحيحة';

/// Shown only when the server answers 429 (too many failed attempts).
/// Does not reveal whether the account exists.
const String secureLoginRateLimitError =
    'محاولات دخول كثيرة، انتظر 15 دقيقة وحاول مرة ثانية';

/// Rate-limit thresholds — MUST match supabase/functions/secure-login/
/// index.ts and the login_attempts table created by sql-v36.sql.
///   * 5 failed attempts per username per 15 minutes
///   * 10 failed attempts per client IP per 15 minutes
const int secureLoginMaxFailuresPerUser = 5;
const int secureLoginMaxFailuresPerIp = 10;
const Duration secureLoginRateLimitWindow = Duration(minutes: 15);

/// Pure rate-limit decision, mirroring the server rule: block once the
/// number of failures inside the window reaches the limit. Kept pure so
/// the threshold logic is unit-testable without a server.
bool isLoginRateLimited({
  required int failuresInWindow,
  required int maxFailures,
}) =>
    failuresInWindow >= maxFailures;

/// Thrown for every secure-login failure. [message] is always one of the
/// two constants above — never a server detail, never an email.
class SecureLoginException implements Exception {
  final String message;

  /// True only for the 429 rate-limit case.
  final bool rateLimited;

  const SecureLoginException(this.message, {this.rateLimited = false});

  @override
  String toString() => message;
}

/// The client-visible success shape of the secure-login function.
/// Deliberately has NO email field: if the server ever returned one,
/// [fromJson] rejects the whole response instead of exposing it.
class SecureLoginResponse {
  final String accessToken;
  final String refreshToken;
  final String userId;
  final String username;

  const SecureLoginResponse({
    required this.accessToken,
    required this.refreshToken,
    required this.userId,
    required this.username,
  });

  factory SecureLoginResponse.fromJson(Map<String, dynamic> json) {
    // Defense in depth: the contract says the server never returns an
    // email. If it ever does (misdeploy, old version), fail the login
    // rather than letting an email reach client code.
    if (json.containsKey('email')) {
      throw const SecureLoginException(secureLoginGenericError);
    }
    final accessToken = json['access_token'];
    final refreshToken = json['refresh_token'];
    final user = json['user'];
    final userId = user is Map<String, dynamic> ? user['id'] : null;
    final username = user is Map<String, dynamic> ? user['username'] : null;
    if (accessToken is! String ||
        accessToken.isEmpty ||
        refreshToken is! String ||
        refreshToken.isEmpty ||
        userId is! String ||
        userId.isEmpty ||
        username is! String ||
        username.isEmpty) {
      throw const SecureLoginException(secureLoginGenericError);
    }
    return SecureLoginResponse(
      accessToken: accessToken,
      refreshToken: refreshToken,
      userId: userId,
      username: username,
    );
  }
}

/// Seam for tests: invokes the Edge Function and returns its decoded JSON
/// body. Production uses [SupabaseClient.functions.invoke].
typedef SecureLoginInvoker = Future<Map<String, dynamic>> Function(
  Map<String, dynamic> body,
);

/// Seam for tests: applies a session to the Supabase client. Production
/// uses [GoTrueClient.setSession].
typedef SecureLoginSessionApplier = Future<void> Function({
  required String accessToken,
  required String refreshToken,
});

class SecureLogin {
  static const _functionName = 'secure-login';

  /// Login with username + password through the secure-login Edge
  /// Function. On success the returned session is applied to [client]
  /// (or [Supabase.instance.client]) and the parsed response is
  /// returned. On ANY failure throws [SecureLoginException] with the
  /// generic message (or the rate-limit message on 429).
  static Future<SecureLoginResponse> loginWithUsername(
    String username,
    String password, {
    SupabaseClient? client,
    SecureLoginInvoker? invoker,
    SecureLoginSessionApplier? applySession,
  }) async {
    final normalized = username.trim().toLowerCase();
    if (normalized.isEmpty || password.isEmpty) {
      throw const SecureLoginException(secureLoginGenericError);
    }
    // Resolved lazily: when the test seams (invoker/applySession) are
    // provided, Supabase.instance is never touched, so the pure logic is
    // unit-testable with no initialization and no network.
    SupabaseClient resolveClient() => client ?? Supabase.instance.client;
    final invoke = invoker ?? _defaultInvoker(resolveClient());
    final apply = applySession ?? _defaultApplier(resolveClient());

    final Map<String, dynamic> data;
    try {
      data = await invoke({'username': normalized, 'password': password});
    } on FunctionException catch (e) {
      // The Edge Function throws FunctionsHttpException (status 401/429)
      // on failure; FunctionsFetchException (status 0) on network error.
      // Either way the user sees only our generic message — never the
      // server's details, never an email.
      if (e.status == 429) {
        throw const SecureLoginException(
          secureLoginRateLimitError,
          rateLimited: true,
        );
      }
      throw const SecureLoginException(secureLoginGenericError);
    } catch (_) {
      throw const SecureLoginException(secureLoginGenericError);
    }

    final response = SecureLoginResponse.fromJson(data);
    // setSession(refreshToken, {accessToken}) — refresh token is the
    // positional argument in gotrue 2.x; it validates the access token
    // and establishes the session (currentUser becomes available).
    await apply(
      accessToken: response.accessToken,
      refreshToken: response.refreshToken,
    );
    return response;
  }

  static SecureLoginInvoker _defaultInvoker(SupabaseClient c) {
    return (Map<String, dynamic> body) async {
      final res = await c.functions.invoke(_functionName, body: body);
      final data = res.data;
      if (data is! Map<String, dynamic>) {
        throw const SecureLoginException(secureLoginGenericError);
      }
      return data;
    };
  }

  static SecureLoginSessionApplier _defaultApplier(SupabaseClient c) {
    return ({required String accessToken, required String refreshToken}) =>
        c.auth.setSession(refreshToken, accessToken: accessToken);
  }
}
