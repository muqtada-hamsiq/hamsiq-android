// Hamsiq native — web-safe helpers for local-file operations.
//
// Android and web differ here (dart:io exists only on Android), so the
// implementation is chosen by conditional import. The io version is
// EXACTLY what the code did before this file existed — Android behavior
// is unchanged. The web version does the equivalent with blob URLs
// (XFile.path on web) and no-ops where there is no on-disk file.
export 'platform_file_stub.dart'
    if (dart.library.io) 'platform_file_io.dart';
