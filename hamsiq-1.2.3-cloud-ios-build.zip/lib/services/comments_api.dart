// Hamsiq native — Comments API (Phase 2, workstream A).
// Mirrors the web app's comments feature exactly:
//   table public.comments (sql-v16.sql):
//     id bigint identity PK, post_id bigint FK posts(id) on delete cascade,
//     author_id uuid FK profiles(id) on delete cascade,
//     body text NOT NULL, created_at timestamptz NOT NULL default now().
//   RLS (sql-v16 + sql-v21): select needs is_approved(); insert needs
//   auth.uid() = author_id + is_approved() + post exists + not flagged,
//   rate-limited to 20/min; delete needs author, post owner, or admin;
//   no update policy (comments cannot be edited).
//   Web order (index.html loadCommentsList): created_at ASC (oldest first),
//   limit 100; counts computed client-side from post_id rows.
// Do NOT invent columns: the column is `body`, not `content`.

import '../models.dart';
import 'supabase_service.dart';

/// One row of public.comments, with its author profile attached when
/// available. The model lives here (not models.dart) so this workstream
/// does not touch files owned by other workstreams.
///
/// Wave 1 columns (sql-v29): parent_id (threaded reply, null for a
/// top-level comment), gif_url (curated-GIF comment), is_pinned.
class CommentItem {
  final int id;
  final int postId;
  final String authorId;
  final String body;
  final DateTime createdAt;
  final int? parentId;
  final String? gifUrl;
  final bool isPinned;
  HamsiqProfile? author;

  CommentItem({
    required this.id,
    required this.postId,
    required this.authorId,
    required this.body,
    required this.createdAt,
    this.parentId,
    this.gifUrl,
    this.isPinned = false,
    this.author,
  });

  factory CommentItem.fromMap(Map<String, dynamic> m) => CommentItem(
        id: (m['id'] as num).toInt(),
        postId: (m['post_id'] as num).toInt(),
        authorId: m['author_id'] as String,
        body: (m['body'] ?? '') as String,
        createdAt: DateTime.parse(m['created_at'] as String),
        parentId:
            m['parent_id'] == null ? null : (m['parent_id'] as num).toInt(),
        gifUrl: m['gif_url'] as String?,
        isPinned: (m['is_pinned'] ?? false) as bool,
      );

  /// True when this comment is a GIF-only comment (no text body).
  bool get isGifOnly =>
      gifUrl != null &&
      gifUrl!.isNotEmpty &&
      body.trim().isEmpty;
}

class CommentsApi {
  /// Web app maxlength for a comment input.
  static const int maxBodyLength = 300;

  /// Instagram's pinned-comment limit (inventory report §1: Help Center
  /// says 3; one 2026 round-up claims 5 — 3 is the verified figure,
  /// and the DB function enforces it too).
  static const int maxPinnedComments = 3;

  /// Curated GIFs for comments. Honest label: there is NO GIF search
  /// API here — Tenor's keyless endpoint returns 403 without an API
  /// key and Giphy search needs a key, so the picker offers this small
  /// fixed set of public Giphy GIFs (each URL verified HTTP 200 on
  /// 2026-11-15). No key, no account, no invented service.
  static const List<String> curatedGifUrls = [
    'https://media.giphy.com/media/3o7abKhOpu0NwenH3O/giphy.gif',
    'https://media.giphy.com/media/l0HlBO7eyXzSZkJri/giphy.gif',
    'https://media.giphy.com/media/26tknCqiYrI8lCk3y/giphy.gif',
    'https://media.giphy.com/media/13HgwGsXF0aiGY/giphy.gif',
    'https://media.giphy.com/media/10JprGM3npA2Tyg/giphy.gif',
    'https://media.giphy.com/media/3o6ZtpxSZbQRRnwCKQ/giphy.gif',
    'https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif',
    'https://media.giphy.com/media/3o7TKr3nzbh5JjDvFK/giphy.gif',
  ];

  /// Display order for a post's comments: pinned first (oldest pinned
  /// first), then the rest oldest first (web app order). Pure helper so
  /// it is unit testable; the fetch sorts client-side, so it also works
  /// before sql-v29 runs (is_pinned simply reads false then).
  static List<CommentItem> orderComments(List<CommentItem> comments) {
    final sorted = List<CommentItem>.of(comments);
    sorted.sort((a, b) {
      if (a.isPinned != b.isPinned) return a.isPinned ? -1 : 1;
      return a.createdAt.compareTo(b.createdAt);
    });
    return sorted;
  }

  /// Replies nested under their parent, in display order: top-level
  /// comments ordered by [orderComments], each followed immediately by
  /// its replies (oldest first). Pure helper, unit testable.
  static List<CommentItem> threadComments(List<CommentItem> comments) {
    final ordered = orderComments(comments);
    final topLevel = ordered.where((c) => c.parentId == null).toList();
    final replies = <int, List<CommentItem>>{};
    for (final c in ordered) {
      if (c.parentId != null) {
        replies.putIfAbsent(c.parentId!, () => []).add(c);
      }
    }
    final out = <CommentItem>[];
    for (final parent in topLevel) {
      out.add(parent);
      out.addAll(replies[parent.id] ?? const []);
    }
    // Orphan replies (parent deleted/not loaded) go at the end.
    final seen = out.map((c) => c.id).toSet();
    for (final c in ordered) {
      if (!seen.contains(c.id)) out.add(c);
    }
    return out;
  }

  /// Comments for one post, oldest first (same order as the web app),
  /// limit 100, with author profiles attached.
  static Future<List<CommentItem>> fetchComments(int postId) async {
    final rows = await Api.client
        .from('comments')
        .select()
        .eq('post_id', postId)
        .order('created_at', ascending: true)
        .limit(100);
    final comments = (rows as List)
        .map((r) => CommentItem.fromMap(r as Map<String, dynamic>))
        .toList();
    if (comments.isEmpty) return comments;
    final authorIds = comments.map((c) => c.authorId).toSet().toList();
    final authors = await Api.fetchProfiles(authorIds);
    for (final c in comments) {
      c.author = authors[c.authorId];
    }
    return orderComments(comments);
  }

  /// Add a comment as the current user. Returns the inserted row with
  /// the author's own profile attached. Throws on empty / over-long text;
  /// the server enforces the 20/min rate limit and the insert RLS policy.
  /// [parentId] makes this a threaded reply; [gifUrl] must be one of
  /// [curatedGifUrls] (a GIF comment may carry empty text). The new
  /// columns are only sent when set, so a plain text comment still
  /// inserts cleanly before sql-v29 runs.
  static Future<CommentItem> addComment(
    int postId,
    String text, {
    int? parentId,
    String? gifUrl,
  }) async {
    final body = text.trim();
    if (gifUrl != null && !curatedGifUrls.contains(gifUrl)) {
      throw Exception('صورة GIF غير معروفة');
    }
    if (body.isEmpty && gifUrl == null) {
      throw Exception('اكتب تعليقاً أولاً');
    }
    if (body.length > maxBodyLength) {
      throw Exception('التعليق طويل جداً (الحد $maxBodyLength حرف)');
    }
    final row = <String, dynamic>{
      'post_id': postId,
      'author_id': Api.myId,
      'body': body,
    };
    if (parentId != null) row['parent_id'] = parentId;
    if (gifUrl != null) row['gif_url'] = gifUrl;
    final rows = await Api.client.from('comments').insert(row).select();
    final comment =
        CommentItem.fromMap((rows as List).first as Map<String, dynamic>);
    comment.author = await Api.fetchProfile(Api.myId);
    return comment;
  }

  /// Reply to a comment (threaded under it). The reply text is prefixed
  /// with nothing — the UI shows the nesting instead.
  static Future<CommentItem> replyToComment(
    int postId,
    int parentCommentId,
    String text,
  ) async {
    return addComment(postId, text, parentId: parentCommentId);
  }

  /// Post a GIF comment (GIF only, no text).
  static Future<CommentItem> addGifComment(int postId, String gifUrl) async {
    return addComment(postId, '', gifUrl: gifUrl);
  }

  /// Pin / unpin a comment via the SECURITY DEFINER function in sql-v29
  /// (only the post owner or the comment's author may pin; max 3 pinned
  /// per post — the function enforces both). Returns the new pinned
  /// state. The caller passes the post owner id for the client-side
  /// permission check so a forbidden tap fails fast with a clear error.
  static Future<bool> setCommentPinned(
    CommentItem comment,
    String postOwnerId,
    bool pinned,
  ) async {
    final myId = Api.myId;
    if (myId != postOwnerId && myId != comment.authorId) {
      throw Exception('فقط صاحب المنشور أو صاحب التعليق يستطيع التثبيت');
    }
    await Api.client.rpc('set_comment_pinned', params: {
      'p_comment_id': comment.id,
      'p_pinned': pinned,
    });
    return pinned;
  }

  /// Delete a comment — own comments only, unless [asPostOwner] is true
  /// (the post owner may also delete comments on their post under the
  /// sql-v16 RLS policy; the author filter is then dropped so the
  /// server-side policy decides).
  static Future<void> deleteComment(
    int commentId, {
    bool asPostOwner = false,
  }) async {
    var query = Api.client.from('comments').delete().eq('id', commentId);
    if (!asPostOwner) {
      query = query.eq('author_id', Api.myId);
    }
    await query;
  }

  /// Comment counts for a list of posts, same approach as the web app's
  /// loadCommentCounts: select post_id rows, count client-side. Every
  /// requested post id is present in the result (0 when it has none).
  static Future<Map<int, int>> fetchCommentCounts(List<int> postIds) async {
    if (postIds.isEmpty) return {};
    final rows = await Api.client
        .from('comments')
        .select('post_id')
        .inFilter('post_id', postIds);
    return countByPost(
      (rows as List).cast<Map<String, dynamic>>(),
      postIds,
    );
  }

  /// Pure helper used by [fetchCommentCounts]: count post_id rows per
  /// post, zero-filling ids with no rows. Kept separate so it is unit
  /// testable without a network connection or a Supabase session.
  static Map<int, int> countByPost(
    List<Map<String, dynamic>> rows,
    List<int> postIds,
  ) {
    final counts = <int, int>{for (final id in postIds) id: 0};
    for (final r in rows) {
      final pid = (r['post_id'] as num).toInt();
      if (counts.containsKey(pid)) counts[pid] = counts[pid]! + 1;
    }
    return counts;
  }
}
