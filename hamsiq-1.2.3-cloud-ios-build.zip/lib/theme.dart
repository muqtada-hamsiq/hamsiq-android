// Hamsiq native — theme. FINAL (user's order 2026-11-15): TRUE BLACK +
// Instagram blue. Background pure black #000000, cards/panels near-black
// (#0A0A0A / #111111), texts and icons white, and the ONLY accent colour
// is Instagram blue #0095F6 (primary buttons, active icons, links).
// Gold #D4AF37 and purple #A78BFA are REMOVED entirely — no third colour.

import 'package:flutter/material.dart';

import 'services/app_strings.dart';

class HamsiqTheme {
  static const Color bg = Color(0xFF000000);
  static const Color bgDeep = Color(0xFF000000);
  static const Color panel = Color(0xFF0A0A0A);
  static const Color panel2 = Color(0xFF111111);
  static const Color line = Color(0xFF262626);
  static const Color text = Color(0xFFFFFFFF);
  static const Color muted = Color(0xFF9291A5);
  // Instagram blue — the single accent colour of the whole app.
  static const Color accent = Color(0xFF0095F6);
  // Darker blue for the second stop of sent-message bubbles.
  static const Color accentDark = Color(0xFF0064E0);

  static ThemeData get dark => ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'Tajawal',
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
          primary: accent,
          secondary: accent,
          surface: panel,
          onSurface: text,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: bg,
          elevation: 0,
          centerTitle: false,
          titleTextStyle: TextStyle(
            color: text,
            fontSize: 22,
            fontWeight: FontWeight.w800,
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: panel2,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          hintStyle: const TextStyle(color: muted),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: accent,
            foregroundColor: Colors.white,
            textStyle: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w700,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            padding: const EdgeInsets.symmetric(vertical: 14),
          ),
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: panel,
          selectedItemColor: accent,
          unselectedItemColor: muted,
          type: BottomNavigationBarType.fixed,
          showSelectedLabels: false,
          showUnselectedLabels: false,
        ),
      );
}

/// Short relative time, same style as the web app ("now", "5 min" ...).
/// H-06 Part 2: the units come from AppStrings, so timestamps render in
/// English in English mode instead of always in Arabic.
String timeAgo(DateTime t) {
  final d = DateTime.now().difference(t);
  if (d.inSeconds < 60) return AppStrings.t('timeNow');
  if (d.inMinutes < 60) {
    return AppStrings.t('timeMin').replaceAll('{n}', '${d.inMinutes}');
  }
  if (d.inHours < 24) {
    return AppStrings.t('timeHour').replaceAll('{n}', '${d.inHours}');
  }
  if (d.inDays < 7) {
    return AppStrings.t('timeDay').replaceAll('{n}', '${d.inDays}');
  }
  return '${t.day}/${t.month}/${t.year}';
}
