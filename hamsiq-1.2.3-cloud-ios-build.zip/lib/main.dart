// Hamsiq native — entry point.
// Phase 1: auth + feed + chats + profile + reels + native camera create.
// No WebView anywhere in this app.

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'models.dart';
import 'screens/auth_screen.dart';
import 'screens/google_setup_screen.dart';
import 'screens/home_shell.dart';
import 'services/account_store.dart';
import 'services/app_strings.dart';
import 'services/google_auth.dart';
import 'services/push_navigation.dart';
import 'services/push_service.dart';
import 'services/supabase_service.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppStrings.load();
  await Supabase.initialize(
    url: Api.supabaseUrl,
    publishableKey: Api.supabaseAnonKey,
  );
  // v1.2.2: multi-account sessions — keep stored tokens fresh on every
  // sign-in / token refresh (Supabase rotates refresh tokens).
  AccountStore.instance.init();
  // Push notifications: never throws and never blocks boot. Until
  // google-services.json is wired, Firebase init fails here and the
  // service degrades silently (in-app notifications only).
  PushService.instance.navigator = AppPushNavigator();
  await PushService.instance.init();
  runApp(const HamsiqApp());
}

class HamsiqApp extends StatefulWidget {
  const HamsiqApp({super.key});

  @override
  State<HamsiqApp> createState() => _HamsiqAppState();
}

class _HamsiqAppState extends State<HamsiqApp> {
  HamsiqProfile? _me;
  bool _checking = true;

  /// A signed-in session with no complete profile yet — a Google OAuth
  /// user who has not finished setup (including the web case: the OAuth
  /// redirect reloads the page, so boot is where the session is first
  /// seen). The session is KEPT: signing out here would strand the user
  /// on the login screen with no way back into setup.
  GoogleProfileInfo? _googleSetup;

  @override
  void initState() {
    super.initState();
    _restoreSession();
  }

  Future<void> _restoreSession() async {
    if (Api.isLoggedIn) {
      try {
        final user = Api.client.auth.currentUser!;
        final profile = await Api.fetchProfile(user.id);
        if (profile != null && profile.username.trim().isNotEmpty) {
          // v1.2.2: record the current account in the switcher list
          // (upgrade path for accounts that logged in before 1.2.2).
          await AccountStore.instance.saveCurrentSession();
          if (mounted) setState(() => _me = profile);
        } else {
          final metaUsername =
              ((user.userMetadata?['username'] ?? '') as String).trim();
          if (metaUsername.isNotEmpty) {
            // Password user whose profile row is missing: the old
            // auto-create path (username comes from user_metadata).
            final me = await Api.ensureMyProfile();
            await AccountStore.instance.saveCurrentSession();
            if (mounted) setState(() => _me = me);
          } else {
            // Google OAuth user with no profile: keep the session and
            // show the setup screen to complete it.
            if (mounted) {
              setState(() => _googleSetup = GoogleProfileInfo.fromUser(user));
            }
          }
        }
      } catch (_) {
        // Session invalid (e.g. signed out elsewhere) — show login.
        await Api.signOut();
      }
    }
    if (mounted) setState(() => _checking = false);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hamsiq',
      debugShowCheckedModeBanner: false,
      theme: HamsiqTheme.dark,
      navigatorKey: PushService.navigatorKey,
      home: _checking
          ? const Scaffold(
              body: Center(
                child: CircularProgressIndicator(color: HamsiqTheme.accent),
              ),
            )
          : _me != null
              ? HomeShell(me: _me!)
              : _googleSetup != null
                  // Google OAuth session without a complete profile:
                  // the setup screen (no skip — home only after it
                  // completes and the profile exists).
                  ? ValueListenableBuilder<String>(
                      valueListenable: AppStrings.lang,
                      builder: (context, lang, _) => Directionality(
                        textDirection: lang == 'ar'
                            ? TextDirection.rtl
                            : TextDirection.ltr,
                        child: GoogleSetupScreen(
                          initialDisplayName: _googleSetup!.displayName,
                          initialAvatarUrl: _googleSetup!.avatarUrl,
                          onCompleted: () async {
                            final me = await Api.ensureMyProfile();
                            await AccountStore.instance
                                .saveCurrentSession();
                            if (mounted) {
                              setState(() {
                                _me = me;
                                _googleSetup = null;
                              });
                            }
                          },
                        ),
                      ),
                    )
                  // v1.2.1: the login screen must lay out right-to-left
                  // when the app language is Arabic. MaterialApp has no
                  // locale set, so it defaults to LTR; force the
                  // direction here and rebuild when the language changes.
                  : ValueListenableBuilder<String>(
                      valueListenable: AppStrings.lang,
                      builder: (context, lang, _) => Directionality(
                        textDirection: lang == 'ar'
                            ? TextDirection.rtl
                            : TextDirection.ltr,
                        child: AuthScreen(
                          onAuthed: () async {
                            final me = await Api.ensureMyProfile();
                            if (mounted) setState(() => _me = me);
                          },
                        ),
                      ),
                    ),
    );
  }
}
