// Shared small widgets for the Hamsiq native app.

import 'package:flutter/material.dart';
import '../models.dart';
import '../services/media_api.dart';
import '../theme.dart';

/// Round user avatar: uploaded photo if present, else the emoji avatar,
/// else a dark circle with the first letter.
class AvatarWidget extends StatelessWidget {
  final HamsiqProfile? profile;
  final double size;
  final bool showRing;

  const AvatarWidget({
    super.key,
    required this.profile,
    this.size = 48,
    this.showRing = false,
  });

  @override
  Widget build(BuildContext context) {
    final photo = profile?.photoUrl;
    final border = showRing
        ? Border.all(color: HamsiqTheme.accent, width: 2)
        : null;
    if (photo != null) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, border: border),
        child: ClipOval(
          child: Image.network(
            photo,
            width: size,
            height: size,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => _fallback(),
          ),
        ),
      );
    }
    return _fallback(border: border);
  }

  Widget _fallback({BoxBorder? border}) {
    final emoji = profile?.displayAvatar ?? '😀';
    final isEmoji = profile?.photoUrl == null &&
        (profile == null || !profile!.avatar.startsWith('http'));
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: HamsiqTheme.panel2,
        border: border,
      ),
      child: Text(
        isEmoji ? emoji : (profile?.displayName.isNotEmpty == true
            ? profile!.displayName[0].toUpperCase()
            : '?'),
        style: TextStyle(fontSize: size * 0.45),
      ),
    );
  }
}

/// Small blue verified tick next to a name (only when verified is true).
/// [size] defaults to 15pt; the feed AppBar brand mark uses 18pt.
class VerifiedTick extends StatelessWidget {
  final double size;
  const VerifiedTick({super.key, this.size = 15});

  @override
  Widget build(BuildContext context) {
    return Icon(Icons.verified, size: size, color: HamsiqTheme.accent);
  }
}

void showError(BuildContext context, Object e) {
  final msg = e.toString().replaceFirst('Exception: ', '');
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(msg), backgroundColor: Colors.red.shade800),
  );
}

void showOk(BuildContext context, String msg) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(msg), backgroundColor: Colors.green.shade800),
  );
}

class LoadingCenter extends StatelessWidget {
  const LoadingCenter({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: CircularProgressIndicator(color: HamsiqTheme.accent),
    );
  }
}

class EmptyCenter extends StatelessWidget {
  final String text;
  const EmptyCenter(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        text,
        style: const TextStyle(color: HamsiqTheme.muted, fontSize: 15),
      ),
    );
  }
}

/// Image.network that re-signs an expired (or about-to-expire)
/// Supabase signed URL before loading (H-04 re-sign-on-render).
/// Public URLs and fresh signed URLs load as-is with no extra call:
/// a stale signed URL is re-signed once in initState and the fresh
/// URL is used instead. While a re-sign is in flight, a sized
/// spinner is shown. The re-sign is best-effort (see
/// MediaApi.ensureFreshUrl): the server-side `resign-media` Edge
/// Function is tried first (so recipients can re-sign too), then
/// direct Storage signing; when both fail the stored URL is tried
/// as-is.
class SignedMediaImage extends StatefulWidget {
  final String url;
  final double? width;
  final double? height;
  final BoxFit fit;
  final ImageLoadingBuilder? loadingBuilder;
  final ImageErrorWidgetBuilder? errorBuilder;

  const SignedMediaImage({
    super.key,
    required this.url,
    this.width,
    this.height,
    this.fit = BoxFit.cover,
    this.loadingBuilder,
    this.errorBuilder,
  });

  @override
  State<SignedMediaImage> createState() => _SignedMediaImageState();
}

class _SignedMediaImageState extends State<SignedMediaImage> {
  String? _fresh;

  @override
  void initState() {
    super.initState();
    // Fresh / public URL: use as-is, no spinner flash, no network.
    if (!MediaApi.needsResign(widget.url)) {
      _fresh = widget.url;
      return;
    }
    MediaApi.ensureFreshUrl(widget.url).then((u) {
      if (mounted) setState(() => _fresh = u);
    });
  }

  @override
  Widget build(BuildContext context) {
    final url = _fresh;
    if (url == null) {
      return SizedBox(
        width: widget.width,
        height: widget.height,
        child: const Center(
          child: SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
        ),
      );
    }
    return Image.network(
      url,
      width: widget.width,
      height: widget.height,
      fit: widget.fit,
      loadingBuilder: widget.loadingBuilder,
      errorBuilder: widget.errorBuilder,
    );
  }
}
