// v1.2.2: Instagram-style account switcher bottom sheet.
// Tapping the username + chevron on the own profile opens this sheet:
// the saved accounts (avatar + username, checkmark on the current one)
// and an "+ Add account" row below. Only accounts that actually logged
// in on this device are ever listed — no demo/fake accounts.

import 'package:flutter/material.dart';

import '../main.dart';
import '../models.dart';
import '../screens/auth_screen.dart';
import '../services/account_store.dart';
import '../services/app_strings.dart';
import '../theme.dart';
import 'common.dart';

/// Load the saved accounts and show the switcher sheet. [context] is
/// the profile screen's context — it stays alive under the sheet and is
/// reused to push the login screen after the sheet closes.
Future<void> showAccountSwitcherSheet(BuildContext context) async {
  final accounts = await AccountStore.instance.loadAccounts();
  final currentId = await AccountStore.instance.currentAccountId();
  if (!context.mounted) return;
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: HamsiqTheme.panel,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (_) => AccountSwitcherSheet(
      accounts: accounts,
      currentId: currentId,
      parentContext: context,
    ),
  );
}

class AccountSwitcherSheet extends StatefulWidget {
  final List<SavedAccount> accounts;
  final String? currentId;

  /// Context of the screen under the sheet (the profile screen). Used
  /// for navigation after the sheet closes — the sheet's own context is
  /// deactivated by then.
  final BuildContext parentContext;

  /// Injectable store for tests; production uses the singleton.
  final AccountStore? store;

  const AccountSwitcherSheet({
    super.key,
    required this.accounts,
    required this.currentId,
    required this.parentContext,
    this.store,
  });

  AccountStore get _store => store ?? AccountStore.instance;

  @override
  State<AccountSwitcherSheet> createState() => _AccountSwitcherSheetState();
}

class _AccountSwitcherSheetState extends State<AccountSwitcherSheet> {
  bool _busy = false;

  HamsiqProfile _asProfile(SavedAccount a) => HamsiqProfile(
        id: a.id,
        username: a.username,
        displayName: a.displayName,
        avatar: '😀',
        avatarUrl: a.avatarUrl,
        bio: '',
        verified: false,
        isAdmin: false,
        approved: true,
        isPrivate: false,
      );

  Future<void> _switchTo(SavedAccount a) async {
    if (_busy) return;
    if (a.id == widget.currentId) {
      if (mounted) Navigator.of(context).pop();
      return;
    }
    setState(() => _busy = true);
    try {
      await widget._store.switchTo(a.id);
      if (!mounted) return;
      // Reload the whole app as the switched account (same pattern as
      // the Settings logout: a fresh HamsiqApp re-runs the session
      // check, so feed, DMs, profile and notifications all follow the
      // switched account).
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HamsiqApp()),
        (_) => false,
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      showError(context, e);
    }
  }

  Future<void> _addAccount() async {
    if (_busy) return;
    if (widget.accounts.length >= AccountStore.maxAccounts) {
      showError(
        context,
        AppStrings.t('accountCapMessage'),
      );
      return;
    }
    // Close the sheet, then open the login screen in add-account mode.
    // The login screen shows a back button that returns to the current
    // account's home WITHOUT logging out — the saved login stays.
    Navigator.of(context).pop();
    await Navigator.of(widget.parentContext).push(
      MaterialPageRoute(
        builder: (_) => Directionality(
          // The standalone login screen is RTL in Arabic; the
          // add-account login must match it (back arrow, fields).
          textDirection: AppStrings.isArabic
              ? TextDirection.rtl
              : TextDirection.ltr,
          child: AuthScreen(
            isAddAccount: true,
            onBack: () => Navigator.of(widget.parentContext).pop(),
            onAuthed: () async {
              await AccountStore.instance.saveCurrentSession();
              if (widget.parentContext.mounted) {
                Navigator.of(widget.parentContext).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const HamsiqApp()),
                  (_) => false,
                );
              }
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 12),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: HamsiqTheme.line,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 8),
          Flexible(
            child: ListView(
              shrinkWrap: true,
              children: [
                for (final a in widget.accounts)
                  ListTile(
                    leading: AvatarWidget(profile: _asProfile(a), size: 44),
                    title: Text(
                      a.username,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      a.displayName,
                      style: const TextStyle(
                        color: HamsiqTheme.muted,
                        fontSize: 13,
                      ),
                    ),
                    trailing: a.id == widget.currentId
                        ? const Icon(Icons.check, color: HamsiqTheme.accent)
                        : null,
                    onTap: () => _switchTo(a),
                  ),
                const Divider(color: HamsiqTheme.line, height: 1),
                ListTile(
                  leading: Container(
                    width: 44,
                    height: 44,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: HamsiqTheme.panel2,
                    ),
                    child: const Icon(Icons.add, color: HamsiqTheme.text),
                  ),
                  title: Text(
                    AppStrings.t('addAccount'),
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  onTap: _addAccount,
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
          if (_busy)
            const Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: CircularProgressIndicator(color: HamsiqTheme.accent),
            ),
        ],
      ),
    );
  }
}
