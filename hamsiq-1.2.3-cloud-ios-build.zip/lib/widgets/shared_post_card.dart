// Hamsiq native — Shared-post DM card + share sheet (Wave 1).
// The DM thread renderer (chats_screen.dart, owned by the coordinator)
// should use these for the two new message types:
//   * 'shared_post' (body = <post id>) -> SharedPostCard
//   * 'story_reply' (body = JSON {"story_id","text"}, media_url = story
//     media) -> StoryReplyCard
// The share sheet (SharePostSheet) is used by the feed post cards and
// the Reels rail: people I follow + user search, tap a person to send
// the post into a DM via MessagesApi.sendSharedPost.

import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/messages_api.dart';
import '../services/share_api.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../screens/post_detail_screen.dart';

// ---------------------------------------------------------------------------
// SharedPostCard — a shared post inside a DM. Tapping opens the post.
// ---------------------------------------------------------------------------

class SharedPostCard extends StatefulWidget {
  final DmMessage message;
  const SharedPostCard({super.key, required this.message});

  @override
  State<SharedPostCard> createState() => _SharedPostCardState();
}

class _SharedPostCardState extends State<SharedPostCard> {
  PostItem? _post;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final postId = int.tryParse((widget.message.body ?? '').trim());
    if (postId == null) {
      if (mounted) setState(() => _failed = true);
      return;
    }
    try {
      final post = await ShareApi.fetchPostById(postId);
      if (!mounted) return;
      setState(() {
        _post = post;
        _failed = post == null;
      });
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final post = _post;
    if (_failed) {
      return Text(
        AppStrings.t('sharedPostLoadFailed'),
        style: const TextStyle(fontSize: 14),
      );
    }
    if (post == null) {
      return const SizedBox(
        width: 200,
        height: 120,
        child: Center(
          child: SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(
              color: HamsiqTheme.accent,
              strokeWidth: 2,
            ),
          ),
        ),
      );
    }
    final author = post.author;
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => PostDetailScreen(post: post)),
        );
      },
      child: Container(
        width: 220,
        decoration: BoxDecoration(
          color: Colors.black38,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: HamsiqTheme.line),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (post.mediaUrl != null && post.mediaUrl!.isNotEmpty)
              ClipRRect(
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(12)),
                child: post.mediaType == 'video'
                    ? Container(
                        width: 220,
                        height: 130,
                        color: HamsiqTheme.panel2,
                        alignment: Alignment.center,
                        child: const Icon(
                          Icons.play_circle_filled,
                          size: 48,
                          color: HamsiqTheme.accent,
                        ),
                      )
                    : SignedMediaImage(
                        url: post.mediaUrl!,
                        width: 220,
                        height: 130,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          width: 220,
                          height: 130,
                          color: HamsiqTheme.panel2,
                          alignment: Alignment.center,
                          child: const Icon(
                            Icons.broken_image_outlined,
                            color: HamsiqTheme.muted,
                          ),
                        ),
                      ),
              ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      AvatarWidget(profile: author, size: 26),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          author?.displayName ?? '',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (author?.verified == true) const VerifiedTick(),
                    ],
                  ),
                  if (post.caption.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(
                      post.caption,
                      style: const TextStyle(fontSize: 13),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                  const SizedBox(height: 6),
                  Text(
                    '♥ ${post.likeCount} · ${AppStrings.t('tapToOpenPost')}',
                    style: const TextStyle(
                      fontSize: 12,
                      color: HamsiqTheme.muted,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// StoryReplyCard — a story reply inside a DM: story thumbnail + text.
// ---------------------------------------------------------------------------

class StoryReplyCard extends StatelessWidget {
  final DmMessage message;
  const StoryReplyCard({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    final parsed = MessagesApi.parseStoryReplyBody(message.body);
    final mediaUrl = message.mediaUrl;
    return Container(
      width: 220,
      decoration: BoxDecoration(
        color: Colors.black38,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: HamsiqTheme.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (mediaUrl != null && mediaUrl.isNotEmpty)
            ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(12)),
              // H-04 re-sign-on-render: the story thumbnail copied
              // into this DM row is a 1h signed URL — refresh it
              // before loading so old replies keep their thumbnail.
              child: SignedMediaImage(
                url: mediaUrl,
                width: 220,
                height: 130,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  width: 220,
                  height: 130,
                  color: HamsiqTheme.panel2,
                  alignment: Alignment.center,
                  child: const Icon(
                    Icons.broken_image_outlined,
                    color: HamsiqTheme.muted,
                  ),
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  AppStrings.t('storyReplyLabel'),
                  style: const TextStyle(
                    fontSize: 12,
                    color: HamsiqTheme.muted,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                if (parsed.text.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(parsed.text, style: const TextStyle(fontSize: 14)),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// SharePostSheet — people picker: people I follow + user search.
// Tap a person to send the post into a DM with them.
// ---------------------------------------------------------------------------

/// Opens the share sheet for [post]. Returns true when the post was
/// sent to at least one person.
Future<bool> showSharePostSheet(BuildContext context, PostItem post) async {
  var sent = false;
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: HamsiqTheme.panel,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (sheetContext) => _SharePostSheet(
      post: post,
      onSent: () => sent = true,
    ),
  );
  return sent;
}

class _SharePostSheet extends StatefulWidget {
  final PostItem post;
  final VoidCallback onSent;
  const _SharePostSheet({required this.post, required this.onSent});

  @override
  State<_SharePostSheet> createState() => _SharePostSheetState();
}

class _SharePostSheetState extends State<_SharePostSheet> {
  List<HamsiqProfile> _following = [];
  List<HamsiqProfile> _results = [];
  bool _loading = true;
  bool _searching = false;
  String? _error;
  String _query = '';
  final _sentTo = <String>{};
  final _searchCtrl = TextEditingController();
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _loadFollowing();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadFollowing() async {
    try {
      final people = await ShareApi.fetchFollowing();
      if (!mounted) return;
      setState(() {
        _following = people;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  void _onQueryChanged(String q) {
    _debounce?.cancel();
    setState(() => _query = q.trim());
    if (_query.isEmpty) {
      setState(() => _results = []);
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 400), () async {
      setState(() => _searching = true);
      try {
        final results = await ShareApi.searchPeople(_query);
        if (!mounted) return;
        setState(() {
          _results = results;
          _searching = false;
        });
      } catch (_) {
        if (mounted) setState(() => _searching = false);
      }
    });
  }

  Future<void> _sendTo(HamsiqProfile person) async {
    if (_sentTo.contains(person.id)) return;
    try {
      await MessagesApi.sendSharedPost(person.id, widget.post.id);
      if (!mounted) return;
      setState(() => _sentTo.add(person.id));
      widget.onSent();
      showOk(context, AppStrings.t('sharedWith').replaceAll('{name}', person.displayName));
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    final shown = _query.isEmpty ? _following : _results;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Text(
                AppStrings.t('sharePostTitle'),
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: _searchCtrl,
                onChanged: _onQueryChanged,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: AppStrings.t('searchPersonHint'),
                  prefixIcon: const Icon(Icons.search, color: HamsiqTheme.muted),
                ),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 320,
              child: _loading
                  ? const LoadingCenter()
                  : _error != null
                      ? Center(
                          child: Text(
                            _error!,
                            style: const TextStyle(color: HamsiqTheme.muted),
                          ),
                        )
                      : _searching
                          ? const LoadingCenter()
                          : shown.isEmpty
                              ? EmptyCenter(
                                  _query.isEmpty
                                      ? AppStrings.t('noFollowingToShare')
                                      : AppStrings.t('noResultsFor').replaceAll('{query}', _query),
                                )
                              : ListView.builder(
                                  itemCount: shown.length,
                                  itemBuilder: (_, i) {
                                    final person = shown[i];
                                    final sent =
                                        _sentTo.contains(person.id);
                                    return ListTile(
                                      leading: AvatarWidget(
                                        profile: person,
                                        size: 42,
                                      ),
                                      title: Text(
                                        person.displayName,
                                        style: const TextStyle(
                                          color: Colors.white,
                                        ),
                                      ),
                                      subtitle: Text(
                                        '@${person.username}',
                                        style: const TextStyle(
                                          color: HamsiqTheme.muted,
                                        ),
                                      ),
                                      trailing: sent
                                          ? const Icon(
                                              Icons.check_circle,
                                              color: HamsiqTheme.accent,
                                            )
                                          : Text(
                                              AppStrings.t('sendAction'),
                                              style: const TextStyle(
                                                color: HamsiqTheme.accent,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                      onTap: () => _sendTo(person),
                                    );
                                  },
                                ),
            ),
          ],
        ),
      ),
    );
  }
}
