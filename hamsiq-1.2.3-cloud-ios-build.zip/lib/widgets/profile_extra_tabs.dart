// Hamsiq native — Profile extra tabs (Wave 1).
// Self-contained widgets the coordinator wires into profile_screen.dart
// (which Agent B must not edit). All data comes from the real tables:
// reposts (sql-v9), posts.is_pinned / grid_order (sql-v29),
// collections (sql-v29).
//
// Wiring notes (for the coordinator — see the Wave 1 report):
//   * Replace the profile's single posts grid with a TabBar:
//     [المنشورات] [الريلز] [إعادات النشر] — RepostsTabGrid is the third tab.
//   * PinnedPostsRow goes directly above the grid (own profile only,
//     shown only when there is at least one pinned post).
//   * CollectionsEntry goes in the Saved area (e.g. a row under the
//     header, or as a fourth tab) and opens CollectionsScreen.
//   * GridReorderView is opened from a "Reorder grid" button on
//     the OWN profile; on save it calls ShareApi.reorderGrid and the
//     parent reloads with ShareApi.fetchOrderedUserPosts.

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/collections_api.dart';
import '../services/share_api.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../screens/collections_screen.dart';
import '../screens/post_detail_screen.dart';

Widget _postTile(BuildContext context, PostItem post) {
  final content = post.mediaUrl != null && post.mediaUrl!.isNotEmpty
      ? SignedMediaImage(
          url: post.mediaUrl!,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(color: HamsiqTheme.panel2),
        )
      : Container(
          color: HamsiqTheme.panel2,
          padding: const EdgeInsets.all(8),
          alignment: Alignment.center,
          child: Text(
            post.caption,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, color: HamsiqTheme.text),
          ),
        );
  return GestureDetector(
    onTap: () {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => PostDetailScreen(post: post)),
      );
    },
    child: Stack(
      fit: StackFit.expand,
      children: [
        content,
        if (post.isReel || post.mediaType == 'video')
          const Positioned(
            top: 6,
            right: 6,
            child: Icon(
              Icons.play_arrow,
              color: Colors.white,
              size: 20,
            ),
          ),
        if (post.isPinned)
          const Positioned(
            top: 6,
            left: 6,
            child: Icon(
              Icons.push_pin,
              color: Colors.white,
              size: 18,
            ),
          ),
      ],
    ),
  );
}

// ---------------------------------------------------------------------------
// RepostsTabGrid — everything the user reposted (only shown when non-empty,
// like Instagram: the Reposts tab appears only after a first repost).
// ---------------------------------------------------------------------------

class RepostsTabGrid extends StatefulWidget {
  final String userId;
  const RepostsTabGrid({super.key, required this.userId});

  @override
  State<RepostsTabGrid> createState() => _RepostsTabGridState();
}

class _RepostsTabGridState extends State<RepostsTabGrid> {
  List<PostItem> _reposts = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final reposts = await ShareApi.fetchUserReposts(widget.userId);
      if (!mounted) return;
      setState(() {
        _reposts = reposts;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const LoadingCenter();
    if (_error != null) {
      return Center(
        child: Text(_error!, style: const TextStyle(color: HamsiqTheme.muted)),
      );
    }
    if (_reposts.isEmpty) {
      return EmptyCenter(AppStrings.t('noRepostsYet'));
    }
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
        childAspectRatio: 1,
      ),
      itemCount: _reposts.length,
      itemBuilder: (_, i) => _postTile(context, _reposts[i]),
    );
  }
}

// ---------------------------------------------------------------------------
// PinnedPostsRow — up to 3 pinned posts, above the grid (own profile).
// The owner can unpin from here; pinning happens in PostDetailScreen.
// ---------------------------------------------------------------------------

class PinnedPostsRow extends StatelessWidget {
  final String userId;
  final bool isMe;
  final VoidCallback? onChanged;
  const PinnedPostsRow({
    super.key,
    required this.userId,
    required this.isMe,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<PostItem>>(
      future: ShareApi.fetchPinnedPosts(userId),
      builder: (context, snap) {
        if (!snap.hasData || snap.data!.isEmpty) {
          return const SizedBox.shrink();
        }
        final pinned = snap.data!;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  const Icon(Icons.push_pin, size: 16, color: HamsiqTheme.muted),
                  const SizedBox(width: 6),
                  Text(
                    AppStrings.t('pinnedPosts'),
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 120,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: pinned.length,
                itemBuilder: (_, i) {
                  final post = pinned[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: SizedBox(
                      width: 110,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          _postTile(context, post),
                          if (isMe)
                            Positioned(
                              top: 4,
                              left: 4,
                              child: GestureDetector(
                                onTap: () async {
                                  try {
                                    await ShareApi.setPostPinned(
                                      post.id,
                                      false,
                                    );
                                    onChanged?.call();
                                  } catch (e) {
                                    if (context.mounted) {
                                      showError(context, e);
                                    }
                                  }
                                },
                                child: Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: const BoxDecoration(
                                    color: Colors.black54,
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.close,
                                    size: 16,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// CollectionsEntry — tile/row opening the Collections screen.
// ---------------------------------------------------------------------------

class CollectionsEntry extends StatelessWidget {
  const CollectionsEntry({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<CollectionItem>>(
      future: CollectionsApi.fetchMyCollections(),
      builder: (context, snap) {
        final count = snap.hasData ? snap.data!.length : 0;
        return ListTile(
          leading: const Icon(
            Icons.collections_bookmark_outlined,
            color: HamsiqTheme.accent,
          ),
          title: Text(AppStrings.t('collectionsEntryTitle')),
          subtitle: Text(
            count == 0
                ? AppStrings.t('collectionsHint')
                : '$count ${AppStrings.t(count == 1 ? 'collectionSingular' : 'collectionPlural')}',
            style: const TextStyle(color: HamsiqTheme.muted),
          ),
          trailing: const Icon(
            Icons.chevron_right,
            color: HamsiqTheme.muted,
          ),
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const CollectionsScreen(),
              ),
            );
          },
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// GridReorderView — owner drags their posts into a custom grid order.
// Save writes posts.grid_order (0..n) via ShareApi.reorderGrid.
// ---------------------------------------------------------------------------

class GridReorderView extends StatefulWidget {
  final String userId;
  final List<PostItem> initialPosts;
  final VoidCallback? onSaved;
  const GridReorderView({
    super.key,
    required this.userId,
    required this.initialPosts,
    this.onSaved,
  });

  @override
  State<GridReorderView> createState() => _GridReorderViewState();
}

class _GridReorderViewState extends State<GridReorderView> {
  late List<PostItem> _posts;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _posts = List.of(widget.initialPosts);
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      await ShareApi.reorderGrid(
        widget.userId,
        _posts.map((p) => p.id).toList(),
      );
      if (!mounted) return;
      widget.onSaved?.call();
      Navigator.of(context).pop();
      showOk(context, AppStrings.t('gridOrderSaved'));
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.t('gridReorder')),
        actions: [
          TextButton(
            onPressed: _saving ? null : _save,
            child: Text(AppStrings.t('save')),
          ),
        ],
      ),
      body: _posts.isEmpty
          ? EmptyCenter(AppStrings.t('noPostsToReorder'))
          : ReorderableListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _posts.length,
              onReorderItem: (oldIndex, newIndex) {
                setState(() {
                  final item = _posts.removeAt(oldIndex);
                  _posts.insert(newIndex, item);
                });
              },
              itemBuilder: (_, i) {
                final post = _posts[i];
                return ListTile(
                  key: ValueKey(post.id),
                  leading: SizedBox(
                    width: 52,
                    height: 52,
                    child: post.mediaUrl != null &&
                            post.mediaUrl!.isNotEmpty
                        ? SignedMediaImage(
                            url: post.mediaUrl!,
                            width: 52,
                            height: 52,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                Container(color: HamsiqTheme.panel2),
                          )
                        : Container(
                            color: HamsiqTheme.panel2,
                            alignment: Alignment.center,
                            child: const Icon(
                              Icons.article_outlined,
                              color: HamsiqTheme.muted,
                            ),
                          ),
                  ),
                  title: Text(
                    post.caption.isEmpty ? AppStrings.t('postNoText') : post.caption,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: Text(
                    post.isPinned ? AppStrings.t('pinnedStaysTop') : timeAgo(post.createdAt),
                    style: const TextStyle(color: HamsiqTheme.muted),
                  ),
                  trailing: const Icon(
                    Icons.drag_handle,
                    color: HamsiqTheme.muted,
                  ),
                );
              },
            ),
    );
  }
}
