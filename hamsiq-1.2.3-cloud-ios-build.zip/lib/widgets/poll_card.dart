// Hamsiq native — poll card + poll composer.
// Poll identification rule (web app sql-v28 + index.html): a poll message
// in the messages table has message_type == 'poll' and body == the poll
// id (uuid string). Any thread rendering a message with that type must
// render PollCard(pollId: message.body) instead of a text bubble.

import 'package:flutter/material.dart';
import '../services/app_strings.dart';
import '../services/polls_api.dart';
import '../theme.dart';
import 'common.dart';

/// Renders one poll inside a thread. Loads the poll (question, options,
/// live counts, my vote) and lets me tap an option to vote or change
/// my vote. Tapping my current option again keeps it (no un-vote in the
/// web model — a vote is always one option).
class PollCard extends StatefulWidget {
  final String pollId;

  const PollCard({super.key, required this.pollId});

  @override
  State<PollCard> createState() => _PollCardState();
}

class _PollCardState extends State<PollCard> {
  PollData? _poll;
  bool _loading = true;
  bool _voting = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final poll = await PollsApi.fetchPoll(widget.pollId);
      if (!mounted) return;
      setState(() {
        _poll = poll;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  Future<void> _vote(String optionId) async {
    if (_voting || _poll == null) return;
    if (_poll!.myVoteOptionId == optionId) return;
    setState(() => _voting = true);
    try {
      await PollsApi.vote(widget.pollId, optionId);
      await _load();
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _voting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const SizedBox(
        width: 220,
        height: 96,
        child: LoadingCenter(),
      );
    }
    if (_error != null || _poll == null) {
      return SizedBox(
        width: 220,
        child: Text(
          _error ?? AppStrings.t('pollLoadFailed'),
          style: const TextStyle(color: HamsiqTheme.muted, fontSize: 13),
        ),
      );
    }
    final poll = _poll!;
    final total = poll.totalVotes;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            const Icon(
              Icons.bar_chart,
              size: 16,
              color: HamsiqTheme.accent,
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                poll.question,
                style: const TextStyle(
                  color: HamsiqTheme.text,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        ...poll.options.map((option) {
          final mine = poll.myVoteOptionId == option.id;
          final share = poll.shareOf(option);
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: InkWell(
              onTap: _voting ? null : () => _vote(option.id),
              borderRadius: BorderRadius.circular(10),
              child: Stack(
                children: [
                  Container(
                    height: 40,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: HamsiqTheme.panel2,
                    ),
                  ),
                  FractionallySizedBox(
                    widthFactor: share == 0 ? 0.02 : share,
                    child: Container(
                      height: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: mine
                            ? HamsiqTheme.accent
                            : HamsiqTheme.accent.withValues(alpha: 0.35),
                      ),
                    ),
                  ),
                  Container(
                    height: 40,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            option.text,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: HamsiqTheme.text,
                              fontSize: 14,
                              fontWeight: mine
                                  ? FontWeight.w700
                                  : FontWeight.w400,
                            ),
                          ),
                        ),
                        if (mine)
                          const Icon(
                            Icons.check_circle,
                            size: 16,
                            color: Colors.white,
                          ),
                        const SizedBox(width: 6),
                        Text(
                          total == 0
                              ? '0'
                              : '${(share * 100).round()}${AppStrings.t('percentSuffix')}',
                          style: const TextStyle(
                            color: HamsiqTheme.text,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
        Text(
          total == 0
              ? AppStrings.t('pollNoVotesYet')
              : '$total ${AppStrings.t(total == 1 ? 'pollVoteSingular' : 'pollVotePlural')} · ${AppStrings.t('pollTapToChangeVote')}',
          style: const TextStyle(color: HamsiqTheme.muted, fontSize: 12),
        ),
      ],
    );
  }
}

/// Bottom sheet to compose a poll: a question + 2–4 options.
/// The caller supplies [onCreatePoll], which creates the poll in the
/// current thread and returns its id; the sheet then pops with that id
/// (so the caller can post the poll message and reload the thread).
/// Usage:
///   final pollId = await showModalBottomSheet<String>(
///     context: context,
///     isScrollControlled: true,
///     builder: (_) => CreatePollSheet(
///       onCreatePoll: (q, opts) => PollsApi.createPoll(
///         groupId: group.id, question: q, options: opts),
///     ),
///   );
///   if (pollId != null) {
///     await PollsApi.postPollMessage(groupId: group.id, pollId: pollId);
///   }
class CreatePollSheet extends StatefulWidget {
  final Future<String> Function(String question, List<String> options)
      onCreatePoll;

  const CreatePollSheet({super.key, required this.onCreatePoll});

  @override
  State<CreatePollSheet> createState() => _CreatePollSheetState();
}

class _CreatePollSheetState extends State<CreatePollSheet> {
  final _question = TextEditingController();
  final List<TextEditingController> _options = [
    TextEditingController(),
    TextEditingController(),
  ];
  bool _creating = false;

  @override
  void dispose() {
    _question.dispose();
    for (final c in _options) {
      c.dispose();
    }
    super.dispose();
  }

  void _addOption() {
    if (_options.length >= 4) return;
    setState(() => _options.add(TextEditingController()));
  }

  Future<void> _create() async {
    if (_creating) return;
    final q = _question.text.trim();
    final opts =
        _options.map((c) => c.text.trim()).where((o) => o.isNotEmpty).toList();
    if (q.isEmpty || opts.length < 2) {
      showError(context, AppStrings.t('pollNeedQuestionAndOptions'));
      return;
    }
    setState(() => _creating = true);
    try {
      final pollId = await widget.onCreatePoll(q, opts);
      if (!mounted) return;
      Navigator.of(context).pop(pollId);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            AppStrings.t('newPollTitle'),
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _question,
            decoration: InputDecoration(hintText: AppStrings.t('pollQuestionHint')),
            maxLength: 120,
          ),
          const SizedBox(height: 8),
          ..._options.asMap().entries.map((e) {
            final i = e.key;
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: TextField(
                controller: e.value,
                decoration: InputDecoration(
                  hintText: '${AppStrings.t('pollOptionLabel')} ${i + 1}',
                ),
                maxLength: 60,
              ),
            );
          }),
          if (_options.length < 4)
            TextButton.icon(
              onPressed: _addOption,
              icon: const Icon(Icons.add, color: HamsiqTheme.accent),
              label: Text(
                AppStrings.t('pollAddOption'),
                style: const TextStyle(color: HamsiqTheme.accent),
              ),
            ),
          const SizedBox(height: 8),
          ElevatedButton(
            onPressed: _creating ? null : _create,
            child: _creating
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white,
                    ),
                  )
                : Text(AppStrings.t('pollCreate')),
          ),
        ],
      ),
    );
  }
}
