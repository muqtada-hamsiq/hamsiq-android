// Hamsiq native — Instagram-style comments bottom sheet (v1.2.1).
// Opens OVER the feed / reel instead of navigating into the post
// detail screen. Reuses CommentsApi and the same comment row UI as
// PostDetailScreen — CommentRow lives here now so both screens share
// one widget instead of two copies.
// The sheet is testable offline: fetch/send can be overridden with
// fakes; by default they use the real CommentsApi.

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/comments_api.dart';
import '../services/notifications_api.dart';
import '../services/supabase_service.dart';
import '../theme.dart';
import 'common.dart';

/// Opens the comments bottom sheet over the current screen (feed or
/// reel). Returns when the sheet is dismissed; callers refresh their
/// comment counts afterwards, like they do after PostDetailScreen.
Future<void> showCommentsSheet(BuildContext context, PostItem post) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: HamsiqTheme.panel,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (ctx) => Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
      child: DraggableScrollableSheet(
        initialChildSize: 0.85,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, scrollController) => CommentsSheet(
          post: post,
          scrollController: scrollController,
        ),
      ),
    ),
  );
}

class CommentsSheet extends StatefulWidget {
  final PostItem post;
  final ScrollController scrollController;
  // Test overrides (offline fakes). Null = real CommentsApi.
  final Future<List<CommentItem>> Function(int postId)?
      fetchCommentsOverride;
  final Future<CommentItem> Function(int postId, String text, int? parentId)?
      sendCommentOverride;
  final Future<CommentItem> Function(int postId, String gifUrl)?
      sendGifOverride;

  const CommentsSheet({
    super.key,
    required this.post,
    required this.scrollController,
    this.fetchCommentsOverride,
    this.sendCommentOverride,
    this.sendGifOverride,
  });

  @override
  State<CommentsSheet> createState() => _CommentsSheetState();
}

class _CommentsSheetState extends State<CommentsSheet> {
  List<CommentItem> _comments = [];
  bool _loading = true;
  Object? _error;
  CommentItem? _replyTo;
  bool _sending = false;
  final _controller = TextEditingController();

  String? get _myId => Api.isLoggedIn ? Api.myId : null;
  bool get _commentsOff => widget.post.commentsDisabled;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final fetch = widget.fetchCommentsOverride ?? CommentsApi.fetchComments;
      final comments = await fetch(widget.post.id);
      if (!mounted) return;
      setState(() {
        _comments = comments;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e;
      });
    }
  }

  Future<void> _send() async {
    final text = _controller.text;
    if (text.trim().isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      final replyTo = _replyTo;
      final CommentItem comment;
      if (widget.sendCommentOverride != null) {
        comment = await widget.sendCommentOverride!(
          widget.post.id,
          text,
          replyTo?.id,
        );
      } else {
        comment = await CommentsApi.addComment(
          widget.post.id,
          text,
          parentId: replyTo?.id,
        );
        // Comment notification to the post owner (best-effort). When
        // replying, also notify the parent comment's author.
        try {
          await NotificationsApi.notifyComment(
            widget.post.userId,
            widget.post.id,
          );
          if (replyTo != null && replyTo.authorId != widget.post.userId) {
            await NotificationsApi.notifyComment(
              replyTo.authorId,
              widget.post.id,
            );
          }
        } catch (_) {}
      }
      if (!mounted) return;
      setState(() {
        _comments = CommentsApi.threadComments([..._comments, comment]);
        _controller.clear();
        _replyTo = null;
        _sending = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _sending = false);
      showError(context, e);
    }
  }

  Future<void> _sendGif(String gifUrl) async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      final CommentItem comment;
      if (widget.sendGifOverride != null) {
        comment = await widget.sendGifOverride!(widget.post.id, gifUrl);
      } else {
        comment = await CommentsApi.addGifComment(widget.post.id, gifUrl);
        try {
          await NotificationsApi.notifyComment(
            widget.post.userId,
            widget.post.id,
          );
        } catch (_) {}
      }
      if (!mounted) return;
      setState(() {
        _comments = CommentsApi.threadComments([..._comments, comment]);
        _sending = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _sending = false);
      showError(context, e);
    }
  }

  void _showGifPicker() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: HamsiqTheme.panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Text(
                AppStrings.t('pickGif'),
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 6, 16, 4),
              child: Text(
                AppStrings.t('gifNote'),
                textAlign: TextAlign.center,
                style: const TextStyle(color: HamsiqTheme.muted, fontSize: 12),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 300,
              child: GridView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  childAspectRatio: 1.4,
                ),
                itemCount: CommentsApi.curatedGifUrls.length,
                itemBuilder: (_, i) {
                  final url = CommentsApi.curatedGifUrls[i];
                  return GestureDetector(
                    onTap: () {
                      Navigator.of(sheetContext).pop();
                      _sendGif(url);
                    },
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        url,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: HamsiqTheme.panel2,
                          alignment: Alignment.center,
                          child: const Icon(
                            Icons.broken_image_outlined,
                            color: HamsiqTheme.muted,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _togglePinComment(CommentItem comment) async {
    try {
      final pinned = await CommentsApi.setCommentPinned(
        comment,
        widget.post.userId,
        !comment.isPinned,
      );
      if (!mounted) return;
      setState(() {
        _comments = _comments
            .map(
              (c) => c.id == comment.id
                  ? CommentItem(
                      id: c.id,
                      postId: c.postId,
                      authorId: c.authorId,
                      body: c.body,
                      createdAt: c.createdAt,
                      parentId: c.parentId,
                      gifUrl: c.gifUrl,
                      isPinned: pinned,
                      author: c.author,
                    )
                  : c,
            )
            .toList();
        _comments = CommentsApi.orderComments(_comments);
      });
      showOk(context, pinned ? AppStrings.t('commentPinned') : AppStrings.t('commentUnpinned'));
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _confirmDelete(CommentItem comment) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('deleteCommentTitle')),
        content: Text(AppStrings.t('deleteCommentBody')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(AppStrings.t('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(
              AppStrings.t('delete'),
              style: const TextStyle(color: Colors.redAccent),
            ),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final myId = _myId;
      await CommentsApi.deleteComment(
        comment.id,
        asPostOwner: myId != null &&
            myId == widget.post.userId &&
            comment.authorId != myId,
      );
      if (!mounted) return;
      setState(() => _comments.removeWhere((c) => c.id == comment.id));
      showOk(context, AppStrings.t('commentDeleted'));
    } catch (e) {
      if (!mounted) return;
      showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    final myId = _myId;
    return Column(
      children: [
        const SizedBox(height: 8),
        Container(
          width: 40,
          height: 4,
          decoration: BoxDecoration(
            color: HamsiqTheme.muted,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          _comments.isEmpty
              ? AppStrings.t('commentsTitle')
              : '${AppStrings.t('commentsTitle')} (${_comments.length})',
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Divider(color: HamsiqTheme.line, height: 1),
        Expanded(
          child: _loading
              ? const LoadingCenter()
              : _error != null
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            AppStrings.t('commentsLoadFailed'),
                            style: const TextStyle(color: HamsiqTheme.muted),
                          ),
                          const SizedBox(height: 12),
                          ElevatedButton(
                            onPressed: _load,
                            child: Text(AppStrings.t('retry')),
                          ),
                        ],
                      ),
                    )
                  : _commentsOff
                      ? Center(
                          child: EmptyCenter(
                            AppStrings.t('commentsClosedPost'),
                          ),
                        )
                      : _comments.isEmpty
                          ? Center(
                              child: EmptyCenter(
                                AppStrings.t('noCommentsYet'),
                              ),
                            )
                          : ListView(
                              controller: widget.scrollController,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                              ),
                              children:
                                  CommentsApi.threadComments(_comments)
                                      .map(
                                        (c) => CommentRow(
                                          comment: c,
                                          isMine: myId != null &&
                                              c.authorId == myId,
                                          isPostOwner: myId != null &&
                                              myId == widget.post.userId,
                                          canPin: (myId != null &&
                                                  myId ==
                                                      widget.post.userId) ||
                                              (myId != null &&
                                                  c.authorId == myId),
                                          onDelete: () => _confirmDelete(c),
                                          onReply: () {
                                            setState(() => _replyTo = c);
                                          },
                                          onTogglePin: () =>
                                              _togglePinComment(c),
                                        ),
                                      )
                                      .toList(),
                            ),
        ),
        // ---- add-comment field (hidden when comments are off) ----
        if (!_commentsOff)
          Container(
            padding: EdgeInsets.fromLTRB(
              12,
              8,
              12,
              MediaQuery.of(context).padding.bottom + 8,
            ),
            decoration: const BoxDecoration(
              color: HamsiqTheme.panel,
              border: Border(top: BorderSide(color: HamsiqTheme.line)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (_replyTo != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${AppStrings.t('replyTo')} ${_replyTo!.author?.displayName ?? ''}',
                            style: const TextStyle(
                              color: HamsiqTheme.accent,
                              fontSize: 13,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        GestureDetector(
                          onTap: () => setState(() => _replyTo = null),
                          child: const Icon(
                            Icons.close,
                            size: 18,
                            color: HamsiqTheme.muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        maxLength: CommentsApi.maxBodyLength,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) => _send(),
                        decoration: InputDecoration(
                          hintText: _replyTo == null
                              ? AppStrings.t('writeComment')
                              : AppStrings.t('writeReply'),
                          counterText: '',
                        ),
                      ),
                    ),
                    const SizedBox(width: 4),
                    IconButton(
                      tooltip: 'GIF',
                      onPressed: _showGifPicker,
                      icon: const Icon(
                        Icons.gif_box_outlined,
                        color: HamsiqTheme.muted,
                      ),
                    ),
                    const SizedBox(width: 4),
                    _sending
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              color: HamsiqTheme.accent,
                              strokeWidth: 2,
                            ),
                          )
                        : IconButton(
                            onPressed: _send,
                            icon: const Icon(
                              Icons.send,
                              color: HamsiqTheme.accent,
                            ),
                          ),
                  ],
                ),
              ],
            ),
          ),
      ],
    );
  }
}

/// One comment row — shared by the comments sheet and the post detail
/// screen. Replies are indented under their parent; pinned comments
/// carry the badge (they sort first via CommentsApi.orderComments).
class CommentRow extends StatelessWidget {
  final CommentItem comment;
  final bool isMine;
  final bool isPostOwner;
  final bool canPin;
  final VoidCallback onDelete;
  final VoidCallback onReply;
  final VoidCallback onTogglePin;
  const CommentRow({
    super.key,
    required this.comment,
    required this.isMine,
    required this.isPostOwner,
    required this.canPin,
    required this.onDelete,
    required this.onReply,
    required this.onTogglePin,
  });

  @override
  Widget build(BuildContext context) {
    final author = comment.author;
    final isReply = comment.parentId != null;
    return Padding(
      // Replies are indented under their parent.
      padding: EdgeInsets.only(
        top: 8,
        bottom: 8,
        left: isReply ? 46 : 0,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AvatarWidget(profile: author, size: isReply ? 30 : 36),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        author?.displayName ?? author?.username ?? '',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (author?.verified == true) ...[
                      const SizedBox(width: 4),
                      const VerifiedTick(),
                    ],
                    if (comment.isPinned) ...[
                      const SizedBox(width: 6),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.push_pin,
                            size: 13,
                            color: HamsiqTheme.accent,
                          ),
                          const SizedBox(width: 2),
                          Text(
                            AppStrings.t('pinnedBadge'),
                            style: const TextStyle(
                              color: HamsiqTheme.accent,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
                Text(
                  '@${author?.username ?? ''} · ${timeAgo(comment.createdAt)}',
                  style: const TextStyle(
                    color: HamsiqTheme.muted,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 4),
                if (comment.gifUrl != null &&
                    comment.gifUrl!.isNotEmpty)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.network(
                      comment.gifUrl!,
                      width: 180,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        width: 180,
                        height: 100,
                        color: HamsiqTheme.panel2,
                        alignment: Alignment.center,
                        child: const Icon(
                          Icons.broken_image_outlined,
                          color: HamsiqTheme.muted,
                        ),
                      ),
                    ),
                  ),
                if (comment.body.isNotEmpty)
                  Text(comment.body, style: const TextStyle(fontSize: 14)),
                const SizedBox(height: 4),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    GestureDetector(
                      onTap: onReply,
                      child: Text(
                        AppStrings.t('replyAction'),
                        style: const TextStyle(
                          color: HamsiqTheme.muted,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    if (canPin) ...[
                      const SizedBox(width: 14),
                      GestureDetector(
                        onTap: onTogglePin,
                        child: Text(
                          comment.isPinned ? AppStrings.t('unpinComment') : AppStrings.t('pinComment'),
                          style: const TextStyle(
                            color: HamsiqTheme.muted,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          if (isMine || isPostOwner)
            IconButton(
              onPressed: onDelete,
              icon: const Icon(
                Icons.delete_outline,
                color: Colors.redAccent,
                size: 20,
              ),
            ),
        ],
      ),
    );
  }
}
