// Hamsiq native — auth screens.
// Login = username + password via the secure-login Edge Function
// (lib/services/secure_login.dart): the email is resolved and the sign-in
// happens server-side, so no email ever reaches the client (audit H-01).
// Signup = email + username + password, then the 8-digit code typed in-app.
// Password rule (same as the web app): min 8 chars, at least one letter
// and one digit.
// Login layout: the user's own design (2026-11-16) as re-matched to
// his mockup — bare 120pt logo, Hamsiq title + tagline, pill
// login/signup toggle, 60pt pill inputs, blue pill login button,
// Google button below it.
// The pasted design's stub handlers (snackbars saying "wire this up")
// were NEVER shipped: _doLogin calls SecureLogin, forgot goes to the
// existing forgot view, create-account goes to the existing signup view.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/google_auth.dart';
import '../services/secure_login.dart';
import '../services/app_strings.dart';
import '../services/supabase_service.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'google_setup_screen.dart';

bool isStrongPassword(String p) =>
    p.length >= 8 &&
    RegExp(r'[A-Za-z\u0600-\u06FF]').hasMatch(p) &&
    RegExp(r'\d').hasMatch(p);

bool isValidUsername(String u) =>
    RegExp(r'^[A-Za-z0-9_.\u0600-\u06FF-]+$').hasMatch(u);

/// Rate limit for the check-username Edge Function — MUST match
/// supabase/functions/check-username/index.ts:
/// 30 availability checks per client IP per 15 minutes.
const int checkUsernameMaxPerIp = 30;
const Duration checkUsernameRateLimitWindow = Duration(minutes: 15);

/// Shown only when the server answers 429 for the availability check.
/// Does not reveal whether the username exists.
/// H-06 Part 2: translated at read time (was a hardcoded const).
/// The name stays: test/check_username_test.dart pins it by name
/// and by value (Arabic while the language is Arabic).
String get checkUsernameRateLimitError =>
    AppStrings.t('authTooManyAttempts');

/// Pure rate-limit decision, mirroring the server rule: block once the
/// number of checks inside the window reaches the limit. Kept pure so
/// the threshold logic is unit-testable without a server.
bool isUsernameCheckRateLimited({
  required int checksInWindow,
  required int maxChecks,
}) =>
    checksInWindow >= maxChecks;

/// Parses the check-username Edge Function response.
///
/// The contract is exactly {"available": true/false} and nothing else.
/// Returns the boolean for a well-formed body, and null for anything
/// else — malformed, missing/non-boolean `available`, or a body carrying
/// any extra key. An `email` key in particular is rejected wholesale:
/// the old availability RPC leaked the taken account's email, so any
/// email-bearing body must never be trusted. A null result must block
/// signup with the generic error, never let it proceed.
bool? parseUsernameAvailability(Object? data) {
  if (data is! Map<String, dynamic>) return null;
  if (data.length != 1 || !data.containsKey('available')) return null;
  final v = data['available'];
  if (v is! bool) return null;
  return v;
}

/// Never show a raw exception to the user. Map the common auth failures
/// to friendly Arabic; our own Arabic messages thrown by Api pass
/// through unchanged.
String friendlyAuthError(Object e) {
  var m = e.toString().replaceFirst(RegExp(r'^(Exception|AuthApiException|PostgrestException):\s*'), '');
  final lower = m.toLowerCase();
  if (lower.contains('invalid format') ||
      lower.contains('validation_failed')) {
    return AppStrings.t('authEmailInvalid');
  }
  if (lower.contains('invalid_credentials') ||
      lower.contains('invalid login credentials')) {
    return AppStrings.t('authWrongCredentials');
  }
  if (lower.contains('socketexception') ||
      lower.contains('failed host lookup') ||
      lower.contains('network') ||
      lower.contains('connection')) {
    return AppStrings.t('authNoConnection');
  }
  if (RegExp(r'[\u0600-\u06FF]').hasMatch(m)) {
    // Already a friendly Arabic message from our own code.
    return m;
  }
  return AppStrings.t('genericError');
}

class AuthScreen extends StatefulWidget {
  final void Function() onAuthed;

  /// v1.2.2: opened from "+ Add account" while another session is
  /// active. Shows a back button that returns to the current account's
  /// home WITHOUT logging out — the saved login stays. The screen must
  /// never sign out the current session when opened this way.
  final bool isAddAccount;
  final VoidCallback? onBack;

  const AuthScreen({
    super.key,
    required this.onAuthed,
    this.isAddAccount = false,
    this.onBack,
  });

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _isLogin = true;
  bool _busy = false;
  String? _error;

  // New login design (user order 2026-11-16): the login form is a Form
  // with required-field validation, and the password has a visibility
  // toggle. _busy is the loading flag (the design's _isLoading): it is
  // set for the whole login call, never a stub.
  final _formKey = GlobalKey<FormState>();
  bool _obscurePassword = true;

  // Design colours: pure black + Instagram blue + white, as the theme.
  static const Color _authBackground = Color(0xFF000000);
  static const Color _authSurface = Color(0xFF0D0D0D);
  static const Color _authPrimaryBlue = Color(0xFF0095F6);
  static const Color _authSecondaryText = Color(0xFF999999);

  final _loginUser = TextEditingController();
  final _loginPass = TextEditingController();
  final _suEmail = TextEditingController();
  final _suUser = TextEditingController();
  final _suPass = TextEditingController();
  final _forgotEmail = TextEditingController();
  final _otpCode = TextEditingController();

  // 'form' | 'otp' | 'forgot' | 'googleSetup' | 'googleLink'
  String _step = 'form';
  String _pendingEmail = '';

  // Google OAuth round-trip state. signInWithOAuth only launches the
  // browser (see lib/services/google_auth.dart): the result arrives on
  // the auth-state stream, so _googlePending guards the listener below.
  // On web the redirect reloads the page and this flag is lost — the
  // main.dart restore path routes that case to the setup screen.
  StreamSubscription<AuthState>? _authSub;
  bool _googlePending = false;
  bool _googleWaiting = false;
  GoogleProfileInfo? _googleInfo;

  @override
  void initState() {
    super.initState();
    _subscribeToGoogleReturn();
  }

  /// Listen for the Google OAuth result on the auth-state stream (see
  /// lib/services/google_auth.dart: signInWithOAuth only launches the
  /// browser). Guarded: widget tests pump AuthScreen standalone without
  /// Supabase.initialize, and Supabase.instance throws before init —
  /// the form must still render there; the app itself (main.dart)
  /// always initializes Supabase before showing this screen.
  void _subscribeToGoogleReturn() {
    try {
      _authSub = Api.client.auth.onAuthStateChange.listen((data) {
        if (!_googlePending) return;
        if (data.event == AuthChangeEvent.signedIn &&
            data.session != null) {
          _googlePending = false;
          if (mounted) setState(() => _googleWaiting = false);
          unawaited(_handleGoogleSession());
        }
      }, onError: (Object e) {
        if (!_googlePending) return;
        _googlePending = false;
        if (!mounted) return;
        if (isGoogleIdentityConflict(e)) {
          // Manual linking is enabled server-side and this Google email
          // already owns a different account: password sign-in first,
          // then linkIdentity — never a new profile.
          setState(() {
            _googleWaiting = false;
            _step = 'googleLink';
            _error = null;
          });
        } else {
          setState(() {
            _googleWaiting = false;
            _error = friendlyGoogleError(e);
          });
        }
      });
    } catch (_) {
      // Supabase not initialized — Google return handling unavailable.
      _authSub = null;
    }
  }

  @override
  void dispose() {
    _authSub?.cancel();
    _loginUser.dispose();
    _loginPass.dispose();
    _suEmail.dispose();
    _suUser.dispose();
    _suPass.dispose();
    _forgotEmail.dispose();
    _otpCode.dispose();
    super.dispose();
  }

  Future<void> _finishAuth() async {
    await Api.ensureMyProfile();
    widget.onAuthed();
  }

  /// Launch the Google OAuth round-trip. Only the browser launch happens
  /// here; the session (or the callback error) arrives later on the
  /// auth-state stream (initState) or, on web, via the main.dart
  /// restore path after the page reloads.
  Future<void> _doGoogleSignIn() async {
    if (_googleWaiting) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final launched = await GoogleAuth.startSignIn();
      if (!launched) {
        if (mounted) setState(() => _error = AppStrings.t('genericError'));
        return;
      }
      _googlePending = true;
      if (mounted) setState(() => _googleWaiting = true);
    } catch (e) {
      if (mounted) setState(() => _error = friendlyGoogleError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// Post-OAuth gate: a session is established, decide where it goes.
  /// With the project's default GoTrue behaviour (auto-linking ON) an
  /// OAuth sign-in for an email that already owns an account signs into
  /// THAT user, so its profile is found here and we go home — a second
  /// profile can never be created for the same email. The needsLink
  /// branch is unreachable at this point (a duplicate yields no session,
  /// only the identity_already_exists stream error handled in initState);
  /// duplicateEmailDetected is therefore always false here, and the
  /// decision table (incl. the duplicate branch) is pinned by tests.
  Future<void> _handleGoogleSession() async {
    final user = Api.client.auth.currentUser;
    if (user == null) {
      if (mounted) setState(() => _error = AppStrings.t('genericError'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final profile = await Api.fetchProfile(user.id);
      final decision = decideGooglePostAuth(
        profile: profile,
        duplicateEmailDetected: false,
      );
      if (decision == GoogleSetupDecision.goHome) {
        await _finishAuth();
        return;
      }
      if (!mounted) return;
      setState(() {
        _googleInfo = GoogleProfileInfo.fromUser(user);
        _step = 'googleSetup';
      });
    } catch (e) {
      if (mounted) setState(() => _error = friendlyGoogleError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// Link flow (GoogleLinkScreen): sign in with the existing account's
  /// password, then launch linkIdentity so Google attaches to the SAME
  /// user id. Returns the AppStrings key of a failure, or null when the
  /// link round-trip was launched (the stream listener routes home on
  /// the returning session). If the link launch itself fails, the user
  /// is already signed in to the right account, so the gate goes home
  /// on the existing profile — still no new profile, no duplicate.
  Future<String?> _linkGoogleWithPassword(
    String email,
    String password,
  ) async {
    try {
      await Api.client.auth.signInWithPassword(
        email: cleanEmail(email),
        password: password,
      );
    } catch (_) {
      return 'authWrongCredentials';
    }
    var launched = false;
    try {
      launched = await GoogleAuth.linkGoogle();
    } catch (e) {
      // Already linked (or the launch raced the returning session):
      // treat as launched so the gate runs on the existing profile.
      if (isGoogleIdentityConflict(e)) launched = true;
    }
    if (!launched) {
      await _handleGoogleSession();
      return null;
    }
    _googlePending = true;
    if (mounted) setState(() => _googleWaiting = true);
    return null;
  }

  Future<void> _doLogin() async {
    // New-design validation: the Form's required-field validators run
    // first (empty fields show the inline message, no network call).
    if (_formKey.currentState != null &&
        !_formKey.currentState!.validate()) {
      return;
    }
    final u = _loginUser.text.trim().toLowerCase();
    final p = _loginPass.text;
    if (u.isEmpty || p.isEmpty) {
      setState(() => _error = AppStrings.t('fillAllFields'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      // H-01 fix: secure username login — the Edge Function resolves the
      // email and signs in server-side; no email ever reaches the client.
      await SecureLogin.loginWithUsername(u, p);
      await _finishAuth();
    } catch (e) {
      setState(() => _error = friendlyAuthError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _doSignup() async {
    final email = cleanEmail(_suEmail.text);
    final u = _suUser.text.trim().toLowerCase();
    final p = _suPass.text;
    if (email.isEmpty || u.isEmpty || p.isEmpty) {
      setState(() => _error = AppStrings.t('fillAllFields'));
      return;
    }
    if (!isValidEmail(email)) {
      setState(() => _error = AppStrings.t('authEmailInvalid'));
      return;
    }
    if (!isValidUsername(u)) {
      setState(() => _error = AppStrings.t('authInvalidUsernameChars'));
      return;
    }
    if (u.length < 3) {
      setState(() => _error = AppStrings.t('authUsernameMin3'));
      return;
    }
    if (!isStrongPassword(p)) {
      setState(() => _error = AppStrings.t('authWeakPassword'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      // H-01 fix: username availability is checked via the check-username
      // Edge Function, which returns ONLY {"available": true/false}. The
      // old availability RPC (which returned the taken account's email
      // to an anonymous caller) is no longer used anywhere in this
      // screen. A taken name and an invalid name look identical from
      // the outside; only the HTTP status distinguishes a rate limit
      // (429) or a server error from a plain "taken" answer.
      final bool available;
      try {
        final res = await Api.client.functions.invoke(
          'check-username',
          body: {'username': u},
        );
        final parsed = parseUsernameAvailability(res.data);
        if (parsed == null) {
          setState(() => _error = AppStrings.t('genericError'));
          return;
        }
        available = parsed;
      } on FunctionsHttpException catch (e) {
        if (e.status == 429) {
          setState(() => _error = checkUsernameRateLimitError);
        } else {
          setState(() => _error = AppStrings.t('genericError'));
        }
        return;
      } catch (_) {
        setState(() => _error = AppStrings.t('genericError'));
        return;
      }
      if (!available) {
        setState(() => _error = AppStrings.t('usernameTaken'));
        return;
      }
      final hasSession = await Api.signUp(
        email: email,
        username: u,
        password: p,
      );
      if (hasSession) {
        await _finishAuth();
      } else {
        setState(() {
          _pendingEmail = email;
          _step = 'otp';
        });
      }
    } catch (e) {
      setState(() => _error = friendlyAuthError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _doVerifyOtp() async {
    final code = _otpCode.text.trim();
    if (code.length != 8) {
      setState(() => _error = AppStrings.t('authOtp8Digits'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await Api.verifySignupOtp(_pendingEmail, code);
      await _finishAuth();
    } catch (e) {
      setState(() => _error = friendlyAuthError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _doForgot() async {
    final email = cleanEmail(_forgotEmail.text);
    if (email.isEmpty) {
      setState(() => _error = AppStrings.t('authEnterEmail'));
      return;
    }
    if (!isValidEmail(email)) {
      setState(() => _error = AppStrings.t('authEmailInvalid'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await Api.resetPassword(email);
      if (!mounted) return;
      showOk(context, AppStrings.t('authResetLinkSent'));
      setState(() => _step = 'form');
    } catch (e) {
      setState(() => _error = friendlyAuthError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // H-06 Part 2: live language rebuild — the standalone login is
    // already wrapped in main.dart, but the add-account login opened
    // from the account switcher is not.
    // v1.2.2: text must never scale with the system font size, so the
    // whole auth screen pins TextScaler.noScaling (same fix as the
    // profile Edit/Share buttons). Direction follows the locale: RTL
    // for Arabic, LTR for English — the pasted design hardcoded RTL.
    return ValueListenableBuilder<String>(
      valueListenable: AppStrings.lang,
      builder: (context, _, __) {
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(textScaler: TextScaler.noScaling),
          child: Directionality(
            textDirection: AppStrings.isArabic
                ? TextDirection.rtl
                : TextDirection.ltr,
            child: _build(context),
          ),
        );
      },
    );
  }

  Widget _build(BuildContext context) {
    // The Google steps carry their own Scaffold — render them directly
    // instead of nesting them inside this screen's Scaffold.
    if (_step == 'googleSetup' && _googleInfo != null) {
      return GoogleSetupScreen(
        initialDisplayName: _googleInfo!.displayName,
        initialAvatarUrl: _googleInfo!.avatarUrl,
        onCompleted: _finishAuth,
      );
    }
    if (_step == 'googleLink') {
      return GoogleLinkScreen(
        onLinkWithPassword: _linkGoogleWithPassword,
        onBack: () => setState(() => _step = 'form'),
      );
    }
    // Mockup-match round (2026-11-16): login and signup share one
    // header (bare 120pt logo, Hamsiq title, tagline, pill toggle)
    // and switch forms in place via _isLogin — no navigation.
    if (_step == 'form') {
      return _isLogin ? _loginView() : _signupView();
    }
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // v1.2.2: back button in add-account mode (top, RTL-correct
              // via AlignmentDirectional + the auto-mirroring arrow icon).
              // Returns to the current account's home without logging out.
              if (widget.isAddAccount)
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back),
                    tooltip: AppStrings.t('back'),
                    onPressed: widget.onBack ??
                        () => Navigator.of(context).pop(),
                  ),
                ),
              const SizedBox(height: 24),
              _authHeader(showToggle: false),
              const SizedBox(height: 36),
              if (_step == 'otp') _otpView(),
              if (_step == 'forgot') _forgotView(),
              if (_error != null) ...[
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.red.shade900.withValues(alpha: 0.4),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.redAccent),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  /// Mockup-match header (login + signup + otp/forgot): the bare
  /// official logo at 120pt (no bordered box — the asset's dark
  /// background blends into the black screen), the "Hamsiq" title,
  /// and the tagline flanked by hairlines. The pill toggle switches
  /// login <-> signup in place; otp/forgot hide it.
  Widget _authHeader({bool showToggle = true}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Center(
          child: Image.asset(
            'assets/logo.png',
            width: 120,
            height: 120,
            fit: BoxFit.contain,
          ),
        ),
        const SizedBox(height: 20),
        const Center(
          child: Text(
            'Hamsiq',
            style: TextStyle(
              fontSize: 40,
              fontWeight: FontWeight.w900,
              color: HamsiqTheme.text,
              letterSpacing: 1,
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: Divider(
                color: Colors.white.withValues(alpha: 0.15),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(
                AppStrings.t('authTagline'),
                style: const TextStyle(
                  color: _authSecondaryText,
                  fontSize: 16,
                ),
              ),
            ),
            Expanded(
              child: Divider(
                color: Colors.white.withValues(alpha: 0.15),
              ),
            ),
          ],
        ),
        if (showToggle) ...[
          const SizedBox(height: 28),
          _modeToggle(),
        ],
      ],
    );
  }

  /// Pill mode toggle (mockup): full-width 56pt, fully rounded dark
  /// track; the active half is blue-filled. In RTL the first child
  /// sits on the right, so login is the blue half on the right when
  /// active, exactly like the mockup. Tapping switches the form in
  /// place via the shared _isLogin state.
  Widget _modeToggle() {
    return Container(
      key: const Key('authModeToggle'),
      height: 56,
      decoration: BoxDecoration(
        color: const Color(0xFF161616),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.06),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: _toggleHalf(
              label: AppStrings.t('loginTab'),
              active: _isLogin,
              onTap: () => setState(() {
                _isLogin = true;
                _error = null;
              }),
            ),
          ),
          Expanded(
            child: _toggleHalf(
              label: AppStrings.t('signupTab'),
              active: !_isLogin,
              onTap: () => setState(() {
                _isLogin = false;
                _error = null;
              }),
            ),
          ),
        ],
      ),
    );
  }

  Widget _toggleHalf({
    required String label,
    required bool active,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 56,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active ? _authPrimaryBlue : Colors.transparent,
          borderRadius: BorderRadius.circular(28),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: active ? FontWeight.w800 : FontWeight.w600,
          ),
        ),
      ),
    );
  }

  /// The new login design (user order 2026-11-16), wired to the real
  /// app: _doLogin calls SecureLogin.loginWithUsername (H-01), the
  /// forgot link opens the existing forgot view, and the create-account
  /// link opens the existing signup view. The pasted design's stub
  /// snackbars are gone. The bubble_chart logo icon is replaced by the
  /// real official logo asset; text alignment follows the locale
  /// (right-aligned in RTL, left-aligned in LTR).
  Widget _loginView() {
    return Scaffold(
      backgroundColor: _authBackground,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 27),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: constraints.maxHeight,
                ),
                child: IntrinsicHeight(
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // v1.2.2: back button in add-account mode.
                        // Returns to the current account's home
                        // without logging out.
                        if (widget.isAddAccount)
                          Align(
                            alignment: AlignmentDirectional.centerStart,
                            child: IconButton(
                              icon: const Icon(Icons.arrow_back),
                              tooltip: AppStrings.t('back'),
                              onPressed: widget.onBack ??
                                  () => Navigator.of(context).pop(),
                            ),
                          ),
                        SizedBox(
                            height: widget.isAddAccount ? 16 : 40),
                        _authHeader(),
                        const SizedBox(height: 32),
                        Text(
                          AppStrings.t('authLoginTitle'),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          AppStrings.t('authLoginSubtitle'),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: _authSecondaryText,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 36),
                        _buildInput(
                          hint: AppStrings.t('authEnterUsername'),
                          controller: _loginUser,
                          icon: Icons.person_outline_rounded,
                          textInputAction: TextInputAction.next,
                        ),
                        const SizedBox(height: 16),
                        _buildInput(
                          hint: AppStrings.t('authEnterPassword'),
                          controller: _loginPass,
                          icon: Icons.lock_outline_rounded,
                          password: true,
                          textInputAction: TextInputAction.done,
                          onSubmitted: (_) => _doLogin(),
                        ),
                        const SizedBox(height: 15),
                        Align(
                          // Mockup: the link sits on the start side
                          // (right in RTL, left in LTR).
                          alignment: AlignmentDirectional.centerStart,
                          child: TextButton(
                            onPressed: () => setState(() {
                              _step = 'forgot';
                              _error = null;
                            }),
                            child: Text(
                              AppStrings.t('authForgot'),
                              style: const TextStyle(
                                color: _authPrimaryBlue,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 17),
                        SizedBox(
                          height: 60,
                          child: ElevatedButton(
                            onPressed: _busy ? null : _doLogin,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _authPrimaryBlue,
                              disabledBackgroundColor:
                                  _authPrimaryBlue.withValues(alpha: 0.5),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(28),
                              ),
                            ),
                            child: _busy
                                ? const SizedBox(
                                    width: 23,
                                    height: 23,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Colors.white,
                                    ),
                                  )
                                : Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        AppStrings.t('loginTab'),
                                        style: const TextStyle(
                                          fontSize: 17,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      const Icon(Icons.login, size: 22),
                                    ],
                                  ),
                          ),
                        ),
                        // Google sign-in (optional): below the login
                        // button, same as on the signup screen.
                        const SizedBox(height: 20),
                        _googleDivider(),
                        const SizedBox(height: 12),
                        _googleButton(),
                        if (_googleWaiting) ...[
                          const SizedBox(height: 12),
                          _googleWaitingRow(),
                        ],
                        if (_error != null) ...[
                          const SizedBox(height: 16),
                          _errorBox(_error!),
                        ],
                        const Spacer(),
                        const SizedBox(height: 45),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              AppStrings.t('authNoAccount'),
                              style: const TextStyle(
                                color: _authSecondaryText,
                                fontSize: 13,
                              ),
                            ),
                            TextButton(
                              onPressed: () => setState(() {
                                _isLogin = false;
                                _error = null;
                              }),
                              child: Text(
                                AppStrings.t('authCreateNow'),
                                style: const TextStyle(
                                  color: _authPrimaryBlue,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 18),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  /// Signup form (mockup-match round): the same header + pill toggle
  /// as the login view, then the existing signup flow (email +
  /// username + password -> _doSignup -> OTP) with the same 60pt pill
  /// inputs, the 60pt pill signup button, and the white Google button
  /// below it. Switches back to login in place via the toggle or the
  /// bottom row — same _isLogin state, no navigation.
  Widget _signupView() {
    return Scaffold(
      backgroundColor: _authBackground,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 27),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: constraints.maxHeight,
                ),
                child: IntrinsicHeight(
                  child: Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        if (widget.isAddAccount)
                          Align(
                            alignment: AlignmentDirectional.centerStart,
                            child: IconButton(
                              icon: const Icon(Icons.arrow_back),
                              tooltip: AppStrings.t('back'),
                              onPressed: widget.onBack ??
                                  () => Navigator.of(context).pop(),
                            ),
                          ),
                        SizedBox(
                            height: widget.isAddAccount ? 16 : 40),
                        _authHeader(),
                        const SizedBox(height: 32),
                        Text(
                          AppStrings.t('authSignupTitle'),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          AppStrings.t('authSignupSubtitle'),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: _authSecondaryText,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 36),
                        _buildInput(
                          hint: AppStrings.t('email'),
                          controller: _suEmail,
                          icon: Icons.mail_outline_rounded,
                          keyboardType: TextInputType.emailAddress,
                          textInputAction: TextInputAction.next,
                        ),
                        const SizedBox(height: 16),
                        _buildInput(
                          hint: AppStrings.t('authEnterUsername'),
                          controller: _suUser,
                          icon: Icons.person_outline_rounded,
                          textInputAction: TextInputAction.next,
                        ),
                        const SizedBox(height: 16),
                        _buildInput(
                          hint: AppStrings.t('authEnterPassword'),
                          controller: _suPass,
                          icon: Icons.lock_outline_rounded,
                          password: true,
                          textInputAction: TextInputAction.done,
                          onSubmitted: (_) => _doSignup(),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          height: 60,
                          child: ElevatedButton(
                            onPressed: _busy ? null : _doSignup,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _authPrimaryBlue,
                              disabledBackgroundColor:
                                  _authPrimaryBlue.withValues(alpha: 0.5),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(28),
                              ),
                            ),
                            child: _busy
                                ? const SizedBox(
                                    width: 23,
                                    height: 23,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Colors.white,
                                    ),
                                  )
                                : Text(
                                    AppStrings.t('signupButton'),
                                    style: const TextStyle(
                                      fontSize: 17,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                          ),
                        ),
                        // Google sign-in (optional): below the signup
                        // button, same as on the login screen.
                        const SizedBox(height: 20),
                        _googleDivider(),
                        const SizedBox(height: 12),
                        _googleButton(),
                        if (_googleWaiting) ...[
                          const SizedBox(height: 12),
                          _googleWaitingRow(),
                        ],
                        if (_error != null) ...[
                          const SizedBox(height: 16),
                          _errorBox(_error!),
                        ],
                        const Spacer(),
                        const SizedBox(height: 32),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              AppStrings.t('authHaveAccount'),
                              style: const TextStyle(
                                color: _authSecondaryText,
                                fontSize: 13,
                              ),
                            ),
                            TextButton(
                              onPressed: () => setState(() {
                                _isLogin = true;
                                _error = null;
                              }),
                              child: Text(
                                AppStrings.t('loginTab'),
                                style: const TextStyle(
                                  color: _authPrimaryBlue,
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 18),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  /// One design input: 60pt pill container with an icon and, for
  /// the password, a visibility toggle. The required-field validator
  /// returns the translated message. The container uses a min height
  /// (not a fixed height) so the validator's error line has room
  /// instead of overflowing the box.
  Widget _buildInput({
    required String hint,
    required TextEditingController controller,
    required IconData icon,
    bool password = false,
    TextInputAction? textInputAction,
    TextInputType? keyboardType,
    void Function(String)? onSubmitted,
  }) {
    final rtl = AppStrings.isArabic;
    return Container(
      constraints: const BoxConstraints(minHeight: 60),
      decoration: BoxDecoration(
        color: _authSurface,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.08),
        ),
      ),
      child: TextFormField(
        controller: controller,
        obscureText: password && _obscurePassword,
        keyboardType: keyboardType,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 15,
        ),
        textAlign: rtl ? TextAlign.right : TextAlign.left,
        textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
        cursorColor: _authPrimaryBlue,
        textInputAction: textInputAction,
        onFieldSubmitted: onSubmitted,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(
            color: _authSecondaryText,
            fontSize: 14,
          ),
          prefixIcon: Icon(
            icon,
            color: _authSecondaryText,
            size: 21,
          ),
          suffixIcon: password
              ? IconButton(
                  onPressed: () {
                    setState(() {
                      _obscurePassword = !_obscurePassword;
                    });
                  },
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_off_outlined
                        : Icons.visibility_outlined,
                    color: _authSecondaryText,
                    size: 21,
                  ),
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 18,
          ),
        ),
        validator: (value) {
          if (value == null || value.trim().isEmpty) {
            return AppStrings.t('authFieldRequired');
          }
          return null;
        },
      ),
    );
  }

  /// "— or —" divider above the Google button (login + signup).
  Widget _googleDivider() {
    return Row(
      children: [
        const Expanded(child: Divider(color: HamsiqTheme.muted)),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Text(
            AppStrings.t('googleOr'),
            style: const TextStyle(color: HamsiqTheme.muted),
          ),
        ),
        const Expanded(child: Divider(color: HamsiqTheme.muted)),
      ],
    );
  }

  /// Waiting-for-Google row (login + signup).
  Widget _googleWaitingRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const SizedBox(
          height: 16,
          width: 16,
          child: CircularProgressIndicator(strokeWidth: 2),
        ),
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            AppStrings.t('googleWaiting'),
            style: const TextStyle(color: HamsiqTheme.muted),
          ),
        ),
      ],
    );
  }

  /// Error box (same look as the legacy screen).
  Widget _errorBox(String error) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.red.shade900.withValues(alpha: 0.4),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        error,
        style: const TextStyle(color: Colors.redAccent),
        textAlign: TextAlign.center,
      ),
    );
  }

  /// White Google button with the official "G" logo (assets/google_g.png).
  Widget _googleButton() {
    return ElevatedButton(
      onPressed: (_busy || _googleWaiting) ? null : _doGoogleSignIn,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            'assets/google_g.png',
            width: 20,
            height: 20,
          ),
          const SizedBox(width: 10),
          Text(AppStrings.t('googleContinue'),
              style: const TextStyle(fontSize: 16)),
        ],
      ),
    );
  }

  Widget _otpView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          AppStrings.t('authOtpTitle'),
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 8),
        Text(
          AppStrings.t('authOtpSentTo').replaceAll('{email}', _pendingEmail),
          style: const TextStyle(color: HamsiqTheme.muted),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 24),
        TextField(
          controller: _otpCode,
          decoration: InputDecoration(
            hintText: AppStrings.t('authOtpHint'),
            prefixIcon: const Icon(Icons.shield_outlined),
          ),
          keyboardType: TextInputType.number,
          maxLength: 8,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24, letterSpacing: 8),
          onSubmitted: (_) => _doVerifyOtp(),
        ),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: _busy ? null : _doVerifyOtp,
          child: Text(AppStrings.t('confirm'), style: const TextStyle(fontSize: 17)),
        ),
        const SizedBox(height: 12),
        TextButton(
          onPressed: () => setState(() => _step = 'form'),
          child: Text(AppStrings.t('back'), style: const TextStyle(color: HamsiqTheme.accent)),
        ),
      ],
    );
  }

  Widget _forgotView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          AppStrings.t('authForgotTitle'),
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 8),
        Text(
          AppStrings.t('authForgotBody'),
          style: const TextStyle(color: HamsiqTheme.muted),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 24),
        TextField(
          controller: _forgotEmail,
          decoration: InputDecoration(
            hintText: AppStrings.t('email'),
            prefixIcon: const Icon(Icons.mail_outline),
          ),
          keyboardType: TextInputType.emailAddress,
          onSubmitted: (_) => _doForgot(),
        ),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: _busy ? null : _doForgot,
          child: Text(AppStrings.t('authSendLink'), style: const TextStyle(fontSize: 17)),
        ),
        const SizedBox(height: 12),
        TextButton(
          onPressed: () => setState(() => _step = 'form'),
          child: Text(AppStrings.t('back'), style: const TextStyle(color: HamsiqTheme.accent)),
        ),
      ],
    );
  }
}
