// Hamsiq native — Stories UI (Phase 2, workstream D).
// Real data only, via StoriesApi (tables stories / highlights /
// highlight_stories from sql-v5.sql + sql-v16.sql).
//
// Public widgets for the coordinator to wire in:
//   StoryBar(me: profile, onChanged: () => ...) — horizontal story row
//     for the top of the feed. My circle: tap opens my stories (or the
//     publish sheet when I have none); long-press always opens publish.
//     Tapping a friend opens the full-screen StoryViewer.
//   StoryViewer(groups: [...], initialGroupIndex: 0, me: profile)
//     — full-screen viewer with progress bars, tap right/left, hold to
//     pause, auto-advance, delete + add-to-highlight for my own stories.
//   StoriesScreen(me: profile) — stories + my highlights in one screen.
//
// "Seen" rings in the StoryBar stay session-local (ring tint only).
// Wave 1 (sql-v29): views ARE real DB rows — StoriesApi.recordStoryView
// writes public.story_views on every view; the owner sees the count +
// who-viewed list via the eye button in the viewer.

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart'; // also provides XFile
import 'package:video_player/video_player.dart';
import '../models.dart';
import '../services/app_strings.dart';
import '../services/media_api.dart';
import '../services/stories_api.dart';
import '../services/supabase_service.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'camera_screen.dart';

// ---------------------------------------------------------------------------
// StoryBar
// ---------------------------------------------------------------------------

class StoryBar extends StatefulWidget {
  final HamsiqProfile me;

  /// Called after a story is published or deleted, so the parent can
  /// refresh anything that depends on stories.
  final VoidCallback? onChanged;

  const StoryBar({super.key, required this.me, this.onChanged});

  @override
  State<StoryBar> createState() => _StoryBarState();
}

class _StoryBarState extends State<StoryBar> {
  List<UserStories> _groups = [];
  bool _loading = true;
  String? _error;
  bool _uploading = false;

  /// Users whose stories were opened this session (no story_views table
  /// exists in the DB, so this is in-memory only).
  final _seenUserIds = <String>{};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final stories = await StoriesApi.fetchActiveStories();
      // Wave 2: Close Friends stories are visible only to the list +
      // the owner (client-side filter — see StoriesApi).
      final cfOwners = await StoriesApi.fetchCloseFriendOwnerIds();
      final visible = StoriesApi.filterCloseFriendsStories(
        stories,
        cfOwners,
        widget.me.id,
      );
      if (!mounted) return;
      final authorIds = visible.map((s) => s.userId).toSet().toList();
      final authors = await Api.fetchProfiles(authorIds);
      if (!mounted) return;
      setState(() {
        _groups = StoriesApi.groupByUser(visible, authors);
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  UserStories? get _myGroup {
    for (final g in _groups) {
      if (g.author.id == widget.me.id) return g;
    }
    return null;
  }

  Future<void> _openViewer(int groupIndex) async {
    final group = _groups[groupIndex];
    setState(() => _seenUserIds.add(group.author.id));
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => StoryViewer(
          groups: _groups,
          initialGroupIndex: groupIndex,
          me: widget.me,
          onChanged: () {
            _load();
            widget.onChanged?.call();
          },
        ),
      ),
    );
    // Stories may have been deleted inside the viewer — refresh.
    if (mounted) _load();
  }

  void _showPublishSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: HamsiqTheme.panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera, color: Colors.white),
              title: Text(AppStrings.t('captureCamera'),
                  style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.of(sheetContext).pop();
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => CameraScreen(
                      onCaptured: (file, isVideo) {
                        Navigator.of(context).pop(); // caller pops
                        _publishFile(file, isVideo);
                      },
                      onUseGallery: () {
                        Navigator.of(context).pop();
                        _pickFromGallery(ImageSource.gallery, false);
                      },
                    ),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Colors.white),
              title: Text(AppStrings.t('photoFromGallery'),
                  style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.of(sheetContext).pop();
                _pickFromGallery(ImageSource.gallery, false);
              },
            ),
            ListTile(
              leading: const Icon(Icons.video_library, color: Colors.white),
              title: Text(AppStrings.t('videoFromGallery'),
                  style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.of(sheetContext).pop();
                _pickFromGallery(ImageSource.gallery, true);
              },
            ),
            // Wave 2: Close Friends story (green ring, list only).
            ListTile(
              leading: const Icon(Icons.star, color: Colors.green),
              title: Text(AppStrings.t('closeFriendsStory'),
                  style: TextStyle(color: Colors.white)),
              subtitle: Text(
                AppStrings.t('closeFriendsStoryHint'),
                style: TextStyle(color: HamsiqTheme.muted, fontSize: 12),
              ),
              onTap: () {
                Navigator.of(sheetContext).pop();
                _pickFromGallery(ImageSource.gallery, false,
                    closeFriends: true);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickFromGallery(
    ImageSource source,
    bool isVideo, {
    bool closeFriends = false,
  }) async {
    try {
      final picker = ImagePicker();
      final XFile? picked = isVideo
          ? await picker.pickVideo(source: source)
          : await picker.pickImage(
              source: source,
              maxWidth: 1080,
              imageQuality: 85,
            );
      if (picked == null) return;
      await _publishFile(picked, isVideo, closeFriends: closeFriends);
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _publishFile(
    XFile file,
    bool isVideo, {
    bool closeFriends = false,
  }) async {
    if (_uploading) return;
    setState(() => _uploading = true);
    try {
      final String? url;
      if (isVideo) {
        url = await MediaApi.uploadVideo(
          await file.readAsBytes(),
          MediaApi.uniqueVideoPath('story'),
        );
      } else {
        url = await Api.uploadImage(
          await file.readAsBytes(),
          Api.uniqueImagePath('story'),
        );
      }
      if (url == null) throw Exception(AppStrings.t('fileUploadFailed'));
      if (closeFriends) {
        await StoriesApi.publishCloseFriendsStory(
          url,
          isVideo ? 'video' : 'image',
        );
      } else {
        await StoriesApi.publishStory(url, isVideo ? 'video' : 'image');
      }
      await _load();
      widget.onChanged?.call();
      if (mounted) {
        showOk(
          context,
          closeFriends
              ? AppStrings.t('closeFriendsStoryPublished')
              : AppStrings.t('storyPublished'),
        );
      }
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          height: 112,
          child: _loading
              ? const Center(
                  child: SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      color: HamsiqTheme.accent,
                      strokeWidth: 2,
                    ),
                  ),
                )
              : ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  children: [
                    _myCircle(),
                    for (var i = 0; i < _groups.length; i++)
                      if (_groups[i].author.id != widget.me.id)
                        _friendCircle(i),
                    if (_error != null)
                      Center(
                        child: IconButton(
                          tooltip: AppStrings.t('retry'),
                          onPressed: _load,
                          icon: const Icon(Icons.refresh,
                              color: HamsiqTheme.muted),
                        ),
                      ),
                  ],
                ),
        ),
        if (_uploading)
          const LinearProgressIndicator(color: HamsiqTheme.accent),
      ],
    );
  }

  Widget _myCircle() {
    final myGroup = _myGroup;
    final hasStories = myGroup != null && myGroup.stories.isNotEmpty;
    return _StoryCircle(
      profile: widget.me,
      label: AppStrings.t('myStory'),
      ringColor: hasStories ? HamsiqTheme.accent : HamsiqTheme.line,
      showPlus: true,
      onTap: () {
        if (hasStories) {
          final index = _groups.indexOf(myGroup);
          if (index >= 0) _openViewer(index);
        } else {
          _showPublishSheet();
        }
      },
      onLongPress: _showPublishSheet,
    );
  }

  Widget _friendCircle(int groupIndex) {
    final group = _groups[groupIndex];
    final seen = _seenUserIds.contains(group.author.id);
    // Wave 2: Close Friends stories get the green ring (like Instagram).
    final isCloseFriends =
        group.stories.any((s) => s.isCloseFriends);
    return _StoryCircle(
      profile: group.author,
      label: group.author.displayName,
      ringColor: isCloseFriends
          ? Colors.green
          : seen
              ? HamsiqTheme.line
              : HamsiqTheme.accent,
      onTap: () => _openViewer(groupIndex),
    );
  }
}

class _StoryCircle extends StatelessWidget {
  final HamsiqProfile profile;
  final String label;
  final Color ringColor;
  final bool showPlus;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  const _StoryCircle({
    required this.profile,
    required this.label,
    required this.ringColor,
    this.showPlus = false,
    required this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: SizedBox(
        width: 78,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 70,
              height: 70,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Mockup-match (feed redesign 2026-11-16): unseen
                  // stories get a blue GRADIENT ring with a soft blue
                  // glow shadow (neon rings in the mockup); seen /
                  // Close-Friends rings stay a plain border in their
                  // own colour, with a faint glow of the same colour.
                  Container(
                    width: 68,
                    height: 68,
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: ringColor == HamsiqTheme.accent
                          ? const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                HamsiqTheme.accent,
                                HamsiqTheme.accentDark,
                                HamsiqTheme.accent,
                              ],
                            )
                          : null,
                      border: ringColor == HamsiqTheme.accent
                          ? null
                          : Border.all(
                              color: ringColor,
                              width: 2.5,
                            ),
                      boxShadow: [
                        BoxShadow(
                          color: ringColor.withValues(
                            alpha: ringColor == HamsiqTheme.accent
                                ? 0.55
                                : 0.25,
                          ),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: AvatarWidget(
                        profile: profile,
                        size: 60,
                      ),
                    ),
                  ),
                  if (showPlus)
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          color: HamsiqTheme.accent,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.black,
                            width: 2,
                          ),
                        ),
                        child: const Icon(
                          Icons.add,
                          size: 15,
                          color: Colors.white,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 5),
            SizedBox(
              width: 74,
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 11,
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// StoryViewer
// ---------------------------------------------------------------------------

/// Full-screen story viewer. [groups] are the users to page through in
/// order; [initialGroupIndex] picks where to start. Progress bars show
/// one segment per story of the current user; images show 5s, videos
/// play for their own duration. Tap right = next, tap left = previous,
/// long-press = pause. Own stories get delete + add-to-highlight actions.
class StoryViewer extends StatefulWidget {
  final List<UserStories> groups;
  final int initialGroupIndex;
  final HamsiqProfile me;
  final VoidCallback? onChanged;

  const StoryViewer({
    super.key,
    required this.groups,
    this.initialGroupIndex = 0,
    required this.me,
    this.onChanged,
  });

  @override
  State<StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<StoryViewer>
    with SingleTickerProviderStateMixin {
  static const _imageDuration = Duration(seconds: 5);

  late List<UserStories> _groups;
  late int _groupIndex;
  int _storyIndex = 0;
  late final AnimationController _progress;
  VideoPlayerController? _videoController;
  bool _videoReady = false;
  bool _videoFailed = false;
  bool _muted = false;
  bool _paused = false;

  // Wave 1: story views (real DB rows) + story replies (real DMs).
  int _viewCount = 0;
  final _replyCtrl = TextEditingController();
  bool _sendingReply = false;

  // Generation guard for the async re-sign in _setupCurrent: a
  // newer setup (user tapped next/prev while a re-sign was in
  // flight) invalidates the older one, so a stale controller can
  // never overwrite the current story's.
  int _setupGen = 0;

  StoryItem get _current => _groups[_groupIndex].stories[_storyIndex];
  HamsiqProfile get _currentAuthor => _groups[_groupIndex].author;
  bool get _isMine => _currentAuthor.id == widget.me.id;

  @override
  void initState() {
    super.initState();
    // Copy: deleting a story mutates the viewer's list, not the caller's.
    _groups = widget.groups
        .map((g) => UserStories(author: g.author, stories: List.of(g.stories)))
        .toList();
    _groupIndex = widget.initialGroupIndex.clamp(0, _groups.length - 1);
    _progress = AnimationController(
      vsync: this,
      duration: _imageDuration,
    )..addStatusListener((status) {
        if (status == AnimationStatus.completed) _next();
      });
    _setupCurrent();
  }

  @override
  void dispose() {
    _progress.dispose();
    _disposeVideo();
    _replyCtrl.dispose();
    super.dispose();
  }

  void _disposeVideo() {
    final c = _videoController;
    _videoController = null;
    if (c == null) return;
    c.pause();
    c.dispose();
  }

  Future<void> _setupCurrent() async {
    final gen = ++_setupGen;
    _progress.stop();
    _progress.reset();
    _disposeVideo();
    setState(() {
      _videoReady = false;
      _videoFailed = false;
      _paused = false;
    });
    final story = _current;
    // Wave 1: record a real view row (never my own story — the owner
    // is not a viewer). A view failure must never break playback, so
    // errors are swallowed. Owners also refresh their view count.
    if (!_isMine) {
      StoriesApi.recordStoryView(story.id).catchError((_) {});
    } else {
      StoriesApi.fetchStoryViewCount(story.id).then((count) {
        if (mounted) setState(() => _viewCount = count);
      }).catchError((_) {});
    }
    if (story.mediaType == 'video' &&
        story.mediaUrl != null &&
        story.mediaUrl!.isNotEmpty) {
      // H-04 re-sign-on-render: re-sign BEFORE creating the video
      // controller, via the server-side resign-media function, so a
      // story uploaded >1h ago still plays for every viewer.
      // Best-effort: on failure ensureFreshUrl returns the stored
      // URL and playback tries it as-is.
      final fresh = await MediaApi.ensureFreshUrl(story.mediaUrl!);
      if (!mounted || gen != _setupGen || !identical(_current, story)) {
        return;
      }
      final c = VideoPlayerController.networkUrl(Uri.parse(fresh));
      _videoController = c;
      c.setLooping(false);
      c.setVolume(_muted ? 0 : 1);
      c.initialize().then((_) {
        if (!mounted || !identical(_videoController, c)) return;
        final d = c.value.duration;
        _progress.duration =
            (d == Duration.zero) ? _imageDuration : d;
        setState(() => _videoReady = true);
        c.play();
        _progress.forward();
      }).catchError((_) {
        // Video failed: fall back to a 5s still so the viewer never stalls.
        if (!mounted || !identical(_videoController, c)) return;
        _progress.duration = _imageDuration;
        setState(() => _videoFailed = true);
        _progress.forward();
      });
    } else {
      _progress.duration = _imageDuration;
      _progress.forward();
    }
  }

  void _next() {
    if (!mounted || _groups.isEmpty) return;
    final group = _groups[_groupIndex];
    if (_storyIndex < group.stories.length - 1) {
      setState(() => _storyIndex++);
      _setupCurrent();
    } else if (_groupIndex < _groups.length - 1) {
      setState(() {
        _groupIndex++;
        _storyIndex = 0;
      });
      _setupCurrent();
    } else {
      Navigator.of(context).pop();
    }
  }

  void _prev() {
    if (!mounted || _groups.isEmpty) return;
    if (_storyIndex > 0) {
      setState(() => _storyIndex--);
      _setupCurrent();
    } else if (_groupIndex > 0) {
      setState(() {
        _groupIndex--;
        _storyIndex = _groups[_groupIndex].stories.length - 1;
      });
      _setupCurrent();
    } else {
      // Already at the very first story: replay it.
      _setupCurrent();
    }
  }

  void _pause() {
    if (_paused) return;
    _paused = true;
    _progress.stop();
    _videoController?.pause();
  }

  void _resume() {
    if (!_paused) return;
    _paused = false;
    _progress.forward();
    if (_videoReady) _videoController?.play();
  }

  void _onTapUp(TapUpDetails details, double width) {
    final dx = details.globalPosition.dx;
    if (dx < width / 3) {
      _prev();
    } else if (dx > width * 2 / 3) {
      _next();
    }
  }

  Future<void> _deleteCurrent() async {
    final story = _current;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('deleteStoryTitle'),
            style: TextStyle(color: Colors.white)),
        content: Text(AppStrings.t('deleteStoryBody'),
            style: TextStyle(color: HamsiqTheme.muted)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(AppStrings.t('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(AppStrings.t('delete'), style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (confirm != true || !mounted) return;
    try {
      await StoriesApi.deleteStory(story.id);
      widget.onChanged?.call();
      if (!mounted) return;
      final group = _groups[_groupIndex];
      setState(() {
        group.stories.removeAt(_storyIndex);
        if (group.stories.isEmpty) {
          _groups.removeAt(_groupIndex);
          _storyIndex = 0;
          if (_groupIndex >= _groups.length) _groupIndex = _groups.length - 1;
        } else if (_storyIndex >= group.stories.length) {
          _storyIndex = group.stories.length - 1;
        }
      });
      if (_groups.isEmpty) {
        if (mounted) Navigator.of(context).pop();
        return;
      }
      _setupCurrent();
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _addToHighlight() async {
    final story = _current;
    List<HighlightItem> existing = [];
    try {
      existing = await StoriesApi.fetchHighlights(widget.me.id);
    } catch (_) {
      existing = [];
    }
    if (!mounted) return;
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => _HighlightNameDialog(existing: existing),
    );
    if (name == null || name.trim().isEmpty || !mounted) return;
    try {
      await StoriesApi.addToHighlight(story.id, name.trim());
      if (mounted) showOk(context, AppStrings.t('addedToHighlights'));
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  /// Wave 1: who viewed my story (real story_views rows). Owner only —
  /// the eye button is only rendered for my own stories.
  Future<void> _showViewers() async {
    final story = _current;
    List<StoryView> views = [];
    try {
      views = await StoriesApi.fetchStoryViews(story.id);
    } catch (e) {
      if (mounted) showError(context, e);
      return;
    }
    if (!mounted) return;
    setState(() => _viewCount = views.length);
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: HamsiqTheme.panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Text(
                '${AppStrings.t('viewsLabel')} (${views.length})',
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 320,
              child: views.isEmpty
                  ? EmptyCenter(AppStrings.t('noViewsYet'))
                  : ListView.builder(
                      itemCount: views.length,
                      itemBuilder: (_, i) {
                        final v = views[i];
                        final viewer = v.viewer;
                        return ListTile(
                          leading: AvatarWidget(profile: viewer, size: 40),
                          title: Text(
                            viewer?.displayName ?? '',
                            style: const TextStyle(color: Colors.white),
                          ),
                          subtitle: Text(
                            '@${viewer?.username ?? ''} · ${timeAgo(v.createdAt)}',
                            style: const TextStyle(
                              color: HamsiqTheme.muted,
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  /// Wave 1: reply to someone else's story — lands as a real DM to the
  /// story owner (StoriesApi.replyToStory -> MessagesApi.sendStoryReply).
  Future<void> _sendReply() async {
    final text = _replyCtrl.text.trim();
    if (text.isEmpty || _sendingReply) return;
    setState(() => _sendingReply = true);
    try {
      await StoriesApi.replyToStory(_currentAuthor.id, _current, text);
      if (!mounted) return;
      _replyCtrl.clear();
      setState(() => _sendingReply = false);
      showOk(context, AppStrings.t('replySent'));
    } catch (e) {
      if (!mounted) return;
      setState(() => _sendingReply = false);
      showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_groups.isEmpty) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Text(AppStrings.t('noStories'), style: TextStyle(color: Colors.white)),
        ),
      );
    }
    final story = _current;
    final group = _groups[_groupIndex];
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTapUp: (d) => _onTapUp(d, width),
        onLongPressStart: (_) => _pause(),
        onLongPressEnd: (_) => _resume(),
        child: Stack(
          fit: StackFit.expand,
          children: [
            _storyMedia(story),
            // Top gradient + header.
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black87, Colors.transparent],
                  ),
                ),
                child: SafeArea(
                  bottom: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          children: [
                            for (var i = 0; i < group.stories.length; i++)
                              Expanded(
                                child: Padding(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 2),
                                  child: _ProgressSegment(
                                    animation: i == _storyIndex
                                        ? _progress
                                        : null,
                                    filled: i < _storyIndex,
                                  ),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            AvatarWidget(profile: _currentAuthor, size: 36),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    _currentAuthor.displayName,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  // Wave 2: Close Friends badge on the story.
                                  if (story.isCloseFriends)
                                    Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.star,
                                            size: 12, color: Colors.green),
                                        SizedBox(width: 3),
                                        Text(
                                          AppStrings.t('titleCloseFriends'),
                                          style: TextStyle(
                                            color: Colors.green,
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                  Text(
                                    timeAgo(story.createdAt),
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            if (story.mediaType == 'video')
                              IconButton(
                                onPressed: () {
                                  setState(() => _muted = !_muted);
                                  _videoController
                                      ?.setVolume(_muted ? 0 : 1);
                                },
                                icon: Icon(
                                  _muted
                                      ? Icons.volume_off
                                      : Icons.volume_up,
                                  color: Colors.white,
                                ),
                              ),
                            if (_isMine)
                              IconButton(
                                tooltip: AppStrings.t('addToHighlights'),
                                onPressed: _addToHighlight,
                                icon: const Icon(Icons.bookmark_add,
                                    color: Colors.white),
                              ),
                            // Wave 1: viewers (owner only) — count + list
                            // from the real story_views table.
                            if (_isMine)
                              TextButton.icon(
                                onPressed: _showViewers,
                                icon: const Icon(
                                  Icons.visibility,
                                  color: Colors.white,
                                  size: 20,
                                ),
                                label: Text(
                                  '$_viewCount',
                                  style: const TextStyle(color: Colors.white),
                                ),
                              ),
                            if (_isMine)
                              IconButton(
                                tooltip: AppStrings.t('delete'),
                                onPressed: _deleteCurrent,
                                icon: const Icon(Icons.delete_outline,
                                    color: Colors.white),
                              ),
                            IconButton(
                              onPressed: () => Navigator.of(context).pop(),
                              icon: const Icon(Icons.close,
                                  color: Colors.white),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            if (_paused)
              const Center(
                child: Icon(Icons.pause_circle_filled,
                    color: Colors.white70, size: 72),
              ),
            // Wave 1: reply input on someone else's story — sends a real
            // DM to the story owner quoting the story.
            if (!_isMine)
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: Container(
                  padding: EdgeInsets.fromLTRB(
                    12,
                    8,
                    12,
                    MediaQuery.of(context).padding.bottom + 12,
                  ),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Colors.black87],
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _replyCtrl,
                          style: const TextStyle(color: Colors.white),
                          textInputAction: TextInputAction.send,
                          onSubmitted: (_) => _sendReply(),
                          decoration: InputDecoration(
                            hintText:
                                '${AppStrings.t('replyToStory')} ${_currentAuthor.displayName}...',
                            filled: true,
                            fillColor: Colors.white.withValues(alpha: 0.15),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(22),
                              borderSide: BorderSide.none,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      _sendingReply
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                color: HamsiqTheme.accent,
                                strokeWidth: 2,
                              ),
                            )
                          : IconButton(
                              onPressed: _sendReply,
                              icon: const Icon(
                                Icons.send,
                                color: HamsiqTheme.accent,
                              ),
                            ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _storyMedia(StoryItem story) {
    final url = story.mediaUrl;
    if (url == null || url.isEmpty) {
      return const Center(
        child: Icon(Icons.broken_image, color: HamsiqTheme.muted, size: 64),
      );
    }
    if (story.mediaType == 'video') {
      final c = _videoController;
      if (_videoFailed) {
        return const Center(
          child: Icon(Icons.broken_image, color: HamsiqTheme.muted, size: 64),
        );
      }
      if (!_videoReady || c == null) {
        return const Center(
          child: CircularProgressIndicator(color: HamsiqTheme.accent),
        );
      }
      return Center(
        child: AspectRatio(
          aspectRatio: c.value.aspectRatio,
          child: VideoPlayer(c),
        ),
      );
    }
    // H-04 re-sign-on-render: SignedMediaImage re-signs the stored
    // (possibly expired) story URL before loading, via the
    // server-side resign-media function, so other viewers keep
    // seeing stories up to 24h after upload.
    return SignedMediaImage(
      url: url,
      fit: BoxFit.contain,
      loadingBuilder: (_, child, progress) => progress == null
          ? child
          : const Center(
              child: CircularProgressIndicator(color: HamsiqTheme.accent),
            ),
      errorBuilder: (_, __, ___) => const Center(
        child: Icon(Icons.broken_image, color: HamsiqTheme.muted, size: 64),
      ),
    );
  }
}

class _ProgressSegment extends StatelessWidget {
  /// [animation] drives the current story's fill; [filled] marks a
  /// completed story; neither set means an upcoming story (empty).
  final Animation<double>? animation;
  final bool filled;

  const _ProgressSegment({this.animation, this.filled = false});

  @override
  Widget build(BuildContext context) {
    final Widget fill;
    if (animation != null) {
      fill = AnimatedBuilder(
        animation: animation!,
        builder: (_, __) => FractionallySizedBox(
          alignment: Alignment.centerLeft,
          widthFactor: animation!.value,
          child: Container(color: Colors.white),
        ),
      );
    } else if (filled) {
      fill = Container(color: Colors.white);
    } else {
      fill = const SizedBox.shrink();
    }
    return Container(
      height: 3,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(2),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(2),
        child: fill,
      ),
    );
  }
}

class _HighlightNameDialog extends StatefulWidget {
  final List<HighlightItem> existing;
  const _HighlightNameDialog({required this.existing});

  @override
  State<_HighlightNameDialog> createState() => _HighlightNameDialogState();
}

class _HighlightNameDialogState extends State<_HighlightNameDialog> {
  final _name = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: HamsiqTheme.panel,
      title: Text(AppStrings.t('addToHighlights'),
          style: TextStyle(color: Colors.white)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextField(
            controller: _name,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(hintText: AppStrings.t('collectionNameHint')),
          ),
          if (widget.existing.isNotEmpty) ...[
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                for (final h in widget.existing)
                  ActionChip(
                    label: Text(h.title),
                    onPressed: () => _name.text = h.title,
                  ),
              ],
            ),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(AppStrings.t('cancel')),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(_name.text.trim()),
          child: Text(AppStrings.t('save')),
        ),
      ],
    );
  }
}

// ---------------------------------------------------------------------------
// StoriesScreen — stories + my highlights in one place
// ---------------------------------------------------------------------------

class StoriesScreen extends StatefulWidget {
  final HamsiqProfile me;
  const StoriesScreen({super.key, required this.me});

  @override
  State<StoriesScreen> createState() => _StoriesScreenState();
}

class _StoriesScreenState extends State<StoriesScreen> {
  List<HighlightItem> _highlights = [];
  bool _loadingHighlights = true;

  @override
  void initState() {
    super.initState();
    _loadHighlights();
  }

  Future<void> _loadHighlights() async {
    try {
      final items = await StoriesApi.fetchHighlights(widget.me.id);
      if (!mounted) return;
      setState(() {
        _highlights = items;
        _loadingHighlights = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loadingHighlights = false);
    }
  }

  Future<void> _openHighlight(HighlightItem highlight) async {
    try {
      final stories = await StoriesApi.fetchHighlightStories(highlight.id);
      if (!mounted) return;
      if (stories.isEmpty) {
        showError(context, AppStrings.t('highlightEmpty'));
        return;
      }
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => StoryViewer(
            groups: [UserStories(author: widget.me, stories: stories)],
            me: widget.me,
          ),
        ),
      );
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.t('storiesTitle'))),
      body: ListView(
        children: [
          const SizedBox(height: 8),
          StoryBar(me: widget.me, onChanged: _loadHighlights),
          const Divider(color: HamsiqTheme.line),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              AppStrings.t('highlightsTitle'),
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          if (_loadingHighlights)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: CircularProgressIndicator(color: HamsiqTheme.accent),
              ),
            )
          else if (_highlights.isEmpty)
            Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                AppStrings.t('noHighlights'),
                style: TextStyle(color: HamsiqTheme.muted),
              ),
            )
          else
            SizedBox(
              height: 100,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: _highlights.length,
                itemBuilder: (_, i) {
                  final h = _highlights[i];
                  return GestureDetector(
                    onTap: () => _openHighlight(h),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 58,
                            height: 58,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                  color: HamsiqTheme.line, width: 2),
                            ),
                            child: ClipOval(
                              child: h.coverUrl != null
                                  // H-04: highlight covers are story
                                  // media URLs — re-sign before loading.
                                  ? SignedMediaImage(
                                      url: h.coverUrl!,
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) =>
                                          _highlightFallback(h))
                                  : _highlightFallback(h),
                            ),
                          ),
                          const SizedBox(height: 4),
                          SizedBox(
                            width: 66,
                            child: Text(
                              h.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  fontSize: 11, color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget _highlightFallback(HighlightItem h) {
    return Container(
      color: HamsiqTheme.panel2,
      alignment: Alignment.center,
      child: Text(
        h.title.isNotEmpty ? h.title.characters.first : '★',
        style: const TextStyle(color: Colors.white, fontSize: 22),
      ),
    );
  }
}
