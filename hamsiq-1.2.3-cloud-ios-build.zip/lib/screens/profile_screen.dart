// Hamsiq native — profile screen (Phase 1).
// Header (avatar, name, bio, stats) + edit / follow actions + 3-column
// grid of the user's posts. All data comes from Api; no fake data.
// Tapping a post tile opens PostDetailScreen for that post
// (H-07a fix 2026-11-16: the old "does nothing" note was stale —
// _postTile already pushed PostDetailScreen since the v1.2.1 refactor;
// the comment is corrected here and the navigation is covered by
// test/profile_interactions_test.dart).


import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/notifications_api.dart';
import '../services/share_api.dart';
import '../services/stories_api.dart';
import '../services/supabase_service.dart';
import '../services/wave3_api.dart';
import '../theme.dart';
import '../widgets/account_switcher_sheet.dart';
import '../widgets/common.dart';
import '../widgets/profile_extra_tabs.dart';
import 'chats_screen.dart';
import 'post_detail_screen.dart';
import 'settings_screen.dart';
import 'stories_screen.dart';

class ProfileScreen extends StatefulWidget {
  final String userId;
  final bool isMe;
  const ProfileScreen({super.key, required this.userId, this.isMe = false});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  HamsiqProfile? _profile;
  List<PostItem> _posts = [];
  int _followers = 0;
  int _following = 0;
  bool _isFollowing = false;
  bool _followBusy = false;
  bool _loading = true;
  Object? _error;
  // Wave 1: the Reposts tab exists only when the user has ≥1 repost.
  bool _hasReposts = false;
  // Wave 3: the Collab tab exists only when the user has ≥1 accepted
  // co-authored post.
  List<PostItem> _collabPosts = [];
  bool _hasCollabs = false;
  // Active tab: 0 posts, 1 reels, then reposts and/or collab if present.
  int _tabIndex = 0;
  // Real highlights (StoriesApi), newest first. Best-effort: a failure
  // here must not break the profile — the row just shows the "new" (+)
  // circle on the own profile.
  List<HighlightItem> _highlights = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _openAccountSwitcher() async {
    await showAccountSwitcherSheet(context);
    // Switching reloads the whole app; closing the sheet needs nothing.
    // Reload silently in case the profile changed meanwhile.
    if (mounted) _load(showLoading: false);
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const SettingsScreen()),
    );
    // Settings can change name/bio/avatar — reload silently on return.
    if (mounted) _load(showLoading: false);
  }

  /// Mockup top row: the "..." opens the profile options sheet. The
  /// hamburger used to open Settings directly; the mockup splits the
  /// two — "..." for options, gear for Settings.
  Future<void> _openOptionsSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: HamsiqTheme.panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (sheetCtx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.ios_share_outlined),
              title: Text(AppStrings.t('shareProfile')),
              onTap: () {
                Navigator.of(sheetCtx).pop();
                _shareProfile();
              },
            ),
            if (widget.isMe)
              ListTile(
                leading: const Icon(Icons.settings_outlined),
                title: Text(AppStrings.t('titleSettings')),
                onTap: () {
                  Navigator.of(sheetCtx).pop();
                  _openSettings();
                },
              )
            else
              ListTile(
                leading: const Icon(Icons.message_outlined),
                title: Text(AppStrings.t('messageButton')),
                onTap: () {
                  Navigator.of(sheetCtx).pop();
                  _openMessage();
                },
              ),
          ],
        ),
      ),
    );
  }

  /// Open one of my / the user's real highlights in the story viewer
  /// (same flow as StoriesScreen). An empty highlight reports itself.
  Future<void> _openHighlight(HighlightItem highlight) async {
    final profile = _profile;
    if (profile == null) return;
    try {
      final stories = await StoriesApi.fetchHighlightStories(highlight.id);
      if (!mounted) return;
      if (stories.isEmpty) {
        showError(context, AppStrings.t('highlightEmpty'));
        return;
      }
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => StoryViewer(
            groups: [UserStories(author: profile, stories: stories)],
            me: profile,
          ),
        ),
      );
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  /// The "new" (+) highlight circle: highlights are created from a
  /// story (open a story, tap save), so the tap explains that flow
  /// instead of opening a dead creator.
  void _showNewHighlightHint() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(AppStrings.t('noHighlights')),
        backgroundColor: HamsiqTheme.panel2,
      ),
    );
  }

  Future<void> _load({bool showLoading = true}) async {
    setState(() {
      if (showLoading) _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait([
        Api.fetchProfile(widget.userId),
        Api.countFollowers(widget.userId),
        Api.countFollowing(widget.userId),
        // Wave 1: ordered grid (pinned first + custom grid order).
        ShareApi.fetchOrderedUserPosts(widget.userId),
        if (!widget.isMe) Api.isFollowing(widget.userId),
        // Wave 1: does the Reposts tab exist? (best-effort: a failure
        // here must not break the profile — the tab just stays hidden).
        ShareApi.fetchUserReposts(widget.userId).then(
          (r) => r.isNotEmpty,
          onError: (_) => false,
        ),
        // Wave 3: accepted co-authored posts (best-effort, same deal).
        Wave3Api.fetchCoAuthoredPosts(widget.userId).then(
          (r) => r,
          onError: (_) => <PostItem>[],
        ),
        // Mockup round: the user's real highlights (best-effort, same
        // deal — a failure just leaves the row at the "new" circle).
        StoriesApi.fetchHighlights(widget.userId).then(
          (r) => r,
          onError: (_) => <HighlightItem>[],
        ),
      ]);
      if (!mounted) return;
      setState(() {
        _profile = results[0] as HamsiqProfile?;
        _followers = results[1] as int;
        _following = results[2] as int;
        _posts = results[3] as List<PostItem>;
        // When isMe there is no isFollowing entry, so the reposts
        // flag sits at index 4 and collabs at 5; otherwise 5 and 6.
        if (!widget.isMe) _isFollowing = results[4] as bool;
        _hasReposts = results[widget.isMe ? 4 : 5] as bool;
        _collabPosts = results[widget.isMe ? 5 : 6] as List<PostItem>;
        _hasCollabs = _collabPosts.isNotEmpty;
        _highlights = results[widget.isMe ? 6 : 7] as List<HighlightItem>;
        final tabCount = 2 +
            (_hasReposts ? 1 : 0) +
            (_hasCollabs ? 1 : 0);
        if (_tabIndex >= tabCount) _tabIndex = 0;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e;
      });
    }
  }

  Future<void> _toggleFollow() async {
    if (_followBusy) return;
    final next = !_isFollowing;
    setState(() {
      _followBusy = true;
      _isFollowing = next;
      _followers += next ? 1 : -1;
    });
    try {
      await Api.setFollowing(widget.userId, next);
      // Wave 1: follow notification to the followed user (best-effort;
      // a notification failure must never undo the follow).
      if (next) {
        try {
          await NotificationsApi.notifyFollow(widget.userId);
        } catch (_) {}
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isFollowing = !next;
        _followers += next ? -1 : 1;
      });
      showError(context, e);
    } finally {
      if (mounted) setState(() => _followBusy = false);
    }
  }

  Future<void> _openMessage() async {
    final profile = _profile;
    if (profile == null) return;
    // DM threads are peer-derived from the messages table (no thread row
    // to create) — opening the thread with this peer IS find-or-create.
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ThreadScreen(peer: profile)),
    );
  }

  Future<void> _shareProfile() async {
    final profile = _profile;
    if (profile == null) return;
    // Same link format as the web app (index.html:4643):
    // https://muqtada-pages.neocities.org/#u/<username>
    final link =
        'https://muqtada-pages.neocities.org/#u/${Uri.encodeComponent(profile.username)}';
    await Clipboard.setData(ClipboardData(text: link));
    if (mounted) showOk(context, AppStrings.t('profileLinkCopied'));
  }

  Future<void> _openEditDialog() async {
    final profile = _profile;
    if (profile == null) return;
    final nameCtrl = TextEditingController(text: profile.displayName);
    final bioCtrl = TextEditingController(text: profile.bio);
    var busy = false;

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          Future<void> pickAvatar(ImageSource source) async {
            if (busy) return;
            setDialogState(() => busy = true);
            try {
              final picked = await ImagePicker().pickImage(
                source: source,
                maxWidth: 512,
                imageQuality: 85,
              );
              if (picked == null) return;
              final url = await Api.uploadImage(
                await picked.readAsBytes(),
                Api.uniqueImagePath('avatar'),
              );
              if (url == null) throw Exception(AppStrings.t('photoUploadFailed'));
              await Api.updateMyProfile(
                displayName: nameCtrl.text.trim(),
                bio: bioCtrl.text.trim(),
                avatarUrl: url,
              );
              if (!mounted || !dialogCtx.mounted) return;
              Navigator.of(dialogCtx).pop();
              await _load();
              if (mounted) showOk(context, AppStrings.t('photoUpdated'));
            } catch (e) {
              if (ctx.mounted) showError(ctx, e);
            } finally {
              if (ctx.mounted) setDialogState(() => busy = false);
            }
          }

          Future<void> save() async {
            if (busy) return;
            setDialogState(() => busy = true);
            try {
              await Api.updateMyProfile(
                displayName: nameCtrl.text.trim(),
                bio: bioCtrl.text.trim(),
              );
              if (!mounted || !dialogCtx.mounted) return;
              Navigator.of(dialogCtx).pop();
              await _load();
              if (mounted) showOk(context, AppStrings.t('editsSaved'));
            } catch (e) {
              if (ctx.mounted) showError(ctx, e);
            } finally {
              if (ctx.mounted) setDialogState(() => busy = false);
            }
          }

          return AlertDialog(
            backgroundColor: HamsiqTheme.panel,
            title: Text(AppStrings.t('editProfile')),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TextField(
                    controller: nameCtrl,
                    decoration:
                        InputDecoration(hintText: AppStrings.t('displayName')),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: bioCtrl,
                    decoration: InputDecoration(hintText: AppStrings.t('bio')),
                    maxLines: 3,
                    minLines: 2,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    AppStrings.t('changePhoto'),
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: busy
                              ? null
                              : () => pickAvatar(ImageSource.camera),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: HamsiqTheme.panel2,
                            foregroundColor: Colors.white,
                          ),
                          icon: const Icon(Icons.camera_alt_outlined),
                          label: Text(AppStrings.t('camera')),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: busy
                              ? null
                              : () => pickAvatar(ImageSource.gallery),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: HamsiqTheme.panel2,
                            foregroundColor: Colors.white,
                          ),
                          icon: const Icon(Icons.photo_outlined),
                          label: Text(AppStrings.t('gallery')),
                        ),
                      ),
                    ],
                  ),
                  if (busy) ...[
                    const SizedBox(height: 12),
                    const Center(
                      child: CircularProgressIndicator(
                        color: HamsiqTheme.accent,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed:
                    busy ? null : () => Navigator.of(dialogCtx).pop(),
                style: TextButton.styleFrom(
                  foregroundColor: Colors.white,
                ),
                child: Text(AppStrings.t('cancel')),
              ),
              ElevatedButton(
                onPressed: busy ? null : save,
                child: Text(AppStrings.t('save')),
              ),
            ],
          );
        },
      ),
    );
    nameCtrl.dispose();
    bioCtrl.dispose();
  }

  Widget _statColumn(int count, String label) {
    return Expanded(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '$count',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: HamsiqTheme.text,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 13,
              color: HamsiqTheme.muted,
            ),
          ),
        ],
      ),
    );
  }

  /// Thin vertical divider between the three stat columns (mockup).
  Widget _statDivider() {
    return Container(width: 1, height: 38, color: HamsiqTheme.line);
  }

  /// 120pt avatar with a blue gradient ring + soft blue glow (mockup).
  Widget _glowingAvatar(HamsiqProfile profile) {
    return Container(
      width: 126,
      height: 126,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF4DA3FF),
            HamsiqTheme.accent,
            HamsiqTheme.accentDark,
            HamsiqTheme.accent,
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: HamsiqTheme.accent.withValues(alpha: 0.45),
            blurRadius: 26,
            spreadRadius: 2,
          ),
        ],
      ),
      child: AvatarWidget(profile: profile, size: 120, showRing: false),
    );
  }

  // Mockup round (2026-11-16): the header sits on a blue flowing-waves
  // background, with the mockup's top row ("..." / @username + verified
  // / gear), the 120pt glowing avatar on the right, stats on the left,
  // and the real highlights row underneath. All values are real
  // Supabase data — no demo stats, bio, link, posts or highlights.
  // NOTE on the profile website link: the mockup shows a link, but the
  // profile model has no website column, so no link is rendered at all
  // (and never the mockup's fake demo URL).
  Widget _header(HamsiqProfile profile) {
    return ProfileWavesBackground(
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          16,
          MediaQuery.of(context).padding.top + 4,
          16,
          18,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ProfileTopBar(
              username: profile.username,
              verified: profile.verified,
              isMe: widget.isMe,
              onMore: _openOptionsSheet,
              onSettings: _openSettings,
              onSwitchAccount: _openAccountSwitcher,
              onBack: () => Navigator.of(context).maybePop(),
            ),
            const SizedBox(height: 18),
            // Avatar on the right, statistics on the left. The stats
            // order is the mockup's (left to right in the forced-LTR
            // row): following, followers, posts.
            Directionality(
              textDirection: TextDirection.ltr,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: Row(
                      children: [
                        _statColumn(
                          _following,
                          AppStrings.t('followingStat'),
                        ),
                        _statDivider(),
                        _statColumn(
                          _followers,
                          AppStrings.t('followersStat'),
                        ),
                        _statDivider(),
                        _statColumn(_posts.length, AppStrings.t('postsCount')),
                      ],
                    ),
                  ),
                  const SizedBox(width: 14),
                  GestureDetector(
                    onTap: widget.isMe ? _openEditDialog : null,
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        _glowingAvatar(profile),
                        if (widget.isMe)
                          Positioned(
                            bottom: 0,
                            left: 0,
                            child: Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                color: HamsiqTheme.accent,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.black,
                                  width: 2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: HamsiqTheme.accent.withValues(alpha: 0.6),
                                    blurRadius: 12,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                              child: const Icon(
                                Icons.add,
                                color: Colors.white,
                                size: 20,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            // Display name is below the avatar, right-aligned under it.
            // Deliberate deviation from the pasted design: physical
            // Alignment.centerRight, NOT AlignmentDirectional.centerEnd —
            // in the app's RTL locale centerEnd resolves to the LEFT,
            // which would contradict the design (name under the avatar
            // on the right). The verified tick is kept next to the name
            // (the pasted design drops it; dropping a verification
            // badge would be a regression).
            Align(
              alignment: Alignment.centerRight,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Flexible(
                    child: Text(
                      profile.displayName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: HamsiqTheme.text,
                      ),
                    ),
                  ),
                  if (profile.verified) ...[
                    const SizedBox(width: 5),
                    const VerifiedTick(),
                  ],
                ],
              ),
            ),
            if (profile.bio.isNotEmpty) ...[
              const SizedBox(height: 7),
              Text(
                profile.bio,
                textAlign: TextAlign.start,
                style: const TextStyle(
                  fontSize: 15,
                  height: 1.45,
                  color: HamsiqTheme.text,
                ),
              ),
            ],
            const SizedBox(height: 16),
            if (widget.isMe)
              OwnProfileActions(
                onEdit: _openEditDialog,
                onShare: _shareProfile,
              )
            else
              Row(
                children: [
                  Expanded(
                    child: _isFollowing
                        ? ElevatedButton(
                            onPressed: _followBusy ? null : _toggleFollow,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: HamsiqTheme.panel2,
                              foregroundColor: Colors.white,
                            ),
                            child: Text(AppStrings.t('followingButton')),
                          )
                        : ElevatedButton(
                            onPressed: _followBusy ? null : _toggleFollow,
                            child: Text(AppStrings.t('followButton')),
                          ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _openMessage,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: HamsiqTheme.panel2,
                        foregroundColor: Colors.white,
                      ),
                      child: Text(AppStrings.t('messageButton')),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _shareProfile,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: HamsiqTheme.panel2,
                        foregroundColor: Colors.white,
                      ),
                      child: Text(AppStrings.t('shareTooltip')),
                    ),
                  ),
                ],
              ),
            // Highlights: the user's real collections only. With none,
            // the own profile shows just the "new" (+) circle; other
            // profiles show no row at all.
            if (widget.isMe || _highlights.isNotEmpty) ...[
              const SizedBox(height: 18),
              ProfileHighlightsRow(
                highlights: _highlights,
                isMe: widget.isMe,
                onOpen: _openHighlight,
                onNew: _showNewHighlightHint,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _postTile(PostItem post) {
    final content = post.mediaUrl != null && post.mediaUrl!.isNotEmpty
        ? SignedMediaImage(
            url: post.mediaUrl!,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: HamsiqTheme.panel2),
          )
        : Container(
            color: HamsiqTheme.panel2,
            padding: const EdgeInsets.all(8),
            alignment: Alignment.center,
            child: Text(
              post.caption,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 12,
                color: HamsiqTheme.text,
              ),
            ),
          );
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => PostDetailScreen(post: post)),
        );
      },
      child: Stack(
        fit: StackFit.expand,
        children: [
          content,
          if (post.isReel || post.mediaType == 'video')
            const Positioned(
              top: 6,
              right: 6,
              child: Icon(Icons.play_arrow, color: Colors.white, size: 20),
            ),
          if (post.isPinned)
            const Positioned(
              top: 6,
              left: 6,
              child: Icon(Icons.push_pin, color: Colors.white, size: 18),
            ),
        ],
      ),
    );
  }

  Widget _gridSliver(List<PostItem> posts, String emptyText) {
    if (posts.isEmpty) {
      return SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.only(top: 24),
          child: EmptyCenter(emptyText),
        ),
      );
    }
    return SliverGrid.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
        childAspectRatio: 1,
      ),
      itemCount: posts.length,
      itemBuilder: (_, i) => _postTile(posts[i]),
    );
  }

  @override
  Widget build(BuildContext context) {
    // H-06 Part 2: live language rebuild on language change.
    return ValueListenableBuilder<String>(
      valueListenable: AppStrings.lang,
      builder: (context, _, __) => _build(context),
    );
  }

  Widget _build(BuildContext context) {
    // Tab keys in order: posts, reels, reposts (if any), collab (if any).
    final tabKeys = <String>[
      'posts',
      'reels',
      if (_hasReposts) 'reposts',
      if (_hasCollabs) 'collab',
    ];
    final tab = tabKeys[_tabIndex.clamp(0, tabKeys.length - 1)];
    final tabIcons = <String, IconData>{
      'posts': Icons.grid_on,
      'reels': Icons.smart_display_outlined,
      'reposts': Icons.repeat,
      'collab': Icons.group_outlined,
    };
    final reels = _posts
        .where((p) => p.isReel || p.mediaType == 'video')
        .toList();
    return Scaffold(
      // Mockup round: no AppBar — the top row ("..." / @username /
      // gear) lives inside the waves header, so the waves flow behind
      // it. Other profiles get a back arrow in that row instead of
      // the gear.
      body: _loading
          ? const LoadingCenter()
          : _error != null
              ? EmptyCenter(AppStrings.t('profileLoadFailed'))
              : _profile == null
                  ? EmptyCenter(AppStrings.t('accountNotFound'))
                  : DefaultTabController(
                      length: tabKeys.length,
                      child: CustomScrollView(
                        slivers: [
                          SliverToBoxAdapter(child: _header(_profile!)),
                          SliverToBoxAdapter(
                            child: TabBar(
                              onTap: (i) => setState(() => _tabIndex = i),
                              indicatorColor: HamsiqTheme.accent,
                              indicatorWeight: 3,
                              labelColor: HamsiqTheme.text,
                              unselectedLabelColor: HamsiqTheme.muted,
                              tabs: [
                                for (final k in tabKeys)
                                  Tab(icon: Icon(tabIcons[k], size: 26)),
                              ],
                            ),
                          ),
                          // Wave 1: pinned posts sit directly above the
                          // grid (renders nothing when there are none).
                          if (tab == 'posts')
                            SliverToBoxAdapter(
                              child: PinnedPostsRow(
                                userId: widget.userId,
                                isMe: widget.isMe,
                                onChanged: _load,
                              ),
                            ),
                          if (tab == 'posts')
                            _gridSliver(_posts, AppStrings.t('noPostsYet'))
                          else if (tab == 'reels')
                            _gridSliver(reels, AppStrings.t('noReelsYet'))
                          else if (tab == 'reposts')
                            SliverToBoxAdapter(
                              child: RepostsTabGrid(userId: widget.userId),
                            )
                          else
                            _gridSliver(
                              _collabPosts,
                              AppStrings.t('noCollabPostsYet'),
                            ),
                        ],
                      ),
                    ),
    );
  }
}

/// v1.2.1: own-profile actions, Instagram-style — two compact dark
/// buttons side by side (edit + share) instead of one giant
/// full-width blue button. Height is fixed and small, like
/// Instagram's profile buttons.
///
/// Mockup round (2026-11-16): the mockup's buttons are a blue filled
/// "edit profile" (pencil) and an outlined "share profile", equal
/// widths, 12pt radius.
class OwnProfileActions extends StatelessWidget {
  final VoidCallback onEdit;
  final VoidCallback onShare;
  const OwnProfileActions({
    super.key,
    required this.onEdit,
    required this.onShare,
  });

  /// Compact button height (Instagram-style).
  static const double buttonHeight = 34;

  Widget _compactButton({
    required String label,
    required IconData icon,
    required VoidCallback onPressed,
    required bool filled,
  }) {
    final labelRow = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 17, color: Colors.white),
        const SizedBox(width: 6),
        Flexible(
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
            textScaler: TextScaler.noScaling,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
    );
    final styleBase = ButtonStyle(
      padding: WidgetStateProperty.all(EdgeInsets.zero),
      minimumSize: WidgetStateProperty.all(
        const Size(0, buttonHeight),
      ),
      textStyle: WidgetStateProperty.all(
        const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
      ),
      shape: WidgetStateProperty.all(shape),
      elevation: WidgetStateProperty.all(0),
    );
    return SizedBox(
      height: buttonHeight,
      child: filled
          ? ElevatedButton(
              onPressed: onPressed,
              // v1.2.2: the label style is set explicitly ON the Text
              // widget with textScaler noScaling. Diagnosis: the
              // styleFrom textStyle IS 14pt (widget test proves it),
              // but the phone web build inherits the iPhone's larger
              // system text size through MediaQuery.textScaler — at
              // 1.5x the 14pt label renders at 21pt and fills the
              // fixed 34pt button (the user's screenshot). noScaling
              // pins the label to a true 14pt on any phone, and the
              // ellipsis keeps the long Arabic label inside the button.
              style: styleBase.copyWith(
                backgroundColor:
                    WidgetStateProperty.all(HamsiqTheme.accent),
                foregroundColor:
                    WidgetStateProperty.all(Colors.white),
              ),
              child: labelRow,
            )
          : OutlinedButton(
              onPressed: onPressed,
              style: styleBase.copyWith(
                foregroundColor:
                    WidgetStateProperty.all(Colors.white),
                side: WidgetStateProperty.all(
                  const BorderSide(
                    color: HamsiqTheme.accent,
                    width: 1.5,
                  ),
                ),
              ),
              child: labelRow,
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _compactButton(
            label: AppStrings.t('editProfile'),
            icon: Icons.edit_outlined,
            onPressed: onEdit,
            filled: true,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _compactButton(
            label: AppStrings.t('shareProfile'),
            icon: Icons.ios_share_outlined,
            onPressed: onShare,
            filled: false,
          ),
        ),
      ],
    );
  }
}

/// v1.2.2: Instagram-style profile top bar title — the username with a
/// small down chevron beside it on the OWN profile; tapping it opens
/// the account switcher. Other profiles show the plain username with
/// no chevron and no tap. The row follows the ambient text direction,
/// so it mirrors correctly if the app ever runs RTL end-to-end.
class ProfileUsernameTitle extends StatelessWidget {
  final String username;
  final bool showChevron;
  final VoidCallback? onTap;

  const ProfileUsernameTitle({
    super.key,
    required this.username,
    this.showChevron = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final row = Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Flexible(
          child: Text(
            username,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: HamsiqTheme.text,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        if (showChevron) ...[
          const SizedBox(width: 2),
          const Icon(
            Icons.keyboard_arrow_down,
            size: 16,
            color: HamsiqTheme.text,
          ),
        ],
      ],
    );
    if (onTap == null) return row;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: row,
    );
  }
}

/// Mockup round (2026-11-16): the profile top row, drawn inside the
/// waves header (no AppBar). Physical layout, as in the mockup image:
/// gear on the RIGHT (own profile — opens Settings) or a back arrow
/// (other profiles — pops), "@username" + verified badge CENTRED, and
/// "..." on the LEFT (opens the options sheet). The centre row is
/// forced LTR so the swap icon, @username and tick sit exactly as in
/// the mockup; tapping it on the own profile opens the account
/// switcher (the mockup's ⇄ icon replaces the old chevron).
class ProfileTopBar extends StatelessWidget {
  final String username;
  final bool verified;
  final bool isMe;
  final VoidCallback onMore;
  final VoidCallback onSettings;
  final VoidCallback onSwitchAccount;
  final VoidCallback onBack;

  const ProfileTopBar({
    super.key,
    required this.username,
    required this.verified,
    required this.isMe,
    required this.onMore,
    required this.onSettings,
    required this.onSwitchAccount,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (isMe)
          IconButton(
            icon: const Icon(Icons.settings_outlined, size: 26),
            tooltip: AppStrings.t('titleSettings'),
            onPressed: onSettings,
          )
        else
          IconButton(
            icon: const Icon(Icons.arrow_back, size: 26),
            tooltip: AppStrings.t('back'),
            onPressed: onBack,
          ),
        Expanded(
          child: Center(
            child: InkWell(
              onTap: isMe ? onSwitchAccount : null,
              borderRadius: BorderRadius.circular(8),
              child: Directionality(
                textDirection: TextDirection.ltr,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (isMe) ...[
                      const Icon(
                        Icons.swap_horiz,
                        size: 20,
                        color: HamsiqTheme.text,
                      ),
                      const SizedBox(width: 6),
                    ],
                    Flexible(
                      child: Text(
                        '@$username',
                        style: const TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w800,
                          color: HamsiqTheme.text,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (verified) ...[
                      const SizedBox(width: 5),
                      const VerifiedTick(size: 18),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
        IconButton(
          icon: const Icon(Icons.more_horiz, size: 26),
          tooltip: AppStrings.t('profileOptions'),
          onPressed: onMore,
        ),
      ],
    );
  }
}

/// Mockup round: the blue flowing-waves header background. Pure
/// gradients + a CustomPainter of translucent blue bezier ribbons —
/// no image assets, no external images.
class ProfileWavesBackground extends StatelessWidget {
  final Widget child;
  const ProfileWavesBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF020A18),
                  HamsiqTheme.bg,
                  HamsiqTheme.bg,
                ],
                stops: [0.0, 0.55, 1.0],
              ),
            ),
            child: const CustomPaint(painter: ProfileWavesPainter()),
          ),
        ),
        child,
      ],
    );
  }
}

/// The flowing light waves: soft blue radial glows (top-right behind
/// the avatar, mid-left) plus four bezier ribbons in translucent
/// #0095F6, blurred for a neon glow.
class ProfileWavesPainter extends CustomPainter {
  const ProfileWavesPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    void glow(Offset center, double radius, double opacity) {
      final paint = Paint()
        ..shader = RadialGradient(
          colors: [
            HamsiqTheme.accent.withValues(alpha: opacity),
            HamsiqTheme.accent.withValues(alpha: 0),
          ],
        ).createShader(Rect.fromCircle(center: center, radius: radius));
      canvas.drawRect(Rect.fromLTWH(0, 0, w, h), paint);
    }

    glow(Offset(w * 0.88, h * 0.12), w * 0.65, 0.30);
    glow(Offset(w * 0.05, h * 0.55), w * 0.50, 0.16);

    // (vertical position, opacity, stroke width) per ribbon.
    const ribbons = [
      (0.10, 0.42, 3.0),
      (0.20, 0.30, 2.5),
      (0.30, 0.20, 2.0),
      (0.58, 0.16, 2.0),
    ];
    for (final (y, opacity, width) in ribbons) {
      final path = Path()
        ..moveTo(-20, h * y)
        ..cubicTo(
          w * 0.30,
          h * (y - 0.10),
          w * 0.55,
          h * (y + 0.12),
          w * 0.75,
          h * (y + 0.02),
        )
        ..cubicTo(
          w * 0.88,
          h * (y - 0.04),
          w * 0.95,
          h * (y + 0.06),
          w + 20,
          h * (y - 0.02),
        );
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = width
          ..color = HamsiqTheme.accent.withValues(alpha: opacity)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Mockup round: the highlights row — 64pt circles with a blue ring.
/// Real highlight collections only (cover or first-letter fallback,
/// title underneath); tapping one opens it in the story viewer. The
/// own profile always starts with the "new" (+) circle; when the user
/// has no highlights that is the ONLY circle. The row is forced LTR
/// so "+" sits on the left, as in the mockup.
class ProfileHighlightsRow extends StatelessWidget {
  final List<HighlightItem> highlights;
  final bool isMe;
  final ValueChanged<HighlightItem> onOpen;
  final VoidCallback onNew;

  const ProfileHighlightsRow({
    super.key,
    required this.highlights,
    required this.isMe,
    required this.onOpen,
    required this.onNew,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 96,
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: [
            if (isMe)
              _circle(
                label: AppStrings.t('newHighlight'),
                onTap: onNew,
                child: const Icon(
                  Icons.add,
                  size: 28,
                  color: Colors.white,
                ),
              ),
            for (final h in highlights)
              _circle(
                label: h.title,
                onTap: () => onOpen(h),
                child: _cover(h),
              ),
          ],
        ),
      ),
    );
  }

  Widget _circle({
    required String label,
    required VoidCallback onTap,
    required Widget child,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: HamsiqTheme.panel2,
                border: Border.all(
                  color: HamsiqTheme.accent,
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: HamsiqTheme.accent.withValues(alpha: 0.25),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: ClipOval(child: child),
            ),
            const SizedBox(height: 4),
            SizedBox(
              width: 72,
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _cover(HighlightItem h) {
    if (h.coverUrl == null) return _fallback(h);
    return SignedMediaImage(
      url: h.coverUrl!,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => _fallback(h),
    );
  }

  Widget _fallback(HighlightItem h) {
    return Container(
      color: HamsiqTheme.panel2,
      alignment: Alignment.center,
      child: Text(
        h.title.isNotEmpty ? h.title.characters.first : '★',
        style: const TextStyle(color: Colors.white, fontSize: 22),
      ),
    );
  }
}
