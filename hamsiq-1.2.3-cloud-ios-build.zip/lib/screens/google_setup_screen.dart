// Hamsiq native — Google sign-in setup + link screens.
//
// Shown after a Google OAuth session is established:
//   * GoogleSetupScreen — the user has NO complete profile yet (new
//     Google user, or a profile row without a username). They pick a
//     display name (prefilled from Google), a username (live-checked
//     through the check-username Edge Function, same rules as signup)
//     and a password + confirmation (same >=8 + letter + digit rule).
//     There is NO skip: the screen has no back button and AuthScreen /
//     main.dart only route home after this completes.
//   * GoogleLinkScreen — only when the Google email already owns a
//     different account (GoTrue `identity_already_exists`, manual
//     linking enabled server-side). The user signs in with that
//     account's password first; AuthScreen then launches linkIdentity.
//     No profile is ever created from this screen.
// All user-visible strings come from AppStrings (ar+en); no hardcoded
// literals here. Errors are generic — never an email, never a server
// detail.

import 'dart:async';

import 'package:flutter/material.dart';

import '../services/app_strings.dart';
import '../services/google_auth.dart';
import '../services/supabase_service.dart';
import '../theme.dart';

/// Debounce for the live username check (the check-username function is
/// rate-limited to 30 checks per IP per 15 minutes — see auth_screen).
const Duration _usernameCheckDebounce = Duration(milliseconds: 600);

enum _NameState { idle, checking, available, taken, error }

/// Shared scaffold chrome for both Google screens: logo + title + body.
Widget _googleScaffold({
  required String title,
  required String body,
  required List<Widget> children,
  Widget? bottomAction,
}) {
  return Scaffold(
    body: SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: Image.asset(
                  'assets/logo.png',
                  width: 96,
                  height: 96,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              body,
              style: const TextStyle(color: HamsiqTheme.muted),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ...children,
            if (bottomAction != null) ...[
              const SizedBox(height: 12),
              bottomAction,
            ],
          ],
        ),
      ),
    ),
  );
}

Widget _errorBox(String? error) {
  if (error == null) return const SizedBox.shrink();
  return Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: Colors.red.shade900.withValues(alpha: 0.4),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Text(
      error,
      style: const TextStyle(color: Colors.redAccent),
      textAlign: TextAlign.center,
    ),
  );
}

class GoogleSetupScreen extends StatefulWidget {
  final String initialDisplayName;
  final String? initialAvatarUrl;

  /// Called after the profile is created and the session recorded.
  /// AuthScreen / main.dart route home from here.
  final VoidCallback onCompleted;

  /// Test seams. When null, the real check-username path and
  /// [GoogleAuth.completeSetup] are used.
  final GoogleUsernameChecker? checkUsername;
  final GoogleCompleteSetup? completeSetup;

  const GoogleSetupScreen({
    super.key,
    required this.initialDisplayName,
    this.initialAvatarUrl,
    required this.onCompleted,
    this.checkUsername,
    this.completeSetup,
  });

  @override
  State<GoogleSetupScreen> createState() => _GoogleSetupScreenState();
}

class _GoogleSetupScreenState extends State<GoogleSetupScreen> {
  late final TextEditingController _displayName;
  final _username = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  Timer? _debounce;
  _NameState _nameState = _NameState.idle;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _displayName = TextEditingController(text: widget.initialDisplayName);
    _username.addListener(_onUsernameChanged);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _displayName.dispose();
    _username.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  void _onUsernameChanged() {
    _debounce?.cancel();
    final u = _username.text.trim().toLowerCase();
    if (u.length < 3) {
      setState(() => _nameState = _NameState.idle);
      return;
    }
    setState(() => _nameState = _NameState.checking);
    _debounce = Timer(_usernameCheckDebounce, () async {
      final check =
          widget.checkUsername ?? GoogleAuth.checkUsernameAvailability;
      try {
        final available = await check(u);
        if (!mounted) return;
        setState(() {
          _nameState = available == null
              ? _NameState.error
              : available
                  ? _NameState.available
                  : _NameState.taken;
        });
      } on GoogleSetupException {
        // Rate limit (or any setup error) during the live check: show
        // the neutral error state; submit re-checks authoritatively.
        if (mounted) setState(() => _nameState = _NameState.error);
      } catch (_) {
        if (mounted) setState(() => _nameState = _NameState.error);
      }
    });
  }

  Widget _usernameStatus() {
    switch (_nameState) {
      case _NameState.idle:
        return const SizedBox.shrink();
      case _NameState.checking:
        return Text(
          AppStrings.t('googleUsernameChecking'),
          style: const TextStyle(color: HamsiqTheme.muted),
        );
      case _NameState.available:
        return Text(
          AppStrings.t('googleUsernameAvailable'),
          style: const TextStyle(color: Colors.green),
        );
      case _NameState.taken:
        return Text(
          AppStrings.t('usernameTaken'),
          style: const TextStyle(color: Colors.redAccent),
        );
      case _NameState.error:
        return Text(
          AppStrings.t('genericError'),
          style: const TextStyle(color: Colors.redAccent),
        );
    }
  }

  Future<void> _doSubmit() async {
    final errorKey = validateGoogleSetup(
      username: _username.text,
      password: _password.text,
      confirmPassword: _confirm.text,
    );
    if (errorKey != null) {
      setState(() => _error = AppStrings.t(errorKey));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final complete = widget.completeSetup ?? GoogleAuth.completeSetup;
      await complete(
        username: _username.text,
        displayName: _displayName.text,
        password: _password.text,
        confirmPassword: _confirm.text,
        avatarUrl: widget.initialAvatarUrl,
      );
      widget.onCompleted();
    } on GoogleSetupException catch (e) {
      setState(() => _error = AppStrings.t(e.messageKey));
    } catch (e) {
      setState(() => _error = friendlyGoogleError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: AppStrings.lang,
      builder: (context, _, __) => _googleScaffold(
        title: AppStrings.t('googleSetupTitle'),
        body: AppStrings.t('googleSetupBody'),
        children: [
          if (widget.initialAvatarUrl != null &&
              widget.initialAvatarUrl!.isNotEmpty)
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(40),
                child: Image.network(
                  widget.initialAvatarUrl!,
                  width: 80,
                  height: 80,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) =>
                      const Icon(Icons.account_circle, size: 80),
                ),
              ),
            ),
          if (widget.initialAvatarUrl != null &&
              widget.initialAvatarUrl!.isNotEmpty)
            const SizedBox(height: 16),
          TextField(
            controller: _displayName,
            decoration: InputDecoration(
              hintText: AppStrings.t('displayName'),
              prefixIcon: const Icon(Icons.badge_outlined),
            ),
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _username,
            decoration: InputDecoration(
              hintText: AppStrings.t('username'),
              prefixIcon: const Icon(Icons.person_outline),
            ),
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 6),
          _usernameStatus(),
          const SizedBox(height: 12),
          TextField(
            controller: _password,
            decoration: InputDecoration(
              hintText: AppStrings.t('authPasswordHint'),
              prefixIcon: const Icon(Icons.lock_outline),
            ),
            obscureText: true,
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _confirm,
            decoration: InputDecoration(
              hintText: AppStrings.t('googleConfirmPassword'),
              prefixIcon: const Icon(Icons.lock_outline),
            ),
            obscureText: true,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _doSubmit(),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _busy ? null : _doSubmit,
            child: _busy
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Text(AppStrings.t('save'),
                    style: const TextStyle(fontSize: 17)),
          ),
          const SizedBox(height: 16),
          _errorBox(_error),
        ],
      ),
    );
  }
}

class GoogleLinkScreen extends StatefulWidget {
  /// Signs in with the existing account's password, then launches the
  /// Google link round-trip. Returns the AppStrings KEY of a failure,
  /// or null when the link was launched (the auth-state listener in
  /// AuthScreen routes home on the returning session).
  final Future<String?> Function(String email, String password)
      onLinkWithPassword;

  /// Back to the login/signup form.
  final VoidCallback onBack;

  const GoogleLinkScreen({
    super.key,
    required this.onLinkWithPassword,
    required this.onBack,
  });

  @override
  State<GoogleLinkScreen> createState() => _GoogleLinkScreenState();
}

class _GoogleLinkScreenState extends State<GoogleLinkScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _doLink() async {
    final email = cleanEmail(_email.text);
    if (email.isEmpty || _password.text.isEmpty) {
      setState(() => _error = AppStrings.t('fillAllFields'));
      return;
    }
    if (!isValidEmail(email)) {
      setState(() => _error = AppStrings.t('authEmailInvalid'));
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final errorKey =
          await widget.onLinkWithPassword(email, _password.text);
      if (!mounted) return;
      if (errorKey != null) {
        setState(() => _error = AppStrings.t(errorKey));
      }
    } catch (e) {
      if (mounted) setState(() => _error = friendlyGoogleError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: AppStrings.lang,
      builder: (context, _, __) => _googleScaffold(
        title: AppStrings.t('googleLinkTitle'),
        body: AppStrings.t('googleLinkBody'),
        children: [
          TextField(
            controller: _email,
            decoration: InputDecoration(
              hintText: AppStrings.t('email'),
              prefixIcon: const Icon(Icons.mail_outline),
            ),
            keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.next,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _password,
            decoration: InputDecoration(
              hintText: AppStrings.t('authPasswordLabel'),
              prefixIcon: const Icon(Icons.lock_outline),
            ),
            obscureText: true,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _doLink(),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _busy ? null : _doLink,
            child: _busy
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Text(AppStrings.t('googleLinkButton'),
                    style: const TextStyle(fontSize: 17)),
          ),
          const SizedBox(height: 16),
          _errorBox(_error),
        ],
        bottomAction: TextButton(
          onPressed: widget.onBack,
          child: Text(AppStrings.t('back'),
              style: const TextStyle(color: HamsiqTheme.accent)),
        ),
      ),
    );
  }
}
