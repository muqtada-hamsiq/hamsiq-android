// Hamsiq native — main shell: 5-item bottom nav (Home, Discover,
// + Create, Reels, Profile) matching the web app. The + button opens the
// create sheet. Chats open from the Home app bar (messenger icon), pushed
// as a full-screen route — so the bottom nav disappears inside a thread,
// like the web app's v39 behaviour.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models.dart';
import '../services/app_strings.dart';
import '../services/media_api.dart';
import '../services/platform_file.dart';
import '../services/push_service.dart';
import '../services/supabase_service.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'camera_screen.dart';
import 'feed_screen.dart';
import 'chats_screen.dart';
import 'profile_screen.dart';
import 'reels_screen.dart';

class HomeShell extends StatefulWidget {
  final HamsiqProfile me;
  const HomeShell({super.key, required this.me});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;
  final _feedTick = ValueNotifier<int>(0);
  late HamsiqProfile _me;

  @override
  void initState() {
    super.initState();
    _me = widget.me;
    // Push: home mounting means a signed-in account (login, account
    // switch, or Google-setup completion) — register this device's FCM
    // token for it and, at most once per device, ask for the
    // notification permission with a short rationale. Both are
    // best-effort and never block home.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      unawaited(PushService.instance.onSignedIn());
      unawaited(PushService.instance.maybeRequestPermission(context));
    });
  }

  void _openCreate() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: HamsiqTheme.panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => CreateSheet(
        onPosted: () => _feedTick.value++,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      FeedScreen(
        me: _me,
        refreshTick: _feedTick,
        onOpenChats: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const ChatsScreen()),
          );
        },
      ),
      DiscoverScreen(me: _me),
      const SizedBox.shrink(), // centre + is a button, not a page
      const ReelsScreen(),
      ProfileScreen(userId: _me.id, isMe: true),
    ];
    return Scaffold(
      body: IndexedStack(index: _tab, children: pages),
      bottomNavigationBar: ValueListenableBuilder<String>(
        valueListenable: AppStrings.lang,
        builder: (context, _, __) => BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) {
          if (i == 2) {
            _openCreate();
            return;
          }
          setState(() => _tab = i);
        },
        items: [
          BottomNavigationBarItem(
            icon: const Icon(Icons.home_outlined),
            activeIcon: const Icon(Icons.home),
            label: AppStrings.t('navHome'),
          ),
          BottomNavigationBarItem(
            icon: const Icon(Icons.search_outlined),
            activeIcon: const Icon(Icons.search),
            label: AppStrings.t('navDiscover'),
          ),
          BottomNavigationBarItem(
            icon: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: HamsiqTheme.accent,
                shape: BoxShape.circle,
                // Mockup-match: soft blue glow around the centre +.
                boxShadow: [
                  BoxShadow(
                    color: HamsiqTheme.accent.withValues(alpha: 0.45),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: const Icon(Icons.add, color: Colors.white, size: 28),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: const Icon(Icons.movie_outlined),
            activeIcon: const Icon(Icons.movie),
            label: AppStrings.t('navReels'),
          ),
          BottomNavigationBarItem(
            icon: AvatarWidget(profile: _me, size: 28),
            activeIcon: AvatarWidget(
              profile: _me,
              size: 28,
              showRing: true,
            ),
            label: AppStrings.t('navProfile'),
          ),
        ],
        ),
      ),
    );
  }
}

/// Create sheet: text post, optionally with a photo taken with the native
/// camera or picked from the gallery (image_picker — the key fix vs the
/// Capacitor wrapper, where the WebView never got camera permission).
class CreateSheet extends StatefulWidget {
  final VoidCallback onPosted;
  const CreateSheet({super.key, required this.onPosted});

  @override
  State<CreateSheet> createState() => _CreateSheetState();
}

class _CreateSheetState extends State<CreateSheet> {
  final _caption = TextEditingController();
  XFile? _photo;
  XFile? _video;
  bool _busy = false;

  Future<void> _pick(ImageSource source) async {
    try {
      final f = await ImagePicker().pickImage(
        source: source,
        maxWidth: 1080,
        imageQuality: 85,
      );
      if (f != null) setState(() => _photo = f);
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  /// Open the in-app camera (Phase 2). Photo -> the existing photo flow;
  /// video -> published as a reel.
  Future<void> _openCamera() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => CameraScreen(
          onCaptured: (file, isVideo) {
            Navigator.of(context).pop();
            setState(() {
              if (isVideo) {
                _video = file;
                _photo = null;
              } else {
                _photo = file;
                _video = null;
              }
            });
          },
          onUseGallery: () {
            Navigator.of(context).pop();
            _pick(ImageSource.gallery);
          },
        ),
      ),
    );
  }

  Future<void> _post() async {
    final caption = _caption.text.trim();
    if (caption.isEmpty && _photo == null && _video == null) return;
    setState(() => _busy = true);
    try {
      String? url;
      String mediaType = 'image';
      bool isReel = false;
      if (_photo != null) {
        url = await Api.uploadImage(
          await readPickedBytes(_photo!),
          Api.uniqueImagePath('post'),
        );
        if (url == null) throw Exception(AppStrings.t('photoUploadFailed'));
      } else if (_video != null) {
        url = await MediaApi.uploadVideo(
          await readPickedBytes(_video!),
          MediaApi.uniqueVideoPath('reel'),
        );
        if (url == null) throw Exception(AppStrings.t('videoUploadFailed'));
        mediaType = 'video';
        isReel = true;
      }
      await Api.createPost(
        caption: caption,
        mediaUrl: url,
        mediaType: mediaType,
        isReel: isReel,
      );
      if (!mounted) return;
      Navigator.of(context).pop();
      widget.onPosted();
      showOk(context, AppStrings.t('published'));
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            AppStrings.t('newPostTitle'),
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _caption,
            decoration: InputDecoration(hintText: AppStrings.t('writeSomething')),
            maxLines: 4,
            minLines: 2,
          ),
          if (_photo != null) ...[
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: pickedImage(
                _photo!,
                height: 180,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
          ],
          if (_video != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: HamsiqTheme.panel2,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(Icons.videocam, color: HamsiqTheme.accent),
                  SizedBox(width: 8),
                  Text(AppStrings.t('videoReadyReels')),
                ],
              ),
            ),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              ElevatedButton.icon(
                onPressed: _openCamera,
                style: ElevatedButton.styleFrom(
                  backgroundColor: HamsiqTheme.panel2,
                  foregroundColor: Colors.white,
                ),
                icon: const Icon(Icons.camera_alt_outlined),
                label: Text(AppStrings.t('camera')),
              ),
              const SizedBox(width: 8),
              ElevatedButton.icon(
                onPressed: () => _pick(ImageSource.gallery),
                style: ElevatedButton.styleFrom(
                  backgroundColor: HamsiqTheme.panel2,
                  foregroundColor: Colors.white,
                ),
                icon: const Icon(Icons.photo_outlined),
                label: Text(AppStrings.t('gallery')),
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: _busy ? null : _post,
                child: _busy
                    ? const SizedBox(
                        height: 18,
                        width: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Text(AppStrings.t('publishAction')),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Discover (Phase 1): search users by username + grid of latest post
/// photos. Tapping a user opens their profile.
class DiscoverScreen extends StatefulWidget {
  final HamsiqProfile me;
  const DiscoverScreen({super.key, required this.me});

  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  final _search = TextEditingController();
  List<HamsiqProfile> _results = [];
  List<PostItem> _gridPosts = [];
  bool _loadingGrid = true;

  @override
  void initState() {
    super.initState();
    _loadGrid();
  }

  Future<void> _loadGrid() async {
    try {
      final posts = await Api.fetchFeed(limit: 30);
      if (!mounted) return;
      setState(() {
        _gridPosts =
            posts.where((p) => p.mediaUrl != null && !p.isReel).toList();
        _loadingGrid = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loadingGrid = false);
    }
  }

  Future<void> _doSearch(String q) async {
    if (q.trim().isEmpty) {
      setState(() => _results = []);
      return;
    }
    try {
      final r = await Api.searchUsers(q.trim());
      if (mounted) setState(() => _results = r);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.t('titleDiscover'))),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: _search,
              decoration: InputDecoration(
                hintText: AppStrings.t('searchUser'),
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _search.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _search.clear();
                          setState(() => _results = []);
                        },
                      )
                    : null,
              ),
              onChanged: _doSearch,
            ),
          ),
          Expanded(
            child: _search.text.isNotEmpty
                ? ListView.builder(
                    itemCount: _results.length,
                    itemBuilder: (_, i) {
                      final u = _results[i];
                      return ListTile(
                        leading: AvatarWidget(profile: u, size: 44),
                        title: Row(
                          children: [
                            Text(u.displayName),
                            if (u.verified) ...[
                              const SizedBox(width: 4),
                              const VerifiedTick(),
                            ],
                          ],
                        ),
                        subtitle: Text('@${u.username}'),
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => ProfileScreen(userId: u.id),
                            ),
                          );
                        },
                      );
                    },
                  )
                : _loadingGrid
                    ? const LoadingCenter()
                    : _gridPosts.isEmpty
                        ? EmptyCenter(AppStrings.t('noPostsYet'))
                        : GridView.builder(
                            padding: const EdgeInsets.all(2),
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 3,
                              crossAxisSpacing: 2,
                              mainAxisSpacing: 2,
                              childAspectRatio: 0.72,
                            ),
                            itemCount: _gridPosts.length,
                            itemBuilder: (_, i) {
                              final p = _gridPosts[i];
                              return InkWell(
                                onTap: () {
                                  // Tapping a tile opens the author's profile.
                                  if (p.author != null) {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder: (_) => ProfileScreen(
                                          userId: p.author!.id,
                                        ),
                                      ),
                                    );
                                  }
                                },
                                child: SignedMediaImage(
                                  url: p.mediaUrl!,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    color: HamsiqTheme.panel2,
                                  ),
                                ),
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }
}
