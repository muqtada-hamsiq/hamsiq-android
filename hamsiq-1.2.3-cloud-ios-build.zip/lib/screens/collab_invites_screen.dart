// Hamsiq native — Collab invites (Wave 3, sql-v31).
// Two pieces: the incoming-invites list (accept / decline an invite
// to co-author a post) and the invite sheet the post owner opens from
// the post options (pick up to 5 collaborators from people they
// follow, or search by username).

import 'dart:async';

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/share_api.dart';
import '../services/wave3_api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class CollabInvitesScreen extends StatefulWidget {
  const CollabInvitesScreen({super.key});

  @override
  State<CollabInvitesScreen> createState() => _CollabInvitesScreenState();
}

class _CollabInvitesScreenState extends State<CollabInvitesScreen> {
  List<PendingCollabInvite>? _invites;
  String? _error;
  bool _busyId = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final invites = await Wave3Api.fetchMyPendingInvites();
      if (!mounted) return;
      setState(() {
        _invites = invites;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(
        () => _error = e.toString().replaceFirst('Exception: ', ''),
      );
    }
  }

  Future<void> _respond(PendingCollabInvite invite, bool accept) async {
    if (_busyId) return;
    setState(() => _busyId = true);
    try {
      await Wave3Api.respondToCollabInvite(invite.post.id, accept);
      if (!mounted) return;
      showOk(
        context,
        accept
            ? AppStrings.t('collabInviteAccepted')
            : AppStrings.t('collabInviteDeclined'),
      );
      await _load();
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busyId = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final invites = _invites;
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.t('collabInvites'))),
      body: invites == null
          ? (_error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _error!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: HamsiqTheme.muted),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: _load,
                          child: Text(AppStrings.t('retry')),
                        ),
                      ],
                    ),
                  ),
                )
              : const LoadingCenter())
          : RefreshIndicator(
              color: HamsiqTheme.accent,
              onRefresh: _load,
              child: invites.isEmpty
                  ? ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      children: [
                        SizedBox(
                          height:
                              MediaQuery.of(context).size.height * 0.7,
                          child: EmptyCenter(
                            AppStrings.t('noCollabInvites'),
                          ),
                        ),
                      ],
                    )
                  : ListView.builder(
                      itemCount: invites.length,
                      itemBuilder: (_, i) {
                        final invite = invites[i];
                        final post = invite.post;
                        return Container(
                          margin: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: HamsiqTheme.panel,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: HamsiqTheme.line),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  AvatarWidget(
                                    profile: invite.inviter,
                                    size: 42,
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          invite.inviter?.displayName ?? '',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        Text(
                                          AppStrings.t('collabInvitedYou'),
                                          style: const TextStyle(
                                            color: HamsiqTheme.muted,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              if (post.caption.isNotEmpty) ...[
                                const SizedBox(height: 10),
                                Text(
                                  post.caption,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 14),
                                ),
                              ],
                              if (post.mediaUrl != null) ...[
                                const SizedBox(height: 10),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: SignedMediaImage(
                                    url: post.mediaUrl!,
                                    width: double.infinity,
                                    height: 180,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) =>
                                        Container(
                                      height: 180,
                                      color: HamsiqTheme.panel2,
                                    ),
                                  ),
                                ),
                              ],
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: ElevatedButton(
                                      onPressed: _busyId
                                          ? null
                                          : () => _respond(invite, true),
                                      child: Text(
                                        AppStrings.t('collabAccept'),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: ElevatedButton(
                                      onPressed: _busyId
                                          ? null
                                          : () => _respond(invite, false),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: HamsiqTheme.panel2,
                                        foregroundColor: Colors.white,
                                      ),
                                      child: Text(
                                        AppStrings.t('collabDecline'),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
    );
  }
}

/// Invite sheet (post owner): pick collaborators from people I follow
/// or search by username. Shows who is already invited/accepted; the
/// 5-collaborator limit is enforced server-side (invite_collaborator).
Future<void> showCollabInviteSheet(
  BuildContext context,
  PostItem post,
) async {
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: HamsiqTheme.panel,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (_) => _CollabInviteSheet(post: post),
  );
}

class _CollabInviteSheet extends StatefulWidget {
  final PostItem post;
  const _CollabInviteSheet({required this.post});

  @override
  State<_CollabInviteSheet> createState() => _CollabInviteSheetState();
}

class _CollabInviteSheetState extends State<_CollabInviteSheet> {
  List<HamsiqProfile> _following = [];
  List<HamsiqProfile> _results = [];
  List<PostCollaborator> _existing = [];
  bool _loading = true;
  bool _searching = false;
  final _invited = <String>{};
  final _searchCtrl = TextEditingController();
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait([
        ShareApi.fetchFollowing(),
        Wave3Api.fetchPostCollaborators(widget.post.id),
      ]);
      if (!mounted) return;
      setState(() {
        _following = results[0] as List<HamsiqProfile>;
        _existing = results[1] as List<PostCollaborator>;
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _onSearchChanged(String q) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () async {
      final query = q.trim();
      if (query.isEmpty) {
        if (mounted) setState(() => _results = []);
        return;
      }
      setState(() => _searching = true);
      try {
        final r = await ShareApi.searchPeople(query);
        if (mounted) {
          setState(() {
            _results = r;
            _searching = false;
          });
        }
      } catch (_) {
        if (mounted) setState(() => _searching = false);
      }
    });
  }

  PostCollaborator? _existingFor(String userId) {
    for (final c in _existing) {
      if (c.userId == userId) return c;
    }
    return null;
  }

  Future<void> _invite(HamsiqProfile user) async {
    if (_invited.contains(user.id)) return;
    try {
      await Wave3Api.inviteCollaborator(widget.post.id, user.id);
      if (!mounted) return;
      setState(() => _invited.add(user.id));
      showOk(context, AppStrings.t('collabInviteSent'));
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    final shown = _searchCtrl.text.trim().isEmpty ? _following : _results;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Text(
                AppStrings.t('inviteCollaborator'),
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 4),
            Center(
              child: Text(
                '${AppStrings.t('collabMax')} — ${AppStrings.t('collabPending')} / ${AppStrings.t('collabAccepted')}',
                style: const TextStyle(
                  color: HamsiqTheme.muted,
                  fontSize: 12,
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: AppStrings.t('searchUser'),
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (q) {
                setState(() {});
                _onSearchChanged(q);
              },
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 320,
              child: _loading
                  ? const LoadingCenter()
                  : _searching
                      ? const LoadingCenter()
                      : shown.isEmpty
                          ? EmptyCenter(
                              AppStrings.t('noCollabResults'),
                            )
                          : ListView.builder(
                              itemCount: shown.length,
                              itemBuilder: (_, i) {
                                final user = shown[i];
                                final existing = _existingFor(user.id);
                                final sent = _invited.contains(user.id);
                                final already = existing != null;
                                return ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  leading: AvatarWidget(
                                    profile: user,
                                    size: 44,
                                  ),
                                  title: Text(user.displayName),
                                  subtitle: Text('@${user.username}'),
                                  trailing: already
                                      ? Chip(
                                          label: Text(
                                            existing.isAccepted
                                                ? AppStrings.t(
                                                    'collabAccepted',
                                                  )
                                                : AppStrings.t(
                                                    'collabPending',
                                                  ),
                                          ),
                                          backgroundColor:
                                              HamsiqTheme.panel2,
                                        )
                                      : sent
                                          ? const Icon(
                                              Icons.check,
                                              color: HamsiqTheme.accent,
                                            )
                                          : ElevatedButton(
                                              onPressed: () =>
                                                  _invite(user),
                                              child: Text(AppStrings.t('inviteAction')),
                                            ),
                                );
                              },
                            ),
            ),
          ],
        ),
      ),
    );
  }
}
