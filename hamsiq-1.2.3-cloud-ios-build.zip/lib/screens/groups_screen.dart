// Hamsiq native — groups list + group thread.
// Thread look copied from chats_screen.dart (ThreadScreen): same bubble
// style (blue gradient for mine, panel2 for others), same composer bar,
// same 4s polling. This file does NOT import chats_screen.dart.
// Poll messages (message_type == 'poll', body == poll id) render as
// PollCard; text messages render as bubbles.

import 'dart:async';
import 'package:flutter/material.dart';
import '../models.dart';
import '../services/app_strings.dart';
import '../services/groups_api.dart';
import '../services/polls_api.dart';
import '../services/push_service.dart';
import '../services/supabase_service.dart';
import '../services/wave3_api.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/poll_card.dart';
import 'channels_screen.dart';
import 'collab_invites_screen.dart';

class GroupsScreen extends StatefulWidget {
  const GroupsScreen({super.key});

  @override
  State<GroupsScreen> createState() => _GroupsScreenState();
}

class _GroupsScreenState extends State<GroupsScreen> {
  List<GroupInfo> _groups = [];
  bool _loading = true;
  // Wave 3: pending collab-invite badge on the hub tile (best-effort).
  int _pendingCollabCount = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final groups = await GroupsApi.fetchMyGroups();
      if (!mounted) return;
      setState(() {
        _groups = groups;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      showError(context, e);
    }
    // Wave 3: pending collab invites (best-effort; a failure just
    // hides the badge, never the groups list).
    try {
      final invites = await Wave3Api.fetchMyPendingInvites();
      if (mounted) setState(() => _pendingCollabCount = invites.length);
    } catch (_) {}
  }

  Future<void> _openCreate() async {
    final created = await Navigator.of(context).push<int>(
      MaterialPageRoute(builder: (_) => const CreateGroupScreen()),
    );
    if (created != null && mounted) {
      await _load();
      final group =
          _groups.where((g) => g.id == created).toList().firstOrNull;
      if (group != null) _openThread(group);
    }
  }

  Future<void> _openThread(GroupInfo group) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => GroupThreadScreen(group: group)),
    );
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.t('groupsTitle')),
        actions: [
          IconButton(
            onPressed: _openCreate,
            icon: const Icon(Icons.group_add, color: HamsiqTheme.accent),
            tooltip: AppStrings.t('createGroup'),
          ),
        ],
      ),
      // Wave 3 (additive hub): broadcast channels + collab invites
      // live here, above the groups list — the groups list itself is
      // untouched.
      body: Column(
        children: [
          ListTile(
            leading: const CircleAvatar(
              backgroundColor: HamsiqTheme.panel2,
              child: Icon(Icons.campaign_outlined, color: HamsiqTheme.accent),
            ),
            title: Text(
              AppStrings.t('titleChannels'),
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            subtitle: Text(
              AppStrings.t('channelsRowHint'),
              style: TextStyle(color: HamsiqTheme.muted, fontSize: 12),
            ),
            trailing: const Icon(Icons.chevron_left),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const ChannelsScreen(),
                ),
              );
            },
          ),
          ListTile(
            leading: const CircleAvatar(
              backgroundColor: HamsiqTheme.panel2,
              child: Icon(Icons.group_add_outlined, color: HamsiqTheme.accent),
            ),
            title: Text(
              AppStrings.t('collabInvites'),
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            subtitle: Text(
              AppStrings.t('collabInvitesHint'),
              style: TextStyle(color: HamsiqTheme.muted, fontSize: 12),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_pendingCollabCount > 0)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 7,
                      vertical: 2,
                    ),
                    decoration: const BoxDecoration(
                      color: HamsiqTheme.accent,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      '$_pendingCollabCount',
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                const SizedBox(width: 4),
                const Icon(Icons.chevron_left),
              ],
            ),
            onTap: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const CollabInvitesScreen(),
                ),
              );
              if (mounted) _load();
            },
          ),
          const Divider(color: HamsiqTheme.line, height: 1),
          Expanded(
            child: _loading
                ? const LoadingCenter()
                : _groups.isEmpty
                    ? EmptyCenter(AppStrings.t('noGroupsYet'))
                    : RefreshIndicator(
                  color: HamsiqTheme.accent,
                  onRefresh: _load,
                  child: ListView.builder(
                    itemCount: _groups.length,
                    itemBuilder: (_, i) {
                      final group = _groups[i];
                      final last = group.lastMessage;
                      return ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 6,
                        ),
                        leading: Container(
                          width: 52,
                          height: 52,
                          alignment: Alignment.center,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: HamsiqTheme.panel2,
                          ),
                          child: Text(
                            group.name.isNotEmpty
                                ? group.name[0].toUpperCase()
                                : '؟',
                            style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        title: Text(
                          group.name,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                          ),
                        ),
                        subtitle: Text(
                          last == null
                              ? '${group.memberCount} ${group.memberCount == 1 ? AppStrings.t('memberSingular') : AppStrings.t('memberPlural')}'
                              : last.messageType == 'poll'
                                  ? AppStrings.t('pollLabel')
                                  : last.body,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: HamsiqTheme.muted),
                        ),
                        trailing: last == null
                            ? null
                            : Text(
                                timeAgo(last.createdAt),
                                style: const TextStyle(
                                  color: HamsiqTheme.muted,
                                  fontSize: 12,
                                ),
                              ),
                        onTap: () => _openThread(group),
                      );
                    },
                  ),
                ),
            ),
          ],
        ),
      floatingActionButton: FloatingActionButton(
        onPressed: _openCreate,
        backgroundColor: HamsiqTheme.accent,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}

/// Create-group flow: name + pick members from people I follow
/// (GroupsApi.fetchFollowing), with a search box backed by
/// Api.searchUsers to add anyone else. Returns the new group id via
/// Navigator.pop, or null if cancelled.
class CreateGroupScreen extends StatefulWidget {
  const CreateGroupScreen({super.key});

  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final _name = TextEditingController();
  final _search = TextEditingController();
  List<HamsiqProfile> _candidates = [];
  final _selected = <String>{};
  bool _loading = true;
  bool _creating = false;
  bool _searching = false;

  @override
  void initState() {
    super.initState();
    _loadFollowing();
  }

  Future<void> _loadFollowing() async {
    try {
      final following = await GroupsApi.fetchFollowing();
      if (!mounted) return;
      setState(() {
        _candidates = following;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      showError(context, e);
    }
  }

  Future<void> _runSearch(String q) async {
    final query = q.trim();
    if (query.isEmpty) {
      _loadFollowing();
      return;
    }
    setState(() => _searching = true);
    try {
      final found = await Api.searchUsers(query);
      if (!mounted) return;
      final merged = <String, HamsiqProfile>{
        for (final p in _candidates) p.id: p,
        for (final p in found) p.id: p,
      };
      setState(() {
        _candidates = merged.values.toList();
        _searching = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _searching = false);
      showError(context, e);
    }
  }

  Future<void> _create() async {
    if (_creating) return;
    setState(() => _creating = true);
    try {
      final gid = await GroupsApi.createGroup(
        _name.text,
        _selected.toList(),
      );
      if (!mounted) return;
      Navigator.of(context).pop(gid);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.t('createGroup'))),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  controller: _name,
                  decoration: InputDecoration(
                    hintText: AppStrings.t('groupNameHint'),
                  ),
                  maxLength: 60,
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _search,
                  decoration: InputDecoration(
                    hintText: AppStrings.t('searchPeopleToAdd'),
                    prefixIcon: Icon(Icons.search),
                  ),
                  onChanged: (q) {
                    // Debounce-free: searchUsers is a cheap ilike query.
                    if (q.trim().length >= 2) _runSearch(q);
                  },
                ),
              ],
            ),
          ),
          if (_selected.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Align(
                alignment: Alignment.centerRight,
                child: Text(
                  '${AppStrings.t('selectedPrefix')} ${_selected.length} ${_selected.length == 1 ? AppStrings.t('memberSingular') : AppStrings.t('memberPlural')}',
                  style: const TextStyle(color: HamsiqTheme.accent),
                ),
              ),
            ),
          Expanded(
            child: _loading
                ? const LoadingCenter()
                : _candidates.isEmpty
                    ? EmptyCenter(AppStrings.t('noPeopleToAdd'))
                    : ListView.builder(
                        itemCount: _candidates.length,
                        itemBuilder: (_, i) {
                          final p = _candidates[i];
                          final picked = _selected.contains(p.id);
                          return CheckboxListTile(
                            value: picked,
                            activeColor: HamsiqTheme.accent,
                            onChanged: (v) {
                              setState(() {
                                if (v == true) {
                                  _selected.add(p.id);
                                } else {
                                  _selected.remove(p.id);
                                }
                              });
                            },
                            secondary: AvatarWidget(profile: p, size: 44),
                            title: Text(p.displayName),
                            subtitle: Text('@${p.username}'),
                          );
                        },
                      ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: (_creating || _selected.isEmpty) ? null : _create,
                child: _creating
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : _searching
                        ? Text(AppStrings.t('searching'))
                        : Text(AppStrings.t('createGroup')),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class GroupThreadScreen extends StatefulWidget {
  final GroupInfo group;
  const GroupThreadScreen({super.key, required this.group});

  @override
  State<GroupThreadScreen> createState() => _GroupThreadScreenState();
}

class _GroupThreadScreenState extends State<GroupThreadScreen> {
  List<GroupMessage> _messages = [];
  Map<String, HamsiqProfile> _senders = {};
  bool _loading = true;
  bool _sending = false;
  bool _fetching = false;
  Timer? _poll;
  final _scroll = ScrollController();
  final _input = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Push: suppress the banner for this group while it is on screen.
    PushService.instance.setActiveThread(PushRoute.group(widget.group.id));
    _load(jumpToBottom: true);
    _poll = Timer.periodic(const Duration(seconds: 4), (_) => _pollLoad());
  }

  Future<void> _load({bool jumpToBottom = false}) async {
    if (_fetching) return;
    _fetching = true;
    try {
      final msgs = await GroupsApi.fetchGroupMessages(widget.group.id);
      final senderIds = msgs.map((m) => m.senderId).toSet().toList();
      final senders = await Api.fetchProfiles(senderIds);
      if (!mounted) return;
      final atBottom = !_scroll.hasClients ||
          _scroll.position.pixels >=
              _scroll.position.maxScrollExtent - 80;
      setState(() {
        _messages = msgs;
        _senders = senders;
        _loading = false;
      });
      if (jumpToBottom || atBottom) _scrollToBottom();
    } catch (e) {
      if (!mounted) return;
      final wasInitial = _loading;
      setState(() => _loading = false);
      if (wasInitial) showError(context, e);
    } finally {
      _fetching = false;
    }
  }

  void _pollLoad() {
    if (!mounted || _loading) return;
    _load();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_scroll.hasClients) return;
      _scroll.jumpTo(_scroll.position.maxScrollExtent);
    });
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      await GroupsApi.sendGroupMessage(widget.group.id, text);
      if (!mounted) return;
      _input.clear();
      await _load(jumpToBottom: true);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _createPoll() async {
    final pollId = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (_) => CreatePollSheet(
        onCreatePoll: (q, opts) => PollsApi.createPoll(
          groupId: widget.group.id,
          question: q,
          options: opts,
        ),
      ),
    );
    if (pollId == null || !mounted) return;
    try {
      await PollsApi.postPollMessage(
        groupId: widget.group.id,
        pollId: pollId,
      );
      await _load(jumpToBottom: true);
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _showMembers() async {
    try {
      final members =
          await GroupsApi.fetchGroupMembers(widget.group.id);
      if (!mounted) return;
      await showModalBottomSheet<void>(
        context: context,
        builder: (_) => ListView(
          shrinkWrap: true,
          children: [
            Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                AppStrings.t('membersTitle'),
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
            ),
            ...members.map((m) {
              final p = m.profile;
              return ListTile(
                leading: AvatarWidget(profile: p, size: 44),
                title: Text(p?.displayName ?? m.userId),
                subtitle: Text(m.role == 'admin' ? AppStrings.t('roleAdmin') : AppStrings.t('roleMember')),
                trailing: m.userId == Api.myId
                    ? Text(AppStrings.t('youLabel'), style: TextStyle(color: HamsiqTheme.muted))
                    : null,
              );
            }),
          ],
        ),
      );
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  @override
  void dispose() {
    _poll?.cancel();
    _scroll.dispose();
    _input.dispose();
    PushService.instance
        .clearActiveThread(PushRoute.group(widget.group.id));
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final group = widget.group;
    return Scaffold(
      appBar: AppBar(
        title: GestureDetector(
          onTap: _showMembers,
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                alignment: Alignment.center,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: HamsiqTheme.panel2,
                ),
                child: Text(
                  group.name.isNotEmpty ? group.name[0].toUpperCase() : '؟',
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Flexible(
                child: Text(
                  group.name,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _loading
                ? const LoadingCenter()
                : _messages.isEmpty
                    ? EmptyCenter(AppStrings.t('noMessagesYet'))
                    : ListView.builder(
                        controller: _scroll,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 10,
                        ),
                        itemCount: _messages.length,
                        itemBuilder: (_, i) {
                          final m = _messages[i];
                          final mine = m.senderId == Api.myId;
                          final sender = _senders[m.senderId];
                          final isPoll = m.messageType == 'poll';
                          return Align(
                            alignment: mine
                                ? Alignment.centerRight
                                : Alignment.centerLeft,
                            child: Container(
                              margin: const EdgeInsets.symmetric(vertical: 4),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 10,
                              ),
                              constraints: BoxConstraints(
                                maxWidth:
                                    MediaQuery.of(context).size.width * 0.8,
                              ),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16),
                                gradient: mine && !isPoll
                                    ? const LinearGradient(
                                        colors: [
                                          HamsiqTheme.accent,
                                          HamsiqTheme.accentDark,
                                        ],
                                        begin: Alignment.topRight,
                                        end: Alignment.bottomLeft,
                                      )
                                    : null,
                                color: mine
                                    ? (isPoll ? HamsiqTheme.panel2 : null)
                                    : HamsiqTheme.panel2,
                              ),
                              child: isPoll
                                  ? PollCard(pollId: m.body)
                                  : Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        if (!mine)
                                          Padding(
                                            padding: const EdgeInsets.only(
                                              bottom: 4,
                                            ),
                                            child: Text(
                                              sender?.displayName ??
                                                  m.senderId,
                                              style: const TextStyle(
                                                color: HamsiqTheme.accent,
                                                fontSize: 12,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                          ),
                                        Text(
                                          m.body,
                                          style: const TextStyle(
                                            color: HamsiqTheme.text,
                                            fontSize: 15,
                                          ),
                                        ),
                                      ],
                                    ),
                            ),
                          );
                        },
                      ),
          ),
          Container(
            padding: EdgeInsets.only(
              left: 10,
              right: 10,
              top: 8,
              bottom: MediaQuery.of(context).viewInsets.bottom + 10,
            ),
            decoration: const BoxDecoration(
              color: HamsiqTheme.panel,
              border: Border(
                top: BorderSide(color: HamsiqTheme.line),
              ),
            ),
            child: Row(
              children: [
                IconButton(
                  onPressed: _createPoll,
                  icon: const Icon(
                    Icons.bar_chart,
                    color: HamsiqTheme.accent,
                  ),
                  tooltip: AppStrings.t('pollAction'),
                ),
                Expanded(
                  child: TextField(
                    controller: _input,
                    decoration: InputDecoration(
                      hintText: AppStrings.t('writeMessageHint'),
                    ),
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _send(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: _sending ? null : _send,
                  icon: _sending
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: HamsiqTheme.accent,
                          ),
                        )
                      : const Icon(
                          Icons.send,
                          color: HamsiqTheme.accent,
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
