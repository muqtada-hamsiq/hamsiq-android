// Hamsiq native — Muted / snoozed accounts (Wave 2).
// Lists the accounts I muted or snoozed (public.muted_accounts,
// sql-v30) so a mute can be lifted. Muting itself happens from a
// post's options menu (PostDetailScreen); this screen only manages.

import 'package:flutter/material.dart';
import '../services/app_strings.dart';

import '../services/wave2_api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class MutedAccountsScreen extends StatefulWidget {
  const MutedAccountsScreen({super.key});

  @override
  State<MutedAccountsScreen> createState() => _MutedAccountsScreenState();
}

class _MutedAccountsScreenState extends State<MutedAccountsScreen> {
  List<MutedAccount> _accounts = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final accounts = await Wave2Api.fetchMutedAccounts();
      if (!mounted) return;
      setState(() {
        _accounts = accounts;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  Future<void> _unmute(MutedAccount account) async {
    try {
      await Wave2Api.unmuteAccount(account.mutedId);
      if (mounted) {
        _load();
        showOk(context, AppStrings.t('unmuted'));
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.t('titleMutedAccounts'))),
      body: _loading
          ? const LoadingCenter()
          : _error != null
              ? EmptyCenter(_error!)
              : _accounts.isEmpty
                  ? EmptyCenter(
                      AppStrings.t('noMuted'),
                    )
                  : ListView.builder(
                      itemCount: _accounts.length,
                      itemBuilder: (_, i) {
                        final account = _accounts[i];
                        final profile = account.profile;
                        final subtitle = account.isSnooze
                            ? account.isActive
                                ? '${AppStrings.t('snoozedUntil')} ${account.snoozeUntil!.toLocal()}'
                                : AppStrings.t('snoozeEnded')
                            : AppStrings.t('mutedForever');
                        return ListTile(
                          leading: AvatarWidget(profile: profile, size: 44),
                          title: Text(profile?.displayName ?? ''),
                          subtitle: Text(
                            subtitle,
                            style: const TextStyle(color: HamsiqTheme.muted),
                          ),
                          trailing: TextButton(
                            onPressed: () => _unmute(account),
                            child: Text(AppStrings.t('unmuteAction')),
                          ),
                        );
                      },
                    ),
    );
  }
}
