// Hamsiq native — Blend (Wave 3, sql-v31).
// A shared Reels feed between two friends inside a DM: both must opt
// in (one invites, the other accepts), then each sees the reels the
// other liked or shared, in one mixed feed. The feed mixes reels both
// friends liked (post_likes) + reels shared in their DM (messages
// 'shared_post') — see Wave3Api.fetchBlendReels.
//
// Honest limits: the feed refreshes when the screen opens (no daily
// server refresh), and Blend only covers reels (is_reel posts).

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/media_api.dart';
import '../services/supabase_service.dart';
import '../services/wave3_api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class BlendScreen extends StatefulWidget {
  final HamsiqProfile peer;
  const BlendScreen({super.key, required this.peer});

  @override
  State<BlendScreen> createState() => _BlendScreenState();
}

class _BlendScreenState extends State<BlendScreen> {
  BlendState? _blend;
  List<BlendReel>? _reels;
  String? _error;
  bool _loading = true;
  bool _busy = false;

  // Feed player (one controller at a time, like ReelsScreen).
  int _current = 0;
  VideoPlayerController? _controller;
  bool _initialized = false;
  bool _failed = false;
  bool _isPlaying = false;
  // Generation guard for the async re-sign in _initController
  // (same pattern as ReelsScreen): a newer init invalidates an
  // older one still awaiting its fresh URL.
  int _initGen = 0;
  final _pageController = PageController();

  String get _myId => Api.myId;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final blend = await Wave3Api.fetchBlendWith(widget.peer.id);
      List<BlendReel>? reels;
      if (blend != null && blend.isActive) {
        reels = await Wave3Api.fetchBlendReels(widget.peer.id);
      }
      if (!mounted) return;
      setState(() {
        _blend = blend;
        _reels = reels;
        _loading = false;
        _error = null;
      });
      if (reels != null && reels.isNotEmpty) _initController(0);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  // ---------------- Blend invite flow ----------------

  Future<void> _request() async {
    setState(() => _busy = true);
    try {
      final blend = await Wave3Api.requestBlend(widget.peer.id);
      if (mounted) {
        setState(() => _blend = blend);
        showOk(context, AppStrings.t('blendInviteSent'));
      }
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _respond(bool accept) async {
    final blend = _blend;
    if (blend == null) return;
    setState(() => _busy = true);
    try {
      await Wave3Api.respondBlend(blend.id, accept);
      if (mounted) await _load();
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _end() async {
    final blend = _blend;
    if (blend == null) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('blendEnd')),
        content: Text(
          '${AppStrings.t('blendEndConfirm')} ${widget.peer.displayName}.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(AppStrings.t('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(
              AppStrings.t('blendEnd'),
              style: const TextStyle(color: Colors.redAccent),
            ),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Wave3Api.endBlend(blend.id);
      if (mounted) {
        _disposeController();
        await _load();
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  // ---------------- feed player ----------------

  void _onVideoState() {
    final c = _controller;
    if (c == null || !mounted) return;
    if (c.value.isPlaying != _isPlaying) {
      setState(() => _isPlaying = c.value.isPlaying);
    }
  }

  Future<void> _initController(int index) async {
    final gen = ++_initGen;
    final reels = _reels;
    if (reels == null || index < 0 || index >= reels.length) return;
    final url = reels[index].post.mediaUrl;
    if (url == null || url.isEmpty) {
      setState(() => _failed = true);
      return;
    }
    _disposeController();
    // H-04 re-sign-on-render: re-sign BEFORE creating the video
    // controller, via the server-side resign-media function.
    final fresh = await MediaApi.ensureFreshUrl(url);
    if (!mounted || gen != _initGen || _current != index) return;
    final c = VideoPlayerController.networkUrl(Uri.parse(fresh));
    _controller = c;
    _initialized = false;
    _failed = false;
    _isPlaying = false;
    c.addListener(_onVideoState);
    c.setLooping(true);
    c.initialize().then((_) {
      if (!mounted || !identical(_controller, c) || _current != index) {
        return;
      }
      setState(() => _initialized = true);
      c.play();
    }).catchError((_) {
      if (!mounted || !identical(_controller, c) || _current != index) {
        return;
      }
      setState(() => _failed = true);
    });
  }

  void _disposeController() {
    final c = _controller;
    _controller = null;
    if (c == null) return;
    c.removeListener(_onVideoState);
    c.pause();
    c.dispose();
  }

  void _onPageChanged(int index) {
    if (index == _current) return;
    setState(() => _current = index);
    _initController(index);
  }

  void _togglePlayPause(int index) {
    if (index != _current) return;
    final c = _controller;
    if (c == null || !_initialized || _failed) return;
    if (c.value.isPlaying) {
      c.pause();
    } else {
      c.play();
    }
  }

  Future<void> _toggleLike(BlendReel reel) async {
    final post = reel.post;
    final wasLiked = post.likedByMe;
    final wasCount = post.likeCount;
    setState(() {
      post.likedByMe = !wasLiked;
      post.likeCount = wasLiked ? wasCount - 1 : wasCount + 1;
    });
    try {
      await Api.setLiked(post.id, !wasLiked);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        post.likedByMe = wasLiked;
        post.likeCount = wasCount;
      });
      showError(context, e);
    }
  }

  @override
  void dispose() {
    _disposeController();
    _pageController.dispose();
    super.dispose();
  }

  // ---------------- build ----------------

  String _sourceLabel(String source) {
    switch (source) {
      case 'peer':
        return AppStrings.t('blendLikedByPeer');
      case 'me':
        return AppStrings.t('blendLikedByMe');
      case 'both':
        return AppStrings.t('blendLikedByBoth');
      case 'shared':
        return AppStrings.t('blendShared');
      default:
        return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final blend = _blend;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '${AppStrings.t('blend')} · ${widget.peer.displayName}',
        ),
        actions: [
          if (blend != null && (blend.isActive || blend.isPending))
            IconButton(
              icon: const Icon(Icons.close),
              tooltip: AppStrings.t('blendEnd'),
              onPressed: _end,
            ),
        ],
      ),
      body: _loading
          ? const LoadingCenter()
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _error!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: HamsiqTheme.muted),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: _load,
                          child: Text(AppStrings.t('retry')),
                        ),
                      ],
                    ),
                  ),
                )
              : _buildState(),
    );
  }

  Widget _buildState() {
    final blend = _blend;
    if (blend == null) {
      return _buildInviteCard(
        title: AppStrings.t('blendTitle'),
        body: AppStrings.t('blendIntro'),
        buttonLabel: AppStrings.t('blendInvite'),
        onPressed: _request,
      );
    }
    if (blend.isPending && blend.waitingOnPeer(_myId)) {
      return _buildInviteCard(
        title: AppStrings.t('blendTitle'),
        body: AppStrings.t('blendWaiting'),
        buttonLabel: null,
        onPressed: null,
      );
    }
    if (blend.isPending && blend.waitingOnMe(_myId)) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.people_alt_outlined,
                size: 64,
                color: HamsiqTheme.accent,
              ),
              const SizedBox(height: 16),
              Text(
                AppStrings.t('blendWaitingOnMe'),
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: _busy ? null : () => _respond(true),
                    child: Text(AppStrings.t('blendAccept')),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton(
                    onPressed: _busy ? null : () => _respond(false),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: HamsiqTheme.panel2,
                      foregroundColor: Colors.white,
                    ),
                    child: Text(AppStrings.t('blendDecline')),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }
    if (blend.isActive) return _buildFeed();
    // declined / ended — offer to start again.
    return _buildInviteCard(
      title: AppStrings.t('blendTitle'),
      body: AppStrings.t('blendIntro'),
      buttonLabel: AppStrings.t('blendInvite'),
      onPressed: _request,
    );
  }

  Widget _buildInviteCard({
    required String title,
    required String body,
    required String? buttonLabel,
    required VoidCallback? onPressed,
  }) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.people_alt_outlined,
              size: 64,
              color: HamsiqTheme.accent,
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              body,
              style: const TextStyle(color: HamsiqTheme.muted),
              textAlign: TextAlign.center,
            ),
            if (buttonLabel != null) ...[
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _busy ? null : onPressed,
                child: _busy
                    ? const SizedBox(
                        height: 18,
                        width: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Text(buttonLabel),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildFeed() {
    final reels = _reels ?? [];
    if (reels.isEmpty) {
      return EmptyCenter(AppStrings.t('blendEmpty'));
    }
    return Stack(
      children: [
        PageView.builder(
          controller: _pageController,
          scrollDirection: Axis.vertical,
          itemCount: reels.length,
          onPageChanged: _onPageChanged,
          itemBuilder: (context, index) => _buildPage(reels[index], index),
        ),
        Positioned(
          top: MediaQuery.of(context).padding.top + 8,
          left: 12,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.black45,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.people_alt_outlined,
                  size: 16,
                  color: HamsiqTheme.accent,
                ),
                const SizedBox(width: 6),
                Text(
                  _sourceLabel(reels[_current].source),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPage(BlendReel reel, int index) {
    final post = reel.post;
    final isCurrent = index == _current;
    final c = isCurrent ? _controller : null;

    Widget videoArea;
    if (!isCurrent) {
      videoArea = Container(color: HamsiqTheme.bgDeep);
    } else if (_failed) {
      videoArea = Container(
        color: HamsiqTheme.bgDeep,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.play_circle_outline,
                size: 64,
                color: HamsiqTheme.muted,
              ),
              SizedBox(height: 12),
              Text(
                AppStrings.t('videoPlayFailed'),
                style: TextStyle(color: HamsiqTheme.muted, fontSize: 15),
              ),
            ],
          ),
        ),
      );
    } else if (!_initialized || c == null) {
      videoArea = Container(
        color: HamsiqTheme.bgDeep,
        child: const LoadingCenter(),
      );
    } else {
      final size = c.value.size;
      videoArea = SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: size.width,
            height: size.height,
            child: VideoPlayer(c),
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: () => _togglePlayPause(index),
      child: Stack(
        fit: StackFit.expand,
        children: [
          videoArea,
          if (isCurrent && _initialized && !_failed && !_isPlaying)
            const Center(
              child: CircleAvatar(
                radius: 36,
                backgroundColor: Colors.black45,
                child: Icon(
                  Icons.play_arrow,
                  size: 48,
                  color: Colors.white,
                ),
              ),
            ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(
                16,
                32,
                16,
                MediaQuery.of(context).padding.bottom + 16,
              ),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.black87],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      AvatarWidget(profile: post.author, size: 36),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          post.author?.displayName ?? '',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        _sourceLabel(reel.source),
                        style: const TextStyle(
                          color: HamsiqTheme.accent,
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  if (post.caption.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      post.caption,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                      ),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ],
              ),
            ),
          ),
          Positioned(
            right: 8,
            bottom: 170,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  onPressed: () => _toggleLike(reel),
                  icon: Icon(
                    post.likedByMe
                        ? Icons.favorite
                        : Icons.favorite_border,
                    color: post.likedByMe
                        ? HamsiqTheme.accent
                        : Colors.white,
                    size: 30,
                  ),
                ),
                Text(
                  '${post.likeCount}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
