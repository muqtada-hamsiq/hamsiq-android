// Hamsiq native — Drafts + Scheduled posts (Wave 2).
// Drafts live in public.post_drafts, scheduled posts in
// public.scheduled_posts (sql-v30). The create sheet in home_shell.dart
// is owned by another workstream, so drafts are managed here: start a
// draft from the gallery, resume it in the editor, publish it now or
// schedule it. Scheduled posts publish ONLY while the app is open —
// the feed checks for due posts on load and this screen checks on
// open; the UI says so plainly and never implies server scheduling.


import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../services/app_strings.dart';
import '../services/supabase_service.dart';
import '../services/wave2_api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class DraftsScreen extends StatefulWidget {
  const DraftsScreen({super.key});

  @override
  State<DraftsScreen> createState() => _DraftsScreenState();
}

class _DraftsScreenState extends State<DraftsScreen> {
  List<PostDraft> _drafts = [];
  List<ScheduledPost> _scheduled = [];
  bool _loading = true;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    // Publish anything due first, then show the fresh lists.
    try {
      await Wave2Api.publishDueScheduledPosts();
    } catch (_) {}
    try {
      final results = await Future.wait([
        Wave2Api.fetchMyDrafts(),
        Wave2Api.fetchMyScheduled(),
      ]);
      if (!mounted) return;
      setState(() {
        _drafts = results[0] as List<PostDraft>;
        // Only pending scheduled posts are shown; published ones are
        // real posts now and live in the feed/profile.
        _scheduled = (results[1] as List<ScheduledPost>)
            .where((s) => !s.published)
            .toList();
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      showError(context, e);
    }
  }

  Future<void> _newDraft() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 1080,
        imageQuality: 85,
      );
      String? url;
      if (picked != null) {
        url = await Api.uploadImage(
          await picked.readAsBytes(),
          Api.uniqueImagePath('draft'),
        );
        if (url == null) throw Exception(AppStrings.t('photoUploadFailed'));
      }
      final draft = await Wave2Api.saveDraft(caption: '', mediaUrl: url);
      if (!mounted) return;
      await _openEditor(draft);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _newTextDraft() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final draft = await Wave2Api.saveDraft(caption: '');
      if (!mounted) return;
      await _openEditor(draft);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openEditor(PostDraft draft) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => DraftEditorScreen(draft: draft)),
    );
    if (mounted) _load();
  }

  Future<void> _deleteDraft(PostDraft draft) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('deleteDraftTitle')),
        content: Text(AppStrings.t('deleteDraftBody')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(AppStrings.t('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(AppStrings.t('delete'), style: TextStyle(color: Colors.redAccent)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Wave2Api.deleteDraft(draft.id);
      if (mounted) _load();
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _cancelScheduled(ScheduledPost s) async {
    try {
      await Wave2Api.cancelScheduled(s.id);
      if (mounted) {
        _load();
        showOk(context, AppStrings.t('scheduledCancelled'));
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.t('titleDrafts')),
        actions: [
          IconButton(
            icon: const Icon(Icons.note_add_outlined),
            tooltip: AppStrings.t('textDraftTooltip'),
            onPressed: _newTextDraft,
          ),
          IconButton(
            icon: const Icon(Icons.add_photo_alternate_outlined),
            tooltip: AppStrings.t('imageDraftTooltip'),
            onPressed: _newDraft,
          ),
        ],
      ),
      body: _loading
          ? const LoadingCenter()
          : RefreshIndicator(
              color: HamsiqTheme.accent,
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Padding(
                    padding: EdgeInsets.only(bottom: 12),
                    child: Text(
                      AppStrings.t('draftsScheduleNote'),
                      style: TextStyle(color: HamsiqTheme.muted, fontSize: 13),
                    ),
                  ),
                  Text(
                    AppStrings.t('draftsSection'),
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  if (_drafts.isEmpty)
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text(
                        AppStrings.t('noDrafts'),
                        style: TextStyle(color: HamsiqTheme.muted),
                      ),
                    )
                  else
                    ..._drafts.map(
                      (d) => Card(
                        color: HamsiqTheme.panel,
                        child: ListTile(
                          leading: d.mediaUrl != null
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: SignedMediaImage(
                                    url: d.mediaUrl!,
                                    width: 52,
                                    height: 52,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(
                                      width: 52,
                                      height: 52,
                                      color: HamsiqTheme.panel2,
                                      child: const Icon(Icons.image_outlined,
                                          color: HamsiqTheme.muted),
                                    ),
                                  ),
                                )
                              : const CircleAvatar(
                                  backgroundColor: HamsiqTheme.panel2,
                                  child: Icon(Icons.article_outlined,
                                      color: HamsiqTheme.muted),
                                ),
                          title: Text(
                            d.caption.isEmpty ? AppStrings.t('draftNoText') : d.caption,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            '${AppStrings.t('lastEdited')} ${timeAgo(d.updatedAt)}',
                            style: const TextStyle(color: HamsiqTheme.muted),
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline,
                                color: Colors.redAccent),
                            onPressed: () => _deleteDraft(d),
                          ),
                          onTap: () => _openEditor(d),
                        ),
                      ),
                    ),
                  const SizedBox(height: 20),
                  Text(
                    AppStrings.t('scheduledPosts'),
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  if (_scheduled.isEmpty)
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text(
                        AppStrings.t('noScheduled'),
                        style: TextStyle(color: HamsiqTheme.muted),
                      ),
                    )
                  else
                    ..._scheduled.map(
                      (s) => Card(
                        color: HamsiqTheme.panel,
                        child: ListTile(
                          leading: const CircleAvatar(
                            backgroundColor: HamsiqTheme.panel2,
                            child: Icon(Icons.schedule,
                                color: HamsiqTheme.accent),
                          ),
                          title: Text(
                            s.caption.isEmpty ? AppStrings.t('scheduledNoText') : s.caption,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            '${AppStrings.t('publishesAt')} ${s.publishAt.toLocal()}',
                            style: const TextStyle(color: HamsiqTheme.muted),
                          ),
                          trailing: TextButton(
                            onPressed: () => _cancelScheduled(s),
                            child: Text(
                              AppStrings.t('cancel'),
                              style: TextStyle(color: Colors.redAccent),
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
    );
  }
}

/// Edit a draft: caption + media preview, then save / publish now /
/// schedule for a picked date + time.
class DraftEditorScreen extends StatefulWidget {
  final PostDraft draft;
  const DraftEditorScreen({super.key, required this.draft});

  @override
  State<DraftEditorScreen> createState() => _DraftEditorScreenState();
}

class _DraftEditorScreenState extends State<DraftEditorScreen> {
  late final TextEditingController _caption;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _caption = TextEditingController(text: widget.draft.caption);
  }

  @override
  void dispose() {
    _caption.dispose();
    super.dispose();
  }

  Future<void> _save({bool pop = true}) async {
    setState(() => _busy = true);
    try {
      await Wave2Api.saveDraft(
        id: widget.draft.id,
        caption: _caption.text.trim(),
        mediaUrl: widget.draft.mediaUrl,
        mediaType: widget.draft.mediaType,
        isReel: widget.draft.isReel,
      );
      if (!mounted) return;
      if (pop) {
        Navigator.of(context).pop();
        showOk(context, AppStrings.t('draftSaved'));
      }
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _publishNow() async {
    setState(() => _busy = true);
    try {
      await Wave2Api.publishDraft(
        PostDraft(
          id: widget.draft.id,
          caption: _caption.text.trim(),
          mediaUrl: widget.draft.mediaUrl,
          mediaType: widget.draft.mediaType,
          isReel: widget.draft.isReel,
          createdAt: widget.draft.createdAt,
          updatedAt: widget.draft.updatedAt,
        ),
      );
      if (!mounted) return;
      Navigator.of(context).pop();
      showOk(context, AppStrings.t('postPublished'));
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _schedule() async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      initialDate: now.add(const Duration(days: 1)),
      firstDate: now,
      lastDate: now.add(const Duration(days: 30)),
      helpText: AppStrings.t('pickPublishDate'),
      cancelText: AppStrings.t('cancel'),
      confirmText: AppStrings.t('confirm'),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
      helpText: AppStrings.t('pickPublishTime'),
      cancelText: AppStrings.t('cancel'),
      confirmText: AppStrings.t('confirm'),
    );
    if (time == null || !mounted) return;
    final publishAt = DateTime(
      date.year,
      date.month,
      date.day,
      time.hour,
      time.minute,
    );
    setState(() => _busy = true);
    try {
      await Wave2Api.schedulePost(
        caption: _caption.text.trim(),
        mediaUrl: widget.draft.mediaUrl,
        mediaType: widget.draft.mediaType,
        isReel: widget.draft.isReel,
        publishAt: publishAt,
      );
      await Wave2Api.deleteDraft(widget.draft.id);
      if (!mounted) return;
      Navigator.of(context).pop();
      showOk(context, AppStrings.t('scheduledDone'));
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final draft = widget.draft;
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.t('editDraftTitle')),
        actions: [
          TextButton(
            onPressed: _busy ? null : _save,
            child: Text(AppStrings.t('save')),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (draft.mediaUrl != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SignedMediaImage(
                  url: draft.mediaUrl!,
                  height: 280,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    height: 200,
                    color: HamsiqTheme.panel2,
                    alignment: Alignment.center,
                    child: const Icon(Icons.broken_image_outlined,
                        color: HamsiqTheme.muted, size: 40),
                  ),
                ),
              ),
            const SizedBox(height: 12),
            TextField(
              controller: _caption,
              decoration: InputDecoration(hintText: AppStrings.t('writeSomething')),
              maxLines: 5,
              minLines: 3,
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _busy ? null : _publishNow,
              icon: const Icon(Icons.publish),
              label: Text(AppStrings.t('publishNow')),
            ),
            const SizedBox(height: 8),
            ElevatedButton.icon(
              onPressed: _busy ? null : _schedule,
              style: ElevatedButton.styleFrom(
                backgroundColor: HamsiqTheme.panel2,
                foregroundColor: Colors.white,
              ),
              icon: const Icon(Icons.schedule),
              label: Text(AppStrings.t('schedulePublish')),
            ),
            const SizedBox(height: 12),
            Text(
              AppStrings.t('scheduleNoteLong'),
              style: TextStyle(color: HamsiqTheme.muted, fontSize: 13),
            ),
            if (_busy) ...[
              const SizedBox(height: 16),
              const Center(
                child: CircularProgressIndicator(color: HamsiqTheme.accent),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
