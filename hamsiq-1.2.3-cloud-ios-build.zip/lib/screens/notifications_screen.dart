// Hamsiq native — Notifications screen + bell button (Wave 1).
// Lists follow / like / mention / comment / message notifications from
// the REAL public.notifications table (sql-v9), gated by the
// recipient's notif_* toggles (NotificationsApi). In-app only — the
// screen states plainly that there are no push notifications, and no
// code here may imply closed-app push exists.
//
// Wiring (coordinator): the bell entry point is NotificationsBellButton
// below — it is already wired into feed_screen.dart's AppBar. It shows
// an unread dot from NotificationsApi.fetchUnreadCount().

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/notifications_api.dart';
import '../services/supabase_service.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'post_detail_screen.dart';
import 'profile_screen.dart';

/// Bell button with an unread dot. Drop it into an AppBar's actions
/// (already done in feed_screen.dart). Tapping opens
/// NotificationsScreen; returning refreshes the dot.
class NotificationsBellButton extends StatefulWidget {
  const NotificationsBellButton({super.key});

  @override
  State<NotificationsBellButton> createState() =>
      _NotificationsBellButtonState();
}

class _NotificationsBellButtonState extends State<NotificationsBellButton> {
  int _unread = 0;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    try {
      final count = await NotificationsApi.fetchUnreadCount();
      if (mounted) setState(() => _unread = count);
    } catch (_) {
      // Bell without a dot is better than a broken app bar.
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        IconButton(
          tooltip: AppStrings.t('titleNotifications'),
          icon: const Icon(Icons.notifications_outlined),
          onPressed: () async {
            await Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => const NotificationsScreen(),
              ),
            );
            if (mounted) _refresh();
          },
        ),
        if (_unread > 0)
          Positioned(
            top: 10,
            right: 10,
            child: Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(
                // Mockup-match (feed redesign 2026-11-16): the unread
                // dot is Instagram blue, not red.
                color: HamsiqTheme.accent,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.black, width: 1.5),
              ),
            ),
          ),
      ],
    );
  }
}

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<NotificationItem> _items = [];
  bool _loading = true;
  String? _error;
  String _filter = 'all';

  static Map<String, String> get _filters => {
        'all': AppStrings.t('allFilter'),
        'like': AppStrings.t('notifLikes'),
        'comment': AppStrings.t('notifComments'),
        'follow': AppStrings.t('notifFollowers'),
        'mention': AppStrings.t('notifMentions'),
        'message': AppStrings.t('notifMessages'),
      };

  static const Map<String, IconData> _typeIcons = {
    'like': Icons.favorite,
    'comment': Icons.chat_bubble,
    'follow': Icons.person_add,
    'mention': Icons.alternate_email,
    'message': Icons.send,
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final items = await NotificationsApi.fetchMyNotifications();
      if (!mounted) return;
      setState(() {
        _items = items;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  List<NotificationItem> get _shown => _filter == 'all'
      ? _items
      : _items.where((n) => n.type == _filter).toList();

  Future<void> _open(NotificationItem n) async {
    try {
      await NotificationsApi.markRead(n.id);
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _items = _items.map((x) => x.id == n.id ? x.copyWithRead(true) : x).toList();
    });
    if (n.postId != null) {
      final post = await _fetchPostForNotification(n.postId!);
      if (!mounted) return;
      if (post != null) {
        await Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => PostDetailScreen(post: post)),
        );
        if (mounted) _load();
      }
    } else if (n.type == 'follow' || n.type == 'message') {
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ProfileScreen(userId: n.actorId),
        ),
      );
    }
  }

  Future<PostItem?> _fetchPostForNotification(int postId) async {
    try {
      final rows = await Api.client
          .from('posts')
          .select()
          .eq('id', postId)
          .limit(1);
      if ((rows as List).isEmpty) return null;
      final post =
          PostItem.fromMap((rows as List).first as Map<String, dynamic>);
      post.author = await Api.fetchProfile(post.userId);
      return post;
    } catch (_) {
      return null;
    }
  }

  Future<void> _markAllRead() async {
    try {
      await NotificationsApi.markAllRead();
      if (!mounted) return;
      setState(() {
        _items = _items.map((n) => n.copyWithRead(true)).toList();
      });
      showOk(context, AppStrings.t('markedAllRead'));
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.t('titleNotifications')),
        actions: [
          TextButton(
            onPressed: _items.any((n) => !n.isRead) ? _markAllRead : null,
            child: Text(AppStrings.t('markAllRead')),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Text(
              AppStrings.t('notifInAppOnly'),
              style: TextStyle(color: HamsiqTheme.muted, fontSize: 12),
            ),
          ),
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                for (final entry in _filters.entries)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: ChoiceChip(
                      label: Text(entry.value),
                      selected: _filter == entry.key,
                      selectedColor: HamsiqTheme.accent,
                      backgroundColor: HamsiqTheme.panel2,
                      labelStyle: TextStyle(
                        color: _filter == entry.key
                            ? Colors.white
                            : HamsiqTheme.text,
                      ),
                      onSelected: (_) {
                        setState(() => _filter = entry.key);
                      },
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const LoadingCenter()
                : _error != null
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _error!,
                              style: const TextStyle(
                                color: HamsiqTheme.muted,
                              ),
                            ),
                            const SizedBox(height: 12),
                            ElevatedButton(
                              onPressed: _load,
                              child: Text(AppStrings.t('retry')),
                            ),
                          ],
                        ),
                      )
                    : _shown.isEmpty
                        ? RefreshIndicator(
                            color: HamsiqTheme.accent,
                            onRefresh: _load,
                            child: ListView(
                              physics:
                                  const AlwaysScrollableScrollPhysics(),
                              children: [
                                SizedBox(height: 120),
                                EmptyCenter(AppStrings.t('noNotifications')),
                              ],
                            ),
                          )
                        : RefreshIndicator(
                            color: HamsiqTheme.accent,
                            onRefresh: _load,
                            child: ListView.builder(
                              physics:
                                  const AlwaysScrollableScrollPhysics(),
                              itemCount: _shown.length,
                              itemBuilder: (_, i) =>
                                  _NotificationRow(
                                item: _shown[i],
                                icon: _typeIcons[_shown[i].type] ??
                                    Icons.notifications_outlined,
                                onTap: () => _open(_shown[i]),
                              ),
                            ),
                          ),
          ),
        ],
      ),
    );
  }
}

class _NotificationRow extends StatelessWidget {
  final NotificationItem item;
  final IconData icon;
  final VoidCallback onTap;
  const _NotificationRow({
    required this.item,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final actor = item.actor;
    return ListTile(
      onTap: onTap,
      leading: Stack(
        children: [
          AvatarWidget(profile: actor, size: 44),
          Positioned(
            right: 0,
            bottom: 0,
            child: Container(
              padding: const EdgeInsets.all(3),
              decoration: const BoxDecoration(
                color: HamsiqTheme.accent,
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 11, color: Colors.white),
            ),
          ),
        ],
      ),
      title: RichText(
        text: TextSpan(
          style: const TextStyle(color: HamsiqTheme.text, fontSize: 14),
          children: [
            TextSpan(
              text: actor?.displayName ?? '',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            TextSpan(text: ' ${NotificationsApi.typeLabel(item.type)}'),
          ],
        ),
      ),
      subtitle: Text(
        timeAgo(item.createdAt),
        style: const TextStyle(color: HamsiqTheme.muted, fontSize: 12),
      ),
      trailing: item.isRead
          ? null
          : Container(
              width: 9,
              height: 9,
              decoration: const BoxDecoration(
                color: HamsiqTheme.accent,
                shape: BoxShape.circle,
              ),
            ),
    );
  }
}
