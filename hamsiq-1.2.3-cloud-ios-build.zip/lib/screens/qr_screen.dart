// Hamsiq native — Profile QR code (Wave 2).
// A real QR code (qr_flutter) of the profile link — the same link the
// web app uses (index.html:4643). Anyone scanning it opens the profile
// in the browser. Nothing here is hand-drawn or fake.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../theme.dart';
import '../widgets/common.dart';

class QrScreen extends StatelessWidget {
  final HamsiqProfile profile;
  const QrScreen({super.key, required this.profile});

  String get _link =>
      'https://muqtada-pages.neocities.org/#u/${Uri.encodeComponent(profile.username)}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.t('titleQr'))),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AvatarWidget(profile: profile, size: 72, showRing: true),
              const SizedBox(height: 12),
              Text(
                profile.displayName,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Text(
                '@${profile.username}',
                style: const TextStyle(color: HamsiqTheme.muted),
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: QrImageView(
                  data: _link,
                  version: QrVersions.auto,
                  size: 220,
                  backgroundColor: Colors.white,
                  eyeStyle: const QrEyeStyle(
                    eyeShape: QrEyeShape.square,
                    color: Colors.black,
                  ),
                  dataModuleStyle: const QrDataModuleStyle(
                    dataModuleShape: QrDataModuleShape.square,
                    color: Colors.black,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                AppStrings.t('scanQrHint'),
                style: TextStyle(color: HamsiqTheme.muted),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: _link));
                  if (context.mounted) {
                    showOk(context, AppStrings.t('profileLinkCopied'));
                  }
                },
                icon: const Icon(Icons.copy),
                label: Text(AppStrings.t('copyLink')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
