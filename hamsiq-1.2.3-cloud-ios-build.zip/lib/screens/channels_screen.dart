// Hamsiq native — Broadcast channels (Wave 3, sql-v31).
// Instagram model, honest subset: a channel is public/discoverable —
// anyone approved can read it; only the channel OWNER posts; members
// react (one emoji each, changeable) and cannot reply. Channel list +
// create + join/leave + channel thread with reactions.
//
// Honest limits (also shown in the UI): Instagram's >1,000-followers
// eligibility for creating a channel is NOT enforced here, and
// Instagram lets invited collaborators post too — here the owner
// posts alone.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/supabase_service.dart';
import '../services/wave3_api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class ChannelsScreen extends StatefulWidget {
  const ChannelsScreen({super.key});

  @override
  State<ChannelsScreen> createState() => _ChannelsScreenState();
}

class _ChannelsScreenState extends State<ChannelsScreen> {
  List<ChannelInfo>? _channels;
  String? _error;
  bool _busyJoin = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final channels = await Wave3Api.fetchChannels();
      if (!mounted) return;
      setState(() {
        _channels = channels;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(
        () => _error = e.toString().replaceFirst('Exception: ', ''),
      );
    }
  }

  Future<void> _openChannel(ChannelInfo channel) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ChannelScreen(channel: channel),
      ),
    );
    if (mounted) _load();
  }

  Future<void> _toggleJoin(ChannelInfo channel) async {
    if (_busyJoin) return;
    setState(() => _busyJoin = true);
    try {
      if (channel.joinedByMe) {
        await Wave3Api.leaveChannel(channel.id);
      } else {
        await Wave3Api.joinChannel(channel.id);
      }
      if (mounted) _load();
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busyJoin = false);
    }
  }

  Future<void> _showCreate() async {
    final nameCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final created = await showDialog<ChannelInfo>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('createChannel')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              decoration: InputDecoration(
                hintText: AppStrings.t('channelName'),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: descCtrl,
              decoration: InputDecoration(
                hintText: AppStrings.t('channelDescription'),
              ),
              maxLines: 2,
            ),
            const SizedBox(height: 12),
            Text(
              AppStrings.t('channelPublicNote'),
              style: const TextStyle(
                color: HamsiqTheme.muted,
                fontSize: 12,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(AppStrings.t('cancel')),
          ),
          ElevatedButton(
            onPressed: () async {
              try {
                final channel = await Wave3Api.createChannel(
                  name: nameCtrl.text,
                  description: descCtrl.text,
                );
                if (ctx.mounted) Navigator.of(ctx).pop(channel);
              } catch (e) {
                if (ctx.mounted) showError(ctx, e);
              }
            },
            child: Text(AppStrings.t('createChannel')),
          ),
        ],
      ),
    );
    nameCtrl.dispose();
    descCtrl.dispose();
    if (created != null && mounted) {
      await _load();
      _openChannel(created);
    }
  }

  @override
  Widget build(BuildContext context) {
    final channels = _channels;
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.t('titleChannels')),
        actions: [
          IconButton(
            onPressed: _showCreate,
            icon: const Icon(Icons.add, color: HamsiqTheme.accent),
            tooltip: AppStrings.t('createChannel'),
          ),
        ],
      ),
      body: channels == null
          ? (_error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _error!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: HamsiqTheme.muted),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: _load,
                          child: Text(AppStrings.t('retry')),
                        ),
                      ],
                    ),
                  ),
                )
              : const LoadingCenter())
          : RefreshIndicator(
              color: HamsiqTheme.accent,
              onRefresh: _load,
              child: channels.isEmpty
                  ? ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      children: [
                        SizedBox(
                          height:
                              MediaQuery.of(context).size.height * 0.7,
                          child: EmptyCenter(AppStrings.t('noChannels')),
                        ),
                      ],
                    )
                  : ListView.builder(
                      itemCount: channels.length,
                      itemBuilder: (_, i) {
                        final channel = channels[i];
                        return ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 6,
                          ),
                          leading: Container(
                            width: 52,
                            height: 52,
                            alignment: Alignment.center,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: HamsiqTheme.panel2,
                            ),
                            child: Text(
                              channel.name.isNotEmpty
                                  ? channel.name[0].toUpperCase()
                                  : '📢',
                              style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          title: Text(
                            channel.name,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                          subtitle: Text(
                            '${channel.owner?.displayName ?? ''} · ${channel.memberCount} ${AppStrings.t('channelMembers')}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: HamsiqTheme.muted),
                          ),
                          trailing: channel.ownerId == Api.myId
                              ? Chip(
                                  label: Text(AppStrings.t('myChannel')),
                                  backgroundColor: HamsiqTheme.panel2,
                                )
                              : OutlinedButton(
                                  onPressed: () => _toggleJoin(channel),
                                  child: Text(
                                    channel.joinedByMe
                                        ? AppStrings.t('leaveChannel')
                                        : AppStrings.t('joinChannel'),
                                  ),
                                ),
                          onTap: () => _openChannel(channel),
                        );
                      },
                    ),
            ),
    );
  }
}

class ChannelScreen extends StatefulWidget {
  final ChannelInfo channel;
  const ChannelScreen({super.key, required this.channel});

  @override
  State<ChannelScreen> createState() => _ChannelScreenState();
}

class _ChannelScreenState extends State<ChannelScreen> {
  List<ChannelPost> _posts = [];
  bool _loading = true;
  bool _sending = false;
  bool _joined = false;
  Timer? _poll;
  final _input = TextEditingController();

  bool get _isOwner => Api.isLoggedIn && Api.myId == widget.channel.ownerId;

  @override
  void initState() {
    super.initState();
    _joined = widget.channel.joinedByMe || _isOwner;
    _load();
    // New channel posts arrive while the channel is open.
    _poll = Timer.periodic(const Duration(seconds: 10), (_) {
      if (mounted && !_loading) _load(silent: true);
    });
  }

  @override
  void dispose() {
    _poll?.cancel();
    _input.dispose();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    try {
      final posts = await Wave3Api.fetchChannelPosts(widget.channel.id);
      if (!mounted) return;
      setState(() {
        _posts = posts;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      if (!silent) showError(context, e);
    }
  }

  Future<void> _toggleJoin() async {
    try {
      if (_joined) {
        await Wave3Api.leaveChannel(widget.channel.id);
      } else {
        await Wave3Api.joinChannel(widget.channel.id);
      }
      if (mounted) setState(() => _joined = !_joined);
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _send({XFile? image}) async {
    if (_sending || !_isOwner) return;
    final text = _input.text.trim();
    if (text.isEmpty && image == null) return;
    setState(() => _sending = true);
    try {
      String? url;
      if (image != null) {
        url = await Api.uploadImage(
          await image.readAsBytes(),
          Api.uniqueImagePath('channel'),
        );
        if (url == null) throw Exception(AppStrings.t('photoUploadFailed'));
      }
      await Wave3Api.postToChannel(
        channelId: widget.channel.id,
        body: text,
        mediaUrl: url,
        mediaType: 'image',
      );
      if (!mounted) return;
      _input.clear();
      await _load();
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _pickImageAndSend() async {
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 1080,
        imageQuality: 85,
      );
      if (picked != null) await _send(image: picked);
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _react(ChannelPost post, String emoji) async {
    final wasMine = post.myReaction;
    setState(() {
      // Optimistic: flip the counts locally, revert on failure.
      final counts = Map<String, int>.from(post.reactionCounts);
      if (wasMine != null) {
        final c = (counts[wasMine] ?? 1) - 1;
        if (c <= 0) {
          counts.remove(wasMine);
        } else {
          counts[wasMine] = c;
        }
      }
      if (wasMine != emoji) {
        counts[emoji] = (counts[emoji] ?? 0) + 1;
        post.myReaction = emoji;
      } else {
        post.myReaction = null;
      }
      post.reactionCounts = counts;
    });
    try {
      if (wasMine == emoji) {
        await Wave3Api.removeChannelReaction(post.id);
      } else {
        await Wave3Api.reactToChannelPost(post.id, emoji);
      }
    } catch (e) {
      if (!mounted) return;
      // Revert by reloading the true state.
      _load(silent: true);
      showError(context, e);
    }
  }

  Future<void> _confirmDelete(ChannelPost post) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('deleteChannelPostTitle')),
        content: Text(AppStrings.t('deleteChannelPostBody')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(AppStrings.t('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(
              AppStrings.t('delete'),
              style: TextStyle(color: Colors.redAccent),
            ),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Wave3Api.deleteChannelPost(post.id);
      if (mounted) {
        setState(() => _posts.removeWhere((p) => p.id == post.id));
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _showMembers() async {
    List<HamsiqProfile> members = [];
    try {
      members = await Wave3Api.fetchChannelMembers(widget.channel.id);
    } catch (e) {
      if (mounted) showError(context, e);
      return;
    }
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(
          '${AppStrings.t('channelMembers')} (${members.length})',
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: members.isEmpty
              ? Text(AppStrings.t('noMembersYet'))
              : ListView.builder(
                  shrinkWrap: true,
                  itemCount: members.length,
                  itemBuilder: (_, i) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: AvatarWidget(profile: members[i], size: 36),
                    title: Text(members[i].displayName),
                    subtitle: Text('@${members[i].username}'),
                  ),
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(AppStrings.t('cancel')),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final channel = widget.channel;
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(channel.name, overflow: TextOverflow.ellipsis),
            Text(
              '${channel.owner?.displayName ?? ''} · ${channel.memberCount} ${AppStrings.t('channelMembers')}',
              style: const TextStyle(
                fontSize: 12,
                color: HamsiqTheme.muted,
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.people_outline),
            tooltip: AppStrings.t('channelMembers'),
            onPressed: _showMembers,
          ),
          if (!_isOwner)
            TextButton(
              onPressed: _toggleJoin,
              child: Text(
                _joined
                    ? AppStrings.t('leaveChannel')
                    : AppStrings.t('joinChannel'),
                style: const TextStyle(
                  color: HamsiqTheme.accent,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 8,
            ),
            color: HamsiqTheme.panel,
            child: Text(
              '${AppStrings.t('channelPublicNote')} — ${AppStrings.t('channelOwnerOnly')}',
              style: const TextStyle(
                fontSize: 12,
                color: HamsiqTheme.muted,
              ),
            ),
          ),
          if (channel.description.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 8,
              ),
              child: Text(
                channel.description,
                style: const TextStyle(fontSize: 14),
              ),
            ),
          Expanded(
            child: _loading
                ? const LoadingCenter()
                : _posts.isEmpty
                    ? EmptyCenter(AppStrings.t('noChannelPosts'))
                    : RefreshIndicator(
                        color: HamsiqTheme.accent,
                        onRefresh: _load,
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          itemCount: _posts.length,
                          itemBuilder: (_, i) =>
                              _ChannelPostCard(
                            post: _posts[i],
                            canDelete: _isOwner ||
                                (_posts[i].authorId == Api.myId),
                            onReact: (emoji) => _react(_posts[i], emoji),
                            onDelete: () => _confirmDelete(_posts[i]),
                          ),
                        ),
                      ),
          ),
          // Composer: owner only — members read and react.
          if (_isOwner)
            Container(
              padding: EdgeInsets.fromLTRB(
                10,
                8,
                10,
                MediaQuery.of(context).padding.bottom + 10,
              ),
              decoration: const BoxDecoration(
                color: HamsiqTheme.panel,
                border: Border(top: BorderSide(color: HamsiqTheme.line)),
              ),
              child: Row(
                children: [
                  IconButton(
                    onPressed: _sending ? null : _pickImageAndSend,
                    icon: const Icon(
                      Icons.photo_outlined,
                      color: HamsiqTheme.accent,
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _input,
                      decoration: InputDecoration(
                        hintText: AppStrings.t('channelPostHint'),
                      ),
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                    ),
                  ),
                  const SizedBox(width: 4),
                  _sending
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: HamsiqTheme.accent,
                          ),
                        )
                      : IconButton(
                          onPressed: () => _send(),
                          icon: const Icon(
                            Icons.send,
                            color: HamsiqTheme.accent,
                          ),
                        ),
                ],
              ),
            )
          else if (!_joined)
            Container(
              width: double.infinity,
              padding: EdgeInsets.fromLTRB(
                16,
                12,
                16,
                MediaQuery.of(context).padding.bottom + 12,
              ),
              decoration: const BoxDecoration(
                color: HamsiqTheme.panel,
                border: Border(top: BorderSide(color: HamsiqTheme.line)),
              ),
              child: ElevatedButton(
                onPressed: _toggleJoin,
                child: Text(AppStrings.t('joinChannel')),
              ),
            ),
        ],
      ),
    );
  }
}

class _ChannelPostCard extends StatelessWidget {
  final ChannelPost post;
  final bool canDelete;
  final ValueChanged<String> onReact;
  final VoidCallback onDelete;
  const _ChannelPostCard({
    required this.post,
    required this.canDelete,
    required this.onReact,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final author = post.author;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: HamsiqTheme.panel,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: HamsiqTheme.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              AvatarWidget(profile: author, size: 36),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            author?.displayName ?? '',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (author?.verified == true) ...[
                          const SizedBox(width: 4),
                          const VerifiedTick(),
                        ],
                      ],
                    ),
                    Text(
                      timeAgo(post.createdAt),
                      style: const TextStyle(
                        color: HamsiqTheme.muted,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              if (canDelete)
                IconButton(
                  icon: const Icon(
                    Icons.delete_outline,
                    color: Colors.redAccent,
                    size: 20,
                  ),
                  onPressed: onDelete,
                ),
            ],
          ),
          if (post.body.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(post.body, style: const TextStyle(fontSize: 15)),
          ],
          if (post.mediaUrl != null && post.mediaUrl!.isNotEmpty) ...[
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: SignedMediaImage(
                url: post.mediaUrl!,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  height: 160,
                  color: HamsiqTheme.panel2,
                  alignment: Alignment.center,
                  child: const Icon(
                    Icons.broken_image_outlined,
                    color: HamsiqTheme.muted,
                  ),
                ),
              ),
            ),
          ],
          const SizedBox(height: 10),
          // Reactions: counts + the fixed emoji set (tap to react,
          // tap my own emoji again to remove it).
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              for (final emoji in channelReactionEmojis)
                GestureDetector(
                  onTap: () => onReact(emoji),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: post.myReaction == emoji
                          ? HamsiqTheme.accent.withValues(alpha: 0.25)
                          : HamsiqTheme.panel2,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: post.myReaction == emoji
                            ? HamsiqTheme.accent
                            : HamsiqTheme.line,
                      ),
                    ),
                    child: Text(
                      (post.reactionCounts[emoji] ?? 0) > 0
                          ? '$emoji ${post.reactionCounts[emoji]}'
                          : emoji,
                      style: const TextStyle(fontSize: 14),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
