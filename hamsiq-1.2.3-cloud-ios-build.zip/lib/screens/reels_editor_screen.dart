// Hamsiq native — Reels editor (Wave 3).
// Real editor for the user's OWN video clip (gallery or camera):
//   * text overlays with position (tap the preview), colour, size and
//     start/end timing in seconds — stored on the post row
//     (posts.reel_text_overlays, sql-v31) and rendered by the Reels
//     tab while the video plays;
//   * voiceover: recorded from the microphone (record package, .m4a),
//     uploaded to chat-media and played alongside the reel
//     (posts.reel_voiceover_url);
//   * templates: built-in preset text-slot layouts (Wave3Api
//     reelTemplates) — real layouts applied to the user's clip, no
//     "AI" generation and no fake rendering; every placeholder text
//     is edited by the user before publishing.
//
// What this is NOT: there is no on-device video re-encoding here
// (no ffmpeg in the app) — the video file is published as recorded
// and the overlays/voiceover are real data rendered at playback
// time, exactly like Instagram stores text/voiceover as edit data.

import 'dart:async';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:video_player/video_player.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/media_api.dart';
import '../services/platform_file.dart';
import '../services/wave3_api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class ReelsEditorScreen extends StatefulWidget {
  final VoidCallback onPublished;
  const ReelsEditorScreen({super.key, required this.onPublished});

  @override
  State<ReelsEditorScreen> createState() => _ReelsEditorScreenState();
}

class _ReelsEditorScreenState extends State<ReelsEditorScreen> {
  XFile? _video;
  VideoPlayerController? _controller;
  Timer? _posTimer;
  double _positionSec = 0;
  double _durationSec = 0;
  bool _videoFailed = false;

  // Caption.
  final _caption = TextEditingController();

  // Overlays being built.
  List<ReelTextOverlay> _overlays = [];
  String? _templateId;

  // The overlay currently edited in the form (null = adding a new one).
  int? _editingIndex;
  final _overlayText = TextEditingController();
  double _draftX = 0.5;
  double _draftY = 0.2;
  int _draftColor = 0xFFFFFFFF;
  double _draftSize = 22;
  double _draftStart = 0;
  double _draftEnd = 3;

  // Voiceover.
  final _recorder = AudioRecorder();
  bool _recording = false;
  int _recSeconds = 0;
  Timer? _recTimer;
  String? _voiceoverPath;
  Uint8List? _voiceoverBytes;
  int _voiceoverSeconds = 0;
  final _voicePlayer = AudioPlayer();
  bool _voicePlaying = false;

  bool _busy = false;

  @override
  void initState() {
    super.initState();
    // Rebuild on each keystroke so the draft overlay marker on the
    // preview follows the text being typed.
    _overlayText.addListener(() {
      if (mounted) setState(() {});
    });
  }

  static const List<int> _overlayColors = [
    0xFFFFFFFF, // white
    0xFF000000, // black
    0xFFFFFF00, // yellow
    0xFF0095F6, // blue
    0xFFFF3B30, // red
  ];

  @override
  void dispose() {
    _posTimer?.cancel();
    _recTimer?.cancel();
    _controller?.dispose();
    _caption.dispose();
    _overlayText.dispose();
    _recorder.dispose();
    _voicePlayer.dispose();
    super.dispose();
  }

  // ---------------- video pick + preview ----------------

  Future<void> _pickVideo(ImageSource source) async {
    try {
      final picked = await ImagePicker().pickVideo(source: source);
      if (picked == null) return;
      await _initVideo(picked);
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _initVideo(XFile file) async {
    _posTimer?.cancel();
    await _controller?.dispose();
    final c = videoControllerFor(file);
    setState(() {
      _video = file;
      _controller = c;
      _videoFailed = false;
      _positionSec = 0;
      _durationSec = 0;
      _overlays = [];
      _templateId = null;
      _editingIndex = null;
      _overlayText.clear();
    });
    try {
      await c.initialize();
      if (!mounted) return;
      c.setLooping(true);
      setState(() {
        _durationSec = c.value.duration.inMilliseconds / 1000.0;
        _draftEnd = _durationSec > 0 && _durationSec < 3 ? _durationSec : 3;
      });
      c.play();
      _posTimer = Timer.periodic(const Duration(milliseconds: 300), (_) {
        if (!mounted) return;
        final c2 = _controller;
        if (c2 == null || !c2.value.isInitialized) return;
        final pos = c2.value.position.inMilliseconds / 1000.0;
        if ((pos - _positionSec).abs() > 0.05) {
          setState(() => _positionSec = pos);
        }
      });
    } catch (_) {
      if (mounted) setState(() => _videoFailed = true);
    }
  }

  void _togglePlayPause() {
    final c = _controller;
    if (c == null || !c.value.isInitialized) return;
    if (c.value.isPlaying) {
      c.pause();
    } else {
      c.play();
    }
    setState(() {});
  }

  // ---------------- templates ----------------

  void _applyTemplate(ReelTemplate t) {
    setState(() {
      _templateId = t.id;
      _overlays = t.overlays
          .map(
            (o) => o.copyWith(
              endSec: _durationSec > 0 && o.endSec > _durationSec
                  ? _durationSec
                  : o.endSec,
            ),
          )
          .toList();
      _editingIndex = null;
      _overlayText.clear();
    });
    showOk(context, '${AppStrings.t('templateApplied')} «${t.name}» — ${AppStrings.t('templateEditBeforePublish')}');
  }

  void _clearTemplate() {
    setState(() => _templateId = null);
  }

  // ---------------- overlay form ----------------

  void _loadDraftForEdit(int index) {
    final o = _overlays[index];
    setState(() {
      _editingIndex = index;
      _overlayText.text = o.text;
      _draftX = o.x;
      _draftY = o.y;
      _draftColor = o.color;
      _draftSize = o.size;
      _draftStart = o.startSec;
      _draftEnd = o.endSec;
    });
  }

  void _resetDraft() {
    setState(() {
      _editingIndex = null;
      _overlayText.clear();
      _draftX = 0.5;
      _draftY = 0.2;
      _draftColor = 0xFFFFFFFF;
      _draftSize = 22;
      _draftStart = 0;
      _draftEnd = _durationSec > 0 && _durationSec < 3 ? _durationSec : 3;
    });
  }

  void _saveDraftOverlay() {
    final text = _overlayText.text.trim();
    if (text.isEmpty) {
      showError(context, AppStrings.t('writeTextFirst'));
      return;
    }
    final start =
        _draftStart.clamp(0.0, _durationSec > 0 ? _durationSec : 999).toDouble();
    var end =
        _draftEnd.clamp(0.0, _durationSec > 0 ? _durationSec : 999).toDouble();
    if (end <= start) end = start + 1;
    final overlay = ReelTextOverlay(
      text: text,
      x: _draftX,
      y: _draftY,
      color: _draftColor,
      size: _draftSize,
      startSec: start,
      endSec: end,
    );
    setState(() {
      if (_editingIndex != null) {
        _overlays[_editingIndex!] = overlay;
      } else {
        _overlays = [..._overlays, overlay];
      }
    });
    _resetDraft();
  }

  void _deleteOverlay(int index) {
    setState(() {
      _overlays.removeAt(index);
      if (_editingIndex == index) _resetDraft();
    });
  }

  void _onPreviewTap(TapDownDetails details, Size previewSize) {
    final local = details.localPosition;
    setState(() {
      _draftX = (local.dx / previewSize.width).clamp(0.05, 0.95);
      _draftY = (local.dy / previewSize.height).clamp(0.05, 0.95);
    });
  }

  // ---------------- voiceover ----------------

  Future<void> _startVoiceover() async {
    try {
      final ok = await _recorder.hasPermission();
      if (!ok) {
        if (mounted) showError(context, AppStrings.t('micPermission'));
        return;
      }
      final path = voiceTempPath(
        'hamsiq-voiceover-${DateTime.now().millisecondsSinceEpoch}.m4a',
      );
      await _recorder.start(
        const RecordConfig(encoder: AudioEncoder.aacLc),
        path: path,
      );
      if (!mounted) return;
      setState(() {
        _recording = true;
        _recSeconds = 0;
      });
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => _recSeconds++);
      });
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _stopVoiceover({required bool keep}) async {
    if (!_recording) return;
    _recTimer?.cancel();
    _recTimer = null;
    final seconds = _recSeconds;
    setState(() => _recording = false);
    String? path;
    try {
      path = await _recorder.stop();
    } catch (_) {
      path = null;
    }
    if (!keep || path == null || seconds < 1) {
      if (path != null) {
        await deleteFileQuietly(path);
      }
      return;
    }
    final bytes = await readPathBytes(path);
    setState(() {
      _voiceoverPath = path;
      _voiceoverBytes = bytes;
      _voiceoverSeconds = seconds;
    });
  }

  Future<void> _toggleVoicePreview() async {
    final path = _voiceoverPath;
    if (path == null) return;
    try {
      if (_voicePlaying) {
        await _voicePlayer.pause();
        if (mounted) setState(() => _voicePlaying = false);
      } else {
        // Web: the recording is a blob URL, played as a URL source;
        // Android: a real file, played as a device file source.
        await _voicePlayer.play(
          kIsWeb ? UrlSource(path) : DeviceFileSource(path),
        );
        if (mounted) setState(() => _voicePlaying = true);
        _voicePlayer.onPlayerComplete.listen((_) {
          if (mounted) setState(() => _voicePlaying = false);
        });
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  void _deleteVoiceover() {
    final path = _voiceoverPath;
    setState(() {
      _voiceoverPath = null;
      _voiceoverBytes = null;
      _voiceoverSeconds = 0;
      _voicePlaying = false;
    });
    _voicePlayer.stop();
    if (path != null) {
      deleteFileQuietly(path);
    }
  }

  // ---------------- publish ----------------

  Future<void> _publish() async {
    if (_video == null || _busy) return;
    setState(() => _busy = true);
    try {
      final videoUrl = await MediaApi.uploadVideo(
        await readPickedBytes(_video!),
        MediaApi.uniqueVideoPath('reel'),
      );
      if (videoUrl == null) throw Exception(AppStrings.t('videoUploadFailed'));
      String? voiceUrl;
      if (_voiceoverBytes != null) {
        voiceUrl = await MediaApi.uploadAudio(
          _voiceoverBytes!,
          MediaApi.uniqueAudioPath('voiceover'),
        );
        if (voiceUrl == null) throw Exception(AppStrings.t('voiceoverUploadFailed'));
      }
      await Wave3Api.createReelPost(
        caption: _caption.text.trim(),
        videoUrl: videoUrl,
        overlays: _overlays,
        voiceoverUrl: voiceUrl,
        templateId: _templateId,
      );
      if (!mounted) return;
      widget.onPublished();
      Navigator.of(context).pop();
      showOk(context, AppStrings.t('reelPublished'));
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // ---------------- build ----------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.t('reelsEditor')),
        actions: [
          if (_video != null)
            TextButton(
              onPressed: _busy ? null : _publish,
              child: Text(
                AppStrings.t('reelPublish'),
                style: const TextStyle(
                  color: HamsiqTheme.accent,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
        ],
      ),
      body: _video == null ? _buildPicker() : _buildEditor(),
    );
  }

  Widget _buildPicker() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.movie_creation_outlined,
              size: 72,
              color: HamsiqTheme.accent,
            ),
            const SizedBox(height: 16),
            Text(
              AppStrings.t('createReelFromVideo'),
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              AppStrings.t('reelEditorIntro'),
              style: TextStyle(color: HamsiqTheme.muted),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: () => _pickVideo(ImageSource.gallery),
                  icon: const Icon(Icons.video_library_outlined),
                  label: Text(AppStrings.t('fromGallery')),
                ),
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: () => _pickVideo(ImageSource.camera),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: HamsiqTheme.panel2,
                    foregroundColor: Colors.white,
                  ),
                  icon: const Icon(Icons.videocam_outlined),
                  label: Text(AppStrings.t('recordVideo')),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEditor() {
    final c = _controller;
    final isPlaying = c?.value.isPlaying ?? false;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // ---- preview ----
        _buildPreview(c, isPlaying),
        const SizedBox(height: 8),
        Row(
          children: [
            IconButton(
              onPressed: _togglePlayPause,
              icon: Icon(
                isPlaying ? Icons.pause_circle : Icons.play_circle,
                color: HamsiqTheme.accent,
                size: 32,
              ),
            ),
            Expanded(
              child: Text(
                '${_positionSec.toStringAsFixed(1)} / ${_durationSec.toStringAsFixed(1)} ${AppStrings.t('secondsUnit')}',
                style: const TextStyle(color: HamsiqTheme.muted),
              ),
            ),
            TextButton.icon(
              onPressed: () => _pickVideo(ImageSource.gallery),
              icon: const Icon(Icons.swap_horiz, size: 18),
              label: Text(AppStrings.t('changeVideo')),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _caption,
          decoration: InputDecoration(hintText: AppStrings.t('reelDescHint')),
          maxLines: 2,
        ),
        const SizedBox(height: 20),
        // ---- templates ----
        Text(
          AppStrings.t('reelTemplate'),
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            ChoiceChip(
              label: Text(AppStrings.t('reelNoTemplate')),
              selected: _templateId == null,
              selectedColor: HamsiqTheme.accent,
              backgroundColor: HamsiqTheme.panel2,
              onSelected: (_) => _clearTemplate(),
            ),
            for (final t in reelTemplates)
              ChoiceChip(
                label: Text(t.name),
                selected: _templateId == t.id,
                selectedColor: HamsiqTheme.accent,
                backgroundColor: HamsiqTheme.panel2,
                onSelected: (_) => _applyTemplate(t),
              ),
          ],
        ),
        if (_templateId != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              templateById(_templateId)?.descriptionAr ?? '',
              style: const TextStyle(
                color: HamsiqTheme.muted,
                fontSize: 12,
              ),
            ),
          ),
        const SizedBox(height: 20),
        // ---- text overlays ----
        Row(
          children: [
            Text(
              AppStrings.t('overlaysTitle'),
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const Spacer(),
            Text(
              AppStrings.t('reelTapToPlace'),
              style: const TextStyle(
                color: HamsiqTheme.muted,
                fontSize: 12,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _overlayText,
          decoration: InputDecoration(
            hintText: AppStrings.t('reelTextHint'),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Text(AppStrings.t('colourLabel'), style: TextStyle(fontSize: 13)),
            const SizedBox(width: 8),
            for (final color in _overlayColors)
              GestureDetector(
                onTap: () => setState(() => _draftColor = color),
                child: Container(
                  width: 28,
                  height: 28,
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  decoration: BoxDecoration(
                    color: Color(color),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _draftColor == color
                          ? HamsiqTheme.accent
                          : Colors.white38,
                      width: _draftColor == color ? 3 : 1,
                    ),
                  ),
                ),
              ),
            const Spacer(),
            Text(AppStrings.t('sizeLabel'), style: TextStyle(fontSize: 13)),
            SizedBox(
              width: 130,
              child: Slider(
                value: _draftSize,
                min: 14,
                max: 48,
                divisions: 17,
                activeColor: HamsiqTheme.accent,
                onChanged: (v) => setState(() => _draftSize = v),
              ),
            ),
          ],
        ),
        Row(
          children: [
            Expanded(
              child: _SecondsField(
                label: AppStrings.t('reelStartSec'),
                value: _draftStart,
                max: _durationSec,
                onChanged: (v) => setState(() => _draftStart = v),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _SecondsField(
                label: AppStrings.t('reelEndSec'),
                value: _draftEnd,
                max: _durationSec,
                onChanged: (v) => setState(() => _draftEnd = v),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            ElevatedButton.icon(
              onPressed: _saveDraftOverlay,
              icon: Icon(
                _editingIndex == null ? Icons.add : Icons.check,
              ),
              label: Text(
                _editingIndex == null
                    ? AppStrings.t('reelAddText')
                    : AppStrings.t('saveEdit'),
              ),
            ),
            if (_editingIndex != null) ...[
              const SizedBox(width: 8),
              TextButton(
                onPressed: _resetDraft,
                child: Text(AppStrings.t('cancel')),
              ),
            ],
          ],
        ),
        if (_overlays.isNotEmpty) ...[
          const SizedBox(height: 8),
          for (var i = 0; i < _overlays.length; i++)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(
                Icons.text_fields,
                color: HamsiqTheme.accent,
              ),
              title: Text(
                _overlays[i].text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              subtitle: Text(
                '${_overlays[i].startSec.toStringAsFixed(1)}–${_overlays[i].endSec.toStringAsFixed(1)} ${AppStrings.t('secAbbr')} · ${AppStrings.t('sizeLabel')} ${_overlays[i].size.toInt()}',
                style: const TextStyle(color: HamsiqTheme.muted),
              ),
              trailing: IconButton(
                icon: const Icon(
                  Icons.delete_outline,
                  color: Colors.redAccent,
                ),
                onPressed: () => _deleteOverlay(i),
              ),
              selected: _editingIndex == i,
              onTap: () => _loadDraftForEdit(i),
            ),
        ],
        const SizedBox(height: 20),
        // ---- voiceover ----
        Text(
          AppStrings.t('reelVoiceover'),
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        const SizedBox(height: 4),
        Text(
          AppStrings.t('reelVoiceoverNote'),
          style: const TextStyle(color: HamsiqTheme.muted, fontSize: 12),
        ),
        const SizedBox(height: 8),
        if (_recording)
          Row(
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: const BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '${AppStrings.t('recordingNow')} $_recSeconds ${AppStrings.t('secAbbr')}...',
                style: const TextStyle(color: Colors.red),
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: () => _stopVoiceover(keep: true),
                child: Text(AppStrings.t('reelStopVoiceover')),
              ),
              const SizedBox(width: 8),
              TextButton(
                onPressed: () => _stopVoiceover(keep: false),
                child: Text(
                  AppStrings.t('cancel'),
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          )
        else if (_voiceoverBytes != null)
          Row(
            children: [
              IconButton(
                onPressed: _toggleVoicePreview,
                icon: Icon(
                  _voicePlaying ? Icons.pause : Icons.play_arrow,
                  color: HamsiqTheme.accent,
                ),
              ),
              Expanded(
                child: Text(
                  '${AppStrings.t('recordedVoiceover')} ($_voiceoverSeconds ${AppStrings.t('secAbbr')})',
                ),
              ),
              IconButton(
                icon: const Icon(
                  Icons.delete_outline,
                  color: Colors.redAccent,
                ),
                onPressed: _deleteVoiceover,
              ),
              TextButton(
                onPressed: _startVoiceover,
                child: Text(AppStrings.t('rerecord')),
              ),
            ],
          )
        else
          ElevatedButton.icon(
            onPressed: _startVoiceover,
            style: ElevatedButton.styleFrom(
              backgroundColor: HamsiqTheme.panel2,
              foregroundColor: Colors.white,
            ),
            icon: const Icon(Icons.mic),
            label: Text(AppStrings.t('reelRecordVoiceover')),
          ),
        const SizedBox(height: 24),
        ElevatedButton(
          onPressed: _busy ? null : _publish,
          child: _busy
              ? const SizedBox(
                  height: 18,
                  width: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : Text(AppStrings.t('reelPublish')),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildPreview(
    VideoPlayerController? c,
    bool isPlaying,
  ) {
    final size = c?.value.size;
    Widget videoArea;
    if (_videoFailed) {
      videoArea = Container(
        color: HamsiqTheme.bgDeep,
        alignment: Alignment.center,
        child: Text(
          AppStrings.t('videoPlayFailed'),
          style: TextStyle(color: HamsiqTheme.muted),
        ),
      );
    } else if (c == null || !c.value.isInitialized || size == null) {
      videoArea = Container(
        color: HamsiqTheme.bgDeep,
        alignment: Alignment.center,
        child: const LoadingCenter(),
      );
    } else {
      videoArea = SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: size.width,
            height: size.height,
            child: VideoPlayer(c),
          ),
        ),
      );
    }

    // Overlays visible right now render fully; the draft overlay and
    // out-of-window overlays render faded so placement stays visible.
    final visible = overlaysVisibleAt(_overlays, _positionSec);
    return LayoutBuilder(
      builder: (context, constraints) {
        final previewSize = Size(constraints.maxWidth, 380);
        return GestureDetector(
          onTapDown: (d) => _onPreviewTap(d, previewSize),
          child: Container(
            height: 380,
            width: double.infinity,
            decoration: BoxDecoration(
              color: HamsiqTheme.bgDeep,
              borderRadius: BorderRadius.circular(12),
            ),
            clipBehavior: Clip.hardEdge,
            child: Stack(
              children: [
                videoArea,
                for (final o in _overlays)
                  Positioned(
                    left: o.x * previewSize.width - 60,
                    top: o.y * previewSize.height - 20,
                    width: 120,
                    child: Opacity(
                      opacity: visible.contains(o) ? 1.0 : 0.35,
                      child: Text(
                        o.text,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(o.color),
                          fontSize: o.size,
                          fontWeight: FontWeight.bold,
                          shadows: const [
                            Shadow(
                              color: Colors.black87,
                              blurRadius: 4,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                // Draft overlay marker (the text being edited now).
                if (_overlayText.text.isNotEmpty)
                  Positioned(
                    left: _draftX * previewSize.width - 60,
                    top: _draftY * previewSize.height - 20,
                    width: 120,
                    child: Text(
                      _overlayText.text,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color(_draftColor),
                        fontSize: _draftSize,
                        fontWeight: FontWeight.bold,
                        shadows: const [
                          Shadow(color: Colors.black87, blurRadius: 4),
                        ],
                      ),
                    ),
                  ),
                if (!isPlaying)
                  const Center(
                    child: CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.black45,
                      child: Icon(
                        Icons.play_arrow,
                        size: 40,
                        color: Colors.white,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Small seconds input for overlay start/end times.
class _SecondsField extends StatelessWidget {
  final String label;
  final double value;
  final double max;
  final ValueChanged<double> onChanged;
  const _SecondsField({
    required this.label,
    required this.value,
    required this.max,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    // keyed by value so the field refreshes when start/end change
    // from elsewhere (template apply, reset).
    return TextFormField(
      key: ValueKey(value),
      initialValue: value.toStringAsFixed(1),
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(labelText: label),
      onFieldSubmitted: (s) {
        final v = double.tryParse(s);
        if (v == null) return;
        onChanged(v.clamp(0.0, max > 0 ? max : 999));
      },
    );
  }
}
