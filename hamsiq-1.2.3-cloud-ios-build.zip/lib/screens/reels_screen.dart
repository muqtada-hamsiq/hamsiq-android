// Hamsiq native — Reels screen (Phase 1).
// Full-screen vertical video player. Real rows only, from Api.fetchFeed().
// One VideoPlayerController plays at a time (the current page), but the
// immediate neighbours (index ± 1) are preloaded in the background
// (H-07b fix 2026-11-16): swiping to a neighbouring reel shows its
// first frame at once instead of a dark placeholder. Only immediate
// neighbours are kept — anything further away is disposed — so memory
// stays bounded at three controllers max. A video that fails to
// initialize shows a dark tile with the caption instead of crashing.

import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../models.dart';
import '../services/app_strings.dart';
import '../services/comments_api.dart';
import '../services/media_api.dart';
import '../services/supabase_service.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/comments_sheet.dart';
import '../widgets/shared_post_card.dart';
import 'reels_editor_screen.dart';

class ReelsScreen extends StatefulWidget {
  const ReelsScreen({super.key});

  @override
  State<ReelsScreen> createState() => _ReelsScreenState();
}

class _ReelsScreenState extends State<ReelsScreen> {
  List<PostItem>? _reels;
  Map<int, int> _commentCounts = {};
  String? _loadError;
  int _current = 0;
  VideoPlayerController? _controller;
  bool _initialized = false;
  bool _failed = false;
  bool _isPlaying = false;
  bool _muted = false;
  final _pageController = PageController();
  // H-07b: preloaded neighbour controllers (immediate neighbours only,
  // index _current ± 1). _preloadInitialized / _preloadFailed track
  // which neighbours finished initialising; _preloading guards against
  // starting the same neighbour twice.
  final Map<int, VideoPlayerController> _preloadControllers = {};
  final Set<int> _preloadInitialized = {};
  final Set<int> _preloadFailed = {};
  final Set<int> _preloading = {};
  // Wave 3: timed text overlays + voiceover playback for the current
  // reel (posts.reel_text_overlays / reel_voiceover_url, sql-v31).
  // The overlay clock ticks 3x/second from the video position; the
  // voiceover is a plain AudioPlayer looped with the video.
  final _voicePlayer = AudioPlayer();
  Timer? _overlayTimer;
  double _positionSec = 0;

  // Generation guard for the async re-sign in _initController: a
  // newer init (user swiped while a re-sign was in flight)
  // invalidates the older one, so a stale controller can never
  // overwrite the current page's.
  int _initGen = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final feed = await Api.fetchFeed(limit: 60);
      if (!mounted) return;
      final reels = feed
          .where((p) =>
              (p.isReel || p.mediaType == 'video') &&
              p.mediaUrl != null &&
              p.mediaUrl!.isNotEmpty)
          .toList();
      // Comment counts are nice-to-have: a failure here must not hide
      // the reels themselves.
      var counts = <int, int>{};
      try {
        counts = await CommentsApi.fetchCommentCounts(
          reels.map((p) => p.id).toList(),
        );
      } catch (_) {
        counts = {for (final p in reels) p.id: 0};
      }
      setState(() {
        _reels = reels;
        _commentCounts = counts;
        _loadError = null;
      });
      // H-07b: the feed is new, so any preloaded controllers belong to
      // the old feed — drop them before initialising the first page.
      _clearPreloads();
      if (reels.isNotEmpty) {
        _initController(0);
        _preloadAdjacent();
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _loadError = e.toString().replaceFirst('Exception: ', ''));
    }
  }

  void _onVideoState() {
    final c = _controller;
    if (c == null || !mounted) return;
    if (c.value.isPlaying != _isPlaying) {
      setState(() => _isPlaying = c.value.isPlaying);
    }
  }

  /// Attach the initialise-completion handlers for a controller, once,
  /// at creation time. The same handlers serve both roles a controller
  /// can be in: the current page (promote to playing) and a preloaded
  /// neighbour (mark ready so its first frame renders). A controller
  /// that is adopted as current while still initialising is promoted
  /// by this same handler when its future completes — no second
  /// initialize() call is ever made.
  void _attachInitHandlers(
    VideoPlayerController c,
    int index,
    Future<void> fut,
    PostItem post,
  ) {
    fut.then((_) {
      if (!mounted) return;
      _preloading.remove(index);
      if (identical(_controller, c) && _current == index) {
        setState(() => _initialized = true);
        c.play();
        _startVoiceoverFor(post);
        _startOverlayClock();
        return;
      }
      // Parked as a preloaded neighbour while still initialising
      // (fast swipe): mark it ready so its first frame renders.
      if (_preloadControllers[index] == c) {
        setState(() => _preloadInitialized.add(index));
      }
    }).catchError((_) {
      if (!mounted) return;
      _preloading.remove(index);
      if (identical(_controller, c) && _current == index) {
        setState(() => _failed = true);
        return;
      }
      if (_preloadControllers[index] == c) {
        setState(() {
          _preloadFailed.add(index);
          _preloadInitialized.remove(index);
        });
      }
    });
  }

  Future<void> _initController(int index) async {
    final gen = ++_initGen;
    final reels = _reels;
    if (reels == null || index < 0 || index >= reels.length) return;
    final post = reels[index];

    // Dispose the previous page's controller first — unless
    // _onPageChanged already parked it in the preload cache, in which
    // case _controller is already null here.
    _disposeController();

    // H-07b fast path: this page was preloaded as a neighbour, so its
    // controller already exists — adopt it and play at once instead of
    // creating + initialising a new one (which is what used to show a
    // dark placeholder on every swipe). A preloaded neighbour that
    // FAILED to initialise is NOT adopted: it is disposed and a fresh
    // controller is created below (one retry), otherwise the page
    // would sit on a spinner forever.
    final preloaded = _preloadControllers.remove(index);
    if (preloaded != null && !_preloadFailed.contains(index)) {
      final wasReady = _preloadInitialized.remove(index);
      _preloadFailed.remove(index);
      _preloading.remove(index);
      _controller = preloaded;
      _initialized = wasReady;
      _failed = false;
      _isPlaying = false;
      preloaded.addListener(_onVideoState);
      preloaded.setLooping(true);
      preloaded.setVolume(_muted ? 0 : 1);
      if (wasReady) {
        preloaded.play();
        _startVoiceoverFor(post);
        _startOverlayClock();
      }
      // If it was NOT ready yet, the completion handler attached at
      // preload time promotes it (identical(_controller, c) branch).
      return;
    }
    if (preloaded != null) {
      _preloadInitialized.remove(index);
      _preloadFailed.remove(index);
      _preloading.remove(index);
      preloaded.dispose();
    }

    // H-04 re-sign-on-render: re-sign BEFORE creating the video
    // controller, via the server-side resign-media function, so a
    // reel uploaded >1h ago still plays for every viewer.
    // Best-effort: on failure ensureFreshUrl returns the stored URL
    // and playback tries it as-is. The generation + page guard
    // drops this init if the user swiped on while it was in flight.
    final fresh = await MediaApi.ensureFreshUrl(post.mediaUrl!);
    if (!mounted || gen != _initGen || _current != index) return;
    final c = VideoPlayerController.networkUrl(Uri.parse(fresh));
    _controller = c;
    _initialized = false;
    _failed = false;
    _isPlaying = false;
    c.addListener(_onVideoState);
    c.setLooping(true);
    c.setVolume(_muted ? 0 : 1);
    _attachInitHandlers(c, index, c.initialize(), post);
  }

  /// H-07b: initialise the controller for a neighbouring page in the
  /// background, so swiping to it shows its first frame at once.
  /// Never starts the current page, an already-cached neighbour, or a
  /// neighbour whose initialise is already running.
  Future<void> _createPreloadController(int index) async {
    final reels = _reels;
    if (reels == null || index < 0 || index >= reels.length) return;
    if (index == _current) return;
    if (_preloadControllers.containsKey(index) ||
        _preloading.contains(index)) {
      return;
    }
    final post = reels[index];
    // H-04 re-sign-on-render: re-sign BEFORE creating the neighbour
    // controller, same as the current page. The neighbour guard
    // drops this preload if the user swiped past it while the
    // re-sign was in flight (its controller would only be pruned
    // on the next _preloadAdjacent otherwise).
    _preloading.add(index);
    final fresh = await MediaApi.ensureFreshUrl(post.mediaUrl!);
    if (!mounted ||
        _preloadControllers.containsKey(index) ||
        index == _current ||
        (_current - index).abs() != 1) {
      _preloading.remove(index);
      return;
    }
    final c = VideoPlayerController.networkUrl(Uri.parse(fresh));
    _preloadControllers[index] = c;
    _preloading.add(index);
    c.setLooping(true);
    c.setVolume(_muted ? 0 : 1);
    _attachInitHandlers(c, index, c.initialize(), post);
  }

  /// H-07b: keep controllers only for the immediate neighbours
  /// (_current ± 1) — anything further away is disposed — and start
  /// initialising any neighbour that has none yet. At most three
  /// controllers exist at once: the current page + two neighbours.
  void _preloadAdjacent() {
    final reels = _reels;
    if (reels == null) return;
    final wanted = <int>{
      if (_current - 1 >= 0) _current - 1,
      if (_current + 1 < reels.length) _current + 1,
    };
    // Prune: dispose cached controllers that are no longer neighbours.
    for (final i in _preloadControllers.keys.toList()) {
      if (!wanted.contains(i)) _disposePreload(i);
    }
    for (final i in wanted) {
      _createPreloadController(i);
    }
  }

  /// Dispose one preloaded neighbour controller and forget its state.
  void _disposePreload(int index) {
    final c = _preloadControllers.remove(index);
    _preloadInitialized.remove(index);
    _preloadFailed.remove(index);
    _preloading.remove(index);
    c?.dispose();
  }

  /// Dispose every preloaded neighbour controller (feed reloaded, or
  /// the screen is going away) and forget their state.
  void _clearPreloads() {
    for (final i in _preloadControllers.keys.toList()) {
      _disposePreload(i);
    }
  }

  /// Wave 3: start the reel's recorded voiceover (if any), looped with
  /// the video. Stopped on page change / dispose; volume follows mute.
  Future<void> _startVoiceoverFor(PostItem post) async {
    final url = post.reelVoiceoverUrl;
    if (url == null || url.isEmpty) return;
    // H-04 re-sign-on-render: the voiceover is a private-media
    // signed URL too — re-sign BEFORE play(), and drop it if the
    // user swiped to another reel while the re-sign was in flight.
    final fresh = await MediaApi.ensureFreshUrl(url);
    if (!mounted) return;
    final reels = _reels;
    if (reels == null ||
        _current < 0 ||
        _current >= reels.length ||
        reels[_current].id != post.id) {
      return;
    }
    try {
      await _voicePlayer.setReleaseMode(ReleaseMode.loop);
      await _voicePlayer.setVolume(_muted ? 0 : 1);
      await _voicePlayer.play(UrlSource(fresh));
    } catch (_) {
      // A failed voiceover must never break the reel itself.
    }
  }

  Future<void> _stopVoiceover() async {
    try {
      await _voicePlayer.stop();
    } catch (_) {}
  }

  /// Wave 3: 3x/second clock so timed text overlays appear/disappear
  /// at the right second. Only rebuilds when the position moved.
  void _startOverlayClock() {
    _overlayTimer?.cancel();
    _overlayTimer = Timer.periodic(const Duration(milliseconds: 300), (_) {
      final c = _controller;
      if (!mounted || c == null || !c.value.isInitialized) return;
      final pos = c.value.position.inMilliseconds / 1000.0;
      if ((pos - _positionSec).abs() > 0.05) {
        setState(() => _positionSec = pos);
      }
    });
  }

  void _disposeController() {
    final c = _controller;
    _controller = null;
    _overlayTimer?.cancel();
    _overlayTimer = null;
    _stopVoiceover();
    if (c == null) return;
    c.removeListener(_onVideoState);
    c.pause();
    c.dispose();
  }

  void _onPageChanged(int index) {
    if (index == _current) return;
    final previous = _current;
    // Park the outgoing controller in the preload cache (paused)
    // instead of disposing it, so swiping straight back is instant
    // too. Only a one-page move can park: a further jump, or an
    // outgoing reel that never finished initialising, is disposed
    // (its completion handler then no-ops — it is neither the current
    // controller nor in the preload cache).
    final outgoing = _controller;
    _controller = null;
    _overlayTimer?.cancel();
    _overlayTimer = null;
    _stopVoiceover();
    if (outgoing != null) {
      outgoing.removeListener(_onVideoState);
      outgoing.pause();
      if ((index - previous).abs() == 1 && _initialized) {
        _preloadControllers[previous] = outgoing;
        _preloadInitialized.add(previous);
        _preloadFailed.remove(previous);
      } else {
        outgoing.dispose();
      }
    }
    setState(() {
      _current = index;
      _initialized = false;
      _failed = false;
      _isPlaying = false;
    });
    _initController(index);
    _preloadAdjacent();
  }

  void _togglePlayPause(int index) {
    if (index != _current) return;
    final c = _controller;
    if (c == null || !_initialized || _failed) return;
    if (c.value.isPlaying) {
      c.pause();
      _voicePlayer.pause();
    } else {
      c.play();
      _voicePlayer.resume();
    }
  }

  void _toggleMute() {
    setState(() => _muted = !_muted);
    _controller?.setVolume(_muted ? 0 : 1);
    _voicePlayer.setVolume(_muted ? 0 : 1);
  }

  /// Wave 3: open the Reels editor (text overlays / voiceover /
  /// templates); reload the feed when a reel is published.
  Future<void> _openEditor() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ReelsEditorScreen(onPublished: _load),
      ),
    );
    if (mounted) _load();
  }

  Future<void> _toggleLike(PostItem post) async {
    final wasLiked = post.likedByMe;
    final wasCount = post.likeCount;
    setState(() {
      post.likedByMe = !wasLiked;
      post.likeCount = wasLiked ? wasCount - 1 : wasCount + 1;
    });
    try {
      await Api.setLiked(post.id, !wasLiked);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        post.likedByMe = wasLiked;
        post.likeCount = wasCount;
      });
      showError(context, e);
    }
  }

  /// v1.2.1: Instagram-style comments — the bottom sheet opens OVER
  /// the reel (no navigation into the post detail screen).
  Future<void> _openComments(PostItem post) async {
    await showCommentsSheet(context, post);
    // Likes/comments may have changed in the sheet; refresh counts.
    if (!mounted) return;
    final reels = _reels;
    if (reels == null) return;
    try {
      final counts = await CommentsApi.fetchCommentCounts(
        reels.map((p) => p.id).toList(),
      );
      if (!mounted) return;
      setState(() => _commentCounts = counts);
    } catch (_) {
      // Keep the old counts; the feed reload will retry them.
    }
  }

  @override
  void dispose() {
    _disposeController();
    _clearPreloads();
    _voicePlayer.dispose();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // H-06 Part 2: live language rebuild on language change.
    return ValueListenableBuilder<String>(
      valueListenable: AppStrings.lang,
      builder: (context, _, __) => _build(context),
    );
  }

  Widget _build(BuildContext context) {
    if (_loadError != null) {
      return Scaffold(
        backgroundColor: HamsiqTheme.bgDeep,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                _loadError!,
                style: const TextStyle(color: HamsiqTheme.muted, fontSize: 15),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _loadError = null;
                    _reels = null;
                  });
                  _load();
                },
                child: Text(AppStrings.t('retry')),
              ),
            ],
          ),
        ),
      );
    }

    final reels = _reels;
    if (reels == null) {
      return const Scaffold(
        backgroundColor: HamsiqTheme.bgDeep,
        body: LoadingCenter(),
      );
    }
    if (reels.isEmpty) {
      return Scaffold(
        backgroundColor: HamsiqTheme.bgDeep,
        body: EmptyCenter(AppStrings.t('noReelsYet')),
      );
    }

    return Scaffold(
      backgroundColor: HamsiqTheme.bgDeep,
      body: Stack(
        children: [
          PageView.builder(
            controller: _pageController,
            scrollDirection: Axis.vertical,
            itemCount: reels.length,
            onPageChanged: _onPageChanged,
            itemBuilder: (context, index) => _buildPage(reels[index], index),
          ),
          // Wave 3: create a reel in the editor (top-left).
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            left: 12,
            child: IconButton(
              onPressed: _openEditor,
              tooltip: AppStrings.t('createReel'),
              icon: const Icon(
                Icons.movie_creation_outlined,
                color: Colors.white,
                size: 26,
              ),
              style: IconButton.styleFrom(
                backgroundColor: Colors.black45,
              ),
            ),
          ),
          // Mute / unmute — top-right, acts on the current controller.
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            right: 12,
            child: IconButton(
              onPressed: _toggleMute,
              icon: Icon(
                _muted ? Icons.volume_off : Icons.volume_up,
                color: Colors.white,
                size: 26,
              ),
              style: IconButton.styleFrom(
                backgroundColor: Colors.black45,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPage(PostItem post, int index) {
    final isCurrent = index == _current;
    final c = isCurrent ? _controller : null;

    Widget videoArea;
    if (!isCurrent) {
      // H-07b: a preloaded neighbour renders its first frame (paused)
      // instead of a dark placeholder; a neighbour still initialising
      // shows a spinner, and a failed one shows the failed tile.
      final preloaded = _preloadControllers[index];
      if (preloaded != null && _preloadInitialized.contains(index)) {
        final size = preloaded.value.size;
        videoArea = SizedBox.expand(
          child: FittedBox(
            fit: BoxFit.cover,
            child: SizedBox(
              width: size.width,
              height: size.height,
              child: VideoPlayer(preloaded),
            ),
          ),
        );
      } else if (_preloadFailed.contains(index)) {
        videoArea = Container(
          color: HamsiqTheme.bgDeep,
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.play_circle_outline,
                  size: 64,
                  color: HamsiqTheme.muted,
                ),
                const SizedBox(height: 12),
                Text(
                  AppStrings.t('videoPlayFailed'),
                  style: const TextStyle(color: HamsiqTheme.muted, fontSize: 15),
                ),
              ],
            ),
          ),
        );
      } else {
        videoArea = Container(
          color: HamsiqTheme.bgDeep,
          child: const Center(
            child: CircularProgressIndicator(color: HamsiqTheme.accent),
          ),
        );
      }
    } else if (_failed) {
      videoArea = Container(
        color: HamsiqTheme.bgDeep,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.play_circle_outline,
                size: 64,
                color: HamsiqTheme.muted,
              ),
              const SizedBox(height: 12),
              Text(
                AppStrings.t('videoPlayFailed'),
                style: const TextStyle(color: HamsiqTheme.muted, fontSize: 15),
              ),
            ],
          ),
        ),
      );
    } else if (!_initialized || c == null) {
      videoArea = Container(
        color: HamsiqTheme.bgDeep,
        child: const LoadingCenter(),
      );
    } else {
      final size = c.value.size;
      videoArea = SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: size.width,
            height: size.height,
            child: VideoPlayer(c),
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: () => _togglePlayPause(index),
      child: Stack(
        fit: StackFit.expand,
        children: [
          videoArea,
          // Wave 3: timed text overlays on the current reel — shown
          // only while the video position is inside each overlay's
          // start/end window (posts.reel_text_overlays, sql-v31).
          if (isCurrent && _initialized && !_failed)
            for (final o in post.reelTextOverlays)
              if (o.visibleAt(_positionSec))
                Positioned(
                  left: o.x * MediaQuery.of(context).size.width - 60,
                  top: o.y * MediaQuery.of(context).size.height - 20,
                  width: 120,
                  child: Text(
                    o.text,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(o.color),
                      fontSize: o.size,
                      fontWeight: FontWeight.bold,
                      shadows: const [
                        Shadow(color: Colors.black87, blurRadius: 4),
                      ],
                    ),
                  ),
                ),
          // Paused overlay: centered play icon.
          if (isCurrent && _initialized && !_failed && !_isPlaying)
            const Center(
              child: CircleAvatar(
                radius: 36,
                backgroundColor: Colors.black45,
                child: Icon(
                  Icons.play_arrow,
                  size: 48,
                  color: Colors.white,
                ),
              ),
            ),
          // Bottom overlay: author row + caption.
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(
                16,
                32,
                16,
                MediaQuery.of(context).padding.bottom + 16,
              ),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.black87],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      AvatarWidget(profile: post.author, size: 36),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Row(
                          children: [
                            Flexible(
                              child: Text(
                                post.author?.displayName ?? '',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (post.author?.verified == true) ...[
                              const SizedBox(width: 4),
                              const VerifiedTick(),
                            ],
                            const SizedBox(width: 8),
                            Text(
                              timeAgo(post.createdAt),
                              style: const TextStyle(
                                color: HamsiqTheme.muted,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  if (post.caption.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      post.caption,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                      ),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                  // Wave 3: voiceover badge — this reel has a recorded
                  // voiceover playing with the video.
                  if (post.reelVoiceoverUrl != null &&
                      post.reelVoiceoverUrl!.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.mic, size: 14, color: HamsiqTheme.accent),
                        const SizedBox(width: 4),
                        Text(
                          AppStrings.t('reelVoiceover'),
                          style: const TextStyle(
                            color: HamsiqTheme.accent,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),
          // Right-side action rail: like + comments (above the caption
          // overlay so the buttons stay tappable; taps here do not reach
          // the page GestureDetector below).
          Positioned(
            right: 8,
            bottom: 170,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  onPressed: () => _toggleLike(post),
                  icon: Icon(
                    post.likedByMe
                        ? Icons.favorite
                        : Icons.favorite_border,
                    color: post.likedByMe
                        ? HamsiqTheme.accent
                        : Colors.white,
                    size: 30,
                  ),
                ),
                Text(
                  '${post.likeCount}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 12),
                IconButton(
                  onPressed: () => _openComments(post),
                  icon: const Icon(
                    Icons.chat_bubble_outline,
                    color: Colors.white,
                    size: 30,
                  ),
                ),
                Text(
                  '${_commentCounts[post.id] ?? 0}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 12),
                // Wave 1: paper-plane share on the rail only — opens the
                // people picker and sends the Reel into a DM.
                IconButton(
                  onPressed: () => showSharePostSheet(context, post),
                  icon: const Icon(
                    Icons.send_outlined,
                    color: Colors.white,
                    size: 30,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
