// Hamsiq native — in-app camera screen (Phase 2, workstream D).
// Real camera via the `camera` package (already in pubspec.yaml;
// CAMERA + RECORD_AUDIO are declared in AndroidManifest.xml).
//
// The screen NEVER uploads: on capture it hands the file to [onCaptured]
// and the caller decides what to do with it (story, post, ...). The
// caller is also responsible for popping this route after handling the
// file — the screen stays on the live preview until then.
//
// Permission denial and init failure are shown as friendly Arabic
// states with retry + a gallery fallback, never a crash or blank screen.

import 'dart:async';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import '../services/app_strings.dart';
import '../theme.dart';

/// In-app camera: live preview, photo capture, video recording (max 60s),
/// front/back switch, flash toggle, tap-to-focus.
///
/// ```dart
/// Navigator.of(context).push(MaterialPageRoute(
///   builder: (_) => CameraScreen(
///     onCaptured: (file, isVideo) {
///       Navigator.of(context).pop(); // caller pops
///       uploadAndPublish(file, isVideo);
///     },
///     onUseGallery: () => pickFromGallery(), // permission denied fallback
///   ),
/// ));
/// ```
class CameraScreen extends StatefulWidget {
  /// Called with the captured file. `isVideo` is true for a video clip.
  final void Function(XFile file, bool isVideo) onCaptured;

  /// Show the video mode. Set false when only a photo is wanted.
  final bool allowVideo;

  /// Called when the user taps "use gallery" on the permission-denied
  /// state (the caller opens image_picker). Optional.
  final VoidCallback? onUseGallery;

  const CameraScreen({
    super.key,
    required this.onCaptured,
    this.allowVideo = true,
    this.onUseGallery,
  });

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen>
    with WidgetsBindingObserver {
  static const _maxVideo = Duration(seconds: 60);

  CameraController? _controller;
  List<CameraDescription> _cameras = [];
  int _cameraIndex = 0;
  bool _initializing = true;
  bool _permissionDenied = false;
  String? _error;
  bool _disposed = false;

  FlashMode _flash = FlashMode.off;
  bool _isVideoMode = false;
  bool _busy = false; // taking a photo / starting / stopping
  bool _recording = false;
  DateTime? _recordStartedAt;
  Duration _recordElapsed = Duration.zero;
  Timer? _recordTimer;
  Offset? _focusPoint; // relative 0..1 inside the preview, or null
  Timer? _focusTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initCamera();
  }

  @override
  void dispose() {
    _disposed = true;
    WidgetsBinding.instance.removeObserver(this);
    _stopRecordTimer();
    _focusTimer?.cancel();
    _disposeController();
    super.dispose();
  }

  /// Pause the camera when the app goes to background (Android kills the
  /// camera session otherwise) and re-open it on return.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive) {
      if (_recording) {
        // Stop the clip first so the file is not lost.
        unawaited(_stopRecording());
      }
      _disposeController();
    } else if (state == AppLifecycleState.resumed) {
      if (_controller == null && !_permissionDenied && _error == null) {
        _initCamera();
      }
    }
    super.didChangeAppLifecycleState(state);
  }

  void _disposeController() {
    final c = _controller;
    _controller = null;
    if (c == null) return;
    // ignore: discarded_futures — fire-and-forget dispose is fine here.
    c.dispose();
  }

  Future<void> _initCamera() async {
    if (_disposed) return;
    setState(() {
      _initializing = true;
      _permissionDenied = false;
      _error = null;
    });
    try {
      final cameras = await availableCameras();
      if (_disposed) return;
      if (cameras.isEmpty) {
        setState(() {
          _initializing = false;
          _error = AppStrings.t('cameraNoCamera');
        });
        return;
      }
      _cameras = cameras;
      // Prefer the back camera first, like every camera app.
      _cameraIndex = cameras.indexWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
      );
      if (_cameraIndex < 0) _cameraIndex = 0;
      await _openCamera(_cameras[_cameraIndex]);
    } on CameraException catch (e) {
      if (_disposed) return;
      setState(() {
        _initializing = false;
        if (e.code == 'CameraAccessDenied') {
          _permissionDenied = true;
        } else {
          _error = '${AppStrings.t('cameraOpenFailed')} (${e.description ?? e.code})';
        }
      });
    } catch (e) {
      if (_disposed) return;
      setState(() {
        _initializing = false;
        _error = AppStrings.t('cameraOpenFailed');
      });
    }
  }

  Future<void> _openCamera(CameraDescription description) async {
    _disposeController();
    final controller = CameraController(
      description,
      ResolutionPreset.high,
      enableAudio: true,
    );
    _controller = controller;
    try {
      await controller.initialize();
      await controller.setFlashMode(_flash);
    } on CameraException catch (e) {
      if (_disposed) return;
      _disposeController();
      setState(() {
        _initializing = false;
        if (e.code == 'CameraAccessDenied') {
          _permissionDenied = true;
        } else {
          _error = '${AppStrings.t('cameraOpenFailed')} (${e.description ?? e.code})';
        }
      });
      return;
    }
    if (_disposed) return;
    setState(() => _initializing = false);
  }

  Future<void> _switchCamera() async {
    if (_cameras.length < 2 || _busy || _recording) return;
    setState(() {
      _busy = true;
      _initializing = true;
    });
    _cameraIndex = (_cameraIndex + 1) % _cameras.length;
    try {
      await _openCamera(_cameras[_cameraIndex]);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggleFlash() async {
    final c = _controller;
    if (c == null || !c.value.isInitialized) return;
    final next = _flash == FlashMode.off
        ? FlashMode.auto
        : _flash == FlashMode.auto
            ? FlashMode.always
            : FlashMode.off;
    try {
      await c.setFlashMode(next);
      if (mounted) setState(() => _flash = next);
    } catch (_) {
      // Some devices have no flash — ignore silently.
    }
  }

  Future<void> _onTapFocus(TapDownDetails details, Size previewSize) async {
    final c = _controller;
    if (c == null || !c.value.isInitialized) return;
    final dx = (details.localPosition.dx / previewSize.width).clamp(0.0, 1.0);
    final dy = (details.localPosition.dy / previewSize.height).clamp(0.0, 1.0);
    final point = Offset(dx, dy);
    try {
      await c.setFocusPoint(point);
      await c.setExposurePoint(point);
    } catch (_) {
      // Focus not supported on this device — ignore.
    }
    if (!mounted) return;
    _focusTimer?.cancel();
    setState(() => _focusPoint = point);
    _focusTimer = Timer(const Duration(seconds: 1), () {
      if (mounted) setState(() => _focusPoint = null);
    });
  }

  Future<void> _takePhoto() async {
    final c = _controller;
    if (c == null || !c.value.isInitialized || _busy || _recording) return;
    setState(() => _busy = true);
    try {
      final file = await c.takePicture();
      widget.onCaptured(file, false);
    } on CameraException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${AppStrings.t('photoCaptureFailed')} (${e.code})')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggleRecording() async {
    if (_recording) {
      await _stopRecording();
    } else {
      await _startRecording();
    }
  }

  Future<void> _startRecording() async {
    final c = _controller;
    if (c == null || !c.value.isInitialized || _busy || _recording) return;
    setState(() => _busy = true);
    try {
      await c.startVideoRecording();
      if (!mounted) return;
      setState(() {
        _busy = false;
        _recording = true;
        _recordStartedAt = DateTime.now();
        _recordElapsed = Duration.zero;
      });
      _recordTimer = Timer.periodic(const Duration(milliseconds: 250), (_) {
        final started = _recordStartedAt;
        if (started == null) return;
        final elapsed = DateTime.now().difference(started);
        if (!mounted) return;
        if (elapsed >= _maxVideo) {
          unawaited(_stopRecording());
          return;
        }
        setState(() => _recordElapsed = elapsed);
      });
    } on CameraException catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${AppStrings.t('recordStartFailed')} (${e.code})')),
        );
      }
    }
  }

  Future<void> _stopRecording() async {
    final c = _controller;
    if (c == null || !_recording) return;
    _stopRecordTimer();
    setState(() => _busy = true);
    try {
      final file = await c.stopVideoRecording();
      widget.onCaptured(file, true);
    } on CameraException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${AppStrings.t('recordStopFailed')} (${e.code})')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _recording = false;
          _recordStartedAt = null;
          _recordElapsed = Duration.zero;
        });
      }
    }
  }

  void _stopRecordTimer() {
    _recordTimer?.cancel();
    _recordTimer = null;
  }

  String _formatElapsed(Duration d) {
    final s = d.inSeconds;
    return '${(s ~/ 60).toString().padLeft(2, '0')}:${(s % 60).toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: _initializing
            ? _stateBody(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: HamsiqTheme.accent),
                    SizedBox(height: 16),
                    Text(AppStrings.t('cameraOpening'),
                        style: TextStyle(color: Colors.white)),
                  ],
                ),
              )
            : _permissionDenied
                ? _permissionDeniedBody()
                : _error != null
                    ? _stateBody(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.videocam_off,
                                size: 56, color: HamsiqTheme.muted),
                            const SizedBox(height: 12),
                            Text(_error!,
                                textAlign: TextAlign.center,
                                style: const TextStyle(color: Colors.white)),
                            const SizedBox(height: 16),
                            ElevatedButton(
                              onPressed: _initCamera,
                              child: Text(AppStrings.t('retry')),
                            ),
                            if (widget.onUseGallery != null) ...[
                              const SizedBox(height: 8),
                              TextButton(
                                onPressed: widget.onUseGallery,
                                child: Text(AppStrings.t('useGalleryInstead')),
                              ),
                            ],
                          ],
                        ),
                      )
                    : _cameraBody(),
      ),
    );
  }

  Widget _stateBody({required Widget child}) {
    return Stack(
      children: [
        Center(child: child),
        Positioned(
          top: 8,
          right: 8,
          child: IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.close, color: Colors.white),
          ),
        ),
      ],
    );
  }

  Widget _permissionDeniedBody() {
    return _stateBody(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.no_photography, size: 56, color: HamsiqTheme.muted),
            const SizedBox(height: 12),
            Text(
              AppStrings.t('cameraDisabled'),
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              AppStrings.t('cameraDisabledHint'),
              textAlign: TextAlign.center,
              style: TextStyle(color: HamsiqTheme.muted),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _initCamera,
              child: Text(AppStrings.t('retry')),
            ),
            if (widget.onUseGallery != null) ...[
              const SizedBox(height: 8),
              TextButton(
                onPressed: widget.onUseGallery,
                child: Text(AppStrings.t('pickFromGallery')),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _cameraBody() {
    final c = _controller;
    if (c == null || !c.value.isInitialized) {
      return _stateBody(
        child: Text(AppStrings.t('cameraNotReady'),
            style: TextStyle(color: Colors.white)),
      );
    }
    final previewSize = c.value.previewSize;
    final preview = previewSize == null
        ? CameraPreview(c)
        : FittedBox(
            fit: BoxFit.cover,
            child: SizedBox(
              width: previewSize.width,
              height: previewSize.height,
              child: CameraPreview(c),
            ),
          );
    return LayoutBuilder(
      builder: (context, constraints) {
        final size = Size(constraints.maxWidth, constraints.maxHeight);
        return Stack(
          fit: StackFit.expand,
          children: [
            GestureDetector(
              onTapDown: (d) => _onTapFocus(d, size),
              behavior: HitTestBehavior.opaque,
              child: preview,
            ),
            if (_focusPoint != null)
              Positioned(
                left: _focusPoint!.dx * size.width - 28,
                top: _focusPoint!.dy * size.height - 28,
                child: Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    border: Border.all(color: HamsiqTheme.accent, width: 2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            // Top controls.
            Positioned(
              top: 8,
              left: 8,
              right: 8,
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close,
                        color: Colors.white, size: 28),
                  ),
                  const Spacer(),
                  if (_recording)
                    Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: const BoxDecoration(
                            color: Colors.red,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          '${_formatElapsed(_recordElapsed)} / 01:00',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  const Spacer(),
                  IconButton(
                    onPressed: _toggleFlash,
                    icon: Icon(
                      _flash == FlashMode.off
                          ? Icons.flash_off
                          : _flash == FlashMode.auto
                              ? Icons.flash_auto
                              : Icons.flash_on,
                      color: Colors.white,
                      size: 26,
                    ),
                  ),
                  if (_cameras.length > 1)
                    IconButton(
                      onPressed: _switchCamera,
                      icon: const Icon(Icons.cameraswitch,
                          color: Colors.white, size: 26),
                    ),
                ],
              ),
            ),
            // Bottom controls.
            Positioned(
              left: 0,
              right: 0,
              bottom: 24,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (widget.allowVideo && !_recording)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _modeChip(AppStrings.t('modePhoto'), !_isVideoMode,
                            () => setState(() => _isVideoMode = false)),
                        const SizedBox(width: 8),
                        _modeChip(AppStrings.t('modeVideo'), _isVideoMode,
                            () => setState(() => _isVideoMode = true)),
                      ],
                    ),
                  const SizedBox(height: 16),
                  GestureDetector(
                    onTap: _busy
                        ? null
                        : (_isVideoMode ? _toggleRecording : _takePhoto),
                    child: Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 4),
                        color: _recording ? Colors.red : Colors.transparent,
                      ),
                      child: _recording
                          ? const Center(
                              child: Icon(Icons.stop,
                                  color: Colors.white, size: 32),
                            )
                          : _isVideoMode
                              ? const Center(
                                  child: Icon(Icons.videocam,
                                      color: Colors.white, size: 32),
                                )
                              : null,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _recording
                        ? AppStrings.t('tapToStop60')
                        : _isVideoMode
                            ? AppStrings.t('tapToStartRecording')
                            : AppStrings.t('tapToTakePhoto'),
                    style: const TextStyle(color: Colors.white70),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _modeChip(String label, bool selected, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? HamsiqTheme.accent : Colors.black54,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
