// Hamsiq native — Home feed screen (Phase 1).
// Real posts only, via Api.fetchFeed(). Like toggling via Api.setLiked().
// No comment button/count in Phase 1 (not available from the API).

import 'package:flutter/material.dart';
import '../models.dart';
import '../services/app_strings.dart';
import '../services/collections_api.dart';
import '../services/comments_api.dart';
import '../services/supabase_service.dart';
import '../services/wave2_api.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/comments_sheet.dart';
import '../widgets/shared_post_card.dart';
import 'blend_screen.dart';
import 'collections_screen.dart';
import 'notifications_screen.dart';
import 'post_detail_screen.dart';
import 'stories_screen.dart';

class FeedScreen extends StatefulWidget {
  final HamsiqProfile me;
  final ValueNotifier<int> refreshTick;
  final VoidCallback onOpenChats;
  const FeedScreen({super.key, required this.me, required this.refreshTick, required this.onOpenChats});

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  List<PostItem> _posts = [];
  Map<int, int> _commentCounts = {};
  // Real saved state per post id (drives the feed-card bookmark).
  Set<int> _savedIds = {};
  bool _loading = true;
  String? _error;
  // Wave 2: Favourites filter + muted/snoozed accounts. Both are
  // best-effort: a failure leaves the plain feed intact.
  bool _favouritesOnly = false;
  Set<String> _favouriteIds = {};

  /// Posts after the mute filter (favourites filter applies on top).
  List<PostItem> get _visiblePosts {
    var posts = _posts;
    if (_favouritesOnly) {
      posts = filterFavouritePosts(posts, _favouriteIds);
    }
    return posts;
  }

  @override
  void initState() {
    super.initState();
    widget.refreshTick.addListener(_onTick);
    _load();
  }

  @override
  void dispose() {
    widget.refreshTick.removeListener(_onTick);
    super.dispose();
  }

  void _onTick() {
    _load();
  }

  Future<void> _load() async {
    if (_posts.isEmpty) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      // Wave 2: publish any due scheduled posts first (only while
      // the app is open — there is no server-side scheduler).
      try {
        await Wave2Api.publishDueScheduledPosts();
      } catch (_) {}
      final posts = await Api.fetchFeed();
      // Wave 2: favourites + muted sets (best-effort).
      Set<String> favIds = {};
      Set<String> mutedIds = {};
      try {
        favIds = await Wave2Api.fetchMyFavouriteIds();
      } catch (_) {}
      try {
        mutedIds = await Wave2Api.fetchActiveMutedIds();
      } catch (_) {}
      posts.removeWhere((p) => mutedIds.contains(p.userId));
      // Saved state for the bookmark toggles (best-effort: a failure
      // just leaves every bookmark off, never hides the feed).
      var savedIds = <int>{};
      try {
        savedIds = await CollectionsApi.fetchSavedPostIds();
      } catch (_) {
        savedIds = {};
      }
      // Comment counts are nice-to-have: a failure here must not hide
      // the feed itself.
      var counts = <int, int>{};
      try {
        counts = await CommentsApi.fetchCommentCounts(
          posts.map((p) => p.id).toList(),
        );
      } catch (_) {
        counts = {for (final p in posts) p.id: 0};
      }
      if (!mounted) return;
      setState(() {
        _posts = posts;
        _commentCounts = counts;
        _savedIds = savedIds;
        _favouriteIds = favIds;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  Future<void> _toggleLike(PostItem post) async {
    final wasLiked = post.likedByMe;
    final wasCount = post.likeCount;
    setState(() {
      post.likedByMe = !wasLiked;
      post.likeCount = wasLiked ? wasCount - 1 : wasCount + 1;
    });
    try {
      await Api.setLiked(post.id, !wasLiked);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        post.likedByMe = wasLiked;
        post.likeCount = wasCount;
      });
      showError(context, e);
    }
  }

  /// Feed-card bookmark: the SAME real save function the post-detail
  /// screen uses (CollectionsApi via the collections sheet when
  /// saving; toggleSave(false) when unsaving). Never a fake button.
  Future<void> _toggleSave(PostItem post) async {
    if (!_savedIds.contains(post.id)) {
      // Saving opens the collections sheet (save + pick a collection).
      await showAddToCollectionSheet(context, post);
      if (!mounted) return;
      bool savedNow = false;
      try {
        savedNow = await CollectionsApi.isSaved(post.id);
      } catch (_) {
        savedNow = false;
      }
      if (!mounted) return;
      setState(() {
        if (savedNow) {
          _savedIds.add(post.id);
        }
      });
    } else {
      setState(() => _savedIds.remove(post.id));
      try {
        await CollectionsApi.toggleSave(post.id, false);
        if (mounted) showOk(context, AppStrings.t('unsaved'));
      } catch (e) {
        if (!mounted) return;
        setState(() => _savedIds.add(post.id));
        showError(context, e);
      }
    }
  }

  Future<void> _openPost(PostItem post) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PostDetailScreen(post: post)),
    );
    // Likes/comments may have changed in the detail screen; refresh.
    if (mounted) _load();
  }

  /// v1.2.1: Instagram-style comments — the bottom sheet opens OVER
  /// the feed (no navigation into the post); the post itself still
  /// opens the detail screen on tap.
  Future<void> _openComments(PostItem post) async {
    await showCommentsSheet(context, post);
    if (!mounted) return;
    try {
      final counts = await CommentsApi.fetchCommentCounts(
        _visiblePosts.map((p) => p.id).toList(),
      );
      if (!mounted) return;
      setState(() => _commentCounts = counts);
    } catch (_) {
      // Keep the old counts; the next feed reload retries them.
    }
  }

  /// Wave 3: Blend entry point — pick a friend from my chats, then
  /// open the shared Reels feed with them (both must opt in).
  /// KEPT INTENTIONALLY (2026-11-16 feed redesign): the mockup has no
  /// Blend icon in the AppBar, so the button was removed below — but
  /// this entry point + BlendScreen stay intact until a new Blend
  /// placement is decided. Currently unreachable from the feed.
  // ignore: unused_element
  Future<void> _openBlendPicker() async {
    List<ChatRow> rows = [];
    try {
      rows = await Api.fetchChatList();
    } catch (e) {
      if (mounted) showError(context, e);
      return;
    }
    if (!mounted) return;
    final peer = await showModalBottomSheet<HamsiqProfile>(
      context: context,
      backgroundColor: HamsiqTheme.panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Text(
                AppStrings.t('blendPickFriend'),
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(16, 6, 16, 4),
              child: Text(
                AppStrings.t('blendIntroLong'),
                textAlign: TextAlign.center,
                style: TextStyle(color: HamsiqTheme.muted, fontSize: 12),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 320,
              child: rows.isEmpty
                  ? EmptyCenter(AppStrings.t('noChatsYet'))
                  : ListView.builder(
                      itemCount: rows.length,
                      itemBuilder: (_, i) {
                        final row = rows[i];
                        return ListTile(
                          leading: AvatarWidget(profile: row.peer, size: 44),
                          title: Text(row.peer.displayName),
                          subtitle: Text('@${row.peer.username}'),
                          onTap: () =>
                              Navigator.of(sheetContext).pop(row.peer),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
    if (peer != null && mounted) {
      await Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => BlendScreen(peer: peer)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset(
                'assets/logo.png',
                width: 38,
                height: 38,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 9),
            const Text(
              'Hamsiq',
              style: TextStyle(
                color: HamsiqTheme.text,
                fontWeight: FontWeight.w900,
                fontSize: 23,
                letterSpacing: 0.3,
              ),
            ),
            // Mockup-match: blue verified badge next to the brand name.
            const SizedBox(width: 6),
            const VerifiedTick(size: 18),
          ],
        ),
        actions: [
          const NotificationsBellButton(),
          IconButton(
            icon: const Icon(Icons.send_outlined),
            onPressed: widget.onOpenChats,
          ),
        ],
      ),
      body: Column(
        children: [
          StoryBar(me: widget.me, onChanged: _load),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 2),
            child: Row(
              children: [
                ChoiceChip(
                  label: Text(AppStrings.t('allFilter')),
                  selected: !_favouritesOnly,
                  selectedColor: HamsiqTheme.accent,
                  backgroundColor: HamsiqTheme.panel2,
                  labelStyle: TextStyle(
                    color: !_favouritesOnly
                        ? Colors.white
                        : HamsiqTheme.muted,
                  ),
                  onSelected: (_) {
                    if (_favouritesOnly) {
                      setState(() => _favouritesOnly = false);
                    }
                  },
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: Text(AppStrings.t('favouritesFilter')),
                  selected: _favouritesOnly,
                  selectedColor: HamsiqTheme.accent,
                  backgroundColor: HamsiqTheme.panel2,
                  labelStyle: TextStyle(
                    color: _favouritesOnly
                        ? Colors.white
                        : HamsiqTheme.muted,
                  ),
                  onSelected: (_) {
                    if (!_favouritesOnly) {
                      setState(() => _favouritesOnly = true);
                    }
                  },
                ),
              ],
            ),
          ),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loading && _posts.isEmpty) {
      return const LoadingCenter();
    }
    if (_error != null && _posts.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                _error!,
                textAlign: TextAlign.center,
                style: const TextStyle(color: HamsiqTheme.muted, fontSize: 15),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _load,
                child: Text(AppStrings.t('retry')),
              ),
            ],
          ),
        ),
      );
    }
    return RefreshIndicator(
      color: HamsiqTheme.accent,
      onRefresh: _load,
      child: _visiblePosts.isEmpty
          ? ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.7,
                  child: EmptyCenter(
                    _favouritesOnly
                        ? AppStrings.t('noFavouritePosts')
                        : AppStrings.t('noPostsYet'),
                  ),
                ),
              ],
            )
          : ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: _visiblePosts.length,
              itemBuilder: (_, i) => _PostCard(
                post: _visiblePosts[i],
                commentCount: _commentCounts[_visiblePosts[i].id] ?? 0,
                saved: _savedIds.contains(_visiblePosts[i].id),
                onToggleLike: () => _toggleLike(_visiblePosts[i]),
                onOpenPost: () => _openPost(_visiblePosts[i]),
                onOpenComments: () => _openComments(_visiblePosts[i]),
                onShare: () => showSharePostSheet(context, _visiblePosts[i]),
                onToggleSave: () => _toggleSave(_visiblePosts[i]),
              ),
            ),
    );
  }
}

class _PostCard extends StatelessWidget {
  final PostItem post;
  final int commentCount;
  final bool saved;
  final VoidCallback onToggleLike;
  final VoidCallback onOpenPost;
  final VoidCallback onOpenComments;
  final VoidCallback onShare;
  final VoidCallback onToggleSave;
  const _PostCard({
    required this.post,
    required this.commentCount,
    required this.saved,
    required this.onToggleLike,
    required this.onOpenPost,
    required this.onOpenComments,
    required this.onShare,
    required this.onToggleSave,
  });

  @override
  Widget build(BuildContext context) {
    final author = post.author;
    return GestureDetector(
      onTap: onOpenPost,
      child: Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: HamsiqTheme.panel,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: HamsiqTheme.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              AvatarWidget(profile: author, size: 42),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            author?.displayName ?? '',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (author?.verified == true) ...[
                          const SizedBox(width: 4),
                          const VerifiedTick(),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '@${author?.username ?? ''} · ${timeAgo(post.createdAt)}',
                      style: const TextStyle(
                        color: HamsiqTheme.muted,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              // Mockup-match: "..." at the far end of the header row —
              // opens the post, where the full post options live.
              IconButton(
                onPressed: onOpenPost,
                tooltip: AppStrings.t('postOptions'),
                icon: const Icon(
                  Icons.more_horiz,
                  color: HamsiqTheme.muted,
                ),
              ),
            ],
          ),
          if (post.caption.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(
              post.caption,
              style: const TextStyle(fontSize: 15),
            ),
          ],
          if (post.mediaUrl != null) ...[
            const SizedBox(height: 10),
            _PostMedia(post: post),
          ],
          const SizedBox(height: 4),
          // Mockup-match: the action bar sits in its own thin-bordered
          // pill below the media (like / comment / share / bookmark).
          Container(
            decoration: BoxDecoration(
              border: Border.all(color: HamsiqTheme.line),
              borderRadius: BorderRadius.circular(24),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            child: Row(
            children: [
              IconButton(
                onPressed: onToggleLike,
                icon: Icon(
                  post.likedByMe ? Icons.favorite : Icons.favorite_border,
                  color: post.likedByMe
                      ? HamsiqTheme.accent
                      : HamsiqTheme.muted,
                ),
              ),
              Text(
                // Wave 2: the author can hide like counts per post.
                post.hideLikeCount ? '' : '${post.likeCount}',
                style: const TextStyle(color: HamsiqTheme.muted),
              ),
              const SizedBox(width: 8),
              // Wave 2: comments can be turned off per post.
              // v1.2.1: the comment icon opens the bottom sheet over
              // the feed (Instagram-style); the card tap still opens
              // the post detail screen.
              if (!post.commentsDisabled) ...[
                IconButton(
                  onPressed: onOpenComments,
                  icon: const Icon(
                    Icons.chat_bubble_outline,
                    color: HamsiqTheme.muted,
                  ),
                ),
                Text(
                  '$commentCount',
                  style: const TextStyle(color: HamsiqTheme.muted),
                ),
                const SizedBox(width: 8),
              ],
              // Wave 1: paper-plane share — opens the people picker and
              // sends the post as a message card into a DM.
              IconButton(
                onPressed: onShare,
                icon: const Icon(
                  Icons.send_outlined,
                  color: HamsiqTheme.muted,
                ),
              ),
              // Mockup-match (2026-11-16): bookmark toggle at the far
              // end of the action bar, wired to the real save function.
              const Spacer(),
              IconButton(
                onPressed: onToggleSave,
                tooltip: AppStrings.t('save'),
                icon: Icon(
                  saved ? Icons.bookmark : Icons.bookmark_border,
                  color: saved
                      ? HamsiqTheme.accent
                      : HamsiqTheme.muted,
                ),
              ),
            ],
            ),
          ),
        ],
      ),
      ),
    );
  }
}

class _PostMedia extends StatelessWidget {
  final PostItem post;
  const _PostMedia({required this.post});

  @override
  Widget build(BuildContext context) {
    if (post.mediaType == 'video') {
      // Video playback lives in the Reels tab — show a tile only.
      return Container(
        height: 220,
        width: double.infinity,
        decoration: BoxDecoration(
          color: HamsiqTheme.bgDeep,
          // Mockup-match: media corners radius 16.
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Center(
          child: Icon(
            Icons.play_circle_filled,
            size: 64,
            color: HamsiqTheme.accent,
          ),
        ),
      );
    }
    return ClipRRect(
      // Mockup-match: media corners radius 16.
      borderRadius: BorderRadius.circular(16),
      child: SignedMediaImage(
        url: post.mediaUrl!,
        width: double.infinity,
        height: 300,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          height: 300,
          width: double.infinity,
          color: HamsiqTheme.panel2,
          alignment: Alignment.center,
          child: const Icon(
            Icons.broken_image_outlined,
            color: HamsiqTheme.muted,
            size: 40,
          ),
        ),
      ),
    );
  }
}
