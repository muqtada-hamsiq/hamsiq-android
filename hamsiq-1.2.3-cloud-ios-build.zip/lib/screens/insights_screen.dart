// Hamsiq native — Basic Insights (Wave 2).
// Views/likes/followers from EXISTING data only (Wave2Api.fetchInsights):
// post likes, follower counts + growth from follows.created_at, and
// story views from the real story_views table (sql-v29). Post views are
// NOT stored anywhere, so the screen never invents them — it says so
// plainly and shows story views instead. All numbers are labelled as
// estimates from available data.

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/wave2_api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class InsightsScreen extends StatefulWidget {
  const InsightsScreen({super.key});

  @override
  State<InsightsScreen> createState() => _InsightsScreenState();
}

class _InsightsScreenState extends State<InsightsScreen> {
  InsightsData? _data;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final data = await Wave2Api.fetchInsights();
      if (!mounted) return;
      setState(() {
        _data = data;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  Widget _statCard(String label, String value, {String? sub}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: HamsiqTheme.panel,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: HamsiqTheme.line),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 13,
                color: HamsiqTheme.muted,
              ),
            ),
            if (sub != null) ...[
              const SizedBox(height: 2),
              Text(
                sub,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 12,
                  color: HamsiqTheme.accent,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final data = _data;
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.t('titleInsights'))),
      body: _loading
          ? const LoadingCenter()
          : _error != null
              ? EmptyCenter(_error!)
              : data == null
                  ? EmptyCenter(AppStrings.t('noDataYet'))
                  : RefreshIndicator(
                      color: HamsiqTheme.accent,
                      onRefresh: _load,
                      child: ListView(
                        padding: const EdgeInsets.all(16),
                        children: [
                          Text(
                            AppStrings.t('insightsEstimateNote'),
                            style: TextStyle(
                              color: HamsiqTheme.muted,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              _statCard(AppStrings.t('notifFollowers'), '${data.followers}',
                                  sub: data.followersGrowthAvailable
                                      ? '+${data.newFollowers7d} ${AppStrings.t('last7Days')}'
                                      : null),
                              const SizedBox(width: 10),
                              _statCard(AppStrings.t('followingStat'), '${data.following}'),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              _statCard(AppStrings.t('postsStat'), '${data.postsCount}'),
                              const SizedBox(width: 10),
                              _statCard(AppStrings.t('totalLikesStat'), '${data.totalLikes}',
                                  sub:
                                      '${AppStrings.t('average')} ${data.avgLikesPerPost.toStringAsFixed(1)} ${AppStrings.t('perPost')}'),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              _statCard(
                                AppStrings.t('storyViewsStat'),
                                '${data.totalStoryViews}',
                              ),
                              const SizedBox(width: 10),
                              _statCard(
                                AppStrings.t('newFollowers30'),
                                data.followersGrowthAvailable
                                    ? '+${data.newFollowers30d}'
                                    : AppStrings.t('notAvailable'),
                              ),
                            ],
                          ),
                          const SizedBox(height: 20),
                          Text(
                            AppStrings.t('bestPost'),
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          const SizedBox(height: 8),
                          if (data.topPost == null)
                            Text(
                              AppStrings.t('noPostsYet'),
                              style: TextStyle(color: HamsiqTheme.muted),
                            )
                          else
                            _TopPostCard(post: data.topPost!),
                        ],
                      ),
                    ),
    );
  }
}

class _TopPostCard extends StatelessWidget {
  final PostItem post;
  const _TopPostCard({required this.post});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: HamsiqTheme.panel,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: HamsiqTheme.line),
      ),
      child: Row(
        children: [
          if (post.mediaUrl != null && post.mediaUrl!.isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: SignedMediaImage(
                url: post.mediaUrl!,
                width: 64,
                height: 64,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  width: 64,
                  height: 64,
                  color: HamsiqTheme.panel2,
                ),
              ),
            ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  post.caption.isEmpty ? AppStrings.t('postNoText') : post.caption,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  '♥ ${post.likeCount} · ${timeAgo(post.createdAt)}',
                  style: const TextStyle(color: HamsiqTheme.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
