// Hamsiq native — Collections screen (Wave 1).
// Saved posts organised into named collections (sql-v29 tables
// collections + collection_posts, built on saved_posts from sql-v16).
// Reached from the profile's Saved area — see the CollectionsEntry
// widget in widgets/profile_extra_tabs.dart, which the coordinator
// wires into profile_screen.dart (this screen is standalone otherwise).

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/collections_api.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'post_detail_screen.dart';

/// Sheet to add [post] to one of my collections (or create a new one).
/// Also saves the post (saved_posts) — see CollectionsApi.addToCollection.
Future<void> showAddToCollectionSheet(
  BuildContext context,
  PostItem post,
) async {
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: HamsiqTheme.panel,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (sheetContext) => _AddToCollectionSheet(post: post),
  );
}

class _AddToCollectionSheet extends StatefulWidget {
  final PostItem post;
  const _AddToCollectionSheet({required this.post});

  @override
  State<_AddToCollectionSheet> createState() => _AddToCollectionSheetState();
}

class _AddToCollectionSheetState extends State<_AddToCollectionSheet> {
  List<CollectionItem> _collections = [];
  Set<int> _containing = {};
  bool _loading = true;
  String? _error;
  final _nameCtrl = TextEditingController();
  bool _creating = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait([
        CollectionsApi.fetchMyCollections(),
        CollectionsApi.fetchCollectionsContainingPost(widget.post.id),
      ]);
      if (!mounted) return;
      setState(() {
        _collections = results[0] as List<CollectionItem>;
        _containing = results[1] as Set<int>;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  Future<void> _toggle(CollectionItem c) async {
    try {
      if (_containing.contains(c.id)) {
        await CollectionsApi.removeFromCollection(c.id, widget.post.id);
        if (!mounted) return;
        setState(() => _containing.remove(c.id));
      } else {
        await CollectionsApi.addToCollection(c.id, widget.post.id);
        if (!mounted) return;
        setState(() => _containing.add(c.id));
        showOk(context, '${AppStrings.t('addedToCollection')} «${c.name}»');
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _create() async {
    if (_creating) return;
    setState(() => _creating = true);
    try {
      final created =
          await CollectionsApi.createCollection(_nameCtrl.text);
      await CollectionsApi.addToCollection(created.id, widget.post.id);
      if (!mounted) return;
      _nameCtrl.clear();
      await _load();
      if (mounted) showOk(context, AppStrings.t('collectionCreatedAndAdded'));
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _creating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Text(
                AppStrings.t('saveToCollection'),
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _nameCtrl,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: AppStrings.t('newCollectionNameHint'),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  _creating
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            color: HamsiqTheme.accent,
                            strokeWidth: 2,
                          ),
                        )
                      : IconButton(
                          tooltip: AppStrings.t('createCollection'),
                          onPressed: _create,
                          icon: const Icon(
                            Icons.add_circle,
                            color: HamsiqTheme.accent,
                            size: 30,
                          ),
                        ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 300,
              child: _loading
                  ? const LoadingCenter()
                  : _error != null
                      ? Center(
                          child: Text(
                            _error!,
                            style: const TextStyle(color: HamsiqTheme.muted),
                          ),
                        )
                      : _collections.isEmpty
                          ? EmptyCenter(
                              AppStrings.t('noCollectionsYet'),
                            )
                          : ListView.builder(
                              itemCount: _collections.length,
                              itemBuilder: (_, i) {
                                final c = _collections[i];
                                final inIt = _containing.contains(c.id);
                                return ListTile(
                                  leading: const Icon(
                                    Icons.collections_bookmark_outlined,
                                    color: HamsiqTheme.accent,
                                  ),
                                  title: Text(
                                    c.name,
                                    style:
                                        const TextStyle(color: Colors.white),
                                  ),
                                  subtitle: Text(
                                    '${c.postCount} ${c.postCount == 1 ? AppStrings.t('postSingular') : AppStrings.t('postPlural')}',
                                    style: const TextStyle(
                                      color: HamsiqTheme.muted,
                                    ),
                                  ),
                                  trailing: inIt
                                      ? const Icon(
                                          Icons.check_circle,
                                          color: HamsiqTheme.accent,
                                        )
                                      : null,
                                  onTap: () => _toggle(c),
                                );
                              },
                            ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// CollectionsScreen — "All saved" + my named collections.
// ---------------------------------------------------------------------------

class CollectionsScreen extends StatefulWidget {
  const CollectionsScreen({super.key});

  @override
  State<CollectionsScreen> createState() => _CollectionsScreenState();
}

class _CollectionsScreenState extends State<CollectionsScreen> {
  List<CollectionItem> _collections = [];
  List<PostItem> _saved = [];
  bool _loading = true;
  String? _error;
  final _nameCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait([
        CollectionsApi.fetchMyCollections(),
        CollectionsApi.fetchSavedPosts(),
      ]);
      if (!mounted) return;
      setState(() {
        _collections = results[0] as List<CollectionItem>;
        _saved = results[1] as List<PostItem>;
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  Future<void> _createCollection() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) return;
    try {
      await CollectionsApi.createCollection(name);
      _nameCtrl.clear();
      if (mounted) {
        Navigator.of(context).pop();
        _load();
        showOk(context, AppStrings.t('collectionCreated'));
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  void _showCreateDialog() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('newCollectionTitle')),
        content: TextField(
          controller: _nameCtrl,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(hintText: AppStrings.t('collectionNameHint')),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(AppStrings.t('cancel')),
          ),
          TextButton(
            onPressed: _createCollection,
            child: Text(AppStrings.t('createAction')),
          ),
        ],
      ),
    );
  }

  Future<void> _openCollection(CollectionItem c) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => _CollectionDetailScreen(collection: c)),
    );
    if (mounted) _load();
  }

  Future<void> _openPost(PostItem post) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PostDetailScreen(post: post)),
    );
    if (mounted) _load();
  }

  Widget _postTile(PostItem post) {
    if (post.mediaUrl != null && post.mediaUrl!.isNotEmpty) {
      return GestureDetector(
        onTap: () => _openPost(post),
        child: SignedMediaImage(
          url: post.mediaUrl!,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(color: HamsiqTheme.panel2),
        ),
      );
    }
    return GestureDetector(
      onTap: () => _openPost(post),
      child: Container(
        color: HamsiqTheme.panel2,
        padding: const EdgeInsets.all(8),
        alignment: Alignment.center,
        child: Text(
          post.caption,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 12, color: HamsiqTheme.text),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.t('savedAndCollectionsTitle')),
        actions: [
          IconButton(
            tooltip: AppStrings.t('createCollection'),
            onPressed: _showCreateDialog,
            icon: const Icon(Icons.create_new_folder_outlined),
          ),
        ],
      ),
      body: _loading
          ? const LoadingCenter()
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _error!,
                        style: const TextStyle(color: HamsiqTheme.muted),
                      ),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: _load,
                        child: Text(AppStrings.t('retry')),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  color: HamsiqTheme.accent,
                  onRefresh: _load,
                  child: CustomScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    slivers: [
                      if (_collections.isNotEmpty) ...[
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
                            child: Text(
                              AppStrings.t('myCollections'),
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                        SliverList.builder(
                          itemCount: _collections.length,
                          itemBuilder: (_, i) {
                            final c = _collections[i];
                            return ListTile(
                              leading: const Icon(
                                Icons.collections_bookmark_outlined,
                                color: HamsiqTheme.accent,
                              ),
                              title: Text(c.name),
                              subtitle: Text(
                                '${c.postCount} ${c.postCount == 1 ? AppStrings.t('postSingular') : AppStrings.t('postPlural')}',
                                style: const TextStyle(
                                  color: HamsiqTheme.muted,
                                ),
                              ),
                              trailing: const Icon(
                                Icons.chevron_right,
                                color: HamsiqTheme.muted,
                              ),
                              onTap: () => _openCollection(c),
                            );
                          },
                        ),
                      ],
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                          child: Text(
                            AppStrings.t('allSaved'),
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                      if (_saved.isEmpty)
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: EdgeInsets.only(top: 24),
                            child: EmptyCenter(
                              AppStrings.t('noSavedPosts'),
                            ),
                          ),
                        )
                      else
                        SliverGrid.builder(
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            crossAxisSpacing: 2,
                            mainAxisSpacing: 2,
                            childAspectRatio: 1,
                          ),
                          itemCount: _saved.length,
                          itemBuilder: (_, i) => _postTile(_saved[i]),
                        ),
                    ],
                  ),
                ),
    );
  }
}

class _CollectionDetailScreen extends StatefulWidget {
  final CollectionItem collection;
  const _CollectionDetailScreen({required this.collection});

  @override
  State<_CollectionDetailScreen> createState() =>
      _CollectionDetailScreenState();
}

class _CollectionDetailScreenState extends State<_CollectionDetailScreen> {
  List<PostItem> _posts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final posts =
          await CollectionsApi.fetchCollectionPosts(widget.collection.id);
      if (!mounted) return;
      setState(() {
        _posts = posts;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      showError(context, e);
    }
  }

  Future<void> _openPost(PostItem post) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PostDetailScreen(post: post)),
    );
    if (mounted) _load();
  }

  Future<void> _confirmDelete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('deleteCollectionTitle')),
        content: Text(
          AppStrings.t('deleteCollectionBody'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(AppStrings.t('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(
              AppStrings.t('delete'),
              style: TextStyle(color: Colors.redAccent),
            ),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await CollectionsApi.deleteCollection(widget.collection.id);
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.collection.name),
        actions: [
          IconButton(
            tooltip: AppStrings.t('deleteCollectionTooltip'),
            onPressed: _confirmDelete,
            icon: const Icon(Icons.delete_outline),
          ),
        ],
      ),
      body: _loading
          ? const LoadingCenter()
          : _posts.isEmpty
              ? EmptyCenter(AppStrings.t('collectionEmpty'))
              : GridView.builder(
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 2,
                    mainAxisSpacing: 2,
                    childAspectRatio: 1,
                  ),
                  itemCount: _posts.length,
                  itemBuilder: (_, i) {
                    final post = _posts[i];
                    if (post.mediaUrl != null &&
                        post.mediaUrl!.isNotEmpty) {
                      return GestureDetector(
                        onTap: () => _openPost(post),
                        child: SignedMediaImage(
                          url: post.mediaUrl!,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              Container(color: HamsiqTheme.panel2),
                        ),
                      );
                    }
                    return GestureDetector(
                      onTap: () => _openPost(post),
                      child: Container(
                        color: HamsiqTheme.panel2,
                        padding: const EdgeInsets.all(8),
                        alignment: Alignment.center,
                        child: Text(
                          post.caption,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 12,
                            color: HamsiqTheme.text,
                          ),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
