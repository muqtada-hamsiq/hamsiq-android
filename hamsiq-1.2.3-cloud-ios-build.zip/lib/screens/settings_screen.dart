// Hamsiq native — Settings screen, rebuilt from scratch (v1.2.0).
// Instagram-style, simple and uncluttered. Sections: Account (edit
// profile, change password, profile QR), Privacy (private account,
// DM/comment/mention rules, Close Friends, muted accounts), Content
// (v1.2.1: collections, grid reorder, drafts, insights — moved here
// from the profile screen), Notifications (in-app toggles + the push
// row, which shows "not available in this build yet" until
// google-services.json is wired — see lib/services/push_service.dart),
// Language, About (Hamsiq 1.2.1), Logout.
// Every control writes to a real Supabase column via SettingsApi —
// no decorative toggles, no dead rows, no "coming soon", no theme
// options (the app is black by design).


import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../main.dart';
import '../models.dart';
import '../services/account_store.dart';
import '../services/app_strings.dart';
import '../services/push_service.dart';
import '../services/settings_api.dart';
import '../services/share_api.dart';
import '../services/supabase_service.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/profile_extra_tabs.dart';
import 'close_friends_screen.dart';
import 'collections_screen.dart';
import 'drafts_screen.dart';
import 'insights_screen.dart';
import 'muted_accounts_screen.dart';
import 'qr_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  Map<String, dynamic>? _privacy;
  HamsiqProfile? _me;
  bool _loading = true;
  Object? _error;

  String get _email => Api.client.auth.currentUser?.email ?? '';

  @override
  void initState() {
    super.initState();
    AppStrings.load();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait([
        SettingsApi.fetchMyPrivacy(),
        Api.fetchProfile(Api.myId),
      ]);
      if (!mounted) return;
      setState(() {
        _privacy = results[0] as Map<String, dynamic>;
        _me = results[1] as HamsiqProfile?;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e;
      });
    }
  }

  /// Web-app defaults: every boolean privacy/notif column defaults to
  /// true, except is_private which defaults to false.
  bool _flag(String field, {bool defaultValue = true}) {
    final v = _privacy?[field];
    if (v is bool) return v;
    return defaultValue;
  }

  String _choice(String field) =>
      (_privacy?[field] as String?) ?? 'all';

  Future<void> _setBool(String field, bool value) async {
    final prev = _flag(field, defaultValue: field != 'is_private');
    setState(() => _privacy?[field] = value);
    try {
      await SettingsApi.setPrivacy(field, value);
    } catch (e) {
      if (!mounted) return;
      setState(() => _privacy?[field] = prev);
      showError(context, e);
    }
  }

  Future<void> _setChoice(String field, String value) async {
    final prev = _choice(field);
    setState(() => _privacy?[field] = value);
    try {
      await SettingsApi.setPrivacy(field, value);
    } catch (e) {
      if (!mounted) return;
      setState(() => _privacy?[field] = prev);
      showError(context, e);
    }
  }

  // ---------------- account: edit profile ----------------

  // v1.2.1: the 7 rows moved here from the profile screen.
  void _openCollections() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const CollectionsScreen()),
    );
  }

  Future<void> _openGridReorder() async {
    final me = _me;
    if (me == null) return;
    try {
      final posts = await ShareApi.fetchOrderedUserPosts(me.id);
      if (!mounted) return;
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => GridReorderView(
            userId: me.id,
            initialPosts: posts,
            onSaved: () {},
          ),
        ),
      );
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  void _openDrafts() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const DraftsScreen()),
    );
  }

  void _openInsights() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const InsightsScreen()),
    );
  }

  void _openCloseFriends() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const CloseFriendsScreen()),
    );
  }

  void _openMuted() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const MutedAccountsScreen()),
    );
  }

  void _openQr() {
    final me = _me;
    if (me == null) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => QrScreen(profile: me)),
    );
  }

  Future<void> _openEditDialog() async {
    final me = _me;
    if (me == null) return;
    final nameCtrl = TextEditingController(text: me.displayName);
    final bioCtrl = TextEditingController(text: me.bio);
    var busy = false;

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          Future<void> pickAvatar(ImageSource source) async {
            if (busy) return;
            setDialogState(() => busy = true);
            try {
              final picked = await ImagePicker().pickImage(
                source: source,
                maxWidth: 512,
                imageQuality: 85,
              );
              if (picked == null) return;
              final url = await Api.uploadImage(
                await picked.readAsBytes(),
                Api.uniqueImagePath('avatar'),
              );
              if (url == null) {
                throw Exception(AppStrings.t('photoUploadFailed'));
              }
              await Api.updateMyProfile(
                displayName: nameCtrl.text.trim(),
                bio: bioCtrl.text.trim(),
                avatarUrl: url,
              );
              if (!mounted || !dialogCtx.mounted) return;
              Navigator.of(dialogCtx).pop();
              await _load();
              if (mounted) showOk(context, AppStrings.t('photoUpdated'));
            } catch (e) {
              if (ctx.mounted) showError(ctx, e);
            } finally {
              if (ctx.mounted) setDialogState(() => busy = false);
            }
          }

          Future<void> save() async {
            if (busy) return;
            setDialogState(() => busy = true);
            try {
              await Api.updateMyProfile(
                displayName: nameCtrl.text.trim(),
                bio: bioCtrl.text.trim(),
              );
              if (!mounted || !dialogCtx.mounted) return;
              Navigator.of(dialogCtx).pop();
              await _load();
              if (mounted) showOk(context, AppStrings.t('editsSaved'));
            } catch (e) {
              if (ctx.mounted) showError(ctx, e);
            } finally {
              if (ctx.mounted) setDialogState(() => busy = false);
            }
          }

          return AlertDialog(
            backgroundColor: HamsiqTheme.panel,
            title: Text(AppStrings.t('editProfile')),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TextField(
                    controller: nameCtrl,
                    decoration: InputDecoration(
                      hintText: AppStrings.t('displayName'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: bioCtrl,
                    decoration: InputDecoration(
                      hintText: AppStrings.t('bio'),
                    ),
                    maxLines: 3,
                    minLines: 2,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    AppStrings.t('changePhoto'),
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: busy
                              ? null
                              : () => pickAvatar(ImageSource.camera),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: HamsiqTheme.panel2,
                            foregroundColor: Colors.white,
                          ),
                          icon: const Icon(Icons.camera_alt_outlined),
                          label: Text(AppStrings.t('camera')),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: busy
                              ? null
                              : () => pickAvatar(ImageSource.gallery),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: HamsiqTheme.panel2,
                            foregroundColor: Colors.white,
                          ),
                          icon: const Icon(Icons.photo_outlined),
                          label: Text(AppStrings.t('gallery')),
                        ),
                      ),
                    ],
                  ),
                  if (busy) ...[
                    const SizedBox(height: 12),
                    const Center(
                      child: CircularProgressIndicator(
                        color: HamsiqTheme.accent,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed:
                    busy ? null : () => Navigator.of(dialogCtx).pop(),
                style: TextButton.styleFrom(
                  foregroundColor: Colors.white,
                ),
                child: Text(AppStrings.t('cancel')),
              ),
              ElevatedButton(
                onPressed: busy ? null : save,
                child: Text(AppStrings.t('save')),
              ),
            ],
          );
        },
      ),
    );
    nameCtrl.dispose();
    bioCtrl.dispose();
  }

  // ---------------- account: change password ----------------

  Future<void> _openChangePassword() async {
    final currentCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    final confirmCtrl = TextEditingController();
    var busy = false;

    await showDialog<void>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          Future<void> save() async {
            if (busy) return;
            final current = currentCtrl.text;
            final next = newCtrl.text;
            final confirm = confirmCtrl.text;
            if (current.isEmpty || next.isEmpty || confirm.isEmpty) {
              showError(ctx, Exception(AppStrings.t('fillAllFields')));
              return;
            }
            if (next != confirm) {
              showError(ctx, Exception(AppStrings.t('passwordMismatch')));
              return;
            }
            if (!SettingsApi.isStrongPassword(next)) {
              showError(ctx, Exception(AppStrings.t('passwordWeak')));
              return;
            }
            setDialogState(() => busy = true);
            try {
              // Verify the current password first (the web app only asks
              // for the new one; verifying here stops a typo'd account
              // from being locked out by a wrong change).
              if (_email.isNotEmpty) {
                try {
                  final r = await Api.client.auth.signInWithPassword(
                    email: _email,
                    password: current,
                  );
                  if (r.user == null) {
                    throw Exception(AppStrings.t('passwordWrong'));
                  }
                } catch (e) {
                  if (e
                      .toString()
                      .contains('Invalid login credentials')) {
                    throw Exception(AppStrings.t('passwordWrong'));
                  }
                  rethrow;
                }
              }
              await SettingsApi.changePassword(next);
              if (!mounted || !dialogCtx.mounted) return;
              Navigator.of(dialogCtx).pop();
              if (mounted) showOk(context, AppStrings.t('passwordChanged'));
            } catch (e) {
              if (ctx.mounted) showError(ctx, e);
            } finally {
              if (ctx.mounted) setDialogState(() => busy = false);
            }
          }

          return AlertDialog(
            backgroundColor: HamsiqTheme.panel,
            title: Text(AppStrings.t('changePassword')),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TextField(
                    controller: currentCtrl,
                    obscureText: true,
                    decoration: InputDecoration(
                      hintText: AppStrings.t('currentPassword'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: newCtrl,
                    obscureText: true,
                    decoration: InputDecoration(
                      hintText: AppStrings.t('newPassword'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: confirmCtrl,
                    obscureText: true,
                    decoration: InputDecoration(
                      hintText: AppStrings.t('confirmPassword'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    AppStrings.t('passwordRule'),
                    style: const TextStyle(
                      fontSize: 12,
                      color: HamsiqTheme.muted,
                    ),
                  ),
                  if (busy) ...[
                    const SizedBox(height: 12),
                    const Center(
                      child: CircularProgressIndicator(
                        color: HamsiqTheme.accent,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed:
                    busy ? null : () => Navigator.of(dialogCtx).pop(),
                style: TextButton.styleFrom(
                  foregroundColor: Colors.white,
                ),
                child: Text(AppStrings.t('cancel')),
              ),
              ElevatedButton(
                onPressed: busy ? null : save,
                child: Text(AppStrings.t('save')),
              ),
            ],
          );
        },
      ),
    );
    currentCtrl.dispose();
    newCtrl.dispose();
    confirmCtrl.dispose();
  }

  // ---------------- logout ----------------

  Future<void> _confirmLogout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('logout')),
        content: Text(AppStrings.t('confirmLogout')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            style: TextButton.styleFrom(foregroundColor: Colors.white),
            child: Text(AppStrings.t('cancel')),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: Text(AppStrings.t('confirm')),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    try {
      // Push: drop this device's token row so it stops receiving
      // notifications for this account after logout.
      await PushService.instance.unregisterToken();
      // v1.2.2: logging out also drops the account from the saved
      // accounts list, so it stops appearing in the switcher.
      await AccountStore.instance.logoutCurrent();
      await Api.signOut();
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HamsiqApp()),
        (_) => false,
      );
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  // ---------------- widgets ----------------

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w800,
            color: HamsiqTheme.accent,
          ),
        ),
      );

  Widget _sectionHint(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
        child: Text(
          text,
          style: const TextStyle(fontSize: 12, color: HamsiqTheme.muted),
        ),
      );

  Widget _tile({
    required String title,
    String? subtitle,
    Widget? trailing,
    VoidCallback? onTap,
    Color? titleColor,
  }) =>
      ListTile(
        title: Text(
          title,
          style: TextStyle(color: titleColor ?? HamsiqTheme.text),
        ),
        subtitle: subtitle == null
            ? null
            : Text(
                subtitle,
                style: const TextStyle(color: HamsiqTheme.muted),
              ),
        trailing: trailing ?? const Icon(Icons.chevron_left, size: 20),
        onTap: onTap,
      );

  Widget _switchRow({
    required String title,
    String? subtitle,
    required String field,
    bool defaultValue = true,
  }) =>
      SwitchListTile(
        title: Text(title),
        subtitle: subtitle == null
            ? null
            : Text(
                subtitle,
                style: const TextStyle(color: HamsiqTheme.muted),
              ),
        value: _flag(field, defaultValue: defaultValue),
        activeThumbColor: HamsiqTheme.accent,
        onChanged: (v) => _setBool(field, v),
      );

  Widget _choiceRow(
    String title,
    String field,
    List<MapEntry<String, String>> options,
  ) {
    final current = _choice(field);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 15)),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: [
              for (final o in options)
                ButtonSegment<String>(value: o.key, label: Text(o.value)),
            ],
            selected: {current},
            onSelectionChanged: (s) => _setChoice(field, s.first),
            style: ButtonStyle(
              backgroundColor: WidgetStateProperty.resolveWith(
                (states) => states.contains(WidgetState.selected)
                    ? HamsiqTheme.accent
                    : HamsiqTheme.panel2,
              ),
              foregroundColor: WidgetStateProperty.all(Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: AppStrings.lang,
      builder: (_, __, ___) => Scaffold(
        appBar: AppBar(title: Text(AppStrings.t('titleSettings'))),
        body: _loading
            ? const LoadingCenter()
            : _error != null
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        EmptyCenter(AppStrings.t('failedLoadSettings')),
                        const SizedBox(height: 12),
                        ElevatedButton(
                          onPressed: _load,
                          child: Text(AppStrings.t('back')),
                        ),
                      ],
                    ),
                  )
                : ListView(
                    children: [
                      // ---- Account ----
                      _sectionTitle(AppStrings.t('secAccount')),
                      _tile(
                        title: AppStrings.t('editProfile'),
                        subtitle: _me == null
                            ? null
                            : '@${_me!.username}',
                        trailing: const Icon(Icons.edit_outlined, size: 20),
                        onTap: _me == null ? null : _openEditDialog,
                      ),
                      _tile(
                        title: AppStrings.t('changePassword'),
                        subtitle: AppStrings.t('passwordRule'),
                        onTap: _openChangePassword,
                      ),
                      _tile(
                        title: AppStrings.t('titleQr'),
                        subtitle: AppStrings.t('qrHint'),
                        trailing: const Icon(
                          Icons.qr_code_2_outlined,
                          size: 20,
                        ),
                        onTap: _me == null ? null : _openQr,
                      ),

                      // ---- Privacy ----
                      _sectionTitle(AppStrings.t('secPrivacy')),
                      _switchRow(
                        title: AppStrings.t('privateAccount'),
                        subtitle: AppStrings.t('privateAccountHint'),
                        field: 'is_private',
                        defaultValue: false,
                      ),
                      _choiceRow(
                        AppStrings.t('whoCanMessage'),
                        'dm_privacy',
                        [
                          MapEntry('all', AppStrings.t('dmAll')),
                          MapEntry('friends', AppStrings.t('dmFriends')),
                        ],
                      ),
                      _choiceRow(
                        AppStrings.t('whoCanComment'),
                        'comment_privacy',
                        [
                          MapEntry('all', AppStrings.t('privAll')),
                          MapEntry('followers', AppStrings.t('privFollowers')),
                          MapEntry('none', AppStrings.t('privNone')),
                        ],
                      ),
                      _choiceRow(
                        AppStrings.t('whoCanMention'),
                        'mention_privacy',
                        [
                          MapEntry('all', AppStrings.t('privAll')),
                          MapEntry('followers', AppStrings.t('privFollowers')),
                          MapEntry('none', AppStrings.t('privNone')),
                        ],
                      ),
                      _tile(
                        title: AppStrings.t('titleCloseFriends'),
                        subtitle: AppStrings.t('closeFriendsHint'),
                        trailing: const Icon(
                          Icons.star_border_outlined,
                          size: 20,
                        ),
                        onTap: _openCloseFriends,
                      ),
                      _tile(
                        title: AppStrings.t('titleMutedAccounts'),
                        subtitle: AppStrings.t('mutedHint'),
                        trailing: const Icon(
                          Icons.volume_off_outlined,
                          size: 20,
                        ),
                        onTap: _openMuted,
                      ),

                      // ---- Content (v1.2.1: moved from the profile screen) ----
                      _sectionTitle(AppStrings.t('secContent')),
                      _tile(
                        title: AppStrings.t('titleCollections'),
                        subtitle: AppStrings.t('collectionsHint'),
                        trailing: const Icon(
                          Icons.bookmark_border,
                          size: 20,
                        ),
                        onTap: _openCollections,
                      ),
                      _tile(
                        title: AppStrings.t('gridReorder'),
                        subtitle: AppStrings.t('gridReorderHint'),
                        trailing: const Icon(
                          Icons.grid_view_outlined,
                          size: 20,
                        ),
                        onTap: _me == null ? null : _openGridReorder,
                      ),
                      _tile(
                        title: AppStrings.t('titleDrafts'),
                        subtitle: AppStrings.t('draftsHint'),
                        trailing: const Icon(
                          Icons.drafts_outlined,
                          size: 20,
                        ),
                        onTap: _openDrafts,
                      ),
                      _tile(
                        title: AppStrings.t('titleInsights'),
                        subtitle: AppStrings.t('insightsHint'),
                        trailing: const Icon(
                          Icons.bar_chart_outlined,
                          size: 20,
                        ),
                        onTap: _openInsights,
                      ),

                      // ---- Notifications (in-app only) ----
                      _sectionTitle(AppStrings.t('secNotifications')),
                      _sectionHint(AppStrings.t('notifHint')),
                      // Push notifications: tap re-requests the
                      // permission, or opens the system notification
                      // settings when it is permanently denied. The
                      // subtitle is "not available in this build yet"
                      // until google-services.json is wired.
                      ValueListenableBuilder<PushPermissionStatus?>(
                        valueListenable:
                            PushService.instance.permissionStatus,
                        builder: (context, _, __) => _tile(
                          title: AppStrings.t('pushNotifications'),
                          subtitle: AppStrings.t(
                            PushService.instance.statusSubtitleKey(),
                          ),
                          trailing: Icon(
                            PushService.instance.permissionStatus.value ==
                                    PushPermissionStatus.granted
                                ? Icons.notifications_active_outlined
                                : Icons.notifications_off_outlined,
                            size: 20,
                          ),
                          onTap: () async {
                            await PushService.instance
                                .requestPermissionFromSettings();
                            if (mounted) setState(() {});
                          },
                        ),
                      ),
                      _switchRow(
                        title: AppStrings.t('notifMessages'),
                        field: 'notif_messages',
                      ),
                      _switchRow(
                        title: AppStrings.t('notifLikes'),
                        field: 'notif_likes',
                      ),
                      _switchRow(
                        title: AppStrings.t('notifFollowers'),
                        field: 'notif_followers',
                      ),
                      _switchRow(
                        title: AppStrings.t('notifMentions'),
                        field: 'notif_mentions',
                      ),

                      // ---- Language ----
                      _sectionTitle(AppStrings.t('secLanguage')),
                      _sectionHint(AppStrings.t('languageHint')),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                        child: SegmentedButton<String>(
                          segments: [
                            ButtonSegment<String>(
                              value: 'ar',
                              label: Text(AppStrings.t('languageArabic')),
                            ),
                            ButtonSegment<String>(
                              value: 'en',
                              label: Text(AppStrings.t('languageEnglish')),
                            ),
                          ],
                          selected: {AppStrings.current},
                          onSelectionChanged: (s) =>
                              AppStrings.setLanguage(s.first),
                          style: ButtonStyle(
                            backgroundColor:
                                WidgetStateProperty.resolveWith(
                              (states) =>
                                  states.contains(WidgetState.selected)
                                      ? HamsiqTheme.accent
                                      : HamsiqTheme.panel2,
                            ),
                            foregroundColor:
                                WidgetStateProperty.all(Colors.white),
                          ),
                        ),
                      ),

                      // ---- About ----
                      _sectionTitle(AppStrings.t('secAbout')),
                      _tile(
                        title: AppStrings.t('appName'),
                        subtitle:
                            '${AppStrings.t('appVersion')} 1.2.2',
                        trailing: const SizedBox.shrink(),
                      ),

                      // ---- Logout ----
                      const SizedBox(height: 16),
                      _tile(
                        title: AppStrings.t('logout'),
                        titleColor: Colors.redAccent,
                        trailing: const Icon(
                          Icons.logout,
                          color: Colors.redAccent,
                          size: 20,
                        ),
                        onTap: _confirmLogout,
                      ),
                      const SizedBox(height: 32),
                    ],
                  ),
      ),
    );
  }
}
