// Hamsiq native — Post detail screen (Phase 2, workstream A).
// Full post (author, caption, media, like button + count) + comments
// list (oldest first, matching the web app) + add-comment field.
// Own comments can be deleted after a confirmation dialog.

import 'package:flutter/material.dart';
import '../models.dart';
import '../services/app_strings.dart';
import '../services/collections_api.dart';
import '../services/comments_api.dart';
import '../services/notifications_api.dart';
import '../services/share_api.dart';
import '../services/supabase_service.dart';
import '../services/wave2_api.dart';
import '../services/wave3_api.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/comments_sheet.dart';
import '../widgets/shared_post_card.dart';
import 'collab_invites_screen.dart';
import 'collections_screen.dart';

class PostDetailScreen extends StatefulWidget {
  final PostItem post;
  const PostDetailScreen({super.key, required this.post});

  @override
  State<PostDetailScreen> createState() => _PostDetailScreenState();
}

class _PostDetailScreenState extends State<PostDetailScreen> {
  List<CommentItem> _comments = [];
  bool _loading = true;
  bool _sending = false;
  final _controller = TextEditingController();

  // Wave 1 state: repost/save button states, and the comment being
  // replied to (null = top-level comment). _pinnedPost mirrors
  // PostItem.isPinned (final on the model) so the pin button can flip.
  bool _reposted = false;
  bool _saved = false;
  bool _pinnedPost = false;
  CommentItem? _replyTo;

  // Wave 2: per-post options (final on the model, so local mirrors).
  bool _isFavourite = false;
  bool _hideLikes = false;
  bool _commentsOff = false;
  String _altText = '';

  // Wave 3: collab collaborators on this post (additive display only).
  List<PostCollaborator> _collaborators = [];

  PostCollaborator? get _myPendingInvite {
    final myId = Api.isLoggedIn ? Api.myId : null;
    if (myId == null) return null;
    for (final c in _collaborators) {
      if (c.userId == myId && c.isPending) return c;
    }
    return null;
  }

  PostItem get _post => widget.post;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait([
        CommentsApi.fetchComments(_post.id),
        ShareApi.isReposted(_post.id),
        CollectionsApi.isSaved(_post.id),
        // Wave 2: favourite state (best-effort — a failure just
        // leaves the star off).
        Wave2Api.isFavourite(_post.userId).then(
          (v) => v,
          onError: (_) => false,
        ),
        // Wave 3: collab collaborators (best-effort — a failure just
        // hides the co-author row).
        Wave3Api.fetchPostCollaborators(_post.id).then(
          (v) => v,
          onError: (_) => <PostCollaborator>[],
        ),
      ]);
      if (!mounted) return;
      setState(() {
        _comments = results[0] as List<CommentItem>;
        _reposted = results[1] as bool;
        _saved = results[2] as bool;
        _isFavourite = results[3] as bool;
        _collaborators = results[4] as List<PostCollaborator>;
        // Only on first load: after an option toggle the local
        // mirrors are fresher than the stale PostItem passed in.
        if (_loading) {
          _pinnedPost = _post.isPinned;
          _hideLikes = _post.hideLikeCount;
          _commentsOff = _post.commentsDisabled;
          _altText = _post.altText ?? '';
        }
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      showError(context, e);
    }
  }

  Future<void> _toggleLike() async {
    final wasLiked = _post.likedByMe;
    final wasCount = _post.likeCount;
    setState(() {
      _post.likedByMe = !wasLiked;
      _post.likeCount = wasLiked ? wasCount - 1 : wasCount + 1;
    });
    try {
      await Api.setLiked(_post.id, !wasLiked);
      // Wave 1: like notification to the post owner (best-effort; a
      // notification failure must never undo the like). No notification
      // for unliking, and never for my own post (notify() no-ops there).
      if (!wasLiked) {
        try {
          await NotificationsApi.notifyLike(_post.userId, _post.id);
        } catch (_) {}
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _post.likedByMe = wasLiked;
        _post.likeCount = wasCount;
      });
      showError(context, e);
    }
  }

  Future<void> _toggleRepost() async {
    final next = !_reposted;
    setState(() => _reposted = next);
    try {
      await ShareApi.toggleRepost(_post.id, next);
      if (mounted) {
        showOk(context, next ? AppStrings.t('reposted') : AppStrings.t('repostUndone'));
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _reposted = !next);
      showError(context, e);
    }
  }

  Future<void> _toggleSave() async {
    try {
      if (!_saved) {
        // Saving opens the collections sheet (save + pick a collection).
        await showAddToCollectionSheet(context, _post);
        if (!mounted) return;
        final savedNow = await CollectionsApi.isSaved(_post.id);
        if (!mounted) return;
        setState(() => _saved = savedNow);
      } else {
        await CollectionsApi.toggleSave(_post.id, false);
        if (!mounted) return;
        setState(() => _saved = false);
        showOk(context, AppStrings.t('unsaved'));
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _togglePinPost() async {
    final next = !_pinnedPost;
    try {
      await ShareApi.setPostPinned(_post.id, next);
      if (!mounted) return;
      setState(() => _pinnedPost = next);
      showOk(context, next ? AppStrings.t('postPinned') : AppStrings.t('postUnpinned'));
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  // ---------------- Wave 2: post options ----------------

  Future<void> _toggleFavourite() async {
    final next = !_isFavourite;
    setState(() => _isFavourite = next);
    try {
      await Wave2Api.setFavourite(_post.userId, next);
      if (mounted) {
        showOk(
          context,
          next
              ? AppStrings.t('addedToFavourites')
              : AppStrings.t('removedFromFavourites'),
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _isFavourite = !next);
      showError(context, e);
    }
  }

  Future<void> _setHideLikes(bool hide) async {
    setState(() => _hideLikes = hide);
    try {
      await Wave2Api.setPostOptions(_post.id, hideLikeCount: hide);
    } catch (e) {
      if (!mounted) return;
      setState(() => _hideLikes = !hide);
      showError(context, e);
    }
  }

  Future<void> _setCommentsOff(bool off) async {
    setState(() => _commentsOff = off);
    try {
      await Wave2Api.setPostOptions(_post.id, commentsDisabled: off);
    } catch (e) {
      if (!mounted) return;
      setState(() => _commentsOff = !off);
      showError(context, e);
    }
  }

  Future<void> _editAltText() async {
    final ctrl = TextEditingController(text: _altText);
    final saved = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('altText')),
        content: TextField(
          controller: ctrl,
          decoration: InputDecoration(
            hintText: AppStrings.t('altTextHint'),
          ),
          maxLines: 3,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(AppStrings.t('cancel')),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(ctx).pop(ctrl.text.trim()),
            child: Text(AppStrings.t('save')),
          ),
        ],
      ),
    );
    ctrl.dispose();
    if (saved == null || !mounted) return;
    try {
      await Wave2Api.setPostOptions(_post.id, altText: saved);
      if (mounted) {
        setState(() => _altText = saved);
        showOk(context, AppStrings.t('altTextSaved'));
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _muteAuthor({required bool snooze}) async {
    try {
      if (snooze) {
        await Wave2Api.muteAccount(_post.userId, snoozeDays: 30);
      } else {
        await Wave2Api.muteAccount(_post.userId);
      }
      if (mounted) {
        showOk(
          context,
          snooze
              ? AppStrings.t('snoozed30Done')
              : AppStrings.t('mutedDone'),
        );
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  // ---------------- Wave 3: collab ----------------

  /// Owner invites collaborators (sheet); reload the co-author row
  /// when the sheet closes.
  Future<void> _inviteCollaborators() async {
    await showCollabInviteSheet(context, _post);
    if (!mounted) return;
    try {
      final collabs = await Wave3Api.fetchPostCollaborators(_post.id);
      if (mounted) setState(() => _collaborators = collabs);
    } catch (_) {}
  }

  /// I was invited to co-author this post: accept or decline.
  Future<void> _respondToMyInvite(bool accept) async {
    try {
      await Wave3Api.respondToCollabInvite(_post.id, accept);
      if (!mounted) return;
      showOk(
        context,
        accept
            ? AppStrings.t('collabInviteAccepted')
            : AppStrings.t('collabInviteDeclined'),
      );
      final collabs = await Wave3Api.fetchPostCollaborators(_post.id);
      if (mounted) setState(() => _collaborators = collabs);
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  void _showPostOptions() {
    final myId = Api.isLoggedIn ? Api.myId : null;
    final isOwner = myId != null && myId == _post.userId;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: HamsiqTheme.panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 12),
              Center(
                child: Text(
                  AppStrings.t('postOptions'),
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 8),
              ListTile(
                leading: Icon(
                  _isFavourite ? Icons.star : Icons.star_border,
                  color: HamsiqTheme.accent,
                ),
                title: Text(
                  _isFavourite
                      ? AppStrings.t('removeFromFavourites')
                      : AppStrings.t('addToFavourites'),
                ),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _toggleFavourite();
                },
              ),
              if (!isOwner) ...[
                ListTile(
                  leading: const Icon(
                    Icons.volume_off_outlined,
                    color: HamsiqTheme.accent,
                  ),
                  title: Text(AppStrings.t('muteThisAccount')),
                  subtitle: Text(
                    AppStrings.t('muteAccountHint'),
                    style: TextStyle(color: HamsiqTheme.muted, fontSize: 12),
                  ),
                  onTap: () {
                    Navigator.of(ctx).pop();
                    _muteAuthor(snooze: false);
                  },
                ),
                ListTile(
                  leading: const Icon(
                    Icons.snooze_outlined,
                    color: HamsiqTheme.accent,
                  ),
                  title: Text(AppStrings.t('snooze30')),
                  onTap: () {
                    Navigator.of(ctx).pop();
                    _muteAuthor(snooze: true);
                  },
                ),
              ],
              if (isOwner) ...[
                // Wave 3: invite collaborators (owner only, max 5).
                ListTile(
                  leading: const Icon(
                    Icons.group_add_outlined,
                    color: HamsiqTheme.accent,
                  ),
                  title: Text(AppStrings.t('inviteCollaborator')),
                  subtitle: Text(
                    AppStrings.t('collabUpTo5'),
                    style: TextStyle(color: HamsiqTheme.muted, fontSize: 12),
                  ),
                  onTap: () {
                    Navigator.of(ctx).pop();
                    _inviteCollaborators();
                  },
                ),
                SwitchListTile(
                  title: Text(AppStrings.t('hideLikeCount')),
                  value: _hideLikes,
                  activeThumbColor: HamsiqTheme.accent,
                  onChanged: (v) {
                    Navigator.of(ctx).pop();
                    _setHideLikes(v);
                  },
                ),
                SwitchListTile(
                  title: Text(AppStrings.t('commentsOff')),
                  value: _commentsOff,
                  activeThumbColor: HamsiqTheme.accent,
                  onChanged: (v) {
                    Navigator.of(ctx).pop();
                    _setCommentsOff(v);
                  },
                ),
                ListTile(
                  leading: const Icon(
                    Icons.description_outlined,
                    color: HamsiqTheme.accent,
                  ),
                  title: Text(AppStrings.t('altText')),
                  subtitle: Text(
                    _altText.isEmpty ? AppStrings.t('altTextNotWritten') : _altText,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: HamsiqTheme.muted),
                  ),
                  onTap: () {
                    Navigator.of(ctx).pop();
                    _editAltText();
                  },
                ),
              ],
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _send() async {
    final text = _controller.text;
    if (text.trim().isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      final replyTo = _replyTo;
      final comment = await CommentsApi.addComment(
        _post.id,
        text,
        parentId: replyTo?.id,
      );
      // Wave 1: comment notification to the post owner (best-effort).
      // When replying, also notify the parent comment's author.
      try {
        await NotificationsApi.notifyComment(_post.userId, _post.id);
        if (replyTo != null && replyTo.authorId != _post.userId) {
          await NotificationsApi.notifyComment(replyTo.authorId, _post.id);
        }
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _comments = CommentsApi.threadComments([..._comments, comment]);
        _controller.clear();
        _replyTo = null;
        _sending = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _sending = false);
      showError(context, e);
    }
  }

  Future<void> _sendGif(String gifUrl) async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      final comment = await CommentsApi.addGifComment(_post.id, gifUrl);
      try {
        await NotificationsApi.notifyComment(_post.userId, _post.id);
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _comments = CommentsApi.threadComments([..._comments, comment]);
        _sending = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _sending = false);
      showError(context, e);
    }
  }

  void _showGifPicker() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: HamsiqTheme.panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Text(
                AppStrings.t('pickGif'),
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(16, 6, 16, 4),
              child: Text(
                AppStrings.t('gifNote'),
                textAlign: TextAlign.center,
                style: TextStyle(color: HamsiqTheme.muted, fontSize: 12),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 300,
              child: GridView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  childAspectRatio: 1.4,
                ),
                itemCount: CommentsApi.curatedGifUrls.length,
                itemBuilder: (_, i) {
                  final url = CommentsApi.curatedGifUrls[i];
                  return GestureDetector(
                    onTap: () {
                      Navigator.of(sheetContext).pop();
                      _sendGif(url);
                    },
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        url,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          color: HamsiqTheme.panel2,
                          alignment: Alignment.center,
                          child: const Icon(
                            Icons.broken_image_outlined,
                            color: HamsiqTheme.muted,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _togglePinComment(CommentItem comment) async {
    try {
      final pinned = await CommentsApi.setCommentPinned(
        comment,
        _post.userId,
        !comment.isPinned,
      );
      if (!mounted) return;
      setState(() {
        _comments = _comments
            .map(
              (c) => c.id == comment.id
                  ? CommentItem(
                      id: c.id,
                      postId: c.postId,
                      authorId: c.authorId,
                      body: c.body,
                      createdAt: c.createdAt,
                      parentId: c.parentId,
                      gifUrl: c.gifUrl,
                      isPinned: pinned,
                      author: c.author,
                    )
                  : c,
            )
            .toList();
        _comments = CommentsApi.orderComments(_comments);
      });
      showOk(context, pinned ? AppStrings.t('commentPinned') : AppStrings.t('commentUnpinned'));
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _confirmDelete(CommentItem comment) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('deleteCommentTitle')),
        content: Text(AppStrings.t('deleteCommentBody')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(AppStrings.t('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(
              AppStrings.t('delete'),
              style: TextStyle(color: Colors.redAccent),
            ),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final myId = Api.isLoggedIn ? Api.myId : null;
      await CommentsApi.deleteComment(
        comment.id,
        asPostOwner: myId != null &&
            myId == _post.userId &&
            comment.authorId != myId,
      );
      if (!mounted) return;
      setState(() => _comments.removeWhere((c) => c.id == comment.id));
      showOk(context, AppStrings.t('commentDeleted'));
    } catch (e) {
      if (!mounted) return;
      showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    final author = _post.author;
    final myId = Api.isLoggedIn ? Api.myId : null;
    return Scaffold(
      appBar: AppBar(
        title: Text(AppStrings.t('postTitle')),
        actions: [
          // Wave 2: post options (hide likes, comments off, alt text,
          // favourite, mute/snooze).
          IconButton(
            icon: const Icon(Icons.more_vert),
            tooltip: AppStrings.t('postOptions'),
            onPressed: _showPostOptions,
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _loading
                ? const LoadingCenter()
                : RefreshIndicator(
                    color: HamsiqTheme.accent,
                    onRefresh: _load,
                    child: ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.all(12),
                      children: [
                        // ---- post header ----
                        Row(
                          children: [
                            AvatarWidget(profile: author, size: 42),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Flexible(
                                        child: Text(
                                          author?.displayName ?? '',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      if (author?.verified == true) ...[
                                        const SizedBox(width: 4),
                                        const VerifiedTick(),
                                      ],
                                    ],
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    '@${author?.username ?? ''} · ${timeAgo(_post.createdAt)}',
                                    style: const TextStyle(
                                      color: HamsiqTheme.muted,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        // Wave 3: co-authors row (accepted + pending) +
                        // my own pending invite banner (accept/decline).
                        if (_collaborators.isNotEmpty) ...[
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: HamsiqTheme.panel2,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Row(
                                  children: [
                                    Icon(
                                      Icons.group_outlined,
                                      size: 16,
                                      color: HamsiqTheme.accent,
                                    ),
                                    SizedBox(width: 6),
                                    Text(
                                      AppStrings.t('coAuthoredWith'),
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Wrap(
                                  spacing: 12,
                                  runSpacing: 8,
                                  children: [
                                    for (final c in _collaborators)
                                      Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          AvatarWidget(
                                            profile: c.profile,
                                            size: 28,
                                          ),
                                          const SizedBox(width: 6),
                                          Text(
                                            c.profile?.displayName ?? '',
                                            style: const TextStyle(
                                              fontSize: 13,
                                            ),
                                          ),
                                          const SizedBox(width: 4),
                                          Container(
                                            padding:
                                                const EdgeInsets.symmetric(
                                              horizontal: 6,
                                              vertical: 2,
                                            ),
                                            decoration: BoxDecoration(
                                              color: c.isAccepted
                                                  ? HamsiqTheme.accent
                                                      .withValues(alpha: 0.25)
                                                  : HamsiqTheme.panel,
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            child: Text(
                                              c.isAccepted
                                                  ? AppStrings.t('collabAccepted')
                                                  : c.isPending
                                                      ? AppStrings.t('collabPending')
                                                      : AppStrings.t('collabDecline'),
                                              style: TextStyle(
                                                fontSize: 11,
                                                color: c.isAccepted
                                                    ? HamsiqTheme.accent
                                                    : HamsiqTheme.muted,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                  ],
                                ),
                                if (_myPendingInvite != null) ...[
                                  const SizedBox(height: 10),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: ElevatedButton(
                                          onPressed: () =>
                                              _respondToMyInvite(true),
                                          child: Text(AppStrings.t('collabAccept')),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: ElevatedButton(
                                          onPressed: () =>
                                              _respondToMyInvite(false),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                HamsiqTheme.panel,
                                            foregroundColor: Colors.white,
                                          ),
                                          child: Text(AppStrings.t('collabDecline')),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ],
                        if (_post.caption.isNotEmpty) ...[
                          const SizedBox(height: 10),
                          Text(
                            _post.caption,
                            style: const TextStyle(fontSize: 15),
                          ),
                        ],
                        if (_post.mediaUrl != null) ...[
                          const SizedBox(height: 10),
                          _DetailMedia(post: _post),
                        ],
                        // Wave 2: alt text (accessibility description).
                        if (_altText.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(
                            '${AppStrings.t('imageDescription')}: $_altText',
                            style: const TextStyle(
                              fontSize: 13,
                              color: HamsiqTheme.muted,
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ],
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            IconButton(
                              onPressed: _toggleLike,
                              icon: Icon(
                                _post.likedByMe
                                    ? Icons.favorite
                                    : Icons.favorite_border,
                                color: _post.likedByMe
                                    ? HamsiqTheme.accent
                                    : HamsiqTheme.muted,
                              ),
                            ),
                            // Wave 2: hidden like count per post.
                            Text(
                              _hideLikes ? '' : '${_post.likeCount}',
                              style: const TextStyle(
                                color: HamsiqTheme.muted,
                              ),
                            ),
                            const SizedBox(width: 16),
                            const Icon(
                              Icons.chat_bubble_outline,
                              color: HamsiqTheme.muted,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              _commentsOff
                                  ? AppStrings.t('commentsClosed')
                                  : '${_comments.length}',
                              style: const TextStyle(
                                color: HamsiqTheme.muted,
                              ),
                            ),
                            // Wave 1: share / repost / save / pin-post.
                            IconButton(
                              tooltip: AppStrings.t('shareTooltip'),
                              onPressed: () =>
                                  showSharePostSheet(context, _post),
                              icon: const Icon(
                                Icons.send_outlined,
                                color: HamsiqTheme.muted,
                              ),
                            ),
                            IconButton(
                              tooltip: AppStrings.t('repostTooltip'),
                              onPressed: _toggleRepost,
                              icon: Icon(
                                Icons.repeat,
                                color: _reposted
                                    ? HamsiqTheme.accent
                                    : HamsiqTheme.muted,
                              ),
                            ),
                            IconButton(
                              tooltip: AppStrings.t('saveTooltip'),
                              onPressed: _toggleSave,
                              icon: Icon(
                                _saved
                                    ? Icons.bookmark
                                    : Icons.bookmark_border,
                                color: _saved
                                    ? HamsiqTheme.accent
                                    : HamsiqTheme.muted,
                              ),
                            ),
                            if (myId != null && myId == _post.userId)
                              IconButton(
                                tooltip: AppStrings.t('pinTooltip'),
                                onPressed: _togglePinPost,
                                icon: Icon(
                                  _pinnedPost
                                      ? Icons.push_pin
                                      : Icons.push_pin_outlined,
                                  color: _pinnedPost
                                      ? HamsiqTheme.accent
                                      : HamsiqTheme.muted,
                                ),
                              ),
                          ],
                        ),
                        const Divider(color: HamsiqTheme.line),
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Text(
                            AppStrings.t('notifComments'),
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        // Wave 2: comments can be turned off per post.
                        if (_commentsOff)
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 24),
                            child: EmptyCenter(
                              AppStrings.t('commentsClosedPost'),
                            ),
                          )
                        else if (_comments.isEmpty)
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 24),
                            child: EmptyCenter(
                              AppStrings.t('noCommentsYet'),
                            ),
                          )
                        else
                          // Wave 1: threaded — replies nest under their
                          // parent (CommentsApi.threadComments ordering).
                          ...CommentsApi.threadComments(_comments).map(
                            (c) => CommentRow(
                              comment: c,
                              isMine: myId != null && c.authorId == myId,
                              isPostOwner:
                                  myId != null && myId == _post.userId,
                              canPin: (myId != null &&
                                      myId == _post.userId) ||
                                  (myId != null && c.authorId == myId),
                              onDelete: () => _confirmDelete(c),
                              onReply: () {
                                setState(() => _replyTo = c);
                              },
                              onTogglePin: () => _togglePinComment(c),
                            ),
                          ),
                      ],
                    ),
                  ),
          ),
          // ---- add-comment field (hidden when comments are off) ----
          if (!_commentsOff)
            Container(
              padding: EdgeInsets.fromLTRB(
                12,
                8,
                12,
                MediaQuery.of(context).padding.bottom + 8,
              ),
            decoration: const BoxDecoration(
              color: HamsiqTheme.panel,
              border: Border(top: BorderSide(color: HamsiqTheme.line)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Wave 1: replying-to indicator.
                if (_replyTo != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${AppStrings.t('replyTo')} ${_replyTo!.author?.displayName ?? ''}',
                            style: const TextStyle(
                              color: HamsiqTheme.accent,
                              fontSize: 13,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        GestureDetector(
                          onTap: () => setState(() => _replyTo = null),
                          child: const Icon(
                            Icons.close,
                            size: 18,
                            color: HamsiqTheme.muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        maxLength: CommentsApi.maxBodyLength,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) => _send(),
                        decoration: InputDecoration(
                          hintText: _replyTo == null
                              ? AppStrings.t('writeComment')
                              : AppStrings.t('writeReply'),
                          counterText: '',
                        ),
                      ),
                    ),
                    const SizedBox(width: 4),
                    // Wave 1: GIF picker (curated set, no search API).
                    IconButton(
                      tooltip: 'GIF',
                      onPressed: _showGifPicker,
                      icon: const Icon(
                        Icons.gif_box_outlined,
                        color: HamsiqTheme.muted,
                      ),
                    ),
                    const SizedBox(width: 4),
                    _sending
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              color: HamsiqTheme.accent,
                              strokeWidth: 2,
                            ),
                          )
                        : IconButton(
                            onPressed: _send,
                            icon: const Icon(
                              Icons.send,
                              color: HamsiqTheme.accent,
                            ),
                          ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailMedia extends StatelessWidget {
  final PostItem post;
  const _DetailMedia({required this.post});

  @override
  Widget build(BuildContext context) {
    if (post.mediaType == 'video') {
      // Video playback lives in the Reels tab — show a tile only.
      return Container(
        height: 220,
        width: double.infinity,
        decoration: BoxDecoration(
          color: HamsiqTheme.bgDeep,
          borderRadius: BorderRadius.circular(12),
        ),
        child: const Center(
          child: Icon(
            Icons.play_circle_filled,
            size: 64,
            color: HamsiqTheme.accent,
          ),
        ),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: SignedMediaImage(
        url: post.mediaUrl!,
        width: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          height: 300,
          width: double.infinity,
          color: HamsiqTheme.panel2,
          alignment: Alignment.center,
          child: const Icon(
            Icons.broken_image_outlined,
            color: HamsiqTheme.muted,
            size: 40,
          ),
        ),
      ),
    );
  }
}
