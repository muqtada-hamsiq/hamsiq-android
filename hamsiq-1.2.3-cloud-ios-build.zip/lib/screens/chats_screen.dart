// Hamsiq native — chats list + DM thread (Phase 2, workstream C).
// Full message types (text / image / video / voice / file / location /
// contact / poll), reply/quote, seen ticks, mute + archive, voice
// recording + playback. All backed by real columns/tables — see
// lib/services/messages_api.dart for the schema map.
// Polling every 4s; no Realtime yet.

import 'dart:async';
import 'dart:convert';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:video_player/video_player.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/media_api.dart';
import '../services/messages_api.dart';
import '../services/platform_file.dart';
import '../services/polls_api.dart';
import '../services/push_service.dart';
import '../services/supabase_service.dart';
import '../services/wave2_api.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/poll_card.dart';
import '../widgets/shared_post_card.dart';
import 'blend_screen.dart';
import 'groups_screen.dart';
import 'profile_screen.dart';

String _fmtDuration(int totalSeconds) {
  final m = totalSeconds ~/ 60;
  final s = totalSeconds % 60;
  return '$m:${s.toString().padLeft(2, '0')}';
}

String _fmtFileSize(int bytes) {
  if (bytes < 1024) return '$bytes ${AppStrings.t('byteUnit')}';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} ${AppStrings.t('kbUnit')}';
  return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} ${AppStrings.t('mbUnit')}';
}

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});

  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  List<ChatRow> _rows = [];
  Set<String> _muted = {};
  bool _loading = true;
  // Mockup-match redesign (2026-11-16): live search + All/Requests tabs.
  final _search = TextEditingController();
  String _query = '';
  bool _showRequests = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  /// Rows after the live search filter (peer name/username + last
  /// message text). The Requests tab has no data source in the native
  /// app, so it shows a placeholder instead of rows.
  List<ChatRow> get _filteredRows {
    if (_query.isEmpty) return _rows;
    final q = _query.toLowerCase();
    return _rows.where((r) {
      if (r.peer.displayName.toLowerCase().contains(q)) return true;
      if (r.peer.username.toLowerCase().contains(q)) return true;
      final last = r.last;
      if (last != null &&
          MessagesApi.labelForChatMessage(last)
              .toLowerCase()
              .contains(q)) {
        return true;
      }
      return false;
    }).toList();
  }

  Future<void> _load() async {
    try {
      final rows = await Api.fetchChatList();
      // Mute/archive sets are best-effort: the list still renders
      // without them (nothing muted / nothing archived).
      Set<String> muted = {};
      Set<String> archived = {};
      try {
        muted = await MessagesApi.fetchMutedPeerIds();
      } catch (_) {}
      try {
        archived = await MessagesApi.fetchArchivedPeerIds();
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        // Archived chats are hidden from the main list.
        _rows = rows.where((r) => !archived.contains(r.peer.id)).toList();
        _muted = muted;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      showError(context, e);
    }
  }

  Future<void> _openThread(ChatRow row) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ThreadScreen(peer: row.peer)),
    );
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    // H-06 Part 2: live language rebuild on language change.
    return ValueListenableBuilder<String>(
      valueListenable: AppStrings.lang,
      builder: (context, _, __) => _build(context),
    );
  }

  Widget _build(BuildContext context) {
    final rows = _filteredRows;
    return Scaffold(
      backgroundColor: HamsiqTheme.bg,
      body: Column(
        children: [
          // Mockup-match header: the profile waves flow behind the top
          // bar — centred title, blue paper-plane + Hamsiq brand on
          // the right, blue-outline compose button on the left. No
          // back button: the mockup has none (system back still works).
          ProfileWavesBackground(
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
                child: Row(
                  children: [
                    // Brand (right in RTL): paper plane + Hamsiq — a
                    // brand mark, not a button.
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(
                          Icons.send_outlined,
                          color: HamsiqTheme.accent,
                          size: 30,
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Hamsiq',
                          style: TextStyle(
                            color: HamsiqTheme.text,
                            fontWeight: FontWeight.w800,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                    Expanded(
                      child: Center(
                        child: Text(
                          AppStrings.t('directMessagesTitle'),
                          style: const TextStyle(
                            color: HamsiqTheme.text,
                            fontWeight: FontWeight.w800,
                            fontSize: 22,
                          ),
                        ),
                      ),
                    ),
                    // Compose (left in RTL): no dedicated new-chat
                    // picker exists in the app, so this keeps the
                    // Groups entry point, which lives only here.
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: HamsiqTheme.accent,
                          width: 1.5,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: IconButton(
                        icon: const Icon(
                          Icons.edit_square,
                          color: HamsiqTheme.accent,
                        ),
                        tooltip: AppStrings.t('groupsTitle'),
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => const GroupsScreen(),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Search pill (live filter).
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 2, 16, 10),
            child: TextField(
              controller: _search,
              decoration: InputDecoration(
                hintText: AppStrings.t('searchMessages'),
                prefixIcon:
                    const Icon(Icons.search, color: HamsiqTheme.muted),
                filled: true,
                fillColor: HamsiqTheme.panel2,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(26),
                  borderSide: const BorderSide(color: HamsiqTheme.line),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(26),
                  borderSide: const BorderSide(color: HamsiqTheme.line),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(26),
                  borderSide:
                      const BorderSide(color: HamsiqTheme.accent),
                ),
                contentPadding:
                    const EdgeInsets.symmetric(vertical: 12),
              ),
              onChanged: (v) => setState(() => _query = v.trim()),
            ),
          ),
          // All / Requests pill tabs.
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Row(
              children: [
                Expanded(
                  child: _tabPill(
                    label: AppStrings.t('allMessages'),
                    active: !_showRequests,
                    onTap: () => setState(() => _showRequests = false),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _tabPill(
                    label: AppStrings.t('msgRequests'),
                    icon: Icons.person_add_outlined,
                    active: _showRequests,
                    onTap: () => setState(() => _showRequests = true),
                  ),
                ),
              ],
            ),
          ),
          Expanded(child: _buildList(rows)),
        ],
      ),
    );
  }

  /// One pill tab: blue-filled when active, dark when inactive.
  Widget _tabPill({
    required String label,
    required bool active,
    required VoidCallback onTap,
    IconData? icon,
  }) {
    final fg = active ? Colors.white : HamsiqTheme.muted;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          color: active ? HamsiqTheme.accent : HamsiqTheme.panel2,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: active ? HamsiqTheme.accent : HamsiqTheme.line,
          ),
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, color: fg, size: 20),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: TextStyle(
                color: fg,
                fontWeight: FontWeight.w700,
                fontSize: 15,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildList(List<ChatRow> rows) {
    if (_loading) return const LoadingCenter();
    if (_showRequests) {
      // No message-requests data source exists in the native app —
      // the tab is a placeholder until one is built.
      return EmptyCenter(AppStrings.t('noRequestsYet'));
    }
    if (_rows.isEmpty) return EmptyCenter(AppStrings.t('noChatsYet'));
    if (rows.isEmpty) return EmptyCenter(AppStrings.t('noSearchResults'));
    return RefreshIndicator(
      color: HamsiqTheme.accent,
      onRefresh: _load,
      child: ListView.builder(
        itemCount: rows.length,
        itemBuilder: (_, i) => _ChatCard(
          row: rows[i],
          muted: _muted.contains(rows[i].peer.id),
          onTap: () => _openThread(rows[i]),
        ),
      ),
    );
  }
}

/// Mockup-match chat card: rounded ~20, dark fill with a subtle blue
/// glow border, avatar on the right, name + last message, time + unread
/// badge on the left. No online dot: the profile model has no presence
/// data, so none is faked.
class _ChatCard extends StatelessWidget {
  final ChatRow row;
  final bool muted;
  final VoidCallback onTap;
  const _ChatCard({
    required this.row,
    required this.muted,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final last = row.last;
    // Seen ticks come from the real message state only: shown when the
    // last message is mine — double blue tick if read, single grey if
    // not (same convention as the thread screen).
    final mine = last != null && last.senderId == Api.myId;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: HamsiqTheme.panel,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: HamsiqTheme.accent.withValues(alpha: 0.22),
          ),
          boxShadow: [
            BoxShadow(
              color: HamsiqTheme.accent.withValues(alpha: 0.10),
              blurRadius: 14,
            ),
          ],
        ),
        child: Row(
          children: [
            AvatarWidget(profile: row.peer, size: 56),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          row.peer.displayName,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                            color: HamsiqTheme.text,
                          ),
                        ),
                      ),
                      if (row.peer.verified) ...[
                        const SizedBox(width: 4),
                        const VerifiedTick(),
                      ],
                      if (muted) ...[
                        const SizedBox(width: 6),
                        const Icon(
                          Icons.volume_off,
                          size: 15,
                          color: HamsiqTheme.muted,
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (mine) ...[
                        Icon(
                          last.read ? Icons.done_all : Icons.done,
                          size: 16,
                          color: last.read
                              ? HamsiqTheme.accent
                              : HamsiqTheme.muted,
                        ),
                        const SizedBox(width: 4),
                      ],
                      Expanded(
                        child: Text(
                          last == null
                              ? AppStrings.t('startChat')
                              : MessagesApi.labelForChatMessage(last),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style:
                              const TextStyle(color: HamsiqTheme.muted),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (last != null)
                  Text(
                    timeAgo(last.createdAt),
                    style: const TextStyle(
                      color: HamsiqTheme.muted,
                      fontSize: 12,
                    ),
                  ),
                if (row.unread > 0) ...[
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 7,
                      vertical: 2,
                    ),
                    decoration: const BoxDecoration(
                      color: HamsiqTheme.accent,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      '${row.unread}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class ThreadScreen extends StatefulWidget {
  final HamsiqProfile peer;
  const ThreadScreen({super.key, required this.peer});

  @override
  State<ThreadScreen> createState() => _ThreadScreenState();
}

class _ThreadScreenState extends State<ThreadScreen> {
  List<DmMessage> _messages = [];
  bool _loading = true;
  bool _sending = false;
  bool _fetching = false;
  Timer? _poll;
  final _scroll = ScrollController();
  final _input = TextEditingController();

  // Reply / quote (messages.reply_to, sql-v12).
  DmMessage? _replyTo;

  // Mute / archive state for this peer (muted_chats / archived_chats).
  bool _muted = false;
  bool _archived = false;

  // Wave 2: vanish mode (vanish_chats), per-chat theme colour
  // (chat_themes), in-thread translations (MyMemory, session-local).
  bool _vanishOn = false;
  int? _chatColor;
  final _translations = <int, String>{};
  final _translating = <int>{};

  // Voice recording (record package; .m4a via AAC-LC).
  final _recorder = AudioRecorder();
  bool _recording = false;
  // H-07c: guards the async gap between a tap and _recording becoming
  // true — without it a fast double-tap starts the recorder twice.
  bool _recStarting = false;
  int _recSeconds = 0;
  Timer? _recTimer;
  bool _recCancel = false;

  @override
  void initState() {
    super.initState();
    // Push: a foreground message for this thread must not show a
    // banner while the user is already viewing it.
    PushService.instance.setActiveThread(PushRoute.dm(widget.peer.id));
    _init();
    _poll = Timer.periodic(const Duration(seconds: 4), (_) => _pollLoad());
  }

  Future<void> _init() async {
    try {
      // SECURITY DEFINER RPC (sql-v21) — the direct UPDATE policy
      // was dropped there, so Api.markThreadRead no longer works.
      await MessagesApi.markThreadRead(widget.peer.id);
    } catch (_) {
      // Marking read is best-effort; the thread still loads.
    }
    try {
      _muted = await MessagesApi.isMuted(widget.peer.id);
    } catch (_) {}
    try {
      _archived = await MessagesApi.isArchived(widget.peer.id);
    } catch (_) {}
    // Wave 2: vanish toggle + chat theme (best-effort; defaults apply
    // when sql-v30 has not run yet).
    try {
      _vanishOn = await MessagesApi.isVanish(widget.peer.id);
    } catch (_) {}
    try {
      _chatColor = await Wave2Api.fetchChatTheme(widget.peer.id);
    } catch (_) {}
    await _load(jumpToBottom: true);
  }

  Future<void> _load({bool jumpToBottom = false}) async {
    if (_fetching) return;
    _fetching = true;
    try {
      final msgs = await MessagesApi.fetchThread(widget.peer.id);
      if (!mounted) return;
      final atBottom = !_scroll.hasClients ||
          _scroll.position.pixels >=
              _scroll.position.maxScrollExtent - 80;
      final hadUnread =
          msgs.any((m) => m.senderId == widget.peer.id && !m.read);
      setState(() {
        _messages = msgs;
        _loading = false;
      });
      if (jumpToBottom || atBottom) _scrollToBottom();
      if (hadUnread) {
        // Keep the peer's seen ticks accurate while the thread is open.
        try {
          await MessagesApi.markThreadRead(widget.peer.id);
        } catch (_) {}
      }
    } catch (e) {
      if (!mounted) return;
      final wasInitial = _loading;
      setState(() => _loading = false);
      // Only surface errors on the initial load; a failed background
      // poll retries silently 4s later instead of spamming snackbars.
      if (wasInitial) showError(context, e);
    } finally {
      _fetching = false;
    }
  }

  void _pollLoad() {
    if (!mounted || _loading) return;
    _load();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_scroll.hasClients) return;
      _scroll.jumpTo(_scroll.position.maxScrollExtent);
    });
  }

  Map<int, DmMessage> get _byId => {for (final m in _messages) m.id: m};

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      if (_replyTo != null) {
        await MessagesApi.sendReply(
          widget.peer.id,
          text,
          _replyTo!.id,
          vanish: _vanishOn,
        );
      } else if (_vanishOn) {
        // Api.sendMessage has no vanish flag — use the Wave 2 text
        // sender when vanish mode is on.
        await MessagesApi.sendTextMessage(
          widget.peer.id,
          text,
          vanish: true,
        );
      } else {
        await Api.sendMessage(widget.peer.id, text);
      }
      if (!mounted) return;
      _input.clear();
      setState(() => _replyTo = null);
      await _load(jumpToBottom: true);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  // ---------------- poll (sql-v28) ----------------

  Future<void> _createPoll() async {
    if (_sending) return;
    final pollId = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: HamsiqTheme.panel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => CreatePollSheet(
        onCreatePoll: (q, opts) => PollsApi.createPoll(
          dmPeerId: widget.peer.id,
          question: q,
          options: opts,
        ),
      ),
    );
    if (pollId == null || !mounted) return;
    setState(() => _sending = true);
    try {
      await PollsApi.postPollMessage(
        dmPeerId: widget.peer.id,
        pollId: pollId,
      );
      await _load(jumpToBottom: true);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  // ---------------- attach: photo / video ----------------

  Future<void> _pickAndSend({
    required bool video,
    required bool camera,
    bool viewOnce = false,
  }) async {
    try {
      final picker = ImagePicker();
      final XFile? picked = video
          ? await picker.pickVideo(
              source: camera ? ImageSource.camera : ImageSource.gallery,
            )
          : await picker.pickImage(
              source: camera ? ImageSource.camera : ImageSource.gallery,
            );
      if (picked == null || !mounted) return;
      setState(() => _sending = true);
      if (viewOnce) {
        await MessagesApi.sendViewOnceMessage(
          widget.peer.id,
          await readPickedBytes(picked),
          fileName: picked.name,
          isVideo: video,
        );
      } else {
        await MessagesApi.sendPhotoMessage(
          widget.peer.id,
          await readPickedBytes(picked),
          fileName: picked.name,
          isVideo: video,
          vanish: _vanishOn,
        );
      }
      if (!mounted) return;
      await _load(jumpToBottom: true);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _showAttachSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: HamsiqTheme.panel,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library,
                  color: HamsiqTheme.accent),
              title: Text(AppStrings.t('photoFromGallery')),
              onTap: () {
                Navigator.of(ctx).pop();
                _pickAndSend(video: false, camera: false);
              },
            ),
            ListTile(
              leading:
                  const Icon(Icons.camera_alt, color: HamsiqTheme.accent),
              title: Text(AppStrings.t('captureCamera')),
              onTap: () {
                Navigator.of(ctx).pop();
                _pickAndSend(video: false, camera: true);
              },
            ),
            ListTile(
              leading: const Icon(Icons.videocam, color: HamsiqTheme.accent),
              title: Text(AppStrings.t('videoFromGallery')),
              onTap: () {
                Navigator.of(ctx).pop();
                _pickAndSend(video: true, camera: false);
              },
            ),
            // Wave 2: view-once photo — the receiver opens it once,
            // then it is gone (media URL wiped server-side).
            ListTile(
              leading:
                  const Icon(Icons.visibility_off, color: HamsiqTheme.accent),
              title: Text(AppStrings.t('viewOncePhoto')),
              subtitle: Text(
                AppStrings.t('viewOncePhotoHint'),
                style: const TextStyle(color: HamsiqTheme.muted, fontSize: 12),
              ),
              onTap: () {
                Navigator.of(ctx).pop();
                _pickAndSend(video: false, camera: false, viewOnce: true);
              },
            ),
          ],
        ),
      ),
    );
  }

  // ---------------- voice recording (tap to toggle, or hold) ----------------
  // Two ways to record, both driving the same _startRecording /
  // _stopRecording pair (H-07c fix 2026-11-16: the mic button used to
  // have onPressed: null — a dead control — while recording only worked
  // via the long-press gesture around it):
  //   1. TAP the mic button: starts recording; tap again to stop + send.
  //   2. HOLD the mic button: records while held; release sends.
  // While recording the button turns into a red stop icon and the text
  // field is replaced by the recording indicator + cancel.

  /// Tap path: start recording, or stop + send if already recording.
  Future<void> _toggleRecording() async {
    if (_recording) {
      await _stopRecording(send: true);
    } else {
      await _startRecording();
    }
  }

  Future<void> _startRecording() async {
    if (_recording || _recStarting) return;
    _recStarting = true;
    try {
      final ok = await _recorder.hasPermission();
      if (!ok) {
        if (mounted) showError(context, AppStrings.t('micPermission'));
        return;
      }
      final path = voiceTempPath(
        'hamsiq-voice-${DateTime.now().millisecondsSinceEpoch}.m4a',
      );
      await _recorder.start(
        const RecordConfig(encoder: AudioEncoder.aacLc),
        path: path,
      );
      if (!mounted) return;
      setState(() {
        _recording = true;
        _recSeconds = 0;
        _recCancel = false;
      });
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => _recSeconds++);
        if (_recSeconds >= 300) _stopRecording(send: true);
      });
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      _recStarting = false;
    }
  }

  Future<void> _stopRecording({required bool send}) async {
    if (!_recording) return;
    _recTimer?.cancel();
    _recTimer = null;
    final seconds = _recSeconds;
    final cancelled = _recCancel;
    setState(() => _recording = false);
    String? path;
    try {
      path = await _recorder.stop();
    } catch (_) {
      path = null;
    }
    if (!send || cancelled || path == null || seconds < 1) {
      if (path != null) {
        await deleteFileQuietly(path);
      }
      return;
    }
    setState(() => _sending = true);
    try {
      await MessagesApi.sendVoiceMessage(
        widget.peer.id,
        await readPathBytes(path),
        seconds,
      );
      if (!mounted) return;
      await _load(jumpToBottom: true);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _sending = false);
      await deleteFileQuietly(path);
    }
  }

  // ---------------- message actions / menu ----------------

  void _showMessageActions(DmMessage m) {
    final isText = m.messageType == 'text' && (m.body ?? '').isNotEmpty;
    final mine = m.senderId == Api.myId;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: HamsiqTheme.panel,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading:
                  const Icon(Icons.reply, color: HamsiqTheme.accent),
              title: Text(AppStrings.t('replyToMessage')),
              onTap: () {
                Navigator.of(ctx).pop();
                setState(() => _replyTo = m);
              },
            ),
            if (isText)
              ListTile(
                leading: const Icon(Icons.copy, color: HamsiqTheme.accent),
                title: Text(AppStrings.t('copyText')),
                onTap: () {
                  Navigator.of(ctx).pop();
                  Clipboard.setData(ClipboardData(text: m.body!));
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(AppStrings.t('textCopied'))),
                  );
                },
              ),
            // Wave 2: translate in-thread (MyMemory, free keyless —
            // the text is sent to an external service; the sheet says so).
            if (isText)
              ListTile(
                leading:
                    const Icon(Icons.translate, color: HamsiqTheme.accent),
                title: Text(AppStrings.t('translate')),
                subtitle: Text(
                  AppStrings.t('translateViaMyMemory'),
                  style: const TextStyle(color: HamsiqTheme.muted, fontSize: 12),
                ),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _translateMessage(m);
                },
              ),
            // Wave 2: unsend — delete my own message for everyone.
            if (mine)
              ListTile(
                leading: const Icon(
                  Icons.delete_outline,
                  color: Colors.redAccent,
                ),
                title: Text(
                  AppStrings.t('unsendForAll'),
                  style: const TextStyle(color: Colors.redAccent),
                ),
                onTap: () {
                  Navigator.of(ctx).pop();
                  _confirmUnsend(m);
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _translateMessage(DmMessage m) async {
    final body = (m.body ?? '').trim();
    if (body.isEmpty || _translating.contains(m.id)) return;
    setState(() => _translating.add(m.id));
    try {
      final translated = await Wave2Api.translateText(body);
      if (!mounted) return;
      setState(() => _translations[m.id] = translated);
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => _translating.remove(m.id));
    }
  }

  Future<void> _confirmUnsend(DmMessage m) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('unsendTitle')),
        content: Text(AppStrings.t('unsendBody')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(AppStrings.t('cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(
              AppStrings.t('deleteForEveryone'),
              style: const TextStyle(color: Colors.redAccent),
            ),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await MessagesApi.unsendMessage(m.id);
      if (!mounted) return;
      setState(() => _messages.removeWhere((x) => x.id == m.id));
      showOk(context, AppStrings.t('unsentDone'));
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  // ---------------- Wave 2: vanish mode + chat theme ----------------

  Future<void> _toggleVanish() async {
    final next = !_vanishOn;
    if (next) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: HamsiqTheme.panel,
          title: Text(AppStrings.t('vanishMode')),
          content: Text(
            AppStrings.t('vanishDialogBody'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: Text(AppStrings.t('cancel')),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(ctx).pop(true),
              child: Text(AppStrings.t('enableAction')),
            ),
          ],
        ),
      );
      if (ok != true) return;
    }
    try {
      await MessagesApi.setVanish(widget.peer.id, next);
      if (!mounted) return;
      setState(() => _vanishOn = next);
      if (!next) {
        // Turning vanish off purges any read vanish messages now.
        try {
          await MessagesApi.purgeVanishMessages(widget.peer.id);
        } catch (_) {}
        if (mounted) _load();
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _showThemePicker() async {
    final picked = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: HamsiqTheme.panel,
        title: Text(AppStrings.t('chatTheme')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (var i = 0; i < Wave2Api.themeColors.length; i++)
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: Color(Wave2Api.themeColors[i]),
                  radius: 14,
                ),
                title: Text(Wave2Api.themeColorNames[i]),
                trailing: _chatColor == Wave2Api.themeColors[i] ||
                        (_chatColor == null && i == 0)
                    ? const Icon(Icons.check, color: HamsiqTheme.accent)
                    : null,
                onTap: () => Navigator.of(ctx).pop(Wave2Api.themeColors[i]),
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(AppStrings.t('cancel')),
          ),
        ],
      ),
    );
    if (picked == null || !mounted) return;
    try {
      await Wave2Api.setChatTheme(widget.peer.id, picked);
      if (mounted) setState(() => _chatColor = picked);
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _toggleMute() async {
    final next = !_muted;
    try {
      await MessagesApi.setMuted(widget.peer.id, next);
      if (mounted) setState(() => _muted = next);
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> _toggleArchive() async {
    final next = !_archived;
    try {
      await MessagesApi.setArchived(widget.peer.id, next);
      if (!mounted) return;
      setState(() => _archived = next);
      if (next) {
        // Archived chats are hidden from the main list.
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  void _openProfile() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ProfileScreen(userId: widget.peer.id),
      ),
    );
  }

  @override
  void dispose() {
    _poll?.cancel();
    _recTimer?.cancel();
    _recorder.dispose();
    _scroll.dispose();
    _input.dispose();
    PushService.instance.clearActiveThread(PushRoute.dm(widget.peer.id));
    // Wave 2: leaving a vanish thread purges the read vanish
    // messages (fire-and-forget; leaving must never be blocked).
    if (_vanishOn) {
      MessagesApi.purgeVanishMessages(widget.peer.id).catchError((_) {});
    }
    super.dispose();
  }

  // ---------------- message rendering ----------------

  Widget _quoteBlock(DmMessage m) {
    final orig = m.replyTo == null ? null : _byId[m.replyTo];
    final senderName = orig == null
        ? ''
        : orig.senderId == Api.myId
            ? AppStrings.t('youLabel')
            : widget.peer.displayName;
    final preview =
        orig == null ? AppStrings.t('messageLabel') : MessagesApi.labelFor(orig);
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.12),
        borderRadius: BorderRadius.circular(8),
        border: const BorderDirectional(
          start: BorderSide(color: HamsiqTheme.accent, width: 3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (senderName.isNotEmpty)
            Text(
              senderName,
              style: const TextStyle(
                color: HamsiqTheme.accent,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          Text(
            preview,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget _messageBody(DmMessage m, bool mine) {
    switch (m.messageType) {
      case 'image':
        // Wave 2: view-once — expired, or tap-to-open once (receiver).
        if (m.viewOnce) return _viewOnceTile(m, mine, isVideo: false);
        final url = m.mediaUrl;
        if (url == null || url.isEmpty) {
          return Text(AppStrings.t('imagePlaceholder'));
        }
        return GestureDetector(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => FullImageScreen(url: url)),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            // H-04 re-sign-on-render: a stale signed URL is refreshed
            // before loading, so old images keep showing past 1h.
            child: SignedMediaImage(
              url: url,
              width: 220,
              fit: BoxFit.cover,
              loadingBuilder: (ctx, child, progress) => progress == null
                  ? child
                  : const SizedBox(
                      width: 220,
                      height: 160,
                      child: Center(child: CircularProgressIndicator()),
                    ),
              errorBuilder: (_, __, ___) => SizedBox(
                width: 220,
                height: 120,
                child: Center(child: Text(AppStrings.t('imageLoadFailed'))),
              ),
            ),
          ),
        );
      case 'video':
        // Wave 2: view-once video — same once-only behaviour.
        if (m.viewOnce) return _viewOnceTile(m, mine, isVideo: true);
        final url = m.mediaUrl;
        if (url == null || url.isEmpty) {
          return Text(AppStrings.t('videoPlaceholder'));
        }
        return GestureDetector(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => VideoScreen(url: url)),
          ),
          child: Container(
            width: 220,
            height: 140,
            decoration: BoxDecoration(
              color: Colors.black54,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.play_circle_fill,
                    size: 52, color: HamsiqTheme.accent),
                const SizedBox(height: 4),
                Text(AppStrings.t('videoLabel'), style: const TextStyle(fontSize: 13)),
              ],
            ),
          ),
        );
      case 'voice':
        final url = m.mediaUrl;
        if (url == null || url.isEmpty) {
          return Text(AppStrings.t('voiceMessagePlaceholder'));
        }
        return _VoiceBubble(url: url, seconds: m.voiceSeconds, mine: mine);
      case 'file':
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.insert_drive_file,
                color: HamsiqTheme.accent),
            const SizedBox(width: 8),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    (m.fileName ?? AppStrings.t('fileLabel')).trim().isEmpty
                        ? AppStrings.t('fileLabel')
                        : m.fileName!,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (m.fileSize != null)
                    Text(
                      _fmtFileSize(m.fileSize!),
                      style: const TextStyle(
                        fontSize: 12,
                        color: HamsiqTheme.muted,
                      ),
                    ),
                ],
              ),
            ),
          ],
        );
      case 'location':
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.location_on, color: HamsiqTheme.accent),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                m.lat != null && m.lng != null
                    ? AppStrings.t('locationWithCoords')
                        .replaceAll('{lat}', m.lat!.toStringAsFixed(5))
                        .replaceAll('{lng}', m.lng!.toStringAsFixed(5))
                    : AppStrings.t('locationLabel'),
              ),
            ),
          ],
        );
      case 'contact':
        String name = AppStrings.t('contactLabel');
        String sub = '';
        try {
          final c = jsonDecode(m.body ?? '') as Map<String, dynamic>;
          name = (c['name'] as String?)?.trim() ?? name;
          final uname = (c['username'] as String?)?.trim() ?? '';
          if (uname.isNotEmpty) sub = '@$uname';
        } catch (_) {}
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircleAvatar(
              radius: 20,
              backgroundColor: HamsiqTheme.panel2,
              child: Icon(Icons.person, color: HamsiqTheme.accent),
            ),
            const SizedBox(width: 10),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('👤 $name',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  if (sub.isNotEmpty)
                    Text(sub,
                        style: const TextStyle(
                          fontSize: 12,
                          color: HamsiqTheme.muted,
                        )),
                ],
              ),
            ),
          ],
        );
      case 'poll':
        // Polls (sql-v28): body is the poll id; voting UI is PollCard.
        final pollId = (m.body ?? '').trim();
        if (pollId.isEmpty) {
          return Text(AppStrings.t('pollLabel'));
        }
        return PollCard(pollId: pollId);
      case 'shared_post':
        return SharedPostCard(message: m);
      case 'story_reply':
        return StoryReplyCard(message: m);
      default:
        return Text(
          (m.body ?? '').isEmpty ? MessagesApi.labelFor(m) : m.body!,
          style: const TextStyle(
            color: HamsiqTheme.text,
            fontSize: 15,
          ),
        );
    }
  }

  /// Wave 2: view-once tile. Expired -> greyed-out note. My own ->
  /// thumbnail + "once" badge (opening it does not consume it). A
  /// peer's unviewed message -> tap to open once; the tap marks it
  /// seen server-side (media URL wiped) and then shows it.
  Widget _viewOnceTile(DmMessage m, bool mine, {required bool isVideo}) {
    if (m.viewedOnce || m.mediaUrl == null || m.mediaUrl!.isEmpty) {
      return Container(
        width: 220,
        height: 90,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Colors.black38,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: HamsiqTheme.line),
        ),
        child: Text(
          AppStrings.t('viewOnceExpired'),
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 13, color: HamsiqTheme.muted),
        ),
      );
    }
    final url = m.mediaUrl!;
    if (mine) {
      return GestureDetector(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) =>
                isVideo ? VideoScreen(url: url) : FullImageScreen(url: url),
          ),
        ),
        child: Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: isVideo
                  ? Container(
                      width: 220,
                      height: 140,
                      color: Colors.black54,
                      alignment: Alignment.center,
                      child: const Icon(
                        Icons.play_circle_fill,
                        size: 52,
                        color: HamsiqTheme.accent,
                      ),
                    )
                  // H-04 re-sign-on-render: stale signed URL refreshed
                  // before loading (same as the image thumbnail).
                  : SignedMediaImage(
                      url: url,
                      width: 220,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => SizedBox(
                        width: 220,
                        height: 120,
                        child: Center(child: Text(AppStrings.t('imageLoadFailed'))),
                      ),
                    ),
            ),
            const Positioned(
              top: 6,
              left: 6,
              child: _ViewOnceBadge(),
            ),
          ],
        ),
      );
    }
    return GestureDetector(
      onTap: () async {
        try {
          await MessagesApi.markViewOnceSeen(m.id);
        } catch (e) {
          if (mounted) showError(context, e);
          return;
        }
        if (!mounted) return;
        await Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) =>
                isVideo ? VideoScreen(url: url) : FullImageScreen(url: url),
          ),
        );
        if (mounted) _load();
      },
      child: Container(
        width: 220,
        height: 120,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Colors.black38,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: HamsiqTheme.line),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              isVideo ? Icons.play_circle_fill : Icons.visibility,
              size: 40,
              color: HamsiqTheme.accent,
            ),
            const SizedBox(height: 6),
            Text(
              isVideo ? AppStrings.t('viewOnceVideo') : AppStrings.t('viewOncePhoto'),
              style: const TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 2),
            Text(
              AppStrings.t('tapToViewOnce'),
              style: const TextStyle(fontSize: 12, color: HamsiqTheme.muted),
            ),
          ],
        ),
      ),
    );
  }

  Widget _messageItem(DmMessage m) {
    final mine = m.senderId == Api.myId;
    // Wave 2: per-chat theme colour for my bubbles (default blue).
    final myBubble = _chatColor != null
        ? Color(_chatColor!)
        : HamsiqTheme.accent;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () => _showMessageActions(m),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.78,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: mine
                ? LinearGradient(
                    colors: [
                      myBubble,
                      myBubble.withValues(alpha: 0.75),
                    ],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  )
                : null,
            color: mine ? null : HamsiqTheme.panel2,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (m.replyTo != null) _quoteBlock(m),
              _messageBody(m, mine),
              // Wave 2: in-thread translation, shown under the original
              // with the external-service note.
              if (_translations.containsKey(m.id)) ...[
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _translations[m.id]!,
                        style: const TextStyle(fontSize: 14),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        AppStrings.t('autoTranslateMyMemory'),
                        style: const TextStyle(
                          fontSize: 11,
                          color: HamsiqTheme.muted,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              if (_translating.contains(m.id)) ...[
                const SizedBox(height: 6),
                const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: HamsiqTheme.accent,
                  ),
                ),
              ],
              const SizedBox(height: 4),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    timeAgo(m.createdAt),
                    style: TextStyle(
                      fontSize: 11,
                      color: mine
                          ? Colors.white.withOpacity(0.75)
                          : HamsiqTheme.muted,
                    ),
                  ),
                  if (mine) ...[
                    const SizedBox(width: 5),
                    Icon(
                      m.read ? Icons.done_all : Icons.done,
                      size: 16,
                      color: m.read
                          ? const Color(0xFF53BDEB)
                          : Colors.white.withOpacity(0.75),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // H-06 Part 2: live language rebuild on language change.
    return ValueListenableBuilder<String>(
      valueListenable: AppStrings.lang,
      builder: (context, _, __) => _build(context),
    );
  }

  Widget _build(BuildContext context) {
    final peer = widget.peer;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            AvatarWidget(profile: peer, size: 36),
            const SizedBox(width: 10),
            Flexible(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Flexible(
                    child: Text(
                      peer.displayName,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (peer.verified) ...[
                    const SizedBox(width: 4),
                    const VerifiedTick(),
                  ],
                ],
              ),
            ),
          ],
        ),
        actions: [
          // Wave 3: Blend — shared Reels feed with this friend (both
          // must opt in; the Blend screen handles the invite flow).
          IconButton(
            icon: const Icon(Icons.people_alt_outlined),
            tooltip: 'Blend',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => BlendScreen(peer: peer),
                ),
              );
            },
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert),
            onSelected: (v) {
              if (v == 'mute') _toggleMute();
              if (v == 'archive') _toggleArchive();
              if (v == 'profile') _openProfile();
              if (v == 'vanish') _toggleVanish();
              if (v == 'theme') _showThemePicker();
            },
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'mute',
                child: Text(_muted ? AppStrings.t('unmuteChat') : AppStrings.t('muteChat')),
              ),
              PopupMenuItem(
                value: 'archive',
                child: Text(_archived ? AppStrings.t('unarchiveChat') : AppStrings.t('archiveChat')),
              ),
              PopupMenuItem(
                value: 'profile',
                child: Text(AppStrings.t('viewProfile')),
              ),
              // Wave 2: vanish mode + chat theme.
              PopupMenuItem(
                value: 'vanish',
                child: Row(
                  children: [
                    Text(
                      _vanishOn
                          ? AppStrings.t('vanishOff')
                          : AppStrings.t('vanishMode'),
                    ),
                    if (_vanishOn) ...[
                      const SizedBox(width: 8),
                      const Icon(
                        Icons.visibility_off,
                        size: 16,
                        color: HamsiqTheme.accent,
                      ),
                    ],
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'theme',
                child: Text(AppStrings.t('chatTheme')),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Wave 2: vanish-mode banner — honest note included.
          if (_vanishOn)
            Container(
              width: double.infinity,
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              color: HamsiqTheme.panel,
              child: Row(
                children: [
                  const Icon(
                    Icons.visibility_off,
                    size: 16,
                    color: HamsiqTheme.accent,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      AppStrings.t('vanishBanner'),
                      style: const TextStyle(fontSize: 12, color: HamsiqTheme.muted),
                    ),
                  ),
                ],
              ),
            ),
          Expanded(
            child: _loading
                ? const LoadingCenter()
                : _messages.isEmpty
                    ? EmptyCenter(AppStrings.t('noMessagesYet'))
                    : ListView.builder(
                        controller: _scroll,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 10,
                        ),
                        itemCount: _messages.length,
                        itemBuilder: (_, i) => _messageItem(_messages[i]),
                      ),
          ),
          if (_replyTo != null)
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: const BoxDecoration(
                color: HamsiqTheme.panel,
                border: Border(
                  top: BorderSide(color: HamsiqTheme.line),
                ),
              ),
              child: Row(
                children: [
                  const Icon(Icons.reply,
                      size: 18, color: HamsiqTheme.accent),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _replyTo!.senderId == Api.myId
                              ? AppStrings.t('replyToSelf')
                              : '${AppStrings.t('replyTo')} ${peer.displayName}',
                          style: const TextStyle(
                            color: HamsiqTheme.accent,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          MessagesApi.labelFor(_replyTo!),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, size: 20),
                    onPressed: () => setState(() => _replyTo = null),
                  ),
                ],
              ),
            ),
          Container(
            padding: EdgeInsets.only(
              left: 10,
              right: 10,
              top: 8,
              bottom: MediaQuery.of(context).viewInsets.bottom + 10,
            ),
            decoration: const BoxDecoration(
              color: HamsiqTheme.panel,
              border: Border(
                top: BorderSide(color: HamsiqTheme.line),
              ),
            ),
            child: Row(
              children: [
                IconButton(
                  onPressed: _sending ? null : _showAttachSheet,
                  icon: const Icon(
                    Icons.attach_file,
                    color: HamsiqTheme.accent,
                  ),
                ),
                IconButton(
                  onPressed: _sending ? null : _createPoll,
                  icon: const Icon(
                    Icons.poll_outlined,
                    color: HamsiqTheme.accent,
                  ),
                ),
                Expanded(
                  child: _recording
                      ? Row(
                          children: [
                            Container(
                              width: 12,
                              height: 12,
                              decoration: const BoxDecoration(
                                color: Colors.red,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              '${AppStrings.t('recordingNow')} ${_fmtDuration(_recSeconds)} — ${AppStrings.t('recordingReleaseHint')}',
                              style: const TextStyle(color: Colors.red),
                            ),
                            const Spacer(),
                            TextButton(
                              onPressed: () {
                                _recCancel = true;
                                _stopRecording(send: false);
                              },
                              child: Text(
                                AppStrings.t('cancel'),
                                style: const TextStyle(color: Colors.red),
                              ),
                            ),
                          ],
                        )
                      : TextField(
                          controller: _input,
                          decoration: InputDecoration(
                            hintText: AppStrings.t('writeMessageHint'),
                          ),
                          textInputAction: TextInputAction.send,
                          onSubmitted: (_) => _send(),
                        ),
                ),
                const SizedBox(width: 4),
                GestureDetector(
                  onLongPressStart: (_) => _startRecording(),
                  onLongPressEnd: (_) => _stopRecording(send: true),
                  child: IconButton(
                    // H-07c: tap toggles recording (same recording as
                    // the long-press gesture). Never onPressed: null —
                    // a visible button must always do something. While
                    // recording it is a red stop icon; otherwise a mic.
                    // Disabled only while a message is sending, like
                    // the attach / poll / send buttons beside it.
                    onPressed: _sending ? null : _toggleRecording,
                    tooltip: _recording
                        ? AppStrings.t('stopRecordingAndSend')
                        : AppStrings.t('recordVoiceMessage'),
                    icon: Icon(
                      _recording ? Icons.stop : Icons.mic,
                      color: _recording ? Colors.red : HamsiqTheme.accent,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: _sending ? null : _send,
                  icon: _sending
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: HamsiqTheme.accent,
                          ),
                        )
                      : const Icon(
                          Icons.send,
                          color: HamsiqTheme.accent,
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Wave 2: small "once" badge on my own view-once media.
class _ViewOnceBadge extends StatelessWidget {
  const _ViewOnceBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.black54,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.visibility_off, size: 12, color: Colors.white),
          const SizedBox(width: 3),
          Text(
            AppStrings.t('onceBadge'),
            style: const TextStyle(fontSize: 11, color: Colors.white),
          ),
        ],
      ),
    );
  }
}

/// Voice message bubble: play/pause + progress + duration.
/// URL comes from messages.media_url; duration (seconds) from body.
class _VoiceBubble extends StatefulWidget {
  final String url;
  final int seconds;
  final bool mine;
  const _VoiceBubble({
    required this.url,
    required this.seconds,
    required this.mine,
  });

  @override
  State<_VoiceBubble> createState() => _VoiceBubbleState();
}

class _VoiceBubbleState extends State<_VoiceBubble> {
  final _player = AudioPlayer();
  bool _playing = false;
  Duration _pos = Duration.zero;
  Duration _dur = Duration.zero;
  StreamSubscription<void>? _completeSub;
  StreamSubscription<Duration>? _posSub;
  StreamSubscription<Duration>? _durSub;

  @override
  void initState() {
    super.initState();
    _dur = Duration(seconds: widget.seconds);
    _completeSub = _player.onPlayerComplete.listen((_) {
      if (!mounted) return;
      setState(() {
        _playing = false;
        _pos = Duration.zero;
      });
    });
    _posSub = _player.onPositionChanged.listen((p) {
      if (mounted) setState(() => _pos = p);
    });
    _durSub = _player.onDurationChanged.listen((d) {
      if (mounted && d > Duration.zero) setState(() => _dur = d);
    });
  }

  Future<void> _toggle() async {
    try {
      if (_playing) {
        await _player.pause();
        if (mounted) setState(() => _playing = false);
      } else if (_pos > Duration.zero && _pos < _dur) {
        await _player.resume();
        if (mounted) setState(() => _playing = true);
      } else {
        // H-04 re-sign-on-render: a voice URL older than ~1h is
        // expired — refresh it before playing, else playback 403s.
        final fresh = await MediaApi.ensureFreshUrl(widget.url);
        await _player.play(UrlSource(fresh));
        if (mounted) setState(() => _playing = true);
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(AppStrings.t('voicePlayFailed'))),
        );
      }
    }
  }

  @override
  void dispose() {
    _completeSub?.cancel();
    _posSub?.cancel();
    _durSub?.cancel();
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final totalMs = _dur.inMilliseconds > 0
        ? _dur.inMilliseconds.toDouble()
        : (widget.seconds * 1000).toDouble();
    final posMs =
        _pos.inMilliseconds.toDouble().clamp(0.0, totalMs > 0 ? totalMs : 1.0);
    return SizedBox(
      width: 220,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            onPressed: _toggle,
            icon: Icon(
              _playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
              size: 38,
              color: widget.mine ? Colors.white : HamsiqTheme.accent,
            ),
          ),
          Expanded(
            child: Slider(
              value: totalMs > 0 ? posMs : 0,
              min: 0,
              max: totalMs > 0 ? totalMs : 1,
              activeColor:
                  widget.mine ? Colors.white : HamsiqTheme.accent,
              inactiveColor: Colors.white.withOpacity(0.3),
              onChanged: (v) async {
                await _player.seek(Duration(milliseconds: v.round()));
                if (mounted) {
                  setState(() => _pos = Duration(milliseconds: v.round()));
                }
              },
            ),
          ),
          Text(
            _fmtDuration(_dur.inSeconds > 0 ? _dur.inSeconds : widget.seconds),
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }
}

/// Full-screen image viewer for image messages.
class FullImageScreen extends StatefulWidget {
  final String url;
  const FullImageScreen({super.key, required this.url});

  @override
  State<FullImageScreen> createState() => _FullImageScreenState();
}

class _FullImageScreenState extends State<FullImageScreen> {
  String? _fresh;

  @override
  void initState() {
    super.initState();
    // H-04 re-sign-on-render: refresh a stale signed URL before
    // loading, so an old image opens instead of 403ing.
    if (!MediaApi.needsResign(widget.url)) {
      _fresh = widget.url;
      return;
    }
    MediaApi.ensureFreshUrl(widget.url).then((u) {
      if (mounted) setState(() => _fresh = u);
    });
  }

  @override
  Widget build(BuildContext context) {
    // H-06 Part 2: live language rebuild on language change.
    return ValueListenableBuilder<String>(
      valueListenable: AppStrings.lang,
      builder: (context, _, __) => _build(context),
    );
  }

  Widget _build(BuildContext context) {
    final fresh = _fresh;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black),
      body: Center(
        child: fresh == null
            ? const CircularProgressIndicator()
            : InteractiveViewer(
                child: Image.network(
                  fresh,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) =>
                      Text(AppStrings.t('imageLoadFailedPlain')),
                ),
              ),
      ),
    );
  }
}

/// Full-screen video player for video messages.
class VideoScreen extends StatefulWidget {
  final String url;
  const VideoScreen({super.key, required this.url});

  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  VideoPlayerController? _controller;
  bool _ready = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  /// H-04 re-sign-on-render: refresh a stale signed URL BEFORE
  /// creating the controller, so an old video plays instead of
  /// failing initialisation with a 403.
  Future<void> _init() async {
    final fresh = await MediaApi.ensureFreshUrl(widget.url);
    if (!mounted) return;
    final controller =
        VideoPlayerController.networkUrl(Uri.parse(fresh));
    _controller = controller;
    try {
      await controller.initialize();
    } catch (_) {
      if (mounted) setState(() => _failed = true);
      return;
    }
    if (!mounted) return;
    setState(() => _ready = true);
    controller.play();
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // H-06 Part 2: live language rebuild on language change.
    return ValueListenableBuilder<String>(
      valueListenable: AppStrings.lang,
      builder: (context, _, __) => _build(context),
    );
  }

  Widget _build(BuildContext context) {
    final controller = _controller;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black),
      body: Center(
        child: _failed
            ? Text(AppStrings.t('videoPlayFailed'))
            : !_ready || controller == null
                ? const CircularProgressIndicator()
                : GestureDetector(
                    onTap: () {
                      setState(() {
                        controller.value.isPlaying
                            ? controller.pause()
                            : controller.play();
                      });
                    },
                    child: AspectRatio(
                      aspectRatio: controller.value.aspectRatio,
                      child: VideoPlayer(controller),
                    ),
                  ),
      ),
    );
  }
}
