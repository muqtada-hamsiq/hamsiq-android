// Hamsiq native — Close Friends list (Wave 2).
// Manage the people I follow who may see my Close Friends stories.
// The list lives in public.close_friends (sql-v30); stories marked
// is_close_friends show only to this list + me, with the green ring
// in the story bar.

import 'package:flutter/material.dart';

import '../models.dart';
import '../services/app_strings.dart';
import '../services/share_api.dart';
import '../services/wave2_api.dart';
import '../theme.dart';
import '../widgets/common.dart';

class CloseFriendsScreen extends StatefulWidget {
  const CloseFriendsScreen({super.key});

  @override
  State<CloseFriendsScreen> createState() => _CloseFriendsScreenState();
}

class _CloseFriendsScreenState extends State<CloseFriendsScreen> {
  List<HamsiqProfile> _following = [];
  Set<String> _closeFriends = {};
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait([
        ShareApi.fetchFollowing(),
        Wave2Api.fetchMyCloseFriendIds(),
      ]);
      if (!mounted) return;
      setState(() {
        _following = results[0] as List<HamsiqProfile>;
        _closeFriends = results[1] as Set<String>;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  Future<void> _toggle(HamsiqProfile person, bool on) async {
    setState(() {
      if (on) {
        _closeFriends.add(person.id);
      } else {
        _closeFriends.remove(person.id);
      }
    });
    try {
      await Wave2Api.setCloseFriend(person.id, on);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        if (on) {
          _closeFriends.remove(person.id);
        } else {
          _closeFriends.add(person.id);
        }
      });
      showError(context, e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppStrings.t('titleCloseFriends'))),
      body: _loading
          ? const LoadingCenter()
          : _error != null
              ? EmptyCenter(_error!)
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                      child: Text(
                        AppStrings.t('closeFriendsInfo'),
                        style: TextStyle(
                          color: HamsiqTheme.muted,
                          fontSize: 13,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(
                        '${_closeFriends.length} ${AppStrings.t('inTheList')}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Expanded(
                      child: _following.isEmpty
                          ? EmptyCenter(
                              AppStrings.t('followSomeoneFirst'),
                            )
                          : ListView.builder(
                              itemCount: _following.length,
                              itemBuilder: (_, i) {
                                final person = _following[i];
                                final onList =
                                    _closeFriends.contains(person.id);
                                return ListTile(
                                  leading: AvatarWidget(
                                    profile: person,
                                    size: 44,
                                  ),
                                  title: Text(person.displayName),
                                  subtitle: Text(
                                    '@${person.username}',
                                    style: const TextStyle(
                                      color: HamsiqTheme.muted,
                                    ),
                                  ),
                                  trailing: Switch(
                                    value: onList,
                                    activeThumbColor: HamsiqTheme.accent,
                                    onChanged: (v) => _toggle(person, v),
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ),
    );
  }
}
