// Hamsiq native — data models mirroring the Supabase tables used by the
// web app (~/workspace/chat-app/supabase-schema.sql + sql-v4..v28).
// Do not invent columns: every field here exists in the DB.

class HamsiqProfile {
  final String id;
  final String username;
  final String displayName;
  final String avatar; // emoji or text fallback
  final String? avatarUrl; // uploaded photo URL (profiles.avatar_url)
  final String bio;
  final bool verified;
  final bool isAdmin;
  final bool approved;
  final bool isPrivate;

  HamsiqProfile({
    required this.id,
    required this.username,
    required this.displayName,
    required this.avatar,
    this.avatarUrl,
    required this.bio,
    required this.verified,
    required this.isAdmin,
    required this.approved,
    required this.isPrivate,
  });

  factory HamsiqProfile.fromMap(Map<String, dynamic> m) => HamsiqProfile(
        id: m['id'] as String,
        username: (m['username'] ?? '') as String,
        displayName: (m['display_name'] ?? m['username'] ?? '') as String,
        avatar: (m['avatar'] ?? '😀') as String,
        avatarUrl: m['avatar_url'] as String?,
        bio: (m['bio'] ?? '') as String,
        verified: (m['verified'] ?? false) as bool,
        isAdmin: (m['is_admin'] ?? false) as bool,
        approved: (m['approved'] ?? false) as bool,
        isPrivate: (m['is_private'] ?? false) as bool,
      );

  /// The image to show for this user: uploaded photo first, then an
  /// avatar field that is itself a URL, otherwise null (caller shows emoji).
  String? get photoUrl {
    if (avatarUrl != null && avatarUrl!.isNotEmpty) return avatarUrl;
    if (avatar.startsWith('http')) return avatar;
    return null;
  }

  String get displayAvatar => avatar.isEmpty ? '😀' : avatar;
}

class PostItem {
  final int id;
  final String userId;
  final String caption;
  final String? mediaUrl;
  final String mediaType; // 'image' | 'video'
  final bool isReel;
  final DateTime createdAt;
  // Wave 1 (sql-v29): pinned posts (max 3 per user) + grid order.
  final bool isPinned;
  final int gridOrder;
  // Wave 2 (sql-v30): per-post options — hide like counts, comments
  // off, alt text. Defaults keep old rows behaving as before.
  final bool hideLikeCount;
  final bool commentsDisabled;
  final String? altText;
  // Wave 3 (sql-v31): Reels editor — text overlays with timing, a
  // recorded voiceover track, and the built-in template id (null =
  // no template). Defaults keep old reels behaving as before.
  final List<ReelTextOverlay> reelTextOverlays;
  final String? reelVoiceoverUrl;
  final String? reelTemplate;
  HamsiqProfile? author;
  int likeCount;
  bool likedByMe;

  PostItem({
    required this.id,
    required this.userId,
    required this.caption,
    this.mediaUrl,
    required this.mediaType,
    required this.isReel,
    required this.createdAt,
    this.author,
    this.likeCount = 0,
    this.likedByMe = false,
    this.isPinned = false,
    this.gridOrder = 0,
    this.hideLikeCount = false,
    this.commentsDisabled = false,
    this.altText,
    this.reelTextOverlays = const [],
    this.reelVoiceoverUrl,
    this.reelTemplate,
  });

  factory PostItem.fromMap(Map<String, dynamic> m) => PostItem(
        id: (m['id'] as num).toInt(),
        userId: m['user_id'] as String,
        caption: (m['caption'] ?? '') as String,
        mediaUrl: m['media_url'] as String?,
        mediaType: (m['media_type'] ?? 'image') as String,
        isReel: (m['is_reel'] ?? false) as bool,
        createdAt: DateTime.parse(m['created_at'] as String),
        isPinned: (m['is_pinned'] ?? false) as bool,
        gridOrder: (m['grid_order'] as num?)?.toInt() ?? 0,
        hideLikeCount: (m['hide_like_count'] ?? false) as bool,
        commentsDisabled: (m['comments_disabled'] ?? false) as bool,
        altText: m['alt_text'] as String?,
        reelTextOverlays: parseReelTextOverlays(m['reel_text_overlays']),
        reelVoiceoverUrl: m['reel_voiceover_url'] as String?,
        reelTemplate: m['reel_template'] as String?,
      );
}

/// One text overlay on a Reel (Wave 3, sql-v31 posts.reel_text_overlays).
/// [x]/[y] are fractions of the video width/height (0..1); [color] is
/// the ARGB int; [startSec]/[endSec] are seconds into the video.
class ReelTextOverlay {
  final String text;
  final double x;
  final double y;
  final int color;
  final double size;
  final double startSec;
  final double endSec;

  const ReelTextOverlay({
    required this.text,
    required this.x,
    required this.y,
    required this.color,
    required this.size,
    required this.startSec,
    required this.endSec,
  });

  factory ReelTextOverlay.fromMap(Map<String, dynamic> m) =>
      ReelTextOverlay(
        text: (m['text'] ?? '') as String,
        x: ((m['x'] as num?) ?? 0.5).toDouble().clamp(0.0, 1.0),
        y: ((m['y'] as num?) ?? 0.2).toDouble().clamp(0.0, 1.0),
        color: (m['color'] as num?)?.toInt() ?? 0xFFFFFFFF,
        size: ((m['size'] as num?) ?? 22).toDouble().clamp(12.0, 64.0),
        startSec: ((m['start'] as num?) ?? 0).toDouble(),
        endSec: ((m['end'] as num?) ?? 3).toDouble(),
      );

  Map<String, dynamic> toMap() => {
        'text': text,
        'x': x,
        'y': y,
        'color': color,
        'size': size,
        'start': startSec,
        'end': endSec,
      };

  /// Is this overlay on screen at [position] seconds into the video?
  bool visibleAt(double positionSec) =>
      positionSec >= startSec && positionSec <= endSec;

  ReelTextOverlay copyWith({
    String? text,
    double? x,
    double? y,
    int? color,
    double? size,
    double? startSec,
    double? endSec,
  }) =>
      ReelTextOverlay(
        text: text ?? this.text,
        x: x ?? this.x,
        y: y ?? this.y,
        color: color ?? this.color,
        size: size ?? this.size,
        startSec: startSec ?? this.startSec,
        endSec: endSec ?? this.endSec,
      );
}

/// Parse the posts.reel_text_overlays jsonb column (a list of maps, or
/// null / anything malformed -> empty list, never a crash).
List<ReelTextOverlay> parseReelTextOverlays(dynamic raw) {
  if (raw is! List) return [];
  final out = <ReelTextOverlay>[];
  for (final item in raw) {
    if (item is Map<String, dynamic>) {
      try {
        out.add(ReelTextOverlay.fromMap(item));
      } catch (_) {
        // Skip one bad overlay rather than dropping the whole reel.
      }
    } else if (item is Map) {
      try {
        out.add(
          ReelTextOverlay.fromMap(
            item.map((k, v) => MapEntry(k.toString(), v)),
          ),
        );
      } catch (_) {}
    }
  }
  return out;
}

class ChatRow {
  final HamsiqProfile peer;
  final ChatMessage? last;
  final int unread;
  ChatRow({required this.peer, this.last, required this.unread});
}

class ChatMessage {
  final int id;
  final String senderId;
  final String? receiverId;
  final String body;
  final String messageType; // 'text' (Phase 1 only handles text)
  final DateTime createdAt;
  final bool read;

  ChatMessage({
    required this.id,
    required this.senderId,
    this.receiverId,
    required this.body,
    required this.messageType,
    required this.createdAt,
    required this.read,
  });

  factory ChatMessage.fromMap(Map<String, dynamic> m) => ChatMessage(
        id: (m['id'] as num).toInt(),
        senderId: m['sender_id'] as String,
        receiverId: m['receiver_id'] as String?,
        body: (m['body'] ?? '') as String,
        messageType: (m['message_type'] ?? 'text') as String,
        createdAt: DateTime.parse(m['created_at'] as String),
        read: (m['read'] ?? false) as bool,
      );
}
