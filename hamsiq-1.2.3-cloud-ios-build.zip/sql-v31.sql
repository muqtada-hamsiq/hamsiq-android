-- sql-v31.sql — Hamsiq native v1.2.0 Wave 3 (Instagram features)
-- Run in the Supabase SQL Editor AFTER sql-v30.sql. Idempotent: safe to
-- run twice. The native app (~/workspace/hamsiq-native) reads/writes
-- every object below; run this BEFORE building the v1.2.0 APK.
--
-- New in this file:
--   1) posts.reel_text_overlays (jsonb) / reel_voiceover_url /
--      reel_template — Reels editor: text overlays with timing,
--      recorded voiceover, built-in templates. No new posts policy:
--      the v29 owner UPDATE policy ("owners update own posts") already
--      lets the owner write these columns, and the v5/v16/v21 insert
--      policy ("approved users post") covers inserts.
--   2) post_collaborators — Collab posts (up to 5 collaborators,
--      Instagram limit). Invites go through the SECURITY DEFINER
--      function invite_collaborator(); accept/decline through
--      respond_collab_invite(); there is deliberately NO INSERT or
--      UPDATE policy on this table, so nobody can forge an invite or
--      accept someone else's. The owner or the invitee may delete a row.
--   3) channels + channel_members + channel_posts + channel_reactions
--      — Broadcast channels (Instagram: creator posts, subscribers
--      react only, no member replies). Only the channel OWNER can post
--      in this version (Instagram also lets invited collaborators post;
--      that is a later step, not faked here).
--   4) blends — Blend: a shared Reels feed between two friends inside
--      a DM. Both must opt in: the creator inserts a 'pending' row,
--      the invited friend accepts/declines through the SECURITY DEFINER
--      function respond_blend_invite(); either side can end it with
--      end_blend(). There is deliberately NO UPDATE policy on blends.
--      The feed itself needs NO new table: it is built from post_likes
--      (reels both users liked) + messages of type 'shared_post'
--      between them.
--
-- RLS HARD RULES (learned 2026-11-14, 42P17): no policy whose qual or
-- with_check queries its OWN table. Policies below use auth.uid() and
-- the SECURITY DEFINER helpers public.is_approved() / public.is_admin()
-- (they query profiles bypassing RLS), or subqueries on DIFFERENT
-- tables only. Every table a policy references is created BEFORE the
-- policy. New columns are added BEFORE any function that uses them.
--
-- Honest limits (also shown in the app UI):
--   * Broadcast channels are public/discoverable (Instagram: public
--     channels); anyone approved can READ a channel and its posts —
--     membership is only needed to react, and only the owner posts.
--     Instagram's >1,000-followers eligibility for creating a channel
--     is NOT enforced here (no follower-count gate in the DB).
--   * Collab posts show on a collaborator's profile only once the
--     profile grid reads post_collaborators (Wave 3 API provides
--     fetchCoAuthoredPosts; the profile screen wires it in a later
--     step). The post detail screen already shows the co-authors.
--   * Blend refreshes when the screen opens (no daily server refresh);
--     it mixes reels both friends liked + reels shared in their DM.

-- ============ 1) posts: Reels editor columns ============
-- reel_text_overlays: jsonb array of
--   {"text": "...", "x": 0.5, "y": 0.2, "color": 4294967295,
--    "size": 22.0, "start": 0.0, "end": 3.0}
-- x/y are fractions of the video width/height (0..1); color is the
-- ARGB int; start/end are seconds into the video.
alter table public.posts
  add column if not exists reel_text_overlays jsonb not null default '[]'::jsonb;
alter table public.posts
  add column if not exists reel_voiceover_url text;
alter table public.posts
  add column if not exists reel_template text;

-- ============ 2) post_collaborators (Collab posts) ============
create table if not exists public.post_collaborators (
  post_id bigint not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending'
    check (status in ('pending', 'accepted', 'declined')),
  invited_by uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);
create index if not exists idx_post_collaborators_user
  on public.post_collaborators(user_id, status);
create index if not exists idx_post_collaborators_post
  on public.post_collaborators(post_id, status);
alter table public.post_collaborators enable row level security;

-- Select: co-authorship is public info, like the post itself.
drop policy if exists "post_collaborators_select" on public.post_collaborators;
create policy "post_collaborators_select" on public.post_collaborators for select using (
  public.is_approved()
);
-- Delete: the post owner (subquery on posts — a DIFFERENT table) or
-- the invited user themself. No INSERT/UPDATE policy: invites and
-- responses go through the SECURITY DEFINER functions below.
drop policy if exists "post_collaborators_delete" on public.post_collaborators;
create policy "post_collaborators_delete" on public.post_collaborators for delete using (
  auth.uid() = user_id
  or auth.uid() = (select p.user_id from public.posts p where p.id = post_collaborators.post_id)
  or public.is_admin()
);

-- Invite a collaborator. Only the post owner may call it; at most 5
-- collaborators (pending + accepted) per post; the owner cannot invite
-- themself and cannot invite the same person twice.
create or replace function public.invite_collaborator(
  p_post_id bigint,
  p_user_id uuid
)
returns void language plpgsql security definer as $$
declare
  v_me uuid := auth.uid();
  v_owner uuid;
  v_count int;
begin
  if v_me is null then raise exception 'not authenticated'; end if;
  select p.user_id into v_owner from public.posts p where p.id = p_post_id;
  if v_owner is null then raise exception 'no such post'; end if;
  if v_owner <> v_me then raise exception 'only the post owner can invite collaborators'; end if;
  if p_user_id = v_me then raise exception 'you cannot invite yourself'; end if;
  if not exists (select 1 from public.profiles pr where pr.id = p_user_id) then
    raise exception 'no such user';
  end if;
  if exists (select 1 from public.post_collaborators pc
             where pc.post_id = p_post_id and pc.user_id = p_user_id) then
    raise exception 'already invited';
  end if;
  select count(*) into v_count from public.post_collaborators pc
    where pc.post_id = p_post_id and pc.status <> 'declined';
  if v_count >= 5 then raise exception 'at most 5 collaborators per post'; end if;
  insert into public.post_collaborators (post_id, user_id, status, invited_by)
    values (p_post_id, p_user_id, 'pending', v_me);
end;
$$;
grant execute on function public.invite_collaborator(bigint, uuid) to authenticated;

-- Accept / decline my own collab invite. Only the invited user may
-- call it, only while the invite is pending; accepting enforces the
-- 5-collaborator limit (accepted only) at the moment of acceptance.
create or replace function public.respond_collab_invite(
  p_post_id bigint,
  p_accept boolean
)
returns void language plpgsql security definer as $$
declare
  v_me uuid := auth.uid();
  v_status text;
  v_accepted int;
begin
  if v_me is null then raise exception 'not authenticated'; end if;
  select pc.status into v_status from public.post_collaborators pc
    where pc.post_id = p_post_id and pc.user_id = v_me;
  if v_status is null then raise exception 'no such invite'; end if;
  if v_status <> 'pending' then raise exception 'invite already answered'; end if;
  if p_accept then
    select count(*) into v_accepted from public.post_collaborators pc
      where pc.post_id = p_post_id and pc.status = 'accepted';
    if v_accepted >= 5 then raise exception 'this post already has 5 collaborators'; end if;
    update public.post_collaborators set status = 'accepted'
      where post_id = p_post_id and user_id = v_me;
  else
    update public.post_collaborators set status = 'declined'
      where post_id = p_post_id and user_id = v_me;
  end if;
end;
$$;
grant execute on function public.respond_collab_invite(bigint, boolean) to authenticated;

-- ============ 3) broadcast channels ============
create table if not exists public.channels (
  id bigint generated always as identity primary key,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  description text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists idx_channels_owner on public.channels(owner_id);
alter table public.channels enable row level security;

-- Select: public/discoverable — any approved user can see channels.
drop policy if exists "channels_select" on public.channels;
create policy "channels_select" on public.channels for select using (
  public.is_approved()
);
drop policy if exists "channels_insert" on public.channels;
create policy "channels_insert" on public.channels for insert with check (
  auth.uid() = owner_id and public.is_approved()
);
drop policy if exists "channels_update" on public.channels;
create policy "channels_update" on public.channels for update using (
  auth.uid() = owner_id
) with check (auth.uid() = owner_id);
drop policy if exists "channels_delete" on public.channels;
create policy "channels_delete" on public.channels for delete using (
  auth.uid() = owner_id or public.is_admin()
);

create table if not exists public.channel_members (
  channel_id bigint not null references public.channels(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (channel_id, user_id)
);
create index if not exists idx_channel_members_user on public.channel_members(user_id);
alter table public.channel_members enable row level security;

drop policy if exists "channel_members_select" on public.channel_members;
create policy "channel_members_select" on public.channel_members for select using (
  public.is_approved()
);
-- Join: I join only myself, to a channel that exists (subquery on
-- channels — a DIFFERENT table).
drop policy if exists "channel_members_insert" on public.channel_members;
create policy "channel_members_insert" on public.channel_members for insert with check (
  auth.uid() = user_id
  and exists (select 1 from public.channels c where c.id = channel_members.channel_id)
);
-- Leave: myself, or the channel owner removing me (subquery on
-- channels — a DIFFERENT table).
drop policy if exists "channel_members_delete" on public.channel_members;
create policy "channel_members_delete" on public.channel_members for delete using (
  auth.uid() = user_id
  or auth.uid() = (select c.owner_id from public.channels c where c.id = channel_members.channel_id)
);

create table if not exists public.channel_posts (
  id bigint generated always as identity primary key,
  channel_id bigint not null references public.channels(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null default '',
  media_url text,
  media_type text not null default 'text',
  created_at timestamptz not null default now()
);
create index if not exists idx_channel_posts_channel on public.channel_posts(channel_id, created_at desc);
alter table public.channel_posts enable row level security;

-- Select: public channel — any approved user can read its posts.
drop policy if exists "channel_posts_select" on public.channel_posts;
create policy "channel_posts_select" on public.channel_posts for select using (
  public.is_approved()
);
-- Insert: only the channel OWNER posts (subquery on channels — a
-- DIFFERENT table). Members cannot post: reactions only.
drop policy if exists "channel_posts_insert" on public.channel_posts;
create policy "channel_posts_insert" on public.channel_posts for insert with check (
  auth.uid() = author_id
  and exists (select 1 from public.channels c
              where c.id = channel_posts.channel_id and c.owner_id = auth.uid())
);
-- Delete: the author, or the channel owner (subquery on channels).
drop policy if exists "channel_posts_delete" on public.channel_posts;
create policy "channel_posts_delete" on public.channel_posts for delete using (
  auth.uid() = author_id
  or auth.uid() = (select c.owner_id from public.channels c where c.id = channel_posts.channel_id)
  or public.is_admin()
);

-- Reactions: one reaction per user per channel post (changing emoji
-- replaces it via upsert). Members react; the owner reacts too.
create table if not exists public.channel_reactions (
  channel_post_id bigint not null references public.channel_posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  emoji text not null,
  created_at timestamptz not null default now(),
  primary key (channel_post_id, user_id)
);
create index if not exists idx_channel_reactions_post on public.channel_reactions(channel_post_id);
alter table public.channel_reactions enable row level security;

drop policy if exists "channel_reactions_select" on public.channel_reactions;
create policy "channel_reactions_select" on public.channel_reactions for select using (
  public.is_approved()
);
drop policy if exists "channel_reactions_write" on public.channel_reactions;
create policy "channel_reactions_write" on public.channel_reactions for all using (
  auth.uid() = user_id
) with check (auth.uid() = user_id);

-- ============ 4) blends ============
create table if not exists public.blends (
  id bigint generated always as identity primary key,
  user_a uuid not null references public.profiles(id) on delete cascade,
  user_b uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending'
    check (status in ('pending', 'active', 'declined', 'ended')),
  created_by uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_blends_a on public.blends(user_a, status);
create index if not exists idx_blends_b on public.blends(user_b, status);
alter table public.blends enable row level security;

-- Select: only the two participants. No UPDATE policy: accept/decline
-- and ending go through the SECURITY DEFINER functions below.
drop policy if exists "blends_select" on public.blends;
create policy "blends_select" on public.blends for select using (
  auth.uid() = user_a or auth.uid() = user_b
);
-- Insert: I create the invite (user_a is me, user_b is the friend).
drop policy if exists "blends_insert" on public.blends;
create policy "blends_insert" on public.blends for insert with check (
  auth.uid() = created_by
  and auth.uid() = user_a
  and user_b <> auth.uid()
);

-- Accept / decline a Blend invite. Only the invited friend (user_b)
-- may call it, only while the invite is pending.
create or replace function public.respond_blend_invite(
  p_blend_id bigint,
  p_accept boolean
)
returns void language plpgsql security definer as $$
declare
  v_me uuid := auth.uid();
  v_b uuid;
  v_status text;
begin
  if v_me is null then raise exception 'not authenticated'; end if;
  select b.user_b, b.status into v_b, v_status
    from public.blends b where b.id = p_blend_id;
  if v_b is null then raise exception 'no such blend'; end if;
  if v_b <> v_me then raise exception 'only the invited friend can answer'; end if;
  if v_status <> 'pending' then raise exception 'invite already answered'; end if;
  update public.blends
    set status = case when p_accept then 'active' else 'declined' end,
        updated_at = now()
    where id = p_blend_id;
end;
$$;
grant execute on function public.respond_blend_invite(bigint, boolean) to authenticated;

-- End a Blend. Either participant may end it (active or pending).
create or replace function public.end_blend(p_blend_id bigint)
returns void language plpgsql security definer as $$
declare
  v_me uuid := auth.uid();
  v_a uuid;
  v_b uuid;
begin
  if v_me is null then raise exception 'not authenticated'; end if;
  select b.user_a, b.user_b into v_a, v_b
    from public.blends b where b.id = p_blend_id;
  if v_a is null then raise exception 'no such blend'; end if;
  if v_me <> v_a and v_me <> v_b then raise exception 'not a participant'; end if;
  update public.blends set status = 'ended', updated_at = now()
    where id = p_blend_id;
end;
$$;
grant execute on function public.end_blend(bigint) to authenticated;

-- ============ 5) realtime for the new tables ============
do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'post_collaborators') then
    execute 'alter publication supabase_realtime add table public.post_collaborators';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'channels') then
    execute 'alter publication supabase_realtime add table public.channels';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'channel_members') then
    execute 'alter publication supabase_realtime add table public.channel_members';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'channel_posts') then
    execute 'alter publication supabase_realtime add table public.channel_posts';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'channel_reactions') then
    execute 'alter publication supabase_realtime add table public.channel_reactions';
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'blends') then
    execute 'alter publication supabase_realtime add table public.blends';
  end if;
end $$;

-- ============ verification (run after the above) ============
-- select table_name from information_schema.tables where table_schema='public'
--   and table_name in ('post_collaborators','channels','channel_members',
--     'channel_posts','channel_reactions','blends');
-- select column_name from information_schema.columns where table_schema='public'
--   and table_name='posts'
--   and column_name in ('reel_text_overlays','reel_voiceover_url','reel_template');
-- select tablename, policyname from pg_policies where schemaname='public'
--   and tablename in ('post_collaborators','channels','channel_members',
--     'channel_posts','channel_reactions','blends')
--   order by tablename, policyname;
-- select proname from pg_proc where pronamespace='public'::regnamespace
--   and proname in ('invite_collaborator','respond_collab_invite',
--     'respond_blend_invite','end_blend');
