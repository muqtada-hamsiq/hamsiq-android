# Himsiq iOS cloud build

This ZIP includes the Flutter source and a GitHub Actions workflow that builds an **unsigned** iOS IPA on a macOS runner.

## Run the cloud build
1. Add/commit the contents of this ZIP to your GitHub repository `muqtada-hamsiq/hamsiq-android`, keeping the `.github` folder.
2. In GitHub open **Actions** → **Build Himsiq iOS (unsigned)** → **Run workflow**.
3. Download the artifact named `Himsiq-iOS-unsigned-IPA` from the completed workflow run.

## What it does
- Generates the missing iOS Xcode project from Flutter.
- Sets bundle ID `com.hamsiq.app`.
- Adds camera, microphone, photo library permission descriptions and the OAuth URL scheme.
- Builds with `flutter build ios --release --no-codesign`.
- Packages `Payload/Himsiq.app` into an unsigned IPA container.

## Limitations
- The IPA is unsigned and cannot be installed until signed with a valid Apple certificate and provisioning profile.
- This does not publish to the App Store.
- iOS Firebase push notifications still require registering the iOS app in Firebase, adding `GoogleService-Info.plist`, and configuring APNs. The current source catches Firebase initialization failures so other app functions can start without push.
- Add `com.hamsiq.app://login-callback` to Supabase Auth redirect URLs for OAuth.
- Never commit Apple certificates, private keys, provisioning profiles, or secret service credentials.
