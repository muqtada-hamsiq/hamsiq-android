package com.hamsiq.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
