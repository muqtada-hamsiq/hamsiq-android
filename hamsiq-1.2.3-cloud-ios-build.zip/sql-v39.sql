-- ============================================================
-- sql-v39.sql — Hamsiq push notifications (server-side, FCM).
-- Run in the Supabase SQL Editor AFTER sql-v38.sql. Idempotent: safe to
-- run twice. Apply to STAGING first; production only after the staging
-- proof (see the push worker's report for the prod checklist).
--
-- Design (verified from the code, not guessed):
--   * messages (supabase-schema.sql + sql-v4 + sql-v12 + sql-v30):
--       id bigint, sender_id uuid, receiver_id uuid NULL for group
--       messages, group_id bigint NULL for DMs, body text,
--       message_type text, media_url text, created_at, read,
--       reply_to, file_name, file_size, lat, lng,
--       view_once / viewed_once / vanish (sql-v30).
--   * group_members (sql-v4): (group_id bigint, user_id uuid),
--       PK (group_id, user_id), role text.
--   * profiles notif toggles: notif_messages / notif_likes /
--       notif_followers / notif_mentions (sql-v9) + notif_comments
--       (sql-v29). All boolean, default true (NULL treated as true
--       by the Edge Function).
--   * muted_chats (sql-v14): (user_id, chat_kind, chat_id); chat_kind
--       'dm' with chat_id = peer id, or 'group' with chat_id = group
--       id as text. The Edge Function skips push for muted threads.
--   * Calls: there is NO per-recipient call-invite row anywhere.
--       Live ringing is a Realtime broadcast on channel 'mq-calls',
--       event 'call' (web index.html subscribeCallChannel/callSend),
--       and public.call_invites (sql-v17) is a SHAREABLE LINK table
--       (code PK, host_id, group_id NULL for 1:1, group_call_id,
--       expires 24h) with NO recipient column — a DB trigger on it
--       cannot know whom to ring. So calls use the CALLER-INVOKED
--       path only: the caller's app POSTs {type:'call_invite', ...}
--       to the send-push Edge Function with its own JWT (best-effort;
--       a push failure must never fail the call itself). NO calls
--       table is invented here.
--
-- What this file creates:
--   1) public.device_tokens — one row per (user, FCM token).
--   2) public.push_config — server-only key/value store holding the
--      trigger secret + the send-push function URL. RLS enabled with
--      ZERO policies: only postgres / service_role can read it. The
--      secret is NEVER written in this file — it is inserted by the
--      deploy step from an env var via the Management API. The deploy
--      step also inserts two non-secret rows: send_push_url (the
--      function URL) and anon_key (the project's public anon key —
--      the Edge Function gateway rejects requests with no
--      Authorization header before they reach the function, so the
--      trigger must present the anon key; the anon key is public by
--      design and the real auth is the trigger secret header).
--      WHY a table, not a literal in the trigger body: function
--      bodies are visible in pg_proc to any authenticated user, so a
--      secret baked into the trigger function would leak to every
--      logged-in user who queries pg_get_functiondef. A no-policy
--      RLS table keeps it server-only.
--   3) public.notify_push_on_message() + trigger
--      messages_push_notify on public.messages AFTER INSERT.
--      The trigger function is SECURITY DEFINER with pinned
--      search_path (H-05 convention, sql-v34), reads the secret + URL
--      from push_config, and fires ONE async pg_net http_post per
--      insert. pg_net is fire-and-forget (no await): a pg_net failure
--      must NEVER break the message insert, so the call is wrapped
--      in an EXCEPTION block and the function returns NEW regardless.
--      The Edge Function (not the trigger) resolves recipients,
--      checks notif_messages + muted_chats, and fans out to group
--      members — the trigger stays cheap (one config lookup + one
--      HTTP call) and never queries messages/group_members itself.
--
-- pg_net: the trigger is created ONLY if the pg_net extension is
-- present. The deploy step checks pg_extension on the target first;
-- if CREATE EXTENSION pg_net is not permitted, the trigger section
-- must be applied separately once pg_net is enabled — the table +
-- RLS in this file still apply cleanly without it.
--
-- RLS HARD RULES (learned 2026-11-14, 42P17): no policy whose qual
-- or with_check queries its OWN table. device_tokens policies use
-- only auth.uid() = user_id. The trigger function queries
-- push_config (a DIFFERENT table) and never its own table.
-- ============================================================

-- ============ 1) device_tokens ============

create table if not exists public.device_tokens (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  token text not null unique,
  platform text not null default 'android',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_device_tokens_user
  on public.device_tokens (user_id);

alter table public.device_tokens enable row level security;

-- Users manage ONLY their own rows. anon has no session, so
-- auth.uid() is NULL and matches nothing — anon is denied by the
-- qual itself, and the REVOKEs below remove any direct grants.
drop policy if exists device_tokens_owner_select on public.device_tokens;
create policy device_tokens_owner_select on public.device_tokens
  for select using (auth.uid() = user_id);

drop policy if exists device_tokens_owner_insert on public.device_tokens;
create policy device_tokens_owner_insert on public.device_tokens
  for insert with check (auth.uid() = user_id);

drop policy if exists device_tokens_owner_update on public.device_tokens;
create policy device_tokens_owner_update on public.device_tokens
  for update using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists device_tokens_owner_delete on public.device_tokens;
create policy device_tokens_owner_delete on public.device_tokens
  for delete using (auth.uid() = user_id);

-- Least privilege: no grants to anon at all (service_role bypasses
-- RLS and is the only role that may clean up stale tokens).
revoke all on table public.device_tokens from anon, public;
grant select, insert, update, delete on table public.device_tokens
  to authenticated;

-- ============ 2) push_config (server-only) ============

create table if not exists public.push_config (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

alter table public.push_config enable row level security;
-- No policies by design: RLS enabled with zero policies denies
-- authenticated / anon access entirely. Only service_role (which
-- bypasses RLS) and postgres can read/write it — the deploy step
-- inserts the trigger secret + function URL as service_role, and
-- the SECURITY DEFINER trigger function reads them bypassing RLS.
revoke all on table public.push_config from anon, public;

-- ============ 3) trigger function + trigger (pg_net) ============
-- Created only when pg_net is available. If pg_net is missing this
-- block is a harmless no-op and the deploy step reports it.

do $$
declare
  v_secret text;
  v_url text;
begin
  if not exists (select 1 from pg_extension where extname = 'pg_net') then
    raise notice 'sql-v39: pg_net not enabled — skipping push trigger (table + RLS still applied)';
    return;
  end if;

  -- Trigger function: SECURITY DEFINER so it can read push_config
  -- (no-policy RLS table) and call net.http_post. Pinned search_path
  -- (H-05 convention): pg_catalog first, then public, then net so
  -- net.http_post resolves without a caller-controlled search_path.
  create or replace function public.notify_push_on_message()
  returns trigger
  language plpgsql
  security definer
  set search_path = pg_catalog, public, net
  as $fn$
  declare
    v_secret text;
    v_url text;
    v_anon text;
  begin
    -- Config lookup: missing rows mean "not configured yet" — skip
    -- silently (no push) rather than failing the message insert.
    select value into v_secret from public.push_config where key = 'trigger_secret';
    select value into v_url from public.push_config where key = 'send_push_url';
    select value into v_anon from public.push_config where key = 'anon_key';
    if v_secret is null or v_url is null or v_anon is null then
      return new;
    end if;
    -- Fire-and-forget: net.http_post queues the request and returns
    -- immediately; nothing here awaits the response. Any error
    -- (extension hiccup, bad URL, ...) is swallowed so the INSERT
    -- that fired this trigger can never fail because of push.
    -- The Authorization/apikey headers carry the project's ANON key:
    -- Edge Functions verify a JWT at the gateway, so a request with
    -- no Authorization header is rejected 401 BEFORE it reaches
    -- send-push (proven on staging). The anon key is public by
    -- design (every client embeds it); the real authentication is
    -- the x-push-trigger-secret header, checked by the function.
    begin
      perform net.http_post(
        url := v_url,
        headers := jsonb_build_object(
          'Content-Type', 'application/json',
          'apikey', v_anon,
          'Authorization', 'Bearer ' || v_anon,
          'x-push-trigger-secret', v_secret
        ),
        body := jsonb_build_object(
          'type', 'message',
          'message_id', new.id
        )
      );
    exception when others then
      -- Deliberately silent: push is best-effort, messages are not.
      null;
    end;
    return new;
  end;
  $fn$;

  -- Only postgres / service_role may execute the trigger function
  -- directly; the trigger itself runs as the table owner regardless.
  revoke execute on function public.notify_push_on_message()
    from anon, public;
  grant execute on function public.notify_push_on_message()
    to postgres, service_role;

  drop trigger if exists messages_push_notify on public.messages;
  create trigger messages_push_notify
    after insert on public.messages
    for each row execute function public.notify_push_on_message();
end;
$$;

-- ============ verification (run after the above) ============
-- -- 1) table + RLS + policies:
-- select tablename, rowsecurity from pg_tables
--  where schemaname = 'public' and tablename in ('device_tokens', 'push_config');
-- -- Expected: 2 rows, rowsecurity = true.
-- select policyname, cmd from pg_policies
--  where schemaname = 'public' and tablename = 'device_tokens'
--  order by cmd;
-- -- Expected: 4 rows (select/insert/update/delete), each qual/check
-- -- containing auth.uid() = user_id, and nothing else.
-- -- 2) trigger + pg_net state:
-- select extname from pg_extension where extname = 'pg_net';
-- -- Expected: 1 row if pg_net is enabled, else 0 (trigger skipped).
-- select tgname from pg_trigger where tgrelid = 'public.messages'::regclass
--   and tgname = 'messages_push_notify';
-- -- Expected: 1 row iff pg_net is enabled.
-- -- 3) SECURITY DEFINER function has pinned search_path:
-- select proname, prosecdef, proconfig
--   from pg_proc where pronamespace = 'public'::regnamespace
--   and proname = 'notify_push_on_message';
-- -- Expected: 1 row, prosecdef = true,
-- -- proconfig = {search_path=pg_catalog, public, net}.
-- -- NOTE: pg_get_functiondef renders the setting as
-- -- "SET search_path TO 'pg_catalog', 'public', 'net'" — check
-- -- proconfig, not the def text, for the pinned value.
-- -- 4) role behaviour (staging, two throwaway users + anon):
-- --    * user A inserts own token row -> 201; reads own rows -> row.
-- --    * user A reads/inserts/deletes user B's rows -> 0 rows / denied.
-- --    * anon select/insert on device_tokens -> 401.
-- --    * anon/authenticated select on push_config -> 0 rows (no policies).
