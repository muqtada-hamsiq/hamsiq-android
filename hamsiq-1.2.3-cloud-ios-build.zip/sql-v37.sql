-- ============================================================
-- Hamsiq native : schema v37 migration (H-05 follow-up)
-- Sets an explicit safe search_path on the two core RLS helper
-- functions is_approved() and is_admin().
--
-- Why a separate file: these two functions are defined in the lost
-- v1–v3 migrations — no definition exists anywhere in the workspace
-- (the combined schema v4–v31 does not contain them), so sql-v34.sql
-- could not cover them. Their signatures are known from 125+ call
-- sites (public.is_approved() / public.is_admin(), zero arguments),
-- and ALTER ... SET search_path needs only the signature, not the
-- body, so this is safe even without the definitions. Setting
-- search_path on an invoker function is harmless; if either function
-- turns out to be SECURITY DEFINER, this closes the same hole as v34.
-- Idempotent: ALTER ... SET can be re-run safely.
-- Apply AFTER sql-v34.sql. Verify on staging with:
--   select proname, prosecdef, proconfig from pg_proc
--   where proname in ('is_approved','is_admin');
--   -- prosecdef shows whether SECURITY DEFINER; proconfig must show
--   -- search_path=pg_catalog, public for both rows.
-- ============================================================

alter function public.is_approved() set search_path = pg_catalog, public;
alter function public.is_admin() set search_path = pg_catalog, public;

-- Staging check (run manually, do not ship as a migration step):
-- If either ALTER errors with "function does not exist", the function
-- lives under a different schema or signature in the live DB — stop
-- and locate its real definition in pg_proc before proceeding.
