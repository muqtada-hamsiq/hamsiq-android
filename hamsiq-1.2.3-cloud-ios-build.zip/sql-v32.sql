-- ============================================================
-- sql-v32.sql — Hamsiq audit fix H-02 (critical: private-account
-- posts visible to everyone)
-- Run in the Supabase SQL Editor AFTER sql-v31.sql. Idempotent: safe to
-- run twice. Run this BEFORE building the next native APK.
--
-- Problem (verified from the combined schema v4..v31, sql-v5 section,
-- lines ~2125-2128, and from the app's own promise "فقط المتابعون
-- المعتمدون يرون منشوراتك"):
--   create policy "posts visible to approved" on public.posts
--   for select using ( public.is_approved() );
-- Any approved account could read ANY post through the API, including
-- posts of a private account (profiles.is_private = true, added in
-- sql-v9) that the viewer does not follow, and posts of users who
-- blocked the viewer (or whom the viewer blocked). The web app only
-- filtered private authors client-side (index.html loadFeed:
-- "if (a && a.is_private && ... !myFollows.has(a.id) ...) return
-- false"), and the native app documented the same gap in
-- Api.fetchFeed ("private authors are kept simple in Phase 1 (their
-- posts still show...)"). Client-side filtering is not enforcement.
--
-- Fix: DROP and recreate the posts SELECT policy so a post is visible
-- only when ALL of these hold:
--   1) the caller is an approved account (public.is_approved()), AND
--   2) one of:
--        a) the caller IS the post's author (auth.uid() = user_id), or
--        b) the caller is the app admin (public.is_admin()), or
--        c) the caller is NOT blocked in either direction with the
--           author AND (the author's profile is NOT private OR the
--           caller follows the author).
-- A pending follow request is NOT a follow: the follows row is only
-- inserted when the private account approves the request
-- (approve_follow_request(), sql-v9), so a requester sees nothing
-- until approved — exactly like the web app's myFollows check.
--
-- Tables/columns used (all copied exactly from the combined schema
-- v4..v31 — nothing guessed):
--   public.profiles.is_private  (boolean, sql-v9)
--   public.follows(follower_id, following_id)  (sql-v5)
--   public.blocks(blocker_id, blocked_id)      (sql-v5)
--   public.posts.user_id        (sql-v5)
--
-- RLS HARD RULES (learned 2026-11-14, 42P17): no policy whose qual or
-- with_check queries its OWN table. This policy never queries
-- public.posts: the profile/follow/block checks live in SECURITY
-- DEFINER helper functions below (same pattern as
-- public.is_approved() / public.is_admin() — they query profiles
-- bypassing RLS), and the policy itself only references auth.uid()
-- plus those helpers. The helpers query DIFFERENT tables only
-- (profiles, follows, blocks), so there is no recursion.
--
-- The helpers pin SET search_path = pg_catalog, public (the H-05
-- convention from sql-v34.sql), so a caller-controlled search_path
-- cannot shadow names inside them.
--
-- Deliberately UNCHANGED by this migration (out of scope for H-02):
--   * posts.is_hidden stays client-side filtered (web loadFeed /
--     explore / reels check it; the admin still lists hidden posts).
--     This policy does not hide is_hidden posts server-side.
--   * The posts INSERT ("approved users post") and DELETE ("owners or
--     admin delete posts") policies are untouched.
--   * Page posts (posts.page_id): the rule is per AUTHOR, as specified
--     — a post to a page by a private author is hidden from
--     non-followers. loadFeed's client-side filter already did this for
--     feed items; the page's own post list (openPage, index.html line
--     5850) had no such filter, so that view now returns fewer rows —
--     intended enforcement, not a break.
--
-- Web-app impact (every web posts/stories query was checked line by
-- line in ~/workspace/chat-app/index.html; verdicts are listed in the
-- fix report): every query keeps working; the server now enforces
-- what the web already filtered client-side. Two intended behaviour
-- changes, both = the fix working: (1) search results (line 4716) and
-- page posts (line 5850) had NO private-author client filter, so
-- private authors' posts now disappear there for non-followers;
-- (2) saved posts (line 5564) and reposts of a private author's post
-- (loadFeed, line 8008) now return only rows the viewer may see.
-- ============================================================

-- ============ 1) SECURITY DEFINER helpers ============
-- post_author_is_private: is this user's profile private?
-- Returns false when the profile row is missing (fail-open to
-- "public" only for a row that cannot exist as a post author — every
-- post's user_id references profiles(id) — so this is just a NULL
-- guard, not a visibility decision).
create or replace function public.post_author_is_private(p_user_id uuid)
returns boolean
language sql
security definer
stable
set search_path = pg_catalog, public
as $$
  select coalesce(
    (select p.is_private from public.profiles p where p.id = p_user_id),
    false
  );
$$;

-- is_following: does p_follower_id follow p_following_id?
-- One row in public.follows (follower_id, following_id), unique pair.
create or replace function public.is_following(
  p_follower_id uuid,
  p_following_id uuid
)
returns boolean
language sql
security definer
stable
set search_path = pg_catalog, public
as $$
  select exists (
    select 1 from public.follows f
    where f.follower_id = p_follower_id
      and f.following_id = p_following_id
  );
$$;

-- is_blocked_between: has either user blocked the other?
-- public.blocks(blocker_id, blocked_id), unique pair, either direction
-- counts: a blocked viewer must not see the blocker's posts, and a
-- user who blocked someone must not see that person's posts either
-- (matches the web app, which filters both myBlocks and blockedByMe
-- in loadFeed / explore / reels).
create or replace function public.is_blocked_between(
  p_user_id uuid,
  p_other_id uuid
)
returns boolean
language sql
security definer
stable
set search_path = pg_catalog, public
as $$
  select exists (
    select 1 from public.blocks b
    where (b.blocker_id = p_user_id and b.blocked_id = p_other_id)
       or (b.blocker_id = p_other_id and b.blocked_id = p_user_id)
  );
$$;

-- RLS policy quals run as the calling role, so the helpers they call
-- must be executable by the roles that read the posts table. Grants
-- are authenticated-only on purpose (least privilege): anon callers
-- get no rows anyway because is_approved() is false without a
-- session, and granting the helpers to anon would let anyone probe
-- boolean facts (is X private, does A follow B, is A blocked with B)
-- without logging in. If an anon query reaches the policy it returns
-- no rows (or errors) — staging must confirm which.
grant execute on function public.post_author_is_private(uuid)
  to authenticated;
grant execute on function public.is_following(uuid, uuid)
  to authenticated;
grant execute on function public.is_blocked_between(uuid, uuid)
  to authenticated;
-- NOTE: the GRANTs above do NOT remove the EXECUTE that default
-- privileges grant to anon automatically at creation time, so anon
-- could still probe the helpers directly via PostgREST RPC. Revoke
-- explicitly (authenticated keeps its own explicit grant).
revoke execute on function public.post_author_is_private(uuid) from anon, public;
revoke execute on function public.is_following(uuid, uuid) from anon, public;
revoke execute on function public.is_blocked_between(uuid, uuid) from anon, public;

-- ============ 2) posts SELECT policy (H-02) ============
drop policy if exists "posts visible to approved" on public.posts;
create policy "posts visible to approved" on public.posts for select using (
  public.is_approved()
  and (
    auth.uid() = user_id
    or public.is_admin()
    or (
      not public.is_blocked_between(auth.uid(), user_id)
      and (
        not public.post_author_is_private(user_id)
        or public.is_following(auth.uid(), user_id)
      )
    )
  )
);

-- ============ verification (run after the above) ============
-- -- 1) the policy exists and is the only SELECT policy on posts:
-- select policyname, cmd, qual from pg_policies
--  where schemaname = 'public' and tablename = 'posts' and cmd = 'SELECT';
-- -- Expected: one row, policyname "posts visible to approved", qual
-- -- containing is_approved(), is_admin(), post_author_is_private,
-- -- is_following and is_blocked_between — and NOT a bare
-- -- "public.is_approved()" alone.
-- -- 2) the helpers exist and are SECURITY DEFINER with pinned path:
-- select proname, prosecdef,
--        pg_get_functiondef(oid) like '%search_path = pg_catalog, public%' as path_pinned
--   from pg_proc where pronamespace = 'public'::regnamespace
--   and proname in ('post_author_is_private', 'is_following',
--                   'is_blocked_between');
-- -- Expected: 3 rows, prosecdef = true, path_pinned = true.
-- -- 3) role-based behaviour (run as each role on a STAGING project —
-- --    never on production without a staging pass first):
-- --    * anonymous (no JWT):  select from posts returns 0 rows.
-- --    * approved non-follower reading a private author's post:
-- --      0 rows; same reader reading a public author's post: row visible.
-- --    * approved follower of a private author: the author's posts visible.
-- --    * private-account owner: own posts visible.
-- --    * blocked user (either direction): the other party's posts hidden.
-- --    * admin: all posts visible (including private authors' posts).
