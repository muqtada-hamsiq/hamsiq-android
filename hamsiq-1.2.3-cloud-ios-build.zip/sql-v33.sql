-- ============================================================
-- sql-v33.sql — Hamsiq audit fix H-03 (critical: Close Friends
-- stories readable by anyone via the API)
-- Run in the Supabase SQL Editor AFTER sql-v32.sql. Idempotent: safe to
-- run twice. Run this BEFORE building the next native APK.
--
-- Problem (verified from the combined schema v4..v31, sql-v5 section,
-- lines ~2173-2176, and the sql-v30 "Honest limits" note at lines
-- ~3001-3005, which the code itself admits):
--   create policy "stories visible to approved" on public.stories
--   for select using ( public.is_approved() );
--   "Close Friends visibility is enforced client-side in the app;
--    the stories table's existing select policy (is_approved()) still
--    allows an API-level read. Tightening that policy is a separate
--    server change, not done here."
-- Any approved account could fetch any Close Friends story
-- (stories.is_close_friends = true, added in sql-v30) through the
-- API, even without being on the owner's close_friends list. The
-- native story bar only filtered client-side
-- (StoriesApi.filterCloseFriendsStories), and the web app never
-- filtered Close Friends stories at all (no is_close_friends usage
-- anywhere in ~/workspace/chat-app/index.html).
--
-- Fix: DROP and recreate the stories SELECT policy so a story is
-- visible only when ALL of these hold:
--   1) the caller is an approved account (public.is_approved()), AND
--   2) one of:
--        a) the caller IS the story's owner (auth.uid() = user_id), or
--        b) the caller is the app admin (public.is_admin()), or
--        c) the caller is NOT blocked in either direction with the
--           owner AND (the story is NOT a Close Friends story
--           (is_close_friends = false) OR the caller IS on the
--           owner's close_friends list).
-- A public story is therefore visible to every approved user (as
-- before); a Close Friends story is visible only to its owner, to
-- admins, and to the users on that owner's list.
--
-- Tables/columns used (all copied exactly from the combined schema
-- v4..v31 — nothing guessed):
--   public.stories(user_id, is_close_friends)  (sql-v5 + sql-v30)
--   public.close_friends(user_id, friend_id)   (sql-v30; PK is the pair;
--     its SELECT policy already lets the owner or the named friend read
--     a row, so the list is checkable server-side)
--   public.blocks(blocker_id, blocked_id)      (sql-v5; shared helper
--     from sql-v32.sql — see below)
--
-- RLS HARD RULES (learned 2026-11-14, 42P17): no policy whose qual or
-- with_check queries its OWN table. This policy never queries
-- public.stories: the Close Friends membership check lives in the
-- SECURITY DEFINER helper below (same pattern as
-- public.is_approved() / public.is_admin()), and the block check
-- reuses public.is_blocked_between() from sql-v32.sql. The helpers
-- query DIFFERENT tables only (close_friends, blocks), so there is
-- no recursion.
--
-- The helpers pin SET search_path = pg_catalog, public (the H-05
-- convention from sql-v34.sql).
--
-- Deliberately UNCHANGED by this migration (out of scope for H-03):
--   * story_hidden_from ("hide my stories FROM this user", sql-v26)
--     stays client-side filtered (web loadFeed / native
--     fetchActiveStories). It is the same class of gap and should be
--     folded into this policy in a follow-up; it was not in the H-03
--     brief and is flagged here rather than silently widened.
--   * posts.is_hidden is not touched (see sql-v32.sql).
--   * The stories INSERT ("approved users post stories") and DELETE
--     ("owners or admin delete stories") policies are untouched.
--   * Highlights (highlight_stories SELECT is is_approved()) are
--     untouched: a highlight that contains a Close Friends story now
--     simply returns fewer rows to a non-member, because the stories
--     rows themselves are filtered by this policy.
--
-- Web-app impact (every web stories query was checked line by line in
-- ~/workspace/chat-app/index.html; verdicts are listed in the fix
-- report): the web app has no Close Friends UI and never reads
-- is_close_friends, so nothing in it breaks: loadFeed's stories query
-- (line 7977) and the highlight viewer (line 5701) just return fewer
-- rows for non-members, and openStoryViewer (line 8604) already
-- handles a missing row with its existing generic-error toast (that
-- path is unreachable in practice, because a hidden story never
-- renders a ring to tap).
-- ============================================================

-- ============ 1) SECURITY DEFINER helpers ============
-- is_on_close_friends_list: is p_friend_id on p_owner_id's list?
-- One row in public.close_friends (user_id = owner, friend_id).
create or replace function public.is_on_close_friends_list(
  p_owner_id uuid,
  p_friend_id uuid
)
returns boolean
language sql
security definer
stable
set search_path = pg_catalog, public
as $$
  select exists (
    select 1 from public.close_friends cf
    where cf.user_id = p_owner_id
      and cf.friend_id = p_friend_id
  );
$$;

-- is_blocked_between: re-asserted here (CREATE OR REPLACE, identical
-- body to sql-v32.sql) so this file is safe to run on its own if v32
-- was ever skipped. Either direction counts — see sql-v32.sql.
create or replace function public.is_blocked_between(
  p_user_id uuid,
  p_other_id uuid
)
returns boolean
language sql
security definer
stable
set search_path = pg_catalog, public
as $$
  select exists (
    select 1 from public.blocks b
    where (b.blocker_id = p_user_id and b.blocked_id = p_other_id)
       or (b.blocker_id = p_other_id and b.blocked_id = p_user_id)
  );
$$;

-- Same grant rule as sql-v32.sql: authenticated-only (least
-- privilege). Anon callers get no rows because is_approved() is
-- false without a session, and granting is_on_close_friends_list
-- to anon would let anyone probe Close Friends membership.
grant execute on function public.is_on_close_friends_list(uuid, uuid)
  to authenticated;
grant execute on function public.is_blocked_between(uuid, uuid)
  to authenticated;
-- NOTE: default privileges grant EXECUTE to anon at creation time, so
-- revoke explicitly (see sql-v32.sql); authenticated keeps its grant.
revoke execute on function public.is_on_close_friends_list(uuid, uuid) from anon, public;
revoke execute on function public.is_blocked_between(uuid, uuid) from anon, public;

-- ============ 2) stories SELECT policy (H-03) ============
drop policy if exists "stories visible to approved" on public.stories;
create policy "stories visible to approved" on public.stories for select using (
  public.is_approved()
  and (
    auth.uid() = user_id
    or public.is_admin()
    or (
      not public.is_blocked_between(auth.uid(), user_id)
      and (
        not is_close_friends
        or public.is_on_close_friends_list(user_id, auth.uid())
      )
    )
  )
);

-- ============ verification (run after the above) ============
-- -- 1) the policy exists and is the only SELECT policy on stories:
-- select policyname, cmd, qual from pg_policies
--  where schemaname = 'public' and tablename = 'stories' and cmd = 'SELECT';
-- -- Expected: one row, policyname "stories visible to approved", qual
-- -- containing is_approved(), is_admin(), is_close_friends,
-- -- is_on_close_friends_list and is_blocked_between — and NOT a bare
-- -- "public.is_approved()" alone.
-- -- 2) the helpers exist and are SECURITY DEFINER with pinned path:
-- select proname, prosecdef,
--        pg_get_functiondef(oid) like '%search_path = pg_catalog, public%' as path_pinned
--   from pg_proc where pronamespace = 'public'::regnamespace
--   and proname in ('is_on_close_friends_list', 'is_blocked_between');
-- -- Expected: 2 rows, prosecdef = true, path_pinned = true.
-- -- 3) role-based behaviour (run as each role on a STAGING project —
-- --    never on production without a staging pass first):
-- --    * anonymous (no JWT):  select from stories returns 0 rows.
-- --    * approved user, public story (is_close_friends = false):
-- --      visible. Close Friends story of someone whose list the
-- --      reader is NOT on: 0 rows.
-- --    * approved user ON the owner's close_friends list: the Close
-- --      Friends story is visible.
-- --    * story owner: own Close Friends stories visible.
-- --    * blocked user (either direction): the other party's stories
-- --      hidden (public and Close Friends alike).
-- --    * admin: all stories visible (including Close Friends stories).
-- --    * highlight containing a Close Friends story, opened by a
-- --      non-member: that story is missing from the highlight view;
-- --      opened by a list member: present.
