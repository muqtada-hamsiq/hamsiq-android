-- sql-v38.sql — H-04 old-media migration support + set_first_admin hardening.
--
-- Part 1 — H-04 migration log table. The migration itself runs as a
-- script (staging-h04-migrate.py, service_role), NOT as SQL: moving
-- objects between buckets must go through the Storage API, and
-- re-pointing rows needs a fresh signed URL per object. This table
-- only records what the script did, so a migration can be audited
-- and rolled back (restore media_url from old_url) before the old
-- public objects are deleted. One row per migrated table row;
-- (source_table, row_id) is unique so a re-run cannot double-log.
--
-- Part 2 — set_first_admin() search_path. The coordinator applied
-- this exact statement on PRODUCTION on 2026-11-16 via the
-- Management API (HTTP 201): public.set_first_admin() is a SECURITY
-- DEFINER trigger function from the lost v1–v3 (promotes the first
-- profile to admin) and had NO search_path — v34 missed it. After
-- the fix, zero SECURITY DEFINER functions without search_path were
-- re-verified on prod. This statement is recorded here so the file
-- history matches what is live on prod; re-running it on staging /
-- prod is a harmless no-op.

-- ---- Part 1: migration log table ------------------------------------

create table if not exists public.h04_media_migration_log (
  id bigint generated always as identity primary key,
  source_table text not null,
  row_id bigint not null,
  old_url text not null,
  new_url text not null,
  old_bucket text not null default 'chat-media',
  new_bucket text not null default 'private-media',
  storage_path text not null,
  migrated_at timestamptz not null default now()
);

create unique index if not exists h04_media_migration_log_row_uniq
  on public.h04_media_migration_log (source_table, row_id);

alter table public.h04_media_migration_log enable row level security;
-- No policies by design: RLS enabled with zero policies denies
-- authenticated / anon access entirely. Only service_role (which
-- bypasses RLS) and postgres can read/write it — the migration
-- script runs as service_role.

-- ---- Part 2: set_first_admin() search_path --------------------------
-- Applied on prod 2026-11-16 by the coordinator (Management API,
-- HTTP 201). Keep this line verbatim; it is the production state.

alter function public.set_first_admin() set search_path = pg_catalog, public;
